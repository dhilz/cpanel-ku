<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/client_functions.php";
// authenicate sid
if (auth_sid($sid)==1) { header("Location: ".$http_web."/clogin.php"); exit; }

$oid=base64_decode($c);

# START http://www.thewhir.com/marketwatch/112105_Secunia_Finds_WHM_AutoPilot_Flaw.cfm 11/22/2005
# -------------------------------------------------------------------------------------------------

settype($c, 'integer');
$query="select ";
$query.="count(*) ";
$query.="from ";
$query.="hosting_order ";
$query.="where ";
$query.="oid='".addslashes(trim($oid))."'";

$rs=mysql_fetch_row(mysql_query($query));

if ($rs[0]<=0) { die("Invalid Access Attempt!"); }

# -------------------------------------------------------------------------------------------------
# END http://www.thewhir.com/marketwatch/112105_Secunia_Finds_WHM_AutoPilot_Flaw.cfm 11/22/2005

if (isset($submit))
	{
	if (strlen(trim($reason_for_cancel))==0) { $err=true; }
	else
		{		
		# update order
		mysql_query("update hosting_order set status='4', reason_for_cancel='".addslashes(trim($reason_for_cancel))."', cancel_date='".time()."' where oid='".addslashes(trim($oid))."'");
		
		
		// send email notify for the admin
		request_cancel($oid, $email_admin, $reason_for_cancel);

		// send email notify confirm to the client
		request_cancel_confirm($oid, $email_admin, $reason_for_cancel);

		$done=true;
		}
	}

include "inc/header.php";

echo("
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td><img src='".$http_images."/menu_arrow_back.gif'><a href='".$http_web."/client_area.php?sid=".trim($sid)."'>".$text_goback."</a></td>
	</tr>
	<tr>
		<td><hr color='#F0EFED'></td>
	</tr>
</table>
	");

// build query
$query="select ";
$query.="user.uid, ";												// 0
$query.="user.email, ";												// 1
$query.="hosting_order.oid, ";										// 2
$query.="hosting_order.domain_name ";								// 3
$query.="from user, hosting_order ";
$query.="where hosting_order.oid='".addslashes(trim($oid))."' ";
$query.="and hosting_order.uid=user.uid ";								
$query.="order by hosting_order.oid asc ";
$query.="limit 0, 1";

// execute query
$rs=mysql_fetch_row(mysql_query($query));

// assign variables
$uid=$rs[0];
$email=$rs[1];
$domain_name=$rs[3];

echo("
<form action='".$PHP_SELF."' method='POST'>
<input type='hidden' name='sid' value='".trim($sid)."'>
<input type='hidden' name='c' value='".$c."'>
	<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
		<tr>
			<td><img src='".$http_images."/menu_arrow.gif'><b>".$text_cancelhostingfor.": http://".$domain_name."</b></td>
		</tr>
		<tr>
			<td><img src='".$http_images."/the_space.gif' width='1' height='8'></td>
		</tr>
	");
if (isset($done))
	{
	echo("
			<tr>
				<td><img src='".$http_images."/error_arrow.gif'>".$text_requestbeingprocessed."</td>
			</tr>
		</table>
		</form>
		");
	include "inc/footer.php";
	die();
	}
else if (isset($err))
	{
	echo("
		<tr>
			<td><img src='".$http_images."/the_space.gif' width='15' height='9'><img src='".$http_images."/error_arrow.gif'>".$text_pleasecomplete."</td>
		</tr>
		<tr>
			<td><img src='".$http_images."/the_space.gif' width='1' height='8'></td>
		</tr>
		");
	}
echo("
		<tr>
			<td><img src='".$http_images."/the_space.gif' width='15' height='9'>".$text_pleaseexplain.": [<font color='#990000'>".$text_required."</font>]</td>
		</tr>
		<tr>
			<td><img src='".$http_images."/the_space.gif' width='15' height='9'><textarea name='reason_for_cancel' rows='10' cols='70' ".$orderinput_style."></textarea></td>
		</tr>
		<tr>
			<td><img src='".$http_images."/the_space.gif' width='1' height='8'></td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='15' height='9'><input ".$orderbutton_style." type='submit' name='submit' value='".$text_submitcancel."'></td>
		</tr>
	</table>
	</form>
	");
include "inc/footer.php";
?>