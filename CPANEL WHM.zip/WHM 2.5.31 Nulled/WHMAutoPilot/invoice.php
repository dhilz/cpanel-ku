<?PHP
include "../inc/var.php";
include "../inc/connect.php";
include "inc/client_functions.php";
include "inc/login_functions.php";
include "inc/invoice_functions.php";

if (phpversion()<="4.0.6") { $_POST=$HTTP_POST_VARS; }
if (isset($_POST['submit']))
	{
	$query="update ";
	$query.="invoice_config ";
	$query.="set ";
	$query.="logo_path='".addslashes(trim($logo_path))."', ";
	$query.="company_contact='".addslashes(trim($company_contact))."', ";
	$query.="payable_to='".addslashes(trim($payable_to))."', ";
	$query.="invoice_number='".addslashes(trim($invoice_number))."'";

	mysql_query($query);
	}

include $server_admin_inc."/header.php";

echo("
	<table width='725' cellpadding='0' cellspacing='0' border='0'>
		<tr>
			<td width='1%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='375'></td>
			<td width='99%' align='left' valign='top'>

			<table width='725' cellpadding='2' cellspacing='0' border='0'>
				<tr>
					<td align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><b>Invoice Management Center</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[<a href='".$http_admin."/index2.php?sid=".$sid."'><font color='#990000'>Back</font></a>]</td>
				</tr>
				<tr>
					<td align='left' valign='top'><hr color='#F0EFED'></td>
				</tr>
			</table>
	");

echo("
	<table width='100%' cellpadding='0' cellspacing='0' border='0'>
		<tr>
			<td width='49%' align='left' valign='top'>
	");

# start summary
echo("
			<table width='100%' cellpadding='4' cellspacing='0' border='1' bordercolor='#ECEEF0'>
				<tr>
					<td align='left' valign='top' bgcolor='#F2F4F6'><img src='".$http_images."/error_arrow.gif'><b>Web Hosting Invoice Summary</b></td>
				</tr>
	");

$query0="select ";
$query0.="count(*) ";
$query0.="from ";
$query0.="invoice ";
$query0.="where ";
$query0.="status='0' ";
$query0.="and ";
$query0.="invoice_type='0'";

$rs0=mysql_fetch_row(mysql_query($query0));

$query1="select ";
$query1.="total_due_today, ";
$query1.="total_due_reoccur ";
$query1.="from ";
$query1.="invoice ";
$query1.="where ";
$query1.="status='0' ";
$query1.="and ";
$query1.="invoice_type='0'";

$row1=mysql_query($query1);

$total_pending=0;
while ($rs1=mysql_fetch_row($row1)) 
	{
	if ($rs1[0]==0) { $total_pending+=$rs1[1]; }
	else { $total_pending+=$rs1[0]; } 
	}

echo("
				<tr>
					<td align='left' valign='top'>
					<table width='100%' cellpadding='0' cellspacing='0' border='0'>
						<tr>
							<td width='1%' align='left' valign='middle'>&nbsp;<a href='".$http_admin."/invoice_hosting_unpaid.php?sid=".$sid."'><img src='".$http_images."/icon_view.gif' border='0'></a>&nbsp;&nbsp;&nbsp;<td>
							<td width='99%' align='left' valign='middle'>You have ( ".$rs0[0]." ) unpaid invoices totaling: ".$currency."".sprintf("%01.2f", $total_pending)."&nbsp".$currency_type."<td>
						</tr>
					</table>
					</td>
				</tr>
	");

$query2="select ";
$query2.="count(*) ";
$query2.="from ";
$query2.="invoice ";
$query2.="where ";
$query2.="status='2' ";
$query2.="and ";
$query2.="invoice_type='0'";

$rs2=mysql_fetch_row(mysql_query($query2));

$query3="select ";
$query3.="total_due_today, ";
$query3.="total_due_reoccur ";
$query3.="from ";
$query3.="invoice ";
$query3.="where ";
$query3.="status='2' ";
$query3.="and ";
$query3.="invoice_type='0'";

$row3=mysql_query($query3);

$total_past_due=0;
while ($rs3=mysql_fetch_row($row3)) 
	{
	if ($rs3[0]==0) { $total_past_due+=$rs3[1]; }
	else { $total_past_due+=$rs3[0]; } 
	}

echo("
				<tr>
					<td align='left' valign='top'>
					<table width='100%' cellpadding='0' cellspacing='0' border='0'>
						<tr>
							<td width='1%' align='left' valign='middle'>&nbsp;<a href='".$http_admin."/invoice_hosting_past_due.php?sid=".$sid."'><img src='".$http_images."/icon_view.gif' border='0'></a>&nbsp;&nbsp;&nbsp;<td>
							<td width='99%' align='left' valign='middle'>You have ( ".$rs2[0]." ) past due invoices totaling: ".$currency."".sprintf("%01.2f", $total_past_due)."&nbsp".$currency_type."<td>
						</tr>
					</table>
					</td>
				</tr>
	");

$query4="select ";
$query4.="count(*) ";
$query4.="from ";
$query4.="invoice ";
$query4.="where ";
$query4.="status='1' ";
$query4.="and ";
$query4.="invoice_type='0'";

$rs4=mysql_fetch_row(mysql_query($query4));

$query5="select ";
$query5.="total_due_today, ";
$query5.="total_due_reoccur ";
$query5.="from ";
$query5.="invoice ";
$query5.="where ";
$query5.="status='1' ";
$query5.="and ";
$query5.="invoice_type='0'";

$row5=mysql_query($query5);

$total_paid=0;
while ($rs5=mysql_fetch_row($row5)) 
	{ 
	if ($rs5[0]==0) { $total_paid+=$rs5[1]; }
	else { $total_paid+=$rs5[0]; }
	}

echo("
				<tr>
					<td align='left' valign='top'>
					<table width='100%' cellpadding='0' cellspacing='0' border='0'>
						<tr>
							<td width='1%' align='left' valign='middle'>&nbsp;<a href='".$http_admin."/invoice_hosting_paid.php?sid=".$sid."'><img src='".$http_images."/icon_view.gif' border='0'></a>&nbsp;&nbsp;&nbsp;<td>
							<td width='99%' align='left' valign='middle'>You have ( ".$rs4[0]." ) paid invoices totaling: ".$currency."".sprintf("%01.2f", $total_paid)."&nbsp".$currency_type."<td>
						</tr>
					</table>
					</td>
				</tr>
			</table>
	");
# end summary

echo("			
			</td>
			<td width='1%' align='left' valign='top'><img src='".$http_images."/space.gif' width='16' height='1'></td>
			<td width='49%' align='left' valign='top'>
	");

# start summary
echo("
			<table width='100%' cellpadding='4' cellspacing='0' border='1' bordercolor='#ECEEF0'>
				<tr>
					<td align='left' valign='top' bgcolor='#F2F4F6'><img src='".$http_images."/error_arrow.gif'><b>Billable Services Invoice Summary</b></td>
				</tr>
	");

$query0="select ";
$query0.="count(*) ";
$query0.="from ";
$query0.="invoice ";
$query0.="where ";
$query0.="status='0' ";
$query0.="and ";
$query0.="invoice_type='1'";

$rs0=mysql_fetch_row(mysql_query($query0));

$query1="select ";
$query1.="total_due_today, ";
$query1.="charge_tax ";
$query1.="from ";
$query1.="invoice ";
$query1.="where ";
$query1.="status='0' ";
$query1.="and ";
$query1.="invoice_type='1'";

$row1=mysql_query($query1);

$total_pending=0;
while ($rs1=mysql_fetch_row($row1)) 
	{ 
	$total_pending+=($rs1[0]+($rs1[0]*$rs1[1])); 
	}

echo("
				<tr>
					<td align='left' valign='top'>
					<table width='100%' cellpadding='0' cellspacing='0' border='0'>
						<tr>
							<td width='1%' align='left' valign='middle'>&nbsp;<a href='".$http_admin."/invoice_pending.php?sid=".$sid."'><img src='".$http_images."/icon_view.gif' border='0'></a>&nbsp;&nbsp;&nbsp;<td>
							<td width='99%' align='left' valign='middle'>You have ( ".$rs0[0]." ) unpaid invoices totaling: ".$currency."".sprintf("%01.2f", $total_pending)."&nbsp".$currency_type."<td>
						</tr>
					</table>
					</td>
				</tr>
	");

$query2="select ";
$query2.="count(*) ";
$query2.="from ";
$query2.="invoice ";
$query2.="where ";
$query2.="status='2' ";
$query2.="and ";
$query2.="invoice_type='1'";

$rs2=mysql_fetch_row(mysql_query($query2));

$query3="select ";
$query3.="total_due_today, ";
$query3.="charge_tax ";
$query3.="from ";
$query3.="invoice ";
$query3.="where ";
$query3.="status='2' ";
$query3.="and ";
$query3.="invoice_type='1'";

$row3=mysql_query($query3);

$total_past_due=0;
while ($rs3=mysql_fetch_row($row3)) { $total_past_due+=($rs3[0]+($rs3[0]*$rs3[1])); }

echo("
				<tr>
					<td align='left' valign='top'>
					<table width='100%' cellpadding='0' cellspacing='0' border='0'>
						<tr>
							<td width='1%' align='left' valign='middle'>&nbsp;<a href='".$http_admin."/invoice_past_due.php?sid=".$sid."'><img src='".$http_images."/icon_view.gif' border='0'></a>&nbsp;&nbsp;&nbsp;<td>
							<td width='99%' align='left' valign='middle'>You have ( ".$rs2[0]." ) past due invoices totaling: ".$currency."".sprintf("%01.2f", $total_past_due)."&nbsp".$currency_type."<td>
						</tr>
					</table>
					</td>
				</tr>
	");

$query4="select ";
$query4.="count(*) ";
$query4.="from ";
$query4.="invoice ";
$query4.="where ";
$query4.="status='1' ";
$query4.="and ";
$query4.="invoice_type='1'";

$rs4=mysql_fetch_row(mysql_query($query4));

$query5="select ";
$query5.="total_due_today, ";
$query5.="charge_tax ";
$query5.="from ";
$query5.="invoice ";
$query5.="where ";
$query5.="status='1' ";
$query5.="and ";
$query5.="invoice_type='1'";

$row5=mysql_query($query5);

$total_paid=0;
while ($rs5=mysql_fetch_row($row5)) { $total_paid+=($rs5[0]+($rs5[0]*$rs5[1])); }

echo("
				<tr>
					<td align='left' valign='top'>
					<table width='100%' cellpadding='0' cellspacing='0' border='0'>
						<tr>
							<td width='1%' align='left' valign='middle'>&nbsp;<a href='".$http_admin."/invoice_paid.php?sid=".$sid."'><img src='".$http_images."/icon_view.gif' border='0'></a>&nbsp;&nbsp;&nbsp;<td>
							<td width='99%' align='left' valign='middle'>You have ( ".$rs4[0]." ) paid invoices totaling: ".$currency."".sprintf("%01.2f", $total_paid)."&nbsp".$currency_type."<td>
						</tr>
					</table>
					</td>
				</tr>
			</table>
	");
# end summary

echo("			
			</td>
		</tr>
		<tr>
			<td width='49%' align='left' valign='top'><br>
			
			</td>
			<td width='2%' align='left' valign='top'><img src='".$http_images."/space.gif' width='16' height='16'></td>
			<td width='49%' align='left' valign='bottom'><br>
			<table width='100%' cellpadding='4' cellspacing='0' border='1' bordercolor='#ECEEF0'>
				<tr>
					<td align='center' valign='middle'>&nbsp;<a href='".$http_admin."/invoice_create.php?sid=".$sid."'>Create Invoice</a></td>
					<td align='center' valign='middle'>&nbsp;<a href='".$http_admin."/invoice_add_billable_service.php?sid=".$sid."'>Manage Billable Services</a></td>
				</tr>
				<tr>
					<td align='center' valign='middle'>&nbsp;<a href='".$http_admin."/invoice_add_new_client.php?sid=".$sid."'>Add New Client</a></td>
					<td align='center' valign='middle'>&nbsp;<a href='".$http_admin."/invoice_non_hosting_clients.php?sid=".$sid."'>View Non-Hosting Clients</a></td>
				</tr>
			</table>
			</td>
		</tr>
	</table>
	");

# start configure
echo("
			<table width='725' cellpadding='4' cellspacing='0' border='0'>
				<tr>
					<td align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='14'></td>
				</tr>
			</table>
			<table width='725' cellpadding='4' cellspacing='0' border='1' bordercolor='#ECEEF0'>
				<tr>
					<td align='left' valign='top' bgcolor='#F2F4F6'><img src='".$http_images."/error_arrow.gif'><b>Configure Module</b></td>
				</tr>
				<tr>
					<td align='left' valign='top'>
	");

# port from invoice_configure.php
$query0="select ";
$query0.="logo_path, ";
$query0.="company_contact, ";
$query0.="payable_to, ";
$query0.="invoice_number ";
$query0.="from ";
$query0.="invoice_config ";
$query0.="limit 0, 1";

$rs0=mysql_fetch_row(mysql_query($query0));

$logo_path=stripslashes(trim($rs0[0]));
$company_contact=stripslashes(trim($rs0[1]));
$payable_to=stripslashes(trim($rs0[2]));
$invoice_number=stripslashes(trim($rs0[3]));


echo("
	<form action='".$PHP_SELF."' method='POST'>
	<input type='hidden' name='sid' value='".$sid."'>
	<table width='100%' cellpadding='2' cellspacing='0' border='0'>
		<tr>
			<td width='25%' align='left' valign='top'>&nbsp;<img src='".$http_images."/space.gif' width='1' height='4'></td>
			<td width='75%' align='left' valign='top'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'>&nbsp;Invoices Start at:</td>
			<td width='75%' align='left' valign='top'><input size='4' maxlength='255' ".$input_style." type='text' name='invoice_number' value='".$invoice_number."'>&nbsp;&nbsp;<font color='#990000'>We suggest you set this value once and don't change it to prevent duplicate invoice numbers.</font></td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='top'><img src='".$http_image."/space.gif' width='1' height='12'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'>&nbsp;Default Payee:</td>
			<td width='75%' align='left' valign='top'><input size='50' maxlength='255' ".$input_style." type='text' name='payable_to' value='".$payable_to."'></td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='top'><img src='".$http_image."/space.gif' width='1' height='12'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'>&nbsp;Company Contact Info:</td>
			<td width='75%' align='left' valign='top'><textarea name='company_contact' ".$input_style." rows='4' cols='50'>".$company_contact."</textarea></td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='top'><img src='".$http_image."/space.gif' width='1' height='12'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'>&nbsp;Custom Invoice Logo:</td>
			<td width='75%' align='left' valign='top'><input ".$input_style." type='text' name='logo_path' size='50' maxlength='255' value='".$logo_path."'>&nbsp;&nbsp;<font color='#990000'>ex.&nbsp;http://yoursite.com/yourlogo.gif</font></td>
		</tr>
		");
if (trim($logo_path)!="")
	{
	echo("
		<tr>
			<td colspan='2' align='left' valign='top'><img src='".$http_image."/space.gif' width='1' height='12'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'>&nbsp;Current Logo:</td>
			<td width='75%' align='left' valign='top'><img src='".$logo_path."'></td>
		</tr>
		");
	}
echo("
		<tr>
			<td width='25%' align='left' valign='top'>&nbsp;<img src='".$http_images."/space.gif' width='1' height='8'></td>
			<td width='75%' align='left' valign='top'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'></td>
			<td width='75%' align='left' valign='top'><input ".$button_style." type='submit' name='submit' value='Save Configuration Changes Now'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'>&nbsp;<img src='".$http_images."/space.gif' width='1' height='4'></td>
			<td width='75%' align='left' valign='top'></td>
		</tr>
	</table>
	");
# port from invoice_configure.php

echo("
					</td>
				</tr>
			</table>
	</form>
	");
# end configure


echo("
			</td>
		</tr>
	</table>
	");

include $server_admin_inc."/footer.php";
mysql_close($dblink);
?>