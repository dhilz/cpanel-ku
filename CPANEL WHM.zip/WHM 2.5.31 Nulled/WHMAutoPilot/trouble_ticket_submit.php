<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/client_functions.php";

// authenicate sid
if (auth_sid($sid)==1) { header("Location: ".$http_web."/clogin.php"); exit; }

// form posted
if (isset($submit))
	{
	// form handler
	if (strlen(trim($email))==0) {$err=true; $err0=true;} else {$n0=true;}
	if (strlen(trim($subject))==0) {$err=true; $err1=true;} else {$n1=true;}
	if (strlen(trim($message))==0) {$err=true; $err2=true;} else {$n2=true;}

	// all var's received
	if (isset($n0)&&isset($n1)&&isset($n2))
		{
		// enter the ticket into the db
		// build query
		$query="insert into ticket set ";
		$query.="uid='".addslashes(trim($uid))."', ";
		$query.="email='".addslashes(trim($email))."', ";
		$query.="subject='".addslashes(trim($subject))."', ";
		$query.="message='".addslashes(trim($message))."', ";
		$query.="ogcreate='".time()."'";

		// execute query
		@mysql_query($query);

		// get the auto increment id, call it the $id
		$id=mysql_insert_id();

		tt_client_new_ticket($id);

		// set bit for successful!
		$done=true;
		}
	}

$arr=explode("|", clogin_d(base64_decode($c)));
$uid=$arr[0];
$email=$arr[1];

include "inc/header.php";
echo("
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td><img src='".$http_images."/menu_arrow_back.gif'><a href='".$http_web."/client_area.php?sid=".trim($sid)."&status=".trim($status)."'>".$text_goback."</a></td>
	</tr>
	<tr>
		<td><hr color='#F0EFED'></td>
	</tr>
</table>
	");
if (isset($done))
	{
	echo("
		<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
			<tr>
				<td><img src='".$http_images."/menu_arrow.gif'><b>".$text_submitticket."</b></td>
			</tr>
			<tr>
				<td><img src='".$http_images."/error_arrow.gif'>".$text_ticketreceived."</td>
			</tr>
			<tr>
				<td><img src='".$http_images."/the_space.gif' width='15' height='9'>".$text_willcontact."</td>
			</tr>
			<tr>
				<td><img src='".$http_images."/the_space.gif' width='1' height='1'></td>
			</tr>
			<tr>
				<td>[<a href='".$http_web."/client_area.php?sid=".trim($sid)."'>".$text_continue."</a>]</td>
			</tr>
			<tr>
				<td><hr color='#F0EFED'></td>
			</tr>
			<tr>
				<td><font color='#990000' size='1'>".$text_youwrote.":</font></td>
			</tr>
		</table>
		<table width='100%' cellpadding='2' cellspacing='0' border='0'>
			<tr>
				<td width='25%' align='left' valign='top'>".$text_youremail.":</td>
				<td width='75%' align='left' valign='top'><font color='#990000'>".trim($email)."</font></td>
			</tr>
			<tr>
				<td width='25%' align='left' valign='top'>".$text_issuesubject.":</td>
				<td width='75%' align='left' valign='top'><font color='#990000'>".nl2br(trim(stripslashes($subject)))."</font></td>
			</tr>
			<tr>
				<td colspan='2'>".$text_issuedetails.":</td>
			</tr>
			<tr>
				<td colspan='2'><font color='#990000'>".nl2br(trim(stripslashes($message)))."</font></td>
			</tr>
			<tr>
				<td colspan='2'><img src='".$http_images."/the_space.gif' width='1' height='12'></td>
			</tr>
			<tr>
				<td colspan='2'>".$text_ticketid.": <font color='#990000'>".trim($id)."</font></td>
			</tr>
		</table>
		");
	include"inc/footer.php";
	DIE();
	}

// grab the user and email based on sid
echo("
	<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
		<tr>
			<td><img src='".$http_images."/menu_arrow.gif'><b>".$text_submitticket."</b></td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='15' height='9'>".$text_enterissue.".</td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='1' height='1'></td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='15' height='9'><b>".$text_thankspatience."</b></td>
		</tr>
		<tr>
			<td colspan='2'><hr color='#F0EFED'></td>
		</tr>
	");
if (isset($err))
	{
	echo("
		<tr>
			<td colspan='2'><img src='".$http_images."/error_arrow.gif'>".$text_pleasecomplete."</td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='1' height='8'></td>
		</tr>
		");
	}
echo("
		<form action='".$PHP_SELF."' method='POST'>
		<input type='hidden' name='sid' value='".trim($sid)."'>
		<input type='hidden' name='uid' value='".$uid."'>
		<input type='hidden' name='c' value='".$c."'>
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/".((isset($err0))?"error_arrow.gif":"the_space.gif")."' width='15' height='9'>".$text_youremail.":</td>
			<td width='75%' align='left' valign='top'><input ".$orderinput_style." size='40' type='text' name='email' value='".$email."'> <font color='#990000' size='1'>".$text_required."</font></td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='1' height='8'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/".((isset($err1))?"error_arrow.gif":"the_space.gif")."' width='15' height='9'>".$text_entersubject.":</td>
			<td width='75%' align='left' valign='top'><input ".$orderinput_style." size='40' type='text' name='subject' value='".((isset($subject))?"".trim($subject)."":"")."'> <font color='#990000' size='1'>".$text_required."</font></td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='1' height='8'></td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/".((isset($err2))?"error_arrow.gif":"the_space.gif")."' width='15' height='9'>".$text_enterissue2.": <font color='#990000' size='1'>".$text_required."</font></td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='15' height='9'><textarea ".$orderinput_style." name='message' name='message' rows='15' cols='75'>".((isset($message))?"".trim($message)."":"")."</textarea></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'></td>
			<td width='75%' align='left' valign='bottom'><img src='".$http_images."/the_space.gif' width='15' height='9'><input type='submit' ".$orderbutton_style." name='submit' value='".$text_openticket."'></td>
		</tr>
	</table>
	</form>
	");
include "inc/footer.php";
?>