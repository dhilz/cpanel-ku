<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/client_functions.php";

// authenicate sid
if (auth_sid($sid)==1) { header("Location: ".$http_web."/clogin.php"); exit; }

$SETUP[siteurl] = $http_web;
		if (!strpos($_SERVER['HTTP_REFERER'], $_SERVER['HTTP_HOST'])) 
		{
		header("Location: $SETUP[siteurl]");
		exit();
		}

// form posted
if (isset($submit))
	{
	// form handler
	if (strlen(trim($email))==0) {$err=true; $err0=true;} else {$n0=true;}
	if (strlen(trim($subject))==0) {$err=true; $err1=true;} else {$n1=true;}
	if (strlen(trim($message))==0) {$err=true; $err2=true;} else {$n2=true;}

	// all var's received
	if (isset($n0)&&isset($n1)&&isset($n2))
		{
		// enter the ticket into the db
		@mysql_query("insert into ticket set uid='".addslashes(trim($uid))."', email='".addslashes(trim($email))."', subject='".addslashes(trim($subject))."', message='".addslashes(trim($message))."', ogcreate='".time()."'");

		// ticket id
		$id=mysql_insert_id();

		tt_client_new_ticket($id);

		// successful!
		$done=true;
		}
	}
if (isset($action))
	{
	if (trim($action)==0)
		{
		@mysql_query("update ticket set status='1' where id='".addslashes(trim($id))."'");

		// Support Email
		$support=$email_support;
		$reply=$email;
		
		$subject="Ticket #".$id." Closed";
		$message="This message was generated on: ".date("m/d/Y h:i:s a");
			
		// build email 
		$headers="From: ".$reply."\n";
		$headers.="Reply-To: ".$reply."\n";
		$headers.="X-Mailer: PHP/".phpversion();
		
		// send the email
		@mail($support, stripslashes($subject), stripslashes($message), $headers);
		}
	else
		{
		$more=true;
		}
	}
if (isset($submitn))
	{
	@mysql_query("insert into ticket_reply set id='".addslashes(trim($id))."', reply_status='0', reply='".addslashes(trim($client_reply))."', ogcreate='".time()."'");
	
	@mysql_query("update ticket set switch='0' where id='".addslashes(trim($id))."'");

	tt_client_reply($id);
	}


include "inc/header.php";

echo("
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td><img src='".$http_images."/menu_arrow_back.gif'><a href='".$http_web."/client_area.php?sid=".trim($sid)."&status=".trim($status)."'>".$text_goback."</a></td>
	</tr>
	<tr>
		<td><hr color='#F0EFED'></td>
	</tr>
</table>
	");

$rs0=mysql_fetch_row(mysql_query("select subject, message, status, uid, switch from ticket where id='".addslashes(trim($id))."'"));
$rse=mysql_fetch_row(mysql_query("select email from user where uid='".addslashes(trim($rs0[3]))."'"));
echo("
	<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
		<tr>
			<td><img src='".$http_images."/menu_arrow.gif'><b>".$text_troubleticketsystem."</b></td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='1' height='8'></td>
		</tr>
	");
if (isset($err))
	{
	echo("
		<tr>
			<td colspan='2'><img src='".$http_images."/error_arrow.gif'>".$text_pleasecomplete."</td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='1' height='8'></td>
		</tr>
		");
	}
if (isset($more))
	{
	echo("
	<form action='".$PHP_SELF."' method='POST'>
	<input type='hidden' name='sid' value='".trim($sid)."'>
		<input type='hidden' name='id' value='".trim($id)."'>
	<input type='hidden' name='email' value='".trim($email)."'>
		<tr>
			<td colspan='2'><font color='#000000'>".$text_reply.":</font></td>
		</tr>
		<tr>
			<td colspan='2'><textarea ".$orderinput_style." name='client_reply' rows='8' cols='100'></textarea></td>
		</tr>
		<tr>
			<td colspan='2'><input type='submit' name='submitn' value='".$text_updateticket."'></td>
		</tr>
	</form>
		<tr>
			<td colspan='2'><img src='".$http_images."/space.gif' width='1' height='4'></td>
		</tr>
		</table>
		");
	include"inc/footer.php";
	die();
	}
$ctr=mysql_fetch_row(mysql_query("select count(*) from ticket_reply where id='".addslashes(trim($id))."'"));
echo("
		<form action='".$PHP_SELF."' method='POST'>
		<input type='hidden' name='sid' value='".trim($sid)."'>
		<input type='hidden' name='id' value='".trim($id)."'>
		<input type='hidden' name='email' value='".trim($rse[0])."'>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='15' height='9'>".$text_ticketstatus.": <font color='#990000'><b>".(($rs0[2]==0)?$text_active."</b></font>".(($rs0[4]>=1)?"<img src='".$http_images."/space.gif' width='150' height='1'>".$text_resolved." <a href='".$PHP_SELF."?id=".trim($id)."&sid=".trim($sid)."&action=0&email=".$rse[0]."'><font color='#990000'>".$text_yes."</font></a> | <a href='".$PHP_SELF."?id=".trim($id)."&sid=".trim($sid)."&action=1&email=".$rse[0]."'><font color='#990000'>".$text_no."</font></a>":"")."":$text_closed."</b>, .</font>")."</td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/space.gif' width='1' height='4'></td>
		</tr>
		<!--- start new --->
	");
	$x=1;
	# $row3=mysql_query("select reply, reply_status, UNIX_TIMESTAMP(ogcreate) from ticket_reply where id='".addslashes(trim($id))."' order by rid desc");
	$row3=mysql_query("select reply, reply_status, ogcreate from ticket_reply where id='".addslashes(trim($id))."' order by rid desc");
	while ($rs3=mysql_fetch_row($row3))
		{
		if ($x==1) {$bgcolor="#ECEBF0"; $x=0;} else {$bgcolor="#E2E1E6"; $x=1;}
		echo("
			<tr>
				<td colspan='2'><img src='".$http_images."/the_space.gif' width='15' height='9'><font color='#990000' size='1'>".(($rs3[1]==1)?$text_adminwrote:$text_clientwrote)."</font></td>
			</tr>
			<tr>
				<td colspan='2'><img src='".$http_images."/the_space.gif' width='15' height='9'>".nl2br(stripslashes($rs3[0]))."</td>
			</tr>
			<tr>
				<td colspan='2'><img src='".$http_images."/space.gif' width='1' height='8'></td>
			</tr>
			");
		}
echo("
		<tr>
			<td colspan='2'><img src='".$http_images."/space.gif' width='1' height='4'></td>
		</tr>
		<!--- end new --->
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='15' height='9'><font color='#990000' size='1'>".$text_origticket.":</font> <font color='#000000'>".trim(stripslashes($rs0[0]))."</font></td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='15' height='9'><font color='#000000'>".trim(stripslashes($rs0[1]))."</font></td>
		</tr>
	</table>
	</form>
	");
include "inc/footer.php";
?>