<?php

// --- FRAUDGATE MOD FOR WHMAUTOPILOT 2.4.5 --- //

if(getenv("HTTP_REFERER") != "http://www.fraudgate.com")
    exit(0);


include "inc/var.php";
include "inc/connect.php";

  // all of the information is passed withing post variable FG_RESULT_INFO. The first is the status.
  // to get the result info and also, get the transid you must explode fg_result_info
  $result_info = explode(",", $_POST['FG_RESULT_INFO']);
  $transid = $result_info[6];
  mysql_query("UPDATE hosting_order SET fg_call_info='" . addslashes($_POST['FG_RESULT_INFO']) . "' WHERE oid='$transid';");

  $f1 = mysql_fetch_array(mysql_query("SELECT fg_value FROM autopilot_fraudgate WHERE fg_variable = 's_status'"));
  $f2 = mysql_fetch_array(mysql_query("SELECT fg_value FROM autopilot_fraudgate WHERE fg_variable = 'f_status'"));
   switch($result_info[0])
   {
          case 0: { $status = $f1["fg_value"]; break; }
          case 5: { $status = $f1["fg_value"]; break; }
          case 6: { $status = $f1["fg_value"]; break; }
          default: { $status = $f2["fg_value"]; break; }
   }

  // Do update

  if(substr($transid,0,8) == "SESSION-")
  {
      $transid = str_replace("SESSION-", "", $transid);
      $query = "UPDATE session_history SET locked=0, fg_call_info='" . addslashes($_POST['FG_RESULT_INFO']) . "' WHERE sid='$transid';";
      mysql_query($query) or die(mysql_error());
  }
  else
  {
      mysql_query("UPDATE hosting_order SET fg_call_info='" . addslashes($_POST['FG_RESULT_INFO']) . "' WHERE oid='$transid';");
      $query = "UPDATE hosting_order SET status='$status' WHERE oid='$transid';";
  
      if($status != "0")
          $result_query = mysql_query($query) OR DIE("Unable to complete request");
  }


?>
