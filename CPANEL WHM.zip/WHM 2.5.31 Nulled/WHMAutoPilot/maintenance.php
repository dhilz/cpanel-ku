<?php
include "inc/var.php";
include "inc/connect.php";

if($maintenance=="no") 
	{ 
	header("Location: ".$http_web."/step_one.php"); 
	exit; 
	}
echo("
<HTML>
<HEAD>
<style>
		body, td, center, p {font-family: tahoma; font-size: 11px; color: #000000}
		A:link { 
		text-decoration: underline: none; none; color:#000000;
		}
		A:visited { 
		text-decoration: underline: none; none; color:#000000;
		}
		A:hover { 
		text-decoration: underline; font-weight: none;color:#990000;
		}
		.linkTable
		{
		 PADDING-LEFT: 5px
		}
	</style>
  <TITLE>".$site_title." - System under Maintenacne</TITLE>
</HEAD>
<BODY>
<center>
<P>&nbsp;</P>

<P>&nbsp;</P>

<P><TABLE WIDTH='85%' BORDER='0'
CELLSPACING='0' CELLPADDING='0' style='border-style:solid; border-color:999999; border-width:1pxl'>
  <TR>
    <TD WIDTH='100%' BGCOLOR='#e8e8e8'>
      <P><CENTER><BR>
      <B>Down for Maintenance</B><BR>
<BR>
      Currently, the order system for ".$site_title." is down for maintenance and updates,
      please check back soon.<BR><BR>
      If you need to order your hosting package immediately, please
      feel free to email us at <BR>".$email_admin.".<BR><BR><B>Thank You.</CENTER></P>

      <P><CENTER>&nbsp;</CENTER>
    </TD>
  </TR>
</TABLE>

</BODY>
</HTML>
");

?>