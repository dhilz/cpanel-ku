<?PHP
include"inc/var.php";
include "inc/connect.php";
include "inc/client_functions.php";

@admin_logout($sid);

header("Location: ".$http_web."/client_area.php".$c); 
exit;
?>