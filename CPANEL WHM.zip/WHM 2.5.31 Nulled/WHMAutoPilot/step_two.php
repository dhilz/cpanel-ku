<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/client_functions.php";
include "inc/whm_functions.php";
include $server_tools."/step_two_code[0].php";
include "inc/header.php";
echo("
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td><a href='".$http_web."/step_one.php?sid=".trim($sid)."&gid=".trim($gid)."'><font size='1'>".$navigate_selectpackage."</font></a><img src='".$http_images."/order_arrow.gif'><a href='".$http_web."/step_two.php?sid=".trim($sid)."&gid=".trim($gid)."'><font size='1' color='#990000'><b>".$navigate_domainoptions."</b></font></a>".(($pcheck==0)?"<img src='".$http_images."/order_arrow.gif'><font size='1'>".$navigate_addonoptions."</font>":"")."<img src='".$http_images."/order_arrow.gif'><font size='1'>".$navigate_accountinfo."</font></td>
	</tr>
</table>
	");

if ($dedicated==1) { include $server_tools."/step_two_code[1].php"; }
else if ($ds==0) { include $server_tools."/step_two_code[2].php"; }
else if ($ds==1) { include $server_tools."/step_two_code[3].php"; }

echo("
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'></td>
	</tr>
	<tr>
		<td width='10%' align='left' valign='top'></td>
		<td width='90%' align='left' valign='top'><input ".$orderbutton_style." type='submit' name='submit' value='".$steptwo_submitbutton."'></td>
	</tr>
</table>
</form>
	");
include "inc/footer.php";
mysql_close($dblink);
?>