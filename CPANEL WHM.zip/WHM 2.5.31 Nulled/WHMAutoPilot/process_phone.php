<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/client_functions.php";
include "inc/varilogix_functions.php";

$cksid=mysql_fetch_row(mysql_query("select count(*) from session_history where sid='".addslashes(trim($sid))."'"));

if ($cksid[0]<=0) {	header("Location: ".$http_web."/step_one.php");	exit; }
else if (!isset($sid)) { header("Location: ".$http_web."/step_one.php"); exit; }

$query="select ";
$query.="session_history.phone, ";				// 0
$query.="session_history.first_name, ";			// 1
$query.="session_history.email, ";				// 2
$query.="session_history.city, ";				// 3
$query.="session_history.state, ";				// 4
$query.="session_history.zip_code, ";			// 5
$query.="session_history.domain_name, ";		// 6
$query.="session_history.country, ";			// 7
$query.="session_history.payment_method, ";		// 8
$query.="session_history.pid, ";				// 9
$query.="session_history.domain_registration, ";// 10
$query.="session_history.addon_choices, ";		// 11
$query.="session_history.payment_term, ";		// 12
$query.="session_history.total_due_today, ";	// 13
$query.="session_history.total_due_reoccur, ";	// 14
$query.="session_history.bin_number, ";			// 15
$query.="payment_process.name, ";				// 16
$query.="plan_specs.package_name ";				// 17
$query.="from ";
$query.="session_history, plan_specs, payment_process ";
$query.="where ";
$query.="session_history.pid=plan_specs.pid ";
$query.="and ";
$query.="session_history.payment_method=payment_process.pid ";
$query.="and ";
$query.="session_history.sid='".addslashes(trim($sid))."' ";
$query.="limit 0, 1";

$rs=mysql_fetch_row(mysql_query($query));

$phone=stripslashes(trim($rs[0]));
$first_name=stripslashes(trim($rs[1]));
$email=stripslashes(trim($rs[2]));
$a=explode("@", $email);
$email=$a[1];
$city=stripslashes(trim($rs[3]));
$state=stripslashes(trim($rs[4]));
$zip_code=stripslashes(trim($rs[5]));
$domain_name=stripslashes(trim($rs[6]));
$country=strtoupper(stripslashes(trim($rs[7])));
$payment_method=stripslashes(trim($rs[8]));
$pid=stripslashes(trim($rs[9]));
$domain_registration=stripslashes(trim($rs[10]));
$addon_choices=stripslashes(trim($rs[11]));
$payment_term=strtolower(stripslashes(trim($rs[12])));
$total_due_today=$rs[13];
$total_reoccur=$rs[14];
$bin_number=$rs[15];
$payment_type_name=stripslashes(trim($rs[16]));
$package_name=stripslashes(trim($rs[17]));

# ---------------------------------------------------

$query0="select ";
$query0.="package_name, ";		// 0
$query0.="monthly_cost, ";		// 1
$query0.="quarterly_cost, ";	// 2
$query0.="semi_annual_cost, ";	// 3
$query0.="annual_cost, ";		// 4
$query0.="setup_cost, ";		// 5
$query0.="web_space, ";			// 6
$query0.="bandwidth, ";			// 7
$query0.="email, ";				// 8
$query0.="addon_gid, ";			// 9
$query0.="free_trial, ";		// 10
$query0.="free_trial_length ";	// 11
$query0.="from plan_specs ";
$query0.="where pid='".addslashes(trim($pid))."'";

$rs0=mysql_fetch_row(mysql_query($query0));

$package_name=stripslashes(trim($rs0[0]));
$monthly_cost=stripslashes(trim($rs0[1]));
$quarterly_cost=stripslashes(trim($rs0[2]));
$semi_annual_cost=stripslashes(trim($rs0[3]));
$annual_cost=stripslashes(trim($rs0[4]));
$setup_cost=stripslashes(trim($rs0[5]));
$web_space=stripslashes(trim($rs0[6]));
$bandwidth=stripslashes(trim($rs0[7]));
$email_wp=stripslashes(trim($rs0[8]));
$addon_gid=stripslashes(trim($rs0[9]));
$free_trial=stripslashes(trim($rs0[10]));
$free_trial_length=stripslashes(trim($rs0[11]));

# ---------------------------------------------------

if (strcmp("monthly", $payment_term)==0) { $term=1; }
else if (strcmp("quarterly", $payment_term)==0) { $term=3; }
else if (strcmp("semi_annual", $payment_term)==0) { $term=6; }
else if (strcmp("annual", $payment_term)==0) { $term=12; }

# ---------------------------------------------------

$query="select ";
$query.="fraudcall_value ";	
$query.="from ";
$query.="autopilot_fraudcall ";
$query.="where ";
$query.="fraudcall_key='pvs_id' ";
$query.="limit 0, 1";

$rs=mysql_fetch_row(mysql_query($query));

$pvs_id=varilogix_d(base64_decode($rs[0]));

# ---------------------------------------------------

$query="select ";
$query.="fraudcall_value ";	
$query.="from ";
$query.="autopilot_fraudcall ";
$query.="where ";
$query.="fraudcall_key='pvs_password' ";
$query.="limit 0, 1";

$rs=mysql_fetch_row(mysql_query($query));

$pvs_password=varilogix_d(base64_decode($rs[0]));

# ---------------------------------------------------
/*
if (!isset($retry)) { $post_to="https://api.varilogix.com/api/whmautopilot.cgi"; }
else { $post_to="https://api2.varilogix.com/api/whmautopilot.cgi"; }
*/
if (!isset($retry)) { $post_to="https://api.varilogix.com/api/whmautopilot.php"; }
else { $post_to="https://api2.varilogix.com/api/whmautopilot.php"; }

$query_string="pvs_id=".$pvs_id;
$query_string.="&pvs_password=".$pvs_password;
$query_string.="&id=".generate_id();
$query_string.="&phonenumber=".clean_number($phone);
$query_string.="&name=".$first_name;
$query_string.="&service=".urlencode($package_name." for ".$domain_name);
$query_string.="&amount=".sprintf("%01.2f", $total_due_today);
$query_string.="&country=".$country;
$query_string.="&emaildomain=".$email;
$query_string.="&ipaddress=".$_SERVER['REMOTE_ADDR'];
$query_string.="&city=".$city;
$query_string.="&state=".$state;
$query_string.="&zipcode=".$zip_code;
$query_string.="&whoisdomain=".$domain_name;

if  (strcmp($bin_number, "0")!=0)
	{
	# authnet only, first 6 digits of cc number
	$query_string.="&bin=".$bin_number;
	}

$first_run=process($post_to, $query_string, $phone);

if ($first_run) 
	{ 
	?>

	<style>
		body, td {font-family: verdana, arial, helvetica; font-size: 13px; color: #45484A}
		A:link { text-decoration: underline: none; none; color:#45484A; }
		A:visited { text-decoration: underline: none; none; color:#45484A; }
		A:hover { text-decoration: underline; font-weight: none;color:#45484A; }
	</style>

	<?PHP
	#echo $first_run."<-- raw return<BR>";
	$arr=explode("|", $first_run);
	#print_r($arr);
	#echo "<-- raw response<BR><BR>";
	#echo "<-- full response<BR><BR>";
	#echo $sid."<-- this is the session<BR><BR>";

	$api_response=$arr[0];
	$fraud_score=$arr[1];
	$fraud_score=str_replace("?", "0000000", $fraud_score);
	#echo $fraud_score;
	#echo "<-- fraud score<BR><BR>";
	#echo $api_response."<-- API response<BR><BR>";
	# record response and score - if possible

	if ($fraud_score=="0000000") {$fraud_score="0.1";}
	
	$query="update ";
	$query.="session_history ";
	$query.="set ";
	$query.="fraudcall_api_response='".addslashes(trim($api_response))."', ";
	$query.="fraudcall_score='".addslashes(trim($fraud_score))."' ";
	$query.="where ";
	$query.="sid='".addslashes(trim($sid))."' ";
	#print_r($query);
	mysql_query($query);
	/*
	if (ereg($fraud_score, "failed"))
			{
			echo "Numerous attempts for approval have been attempted to this phone call.<BR><BR>This is seen as attempts to abuse the system and or get passed the system without validation.<BR><BR>";
			echo "If you feel this is in error, please contact the hosting admin with your errors.<BR><BR>Due to these errors, your order cannot be processed.";
			exit;
			}
	*/
	$fraudcall_key="install_".clean_number($api_response);

	$query="select ";
	$query.="fraudcall_value, ";
	$query.="fraudcall_message ";
	$query.="from ";
	$query.="autopilot_fraudcall ";
	$query.="where ";
	$query.="fraudcall_key='".addslashes(trim($fraudcall_key))."' ";
	$query.="limit 0, 1";

	$rs=mysql_fetch_row(mysql_query($query));
	/*
	# record response and score - if possible
	$query="update ";
	$query.="session_history ";
	$query.="set ";
	$query.="fraudcall_api_response='".addslashes(trim($api_response))."', ";
	$query.="fraud_score='".addslashes(trim($fraud_score))."' ";
	$query.="where ";
	$query.="sid='".addslashes(trim($sid))."' ";
	$query.="limit 0, 1";

	mysql_query($query);
	*/
	#echo "<br><br><br>";
	#echo $query."<br>";
	#echo $rs[0]."<---- value<br>";
	#echo $rs[1]."<---- message<br>";

	if (strcmp($rs[0], "stop")==0)
		{
		$query="update ";
		$query.="session_history ";
		$query.="set ";
		$query.="locked='0' ";
		$query.="where ";
		$query.="sid='".addslashes(trim($sid))."'";

		mysql_query($query);

		echo "<b>[".str_replace("install_", "Code: ", $fraudcall_key)."] There was a problem with the phone call:</b><br><br>";
		echo strip_tags($rs[1])."<br><br>";
		
		if (strcmp($fraudcall_key, "install_320")!=0)
			{
			echo "<a href='".$http_web."/step_four.php?sid=".$sid."' target='_parent'>Click here</a> to try a new phone number or to try again.<br>";
			}
		
		echo "Otherwise, your order cannot be processed.";
		exit;
		}
	
	echo "<center>[".str_replace("install_", "Code: ", $fraudcall_key)."] Please click the button below to continue.</center><br><br>";

	include "inc/varilogix_form.php";
	}

if (!isset($retry)) 
	{
	header("Location: ".$http_web."/process_phone.php?sid=".$sid."&retry=1".((isset($gid))?"&gid=".$gid."":""));
	exit;
	}
?>

<style>
	body, td {font-family: verdana, arial, helvetica; font-size: 13px; color: #45484A}
	A:link { text-decoration: underline: none; none; color:#45484A; }
	A:visited { text-decoration: underline: none; none; color:#45484A; }
	A:hover { text-decoration: underline; font-weight: none;color:#45484A; }
</style>

<?PHP
$query="update ";
$query.="session_history ";
$query.="set ";
$query.="fraudcall_api_response='1.5.0', ";
$query.="fraudcall_score='API Post incomplete.' ";
$query.="where ";
$query.="sid='".addslashes(trim($sid))."' ";
$query.="limit 0, 1";

mysql_query($query);

echo "<center>The Fraudcall API could not be reached.<br><br>click button to continue.</center>";
#include "inc/varilogix_form.php";
?>