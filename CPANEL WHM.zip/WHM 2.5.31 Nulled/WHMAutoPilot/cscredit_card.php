<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
# include "inc/auth_functions.php";
include "inc/select.php";
include "inc/client_functions.php";
include "inc/whm_functions.php";
include $server_tools."/credit_card_code[cs0].php";
include "inc/header.php";

echo("
	<script language='javascript'>
	function lock(whichform) 
		{
		ua=new String(navigator.userAgent);
		if (ua.match(/IE/g)) 
			{
			for (i=1; i<whichform.elements.length; i++) 
				{
				if (whichform.elements[i].type=='submit') { whichform.elements[i].disabled=true; }
				}
			}

		whichform.submit();
		}
	</script>
	");

if (isset($e69))
	{
	echo("
			<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
				<tr>
					<td><font color='#C60C08'><b>ERROR!</b></font> ".$e69."</td>
				</tr>
			</table>
			");
	}


if (isset($e0))
	{
	echo("
			<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>>
				<tr>
					<td>".$error_nofirstname."</td>
				</tr>
			</table>
			");
	}

if (isset($e1))
	{
	echo("
			<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
				<tr>
					<td>".$error_nolastname."</td>
				</tr>
			</table>
			");
	}

if (isset($e2))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td>".$error_noaddress."</td>
			</tr>
		</table>
		");
	}

if (isset($e3))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td>".$error_nocity."</td>
			</tr>
		</table>
		");
	}

if (isset($e4))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td>".$error_nozip."</td>
			</tr>
		</table>
		");
	}

if (isset($e5))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td>".$error_nophone."</td>
			</tr>
		</table>
		");
	}

if (isset($e6))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td>".$error_nocard."</td>
			</tr>
		</table>
		");
	}

if (isset($e7))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td>".$error_noexpiration."</td>
			</tr>
		</table>
		");
	}

if (isset($e8))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td>".$text_noccv."</td>
			</tr>
		</table>
		");
	}

if (isset($e8))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td>".$text_short_card_number."</td>
			</tr>
		</table>
		");
	}


echo("
	<form action='".$PHP_SELF."' method='POST'>
	<input type='hidden' name='sid' value='".$sid."'>
	<input type='hidden' name='gid' value='".$gid."'>
	");

$query="select ";
$query.="total_due_today, ";	// 0
$query.="total_due_reoccur, ";	// 1
$query.="bin_number, ";			// 2
$query.="first_name, ";			// 3
$query.="last_name, ";			// 4
$query.="street_address_1, ";	// 5
$query.="city, ";				// 6
$query.="state, ";				// 7
$query.="zip_code, ";			// 8
$query.="phone, ";				// 9
$query.="fax, ";				// 10
$query.="email, ";				// 11
$query.="country ";				// 12
$query.="from ";
$query.="session_history ";
$query.="where ";
$query.="sid='".addslashes(trim($sid))."'";

$rs=mysql_fetch_row(mysql_query($query));

$bin_number=stripslashes(trim($rs[2]));
$first_name=stripslashes(trim($rs[3]));
$last_name=stripslashes(trim($rs[4]));
$street_address_1=stripslashes(trim($rs[5]));
$city=stripslashes(trim($rs[6]));
$state=stripslashes(trim($rs[7]));
$zip_code=stripslashes(trim($rs[8]));
$phone=stripslashes(trim($rs[9]));
$fax=stripslashes(trim($rs[10]));
$email=stripslashes(trim($rs[11]));
if (!isset($x_Country)) { $x_Country=stripslashes(trim($rs[12])); }

echo("
	<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
		<tr>
			<td><img src='".$http_images."/menu_arrow.gif'><font color='#C60C08'><b>Your card will be billed today in the amount of:</b> ".$currency."".sprintf("%01.2f", $rs[0])." ".$currency_type."</font></td>
		</tr>
		<tr>
			<td><img src='".$http_images."/space.gif' width='15' height='9'>Recurring charges of ".$currency."".sprintf("%01.2f", $rs[1])." ".$currency_type." will be charged ");
$payment_term=strtolower(str_replace("-", "_", $rs[2]));
if ($payment_term=="monthly") { echo "Monthly"; }
else if ($payment_term=="quarterly") { echo "Quarterly"; }
else if ($payment_term=="semi_annual") { echo "Semi-Annually"; }
else if ($payment_term=="annual") { echo "Annually"; }
echo(".</font></td>
		</tr>
	</table>
	<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
		<tr>
			<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'><td>
		</tr>
	");

$query="select uid from session_history where sid='".addslashes(trim($sid))."'";
$rs=mysql_fetch_row(mysql_query($query));
$uid=$rs[0];
if ($uid>=1)
	{
	$query="select ";
	$query.="count(*) ";				// 12
	$query.="from ";
	$query.="authnet_master_cc ";
	$query.="where uid='".addslashes(trim($uid))."' ";
	$query.="and ";
	$query.="master_cc='1'";
	
	$rs=mysql_fetch_row(mysql_query($query));

	$count=stripslashes(trim($rs[0]));

	if ($count>=1)
		{
		echo("
			<tr>
				<td width='35%' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><b>Use Exsiting Card:</b></td>
				<td width='65%' align='left' valign='top'><select name='ccid' ".$orderinput_style.">
				<option value='0'>No, Enter New Card Information Below</option>
			");
		$query3="select ";
		$query3.="ccid, ";
		$query3.="card_info, ";
		$query3.="master_cc ";
		$query3.="from ";
		$query3.="authnet_master_cc ";
		$query3.="where ";
		$query3.="uid='".addslashes(trim($uid))."' ";

		$row3=mysql_query($query3);
		while ($rs3=mysql_fetch_row($row3))
			{
			list($card_num, $card_exp, $card_code)=explode("|", d("576cb7f68040520768bf51c75f7f4c84", $rs3[1]));
			# ".(($rs3[2]==1)?" style='background-color: #F3F4F5;'":"")."
			echo "<option value='".$rs3[0]."'".(($rs3[2]==1)?" style='background-color: #F3F4F5;'":"").">".substr($card_num, 0, 2)."**********".substr($card_num, -4)."".(($rs3[2]==1)?" (Last Used)":"")."</option>\n";
			}

		unset($x_Card_Num);
		unset($x_Exp_Date_y);
		unset($x_Exp_Date_m);
		unset($x_Card_Code);
		echo("
					</select></td>
				</tr>
			<tr>
				<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'><td>
			</tr>	
			<tr>
				<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'></td>
				<td width='65%' align='left' valign='top'><input type='hidden' name='x_Submit' value='1'><input onclick='lock(this.form);' ".$orderbutton_style." type='submit' name='x_Submit' value='".$text_continue."'></td>
			</tr>
			<tr>
				<td width='35%' align='left' valign='top'></td>
				<td width='65%' align='left' valign='top'>".$text_warning."</td>
			</tr>
			<tr>
				<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'><td>
			</tr>
			");
		}
	}

echo("
		<tr>
			<td colspan='2' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><b>".$text_ccpersonalinfo."</b><td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_firstname.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='40' maxlength='50' type='text' name='x_First_Name' value='".((isset($x_First_Name))?"".$x_First_Name."":"".$first_name."")."'></td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_lastname.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='40' maxlength='50' type='text' name='x_Last_Name' value='".((isset($x_Last_Name))?"".$x_Last_Name."":"".$last_name."")."'></td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_address1.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='40' maxlength='60' type='text' name='x_Address' value='".((isset($x_Address))?"".$x_Address."":"".$street_address_1."")."'></td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_city.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='40' maxlength='40' type='text' name='x_City' value='".((isset($x_City))?"".$x_City."":"".$city."")."'></td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_state.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='3' maxlength='2' type='text' name='x_state' value='".((isset($x_state))?"".$x_state."":"".$state."")."'><BR>( 2 Digits State/Province Abbreviation )</td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_zip.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='20' maxlength='20' type='text' name='x_Zip' value='".((isset($x_Zip))?"".$x_Zip."":"".$zip_code."")."'></td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_country.":</td>
			<td width='65%' align='left' valign='top'>".display_country($x_Country, $orderinput_style)."</td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_phone.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='15' maxlength='15' type='text' name='x_Phone' value='".((isset($x_Phone))?"".$x_Phone."":"".$phone."")."'></td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_fax .":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='15' maxlength='15' type='text' name='x_Fax' value='".((isset($x_Fax))?"".$x_Fax."":"".$fax."")."'></td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_email.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='40' maxlength='255' type='text' name='x_Email' value='".((isset($x_Email))?"".$x_Email."":"".$email."")."'></td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'><td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><b>".$text_ccinfo."</b><td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_ccnumber.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='40' maxlength='22' type='text' name='x_Card_Num' value='".((isset($x_Card_Num))?"".$x_Card_Num."":"".$bin_number."")."'></td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_ccexpiration.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='2' maxlength='2' type='text' name='x_Exp_Date_m' value='".((isset($x_Exp_Date_m))?"".$x_Exp_Date_m."":"")."'>&nbsp;/&nbsp;<input ".$orderinput_style." size='2' maxlength='4' type='text' name='x_Exp_Date_y' value='".((isset($x_Exp_Date_y))?"".$x_Exp_Date_y."":"")."'>&nbsp;<font color='#990000'>ex. MM/YYYY</font></td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_ccv.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='4' maxlength='4' type='text' name='x_Card_Code' value='".((isset($x_Card_Code))?"".$x_Card_Code."":"")."'></td>
		</tr>
		<tr>
			<td colspan='2' align='center' valign='top'><img src='".$http_images."/cvv-pic-3cards.gif'><td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'><td>
		</tr>	
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'></td>
			<td width='65%' align='left' valign='top'><input type='hidden' name='x_Submit' value='1'><input onclick='lock(this.form);' ".$orderbutton_style." type='submit' name='x_Submit' value='".$text_continue."'></td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'></td>
			<td width='65%' align='left' valign='top'>".$text_warning."</td>
		</tr>
	</table>
	");
include "inc/footer.php";
mysql_close($dblink);
?>