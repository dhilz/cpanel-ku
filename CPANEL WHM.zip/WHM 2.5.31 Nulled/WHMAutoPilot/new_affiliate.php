<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/client_functions.php";
include "inc/affiliate_functions.php";

// authenicate sid
if (auth_sid($sid)==1) { header("Location: ".$http_web."/clogin.php"); exit; }

if (isset($submit))
	{
	if (strlen(trim($payable_to))==0) { $err0=true; }
	if (strlen(trim($ssn_tax_id))==0) { $err1=true; }
	
	if (!isset($err0)&&!isset($err1))
		{
		$rsx=mysql_fetch_row(mysql_query("select uid from user where sid='".addslashes(trim($sid))."'"));
		$uid=$rsx[0];

		mysql_query("insert into affiliate_user set uid='".addslashes(trim($uid))."', ogcreate='".time()."', status='2', payable_to='".addslashes(trim($payable_to))."', ssn_tax_id='".addslashes(trim($ssn_tax_id))."'");

		// send out email to admin - notify of request
		affiliate_request($email_admin, $uid);

		$done=true;
		}
	}

include "inc/header.php";

echo("
<table width='".$standard_table_width."' cellpadding='2' cellspacing='0' border='0'>
	<tr>
		<td><img src='".$http_images."/menu_arrow_back.gif'><a href='".$http_web."/client_area.php?sid=".trim($sid)."&status=".trim($status)."'><b>Go Back</b></a></td>
	</tr>
	<tr>
		<td><hr color='#F0EFED'></td>
	</tr>
</table>
	");
if (isset($done))
	{
	echo("
		<table width='".$standard_table_width."' cellpadding='2' cellspacing='0' border='0'>
			<tr>
				<td><img src='".$http_images."/menu_arrow.gif'><b>".$text_becomeaffiliate."</b></td>
			</tr>
			<tr>
				<td><img src='".$http_images."/error_arrow.gif'>Your request was received successfully! We will contact you very soon with more details.</td>
			</tr>
		</table>
		");
	include "inc/footer.php";
	DIE();
	}

// grab the user and email based on sid
$rs0=mysql_fetch_row(mysql_query("select email, uid from user where sid='".addslashes(trim($sid))."'"));
echo("
	<table width='".$standard_table_width."' cellpadding='2' cellspacing='0' border='0'>
		<tr>
			<td><img src='".$http_images."/menu_arrow.gif'><b>".$text_becomeaffiliate."</b></td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='15' height='9'>".$text_commisionratesasof .date("m/d/y h:i:s a").":</td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='1' height='1'></td>
		</tr>
	</table>
	<table width='".$standard_table_width."' cellpadding='2' cellspacing='0' border='0'>
		<tr>
			<td width='1%' align='left' valign='center'><img src='".$http_images."/the_space.gif' width='13' height='9'></td>
			<td width='99%' align='left' valign='center'>
			<table width='100%' cellpadding='2' cellspacing='1' border='0'>
				<tr>
					<td align='left' valign='center' bgcolor='#E5E7E9'>".$text_packagename."</td>
					<td align='left' valign='center' bgcolor='#E5E7E9'>".$text_commissiontype."</td>
					<td align='left' valign='center' bgcolor='#E5E7E9'>".$text_commissionamount."</td>
				</tr>
		");
$y=1;
$row1=mysql_query("select package_name, com_type, com_rate_month, com_rate_onetime, monthly_cost from plan_specs where plan_status='1'");
while ($rs1=mysql_fetch_row($row1))
	{
	if ($rs1[1]!=0)
		{
		$monthly_cost=$rs1[4];
		$com_monthly=$rs1[2];
		if ($y==1) {$bgcolor="#F2F4F6"; $y=0;} else {$bgcolor="#ECEEF0"; $y=1;}
		echo("
			<tr>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>".$rs1[0]."</td>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>".(($rs1[1]==0)?"No Plan Defined":"".(($rs1[1]==1)?"One Time":"Percent")."")."</td>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>".(($rs1[1]==1)?"&nbsp;&nbsp;".$currency."".$rs1[3]."".$currency_type."":"".(($rs1[1]!=0)?"&nbsp;&nbsp;".$rs1[2]."%&nbsp;&nbsp;&nbsp;[".affiliate_month_percentage($currency, $currency_type, $monthly_cost, $com_monthly)." / Month]":"N/A")."")."</td>
			</tr>
			");
		}
	}
echo("
			</table>
			</td>
		</tr>
	</table>
	<table width='".$standard_table_width."' cellpadding='2' cellspacing='0' border='0'>
		<tr>
			<td colspan='2'><hr color='#F0EFED'></td>
		</tr>
		<tr>
			<td><img src='".$http_images."/the_space.gif' width='1' height='9'></td>
			<td>".stripslashes(grab_aff_para($below_public))."</td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='1' height='1'></td>
		</tr>
	</table>
	<form action='".$PHP_SELF."' method='POST'>
	<input type='hidden' name='sid' value='".trim($sid)."'>
	<table width='".$standard_table_width."' cellpadding='2' cellspacing='0' border='0'>
		<tr>
			<td colspan='2'><img src='".$http_images."/menu_arrow.gif'>".$text_pleasecomplete.":</td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/space.gif' width='1' height='1'></td>
		</tr>
	");
if (isset($err0)||isset($err1))
	{
	echo("
		<tr>
			<td colspan='2'><img src='".$http_images."/space.gif' width='15' height='9'><img src='".$http_images."/drop_arrow.gif'><b>".$text_pleasecomplete2.":</b></td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/space.gif' width='1' height='1'></td>
		</tr>
		");
	}
echo("
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'><img src='".$http_images."/".((isset($err0))?"error_arrow":"space").".gif' width='15' height='9'>".$text_SSN.": </td>
			<td width='75%' align='left' valign='top'><input ".$orderinput_style." size='36' maxlength='11' type='text' name='ssn_tax_id' value='".((isset($ssn_tax_id))?"".trim($ssn_tax_id)."":"")."'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'><img src='".$http_images."/".((isset($err0))?"error_arrow":"space").".gif' width='15' height='9'>".$text_payableto.":</td>
			<td width='75%' align='left' valign='top'><input ".$orderinput_style." size='36' maxlength='255' type='text' name='payable_to' value='".((isset($payable_to))?"".trim($payable_to)."":"")."'></td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/space.gif' width='1' height='6'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'></td>
			<td width='75%' align='left' valign='top'><input ".$orderbutton_style." type='submit' name='submit' value='".$text_submitrequest."'></td>
		</tr>
	</table>
	</form>
	");
include "inc/footer.php";
?>