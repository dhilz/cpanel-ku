<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/select.php";
include "inc/client_functions.php";
include $server_tools."/step_four_code[0].php";
include "inc/header.php";

# added 7/9/2004
$default_order="USA"; # comment out for non USA

echo("
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td><a href='".$http_web."/step_one.php?sid=".trim($sid)."&gid=".trim($gid)."'><font size='1'>".$navigate_selectpackage."</font></a><img src='".$http_images."/order_arrow.gif'><a href='".$http_web."/step_two.php?sid=".trim($sid)."&gid=".trim($gid)."'><font size='1'>".$navigate_domainoptions."</font></a>".(($pcheck==0)?"<img src='".$http_images."/order_arrow.gif'><a href='".$http_web."/step_three.php?sid=".trim($sid)."&gid=".trim($gid)."&addon_gid=".base64_encode(trim($rs_gpid[0]))."'><font size='1'>".$navigate_addonoptions."</font></a>":"")."<img src='".$http_images."/order_arrow.gif'><a href='".$http_web."/step_four.php?sid=".trim($sid)."&gid=".trim($gid)."'><font size='1' color='#990000'><b>".$navigate_accountinfo."</b></font></a></td>
	</tr>
</table>

<form action='".$PHP_SELF."' method='POST' name='step_four_form'> 
<input type='hidden' name='sid' value='".trim($sid)."'>
<input type='hidden' name='gid' value='".trim($gid)."'>
".((isset($pid))?"<input type='hidden' name='pid' value='".trim($pid)."'>":"")."
	");
if (isset($err0))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepfour_nofirstname."</td> 
			</tr>
			
		</table>
		");
	}
if (isset($err1))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepfour_nolastname."</td> 
			</tr>
			
		</table>
		");
	}
if (isset($err2))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepfour_noaddress."</td> 
			</tr>
			
		</table>
		");
	}
if (isset($err3))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepfour_nocity."</td> 
			</tr>
			
		</table>
		");
	}
if (isset($err4))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepfour_nostate."</td> 
			</tr>
			
		</table>
		");
	}
if (isset($err5))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepfour_nozipcode."</td> 
			</tr>
			
		</table>
		");
	}
if (isset($err7))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepfour_nophone."</td> 
			</tr>
			
		</table>
		");
	}
if (isset($err8))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepfour_noemailaddress."</td> 
			</tr>
			
		</table>
		");
	}
if (isset($err9))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepfour_nousername."</td> 
			</tr>
			
		</table>
		");
	}
if (isset($err10))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepfour_nopassword."</td> 
			</tr>
			
		</table>
		");
	}
if (isset($err11))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepfour_nospecify."</td> 
			</tr>
			
		</table>
		");
	}
if (isset($err12))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepfour_nochoseother."</td> 
			</tr>
			
		</table>
		");
	}
if (isset($err13))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepfour_mustacceptterms."</td> 
			</tr>
		</table>
		");
	}
if (isset($err14))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepfour_usernametaken."</td> 
			</tr>
		</table>
		");
	}
if (isset($err15))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepfour_emailaddressinuse."</td> 
			</tr>
		</table>
		");
	}
if (isset($err16))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepfour_nobin."</td> 
			</tr>
		</table>
		");
	}
if (isset($err0)||isset($err1)||isset($err2)||isset($err3)||isset($err4)||isset($err5)||isset($err6)||isset($err7)||isset($err8)||isset($err9)||isset($err10)||isset($err11)||isset($err12)||isset($err13)||isset($err14)||isset($err15)||isset($err16))
	{
	echo("
		<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='10'></td>
			</tr>
		</table>
		");
	}
echo("
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td colspan='3' align='left' valign='top'></td> 
	</tr>
	<tr>
		<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'>".$text_clientinformation."</td>
		<td width='".$stepfour_rightcolumn."' align='left' valign='top'>".((isset($exist))?"<b>".$text_loggedinas." <font color='#990000'>".$username."</font></b>":"".$text_existinglogin."")."</td>
	</tr>
	<tr>
		<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err0))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_firstname.":</td>
		<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='first_name' value='".((isset($first_name))?"".trim(stripslashes($first_name))."":"")."'> ".$text_required."</td>
	</tr>
	<tr>
		<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err1))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_lastname.":</td>
		<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='last_name' value='".((isset($last_name))?"".trim(stripslashes($last_name))."":"")."'> ".$text_required."</td>
	</tr>
	<tr>
		<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_companyname.":</td>
		<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='organization_name' value='".((isset($organization_name))?"".trim(stripslashes($organization_name))."":"")."'> ".$text_optional."</td>
	</tr>
	<tr>
		<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err2))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_address1.":</td>
		<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='street_address_1' value='".((isset($street_address_1))?"".trim(stripslashes($street_address_1))."":"")."'> ".$text_required."</td>
	</tr>
	<tr>
		<td width='".$stepfour_leftcolumn."' align='left' valign='top'></td>
		<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='street_address_2' value='".((isset($street_address_2))?"".trim(stripslashes($street_address_2))."":"")."'> ".$text_optional."</td>
	</tr>
	<tr>
		<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err3))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_city.":</td>
		<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='city' value='".((isset($city))?"".trim(stripslashes($city))."":"")."'> ".$text_required."</td>
	</tr>
	");

# added 7/9/2004
if (strcmp($default_order, "USA")==0)
	{
	echo("
		<tr>
			<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err4))?"error_arrow.gif":"space.gif")."' width='15' height='9'>US State or Province:</td>
			<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input type='radio' name='sorp' value='0'".((isset($sorp))?"".(($sorp==0)?" checked":"")."":" checked")." onclick='document.step_four_form.province.disabled=true; document.step_four_form.state.disabled=false;'> ".display_states($state, $orderinput_style)."&nbsp;&nbsp;".$text_required."</td>
		</tr>
		<tr>
			<td width='".$stepfour_leftcolumn."' align='left' valign='top'></td>
			<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input type='radio' name='sorp' value='1'".((isset($sorp))?"".(($sorp==1)?" checked":"")."":"")." onclick='document.step_four_form.province.disabled=false; document.step_four_form.state.disabled=true;'> <input ".$orderinput_style." size='26' maxlength='255' type='text' name='province' value='".((isset($province))?"".trim(stripslashes($province))."":"Enter Province")."'".((isset($sorp))?"".(($sorp==0)?" disabled":"")."":" disabled")."  onFocus=\"if(this.value=='Enter Province') this.value='';\" onBlur=\"if(this.value=='') this.value='Enter Province';\"> ".$text_required."</td>
		</tr>
		");
	}
else
	{
	if (strcmp($check_first_name, "")=="") { $sorp=1; }

	echo("
		<tr>
			<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err4))?"error_arrow.gif":"space.gif")."' width='15' height='9'>Province or US State:</td>
			<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input type='radio' name='sorp' value='1'".((isset($sorp))?"".(($sorp==1)?" checked":"")."":"")." onclick='document.step_four_form.province.disabled=false; document.step_four_form.state.disabled=true;'> <input ".$orderinput_style." size='26' maxlength='255' type='text' name='province' value='".((isset($province))?"".trim(stripslashes($province))."":"Enter Province")."'".((isset($sorp))?"".(($sorp==0)?" disabled":"")."":" disabled")."  onFocus=\"if(this.value=='Enter Province') this.value='';\" onBlur=\"if(this.value=='') this.value='Enter Province';\"> ".$text_required."</td>
		</tr>
		<tr>
			<td width='".$stepfour_leftcolumn."' align='left' valign='top'></td>
			<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input type='radio' name='sorp' value='0'".((isset($sorp))?"".(($sorp==0)?" checked":"")."":" checked")." onclick='document.step_four_form.province.disabled=true; document.step_four_form.state.disabled=false;'> ".display_states($state, $orderinput_style)."&nbsp;&nbsp;".$text_required."</td>
		</tr>
		");

	/*
	echo("
		<tr>
			<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err4))?"error_arrow.gif":"space.gif")."' width='15' height='9'>Province or US State:</td>
			<td width='".$stepfour_rightcolumn."' align='left' valign='top'>
			
		
		<input type='radio' name='sorp' value='1'".((isset($sorp))?"".(($sorp==1)?" checked":"")."":" checked")." onclick='document.step_four_form.province.disabled=false; document.step_four_form.state.disabled=true;'> <input ".$orderinput_style." size='26' maxlength='255' type='text' name='province' value='".((isset($province))?"".trim(stripslashes($province))."":"Enter Province")."'
		
		  onFocus=\"if(this.value=='Enter Province') this.value='';\" onBlur=\"if(this.value=='') this.value='Enter Province';\">
		
		
		
		
		nbsp;&nbsp;".$text_required."</td>
		</tr>
		<tr>
			<td width='".$stepfour_leftcolumn."' align='left' valign='top'></td>
			<td width='".$stepfour_rightcolumn."' align='left' valign='top'>
			
		
		<input type='radio' name='sorp' value='0'".((isset($sorp))?"".(($sorp==0)?" checked":"disabled ")."":" disabled")." 
		onclick='document.step_four_form.province.disabled=true; document.step_four_form.state.disabled=false;'> ".display_states($state, $orderinput_style)."
		
		
		
		&nbsp;&nbsp;".$text_required."</td>
		</tr>
		");
	*/
	}

echo("
	<tr>
		<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err5))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_postalcode.":</td>
		<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='zip_code' value='".((isset($zip_code))?"".trim(stripslashes($zip_code))."":"")."'> ".$text_required."</td>
	</tr>
	<tr>
		<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err6))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_country.":</td>
		<td width='".$stepfour_rightcolumn."' align='left' valign='top'>
	");
@country($country,$orderinput_style);
/* deleted
	<tr>
		<td width='".$stepfour_leftcolumn."' align='left' valign='top'></td>
		<td width='".$stepfour_rightcolumn."' align='left' valign='top'>".$call_hint."</td>
	</tr>
*/
echo("
		<img src='".$http_images."/space.gif' width='5' height='9'>".$text_required."</td>
	</tr>
	<tr>
		<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err7))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_phone.":</td>
		<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='phone' value='".((isset($phone))?"".trim(stripslashes($phone))."":"")."'> ".$text_required."</td>
	</tr>
	<tr>
		<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_fax.":</td>
		<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='fax' value='".((isset($fax))?"".trim(stripslashes($fax))."":"")."'> ".$text_optional."</td>
	</tr>
	<tr>
		<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err8))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_emailaddress.":</td>
		<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='email' value='".((isset($email))?"".trim(stripslashes($email))."":"")."'> ".$text_required."</td>
	</tr>
	");

$query="select ";
$query.="payment_method ";
$query.="from ";
$query.="session_history ";
$query.="where ";
$query.="sid='".addslashes(trim($sid))."' ";
$query.="limit 0, 1";

$rs=mysql_fetch_row(mysql_query($query));

$pay_pro=$rs[0];

# added 7/2/2004
$query="select ";
$query.="fraudcall_value ";
$query.="from ";
$query.="autopilot_fraudcall ";
$query.="where ";
$query.="fraudcall_key='activate_fraud_call' ";
$query.="limit 0, 1";

$rs=mysql_fetch_row(mysql_query($query));
# end 7/2/2004

$act_fc=$rs[0];

if ($pay_pro==8&&strcmp($act_fc, "yes")==0)
	{
	if (strcmp($bin_number, "0")==0) { unset($bin_number); }
	echo("
		<input type='hidden' name='authnet' value='8'>
		<tr>
			<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'></td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'>".$text_cc_bin."</td> 
		</tr>
		<tr>
			<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err9))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_bin.":</td>
			<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='8' maxlength='6' type='text' name='bin_number' value='".((isset($bin_number))?"".trim(stripslashes($bin_number))."":"")."'> ".$text_required."</td>
		</tr>
		");
	}


if (!isset($exist))
	{
	echo("
		<tr>
			<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'></td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'>".$text_clientarealogininfo."</td> 
		</tr>
		<tr>
			<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err9))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_chooseusername.":</td>
			<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='username' value='".((isset($username))?"".trim(stripslashes($username))."":"")."'> ".$text_required."</td>
		</tr>
		<tr>
			<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err10))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_choosepassword.":</td>
			<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='password' name='password' value='".((isset($password))?"".trim(stripslashes($password))."":"")."'> ".$text_required."</td>
		</tr>
		<tr>
			<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err10))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_verifypassword.":</td>
			<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='password' name='password2' value='".((isset($password2))?"".trim(stripslashes($password2))."":"")."'> ".$text_required."</td>
		</tr>
		");
	}
else { echo"<input type='hidden' name='exist' value='1'>"; }
echo("
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'></td>
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'>".$text_advertisinginfo."</td> 
	</tr>
	<tr>
		<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err11)||isset($err12))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_howfound."</td>
		<td width='".$stepfour_rightcolumn."' align='left' valign='top'>
		");
@advert($advert,$orderinput_style);
echo("
		 ".$text_required."</td>
	</tr>
	<tr>
		<td width='".$stepfour_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err12))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_ifother.":</td>
		<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='advert_other' value='".((isset($advert_other))?"".trim(stripslashes($advert_other))."":"")."'></td>
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'></td>
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'>".$text_clientnotes."</td> 
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'>".$text_clientnotes2.":</td>
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><textarea name='client_notes' ".$orderinput_style." rows='4' cols='72'>".((isset($client_notes))?"".$client_notes."":"")."</textarea></td>
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'></td>
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'>".$text_termsofservice."</td> 
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/".((isset($err13))?"error_arrow.gif":"space.gif")."' width='15' height='9'><input type='checkbox' name='tos' value='1'".((isset($tos))?"".((trim($tos)=="1")?" checked":"")."":"")." id='tos'>  <label for='tos'>".$text_termsofservice2."</label><img src='".$http_images."/space.gif' width='22' height='1'>".$text_required."</td>
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='40' height='1'><img src='".$http_images."/error_arrow.gif'><a href='".$tos_agreement."' target='_blank'>".$text_viewterms."</a></td>
	</tr>
</table>
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td><img src='".$http_images."/space.gif' width='1' height='20'></td>
	</tr>
</table>
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td width='".$stepfour_leftcolumn."' align='left' valign='top'></td>
		<td width='".$stepfour_rightcolumn."' align='left' valign='top'><input ".$orderbutton_style." type='submit' name='submit' value='".$stepfour_submitbutton."'></td>
	</tr>
</table>
</form>
	");

include "inc/footer.php";
mysql_close($dblink);
?>
