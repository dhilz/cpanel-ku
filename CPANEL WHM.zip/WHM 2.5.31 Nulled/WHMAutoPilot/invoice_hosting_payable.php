<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/whm_functions.php";
include "inc/invoice_functions.php";

# Decode ID
# ---------------------------------------------------------------------------------
if (!isset($c)) { die("invalid invoice"); }
else { $iid=urldecode(d("576cb7f68040520768bf51c75f7f4c84", $c)); }
# ---------------------------------------------------------------------------------
# END: Decode ID

# Pull out company variable
# ---------------------------------------------------------------------------------
$query0="select ";
$query0.="logo_path, ";
$query0.="company_contact, ";
$query0.="payable_to ";
$query0.="from ";
$query0.="invoice_config ";
$query0.="limit 0, 1";

$rs0=mysql_fetch_row(mysql_query($query0));

$logo_path=stripslashes(trim($rs0[0]));
$company_contact=stripslashes(trim($rs0[1]));
$payable_to=stripslashes(trim($rs0[2]));
# ---------------------------------------------------------------------------------
# END: Pull out company variable

# Pull out invoice details
# ---------------------------------------------------------------------------------
$query1="select ";
$query1.="iid, ";				// 0
$query1.="due_date, ";			// 1
$query1.="payment_method, ";	// 2
$query1.="status, ";			// 3
$query1.="created, ";			// 4
$query1.="date_paid, ";			// 5
$query1.="invoice_number, ";	// 6
$query1.="total_due_today, ";	// 7
$query1.="total_due_reoccur, ";	// 8
$query1.="extras, ";			// 9
$query1.="oid ";				// 10
$query1.="from ";
$query1.="invoice ";
$query1.="where ";
$query1.="iid='".addslashes(trim($iid))."' ";

$rs1=mysql_fetch_row(mysql_query($query1));

$iid=stripslashes(trim($rs1[0]));
$due_date=stripslashes(trim($rs1[1]));
$payment_method=stripslashes(trim($rs1[2]));
$status=stripslashes(trim($rs1[3]));
$created=stripslashes(trim($rs1[4]));
$date_paid=stripslashes(trim($rs1[5]));
$invoice_number=stripslashes(trim($rs1[6]));
$total_due_today=stripslashes(trim($rs1[7]));
$total_due_today=sprintf("%01.2f", $total_due_today);
$total_due_reoccur=stripslashes(trim($rs1[8]));
$total_due_reoccur=sprintf("%01.2f", $total_due_reoccur);
$extras=stripslashes(trim($rs1[9]));
$oid=stripslashes(trim($rs1[10]));
# ---------------------------------------------------------------------------------
# END: Pull out invoice details

# Client details
# ---------------------------------------------------------------------------------
$query2="select ";
$query2.="user.first_name, ";					// 0
$query2.="user.last_name,  ";					// 1
$query2.="user.street_address_1,  ";			// 2
$query2.="user.city,  ";						// 3
$query2.="user.state,  ";						// 4
$query2.="user.zip_code,  ";					// 5
$query2.="user.country,  ";						// 6
$query2.="user.phone,  ";						// 7
$query2.="user.fax,  ";							// 8
$query2.="user.email,  ";						// 9
$query2.="user.street_address_2, ";				// 10
$query2.="hosting_order.domain_name, ";			// 11
$query2.="hosting_order.pid, ";					// 12
$query2.="hosting_order.payment_term, ";			// 13
$query2.="user.organization_name ";				// 14
$query2.="from ";
$query2.="user, hosting_order ";
$query2.="where ";
$query2.="hosting_order.uid=user.uid ";
$query2.="and ";
$query2.="hosting_order.oid='".addslashes(trim($oid))."'";

$rs2=mysql_fetch_row(mysql_query($query2));

$first_name=stripslashes(trim($rs2[0]));
$last_name=stripslashes(trim($rs2[1]));
$address_1=stripslashes(trim($rs2[2]));
$city=stripslashes(trim($rs2[3]));
$state=stripslashes(trim($rs2[4]));
$zip_code=stripslashes(trim($rs2[5]));
$country=stripslashes(trim($rs2[6]));
$phone=stripslashes(trim($rs2[7]));
$fax=stripslashes(trim($rs2[8]));
$email=stripslashes(trim($rs2[9]));
$address_2=stripslashes(trim($rs2[10]));
$domain_name=stripslashes(trim($rs2[11]));
$pid=stripslashes(trim($rs2[12]));
$raw_payment_term=stripslashes(trim($rs2[13]));
$organization_name=stripslashes(trim($rs2[14]));

if (strcmp(strtolower($raw_payment_term), "monthly")==0) { $term=1; }
else if (strcmp(strtolower($raw_payment_term), "quarterly")==0) { $term=3; }
else if (strcmp(strtolower(str_replace("-", "_", $raw_payment_term)), "semi_annual")==0) { $term=6; }
else if (strcmp(strtolower($raw_payment_term), "annual")==0) { $term=12; }
// brandee add on 1-9-2004
if ($total_due_today==0&&$total_due_reoccur==0) { $sub_total=0; }
	else if ($total_due_today==0) { $sub_total=$total_due_reoccur; }
	else { $sub_total=$total_due_today; }
# ---------------------------------------------------------------------------------
# END: Client details

# Package details
# ---------------------------------------------------------------------------------
$query5="select ";
$query5.="package_name, ";		// 0
$query5.="setup_cost, ";		// 1
$query5.="monthly_cost, ";		// 2
$query5.="quarterly_cost, ";	// 3
$query5.="semi_annual_cost, ";	// 4
$query5.="annual_cost ";		// 5
$query5.="from ";
$query5.="plan_specs ";
$query5.="where ";
$query5.="pid='".addslashes(trim($pid))."'";

$rs5=mysql_fetch_row(mysql_query($query5));

$package_name=stripslashes(trim($rs5[0]));
$setup_cost=stripslashes(trim($rs5[1]));
$monthly_cost=stripslashes(trim($rs5[2]));
$quarterly_cost=stripslashes(trim($rs5[3]));
$semi_annual_cost=stripslashes(trim($rs5[4]));
$annual_cost=stripslashes(trim($rs5[5]));
# ---------------------------------------------------------------------------------
# END: Package details

# Processor name
# ---------------------------------------------------------------------------------
$query3="select ";
$query3.="name ";		// 0
$query3.="from ";
$query3.="payment_process ";
$query3.="where ";
$query3.="pid='".addslashes(trim($payment_method))."'";

$rs3=mysql_fetch_row(mysql_query($query3));

$payment_method_name=stripslashes(trim($rs3[0]));
# ---------------------------------------------------------------------------------
# END: Processor name

echo("
	<html>
	<head>
	<title>".$text_payableinvoice." ".$first_name." ".$last_name." [".$domain_name."]</title>
	<style>
	 td{ font-family:tahoma,Tahoma; font-size:8pt; } 
	</style>
	<style>
		 body, td, center, p {font-family:tahoma, arial, helvetica; font-size: 11px; color: #000000} div {font-family:tahoma, arial, helvetica; font-size: 11px} A:link { text-decoration: underline: none; none; color:#000000;} A:visited { text-decoration: underline: none; none; color:#000000;} A:hover { text-decoration: underline; font-weight: none;color:#990000;} .linkTable { PADDING-LEFT: 5px } 
	</style>
	</head>
	<body>
	");
if (trim($logo_path)!="")
		{
		echo("
			<table width='85%' cellpadding='8' cellspacing='0' border='0' align='center'>
				<tr>
					<td align='left' valign='middle'><img src='".$logo_path."'></td>
				</tr>
			</table>
			");
		}
echo("
	<table width='85%' cellpadding='4' cellspacing='0' border='1' align='center'>
		<tr>
			<td width='50%' align='left' valign='top'>
			<table width='100%' cellpadding='2' cellspacing='0' border='0'>
				<tr>
					<td align='left' valign='top'><b>".$text_remitpayment.":</b></td>
				</tr>
				<tr>
					<td align='left' valign='top'>&nbsp;</td>
				</tr>
				<tr>
					<td align='left' valign='top'>".nl2br($company_contact)."</td>
				</tr>
			</table>
			</td>
			<td width='50%' align='left' valign='top'>
			<table width='100%' cellpadding='2' cellspacing='1' border='0'>
				<tr>
					<td align='left' valign='top'><b>".$text_invoicedate .":</b></td>
					<td align='left' valign='top'>".date("m/d/Y", $created)."</td>
				</tr>
				<tr>
					<td align='left' valign='top' bgcolor='#F7F3F7'><b>".$text_invoicenumber.":</b></td>
					<td align='left' valign='top' bgcolor='#F7F3F7'>".$invoice_number."</td>
				</tr>
				<tr>
					<td align='left' valign='top'><b>".$text_invoicedue .":</b></td>
					<td align='left' valign='top'>".date("m/d/Y", $due_date)."</td>
				</tr>
				<tr>
					<td align='left' valign='top' bgcolor='#F7F3F7'><b>".$text_terms .":</b></td>
					<td align='left' valign='top' bgcolor='#F7F3F7'>".$text_autobilling ."</td>
				</tr>
				<tr>
					<td align='left' valign='top'><b>".$text_payableto.":</b></td>
					<td align='left' valign='top'>".$payable_to."</td>
				</tr>
			</table>
			</td>
		</tr>
	</table>
	<table width='85%' cellpadding='8' cellspacing='0' border='0' align='center'>
		<tr>
			<td align='left' valign='top'><br></td>
		</tr>
	</table>
	<table width='85%' cellpadding='4' cellspacing='0' border='1' align='center'>
		<tr>
			<td width='50%' align='left' valign='top'>
			<table width='100%' cellpadding='2' cellspacing='0' border='0'>
				<tr>
					<td align='left' valign='top'><b>".$text_invoicedto.":</b></td>
				</tr>
				<tr>
					<td align='left' valign='top'>&nbsp;</td>
				</tr>
");
if (trim($organization_name)!="")
	{
	echo("
			<tr>
				<td align='left' valign='top'><B>".$organization_name."</b></td>
			</tr>
		");
	}
echo("
				<tr>
					<td align='left' valign='top'><font color='#990000'>".$first_name." ".$last_name."</font></td>
				</tr>
				<tr>
					<td align='left' valign='top'>".$address_1."</td>
				</tr>
		");
if (trim($address_2)!="")
	{
	echo("
			<tr>
				<td align='left' valign='top'>".$address_2."</td>
			</tr>
		");
	}
echo("
				<tr>
					<td align='left' valign='top'>".$city.", ".$state." ".$zip_code." ".$country."</td>
				</tr>
				<tr>
					<td align='left' valign='top'>".$text_phone.": ".$phone."</td>
				</tr>
		");
if (trim($fax)!="")
	{
	echo("
			<tr>
				<td align='left' valign='top'>".$text_fax.": ".$fax."</td>
			</tr>
		");
	}

echo("
				<tr>
					<td align='left' valign='top'>".$email."</td>
				</tr>
			</table>
			</td>
			<td width='50%' align='left' valign='top'>
			<table width='100%' cellpadding='2' cellspacing='1' border='0'>
				<tr>
					<td align='left' valign='top'><font color='#COCOCO'><b>".$text_please." ".(($payment_method=="6")?$text_printandmail:$text_clicktopay)."</b></font></td>
				</tr>
				<tr>
					<td align='left' valign='top'>&nbsp;</td>
				</tr>
				<tr>
					<td align='center' valign='middle'><br><br>
	");

$sid=create_invoice_session($iid);

if ($payment_method=="1") 
	{ 
	$pay_image="paypal.gif";

	# -------------------------------------------------------------

	$query4="select ";
	$query4.="paypal_address, ";
	$query4.="paypal_image_url ";
	$query4.="from ";
	$query4.="payment_process ";
	$query4.="where pid='".addslashes(trim($payment_method))."'";

	$rs4=mysql_fetch_row(mysql_query($query4));
	
	$business=stripslashes(trim($rs4[0]));
	$paypal_image_url=stripslashes(trim($rs4[1]));
	
	# -------------------------------------------------------------

	echo "<form action='https://www.paypal.com/cgi-bin/webscr' method='POST'>\n";
	echo "<input type='hidden' name='cmd' value='_xclick-subscriptions'>\n";
	echo "<input type='hidden' name='business' value='".$business."'>\n";
	echo "<input type='hidden' name='item_name' value='".$package_name." [".$domain_name."]'>\n";
	echo "<input type='hidden' name='custom' value='".$sid."'>\n";
	echo "<input type='hidden' name='return' value='".$http_web."/invoice_success.php'>\n";
	echo "<input type='hidden' name='cancel_return' value='".$http_web."/index.php'>\n";
	echo "<input type='hidden' name='a3' value='".sprintf("%01.2f", $total_due_reoccur)."'>\n";
	echo "<input type='hidden' name='p3' value='".$term."'>\n";
	echo "<input type='hidden' name='t3' value='M'>\n";
	echo "<input type='hidden' name='src' value='1'>\n";
	echo "<input type='hidden' name='sra' value='1'>\n";
	echo "<input type='hidden' name='currency_code' value='".$currency_type."'>\n";
	echo "<input type='hidden' name='no_shipping' value='1'>\n";
	echo "<input type='hidden' name='rm' value='2'>\n";
	echo "<input type='hidden' name='no_note' value='1'>\n";

	if (trim($paypal_image_url)!="") { echo "<input type='hidden' name='image_url' value='".$paypal_image_url."'>\n"; }
	
	if ($total_due_today!=0)
		{
		echo "<input type='hidden' name='a1' value='".$sub_total."'>\n";
		echo "<input type='hidden' name='p1' value='".$term."'>\n";
		echo "<input type='hidden' name='t1' value='M'>\n";
		}
	}
else if ($payment_method=="12") 
	{ 
	$pay_image="paypal.gif";

	# -------------------------------------------------------------

	$query4="select ";
	$query4.="paypal_address, ";
	$query4.="paypal_image_url ";
	$query4.="from ";
	$query4.="payment_process ";
	$query4.="where pid='".addslashes(trim($payment_method))."'";

	$rs4=mysql_fetch_row(mysql_query($query4));
	
	$business=stripslashes(trim($rs4[0]));
	$paypal_image_url=stripslashes(trim($rs4[1]));
	
	# -------------------------------------------------------------

	echo "<form action='https://www.paypal.com/cgi-bin/webscr' method='POST'>\n";
	echo "<input type='hidden' name='cmd' value='_xclick-subscriptions'>\n";
	echo "<input type='hidden' name='business' value='".$business."'>\n";
	echo "<input type='hidden' name='item_name' value='".$package_name." [".$domain_name."]'>\n";
	echo "<input type='hidden' name='custom' value='".$sid."'>\n";
	echo "<input type='hidden' name='return' value='".$http_web."/invoice_success.php'>\n";
	echo "<input type='hidden' name='cancel_return' value='".$http_web."/index.php'>\n";
	echo "<input type='hidden' name='a3' value='".sprintf("%01.2f", $total_due_reoccur)."'>\n";
	echo "<input type='hidden' name='p3' value='".$term."'>\n";
	echo "<input type='hidden' name='t3' value='M'>\n";
	echo "<input type='hidden' name='src' value='1'>\n";
	echo "<input type='hidden' name='sra' value='1'>\n";
	echo "<input type='hidden' name='currency_code' value='".$currency_type."'>\n";
	echo "<input type='hidden' name='no_shipping' value='1'>\n";
	echo "<input type='hidden' name='rm' value='2'>\n";
	echo "<input type='hidden' name='no_note' value='1'>\n";

	if (trim($paypal_image_url)!="") { echo "<input type='hidden' name='image_url' value='".$paypal_image_url."'>\n"; }
	
	if ($total_due_today!=0)
		{
		echo "<input type='hidden' name='a1' value='".$sub_total."'>\n";
		echo "<input type='hidden' name='p1' value='".$term."'>\n";
		echo "<input type='hidden' name='t1' value='M'>\n";
		}
	}
else if ($payment_method=="3") 
	{ 
	$pay_image="paysystems.gif"; 

	# -------------------------------------------------------------
	
	$query4="select ";
	$query4.="paysystems_companyid ";
	$query4.="from ";
	$query4.="payment_process ";
	$query4.="where pid='".addslashes(trim($payment_method))."'";

	$rs4=mysql_fetch_row(mysql_query($query4));

	$paysystems_companyid=stripslashes(trim($rs4[0]));

	# -------------------------------------------------------------

	$query5="select ";
	$query5.="tpp_pro_period ";
	$query5.="from ";
	$query5.="plan_specs ";
	$query5.="where pid='".addslashes(trim($pid))."'";

	$rs5=mysql_fetch_row(mysql_query($query5));

	$tpp_pro_period=stripslashes(trim($rs5[0]));

	# -------------------------------------------------------------

	// Get the days of payment cycle
	if ($term==1) {$xpterm=30;}
	else if ($term==3) {$xpterm=90;}
	else if ($term==6) {$xpterm=180;}
	else if ($term==12) {$xpterm=360;}

	echo "<form action='https://secure.paysystems1.com/cgi-v310/payment/onlinesale-tpppro.asp' method='POST'>\n";
	echo "<input type='hidden' name='companyid' value='".$paysystems_companyid."'>\n";
	echo "<input type='hidden' name='product1' value='".$package_name." [".$domain_name."]'>\n";
	echo "<input type='hidden' name='formget' value='N'>\n";
	echo "<input type='hidden' name='redirect' value='".$http_web."/invoice_success.php'>\n";
	echo "<input type='hidden' name='redirectfail' value='".$http_web."/index.php'>\n";
	echo "<input type='hidden' name='option1' value='".$sid."'>\n";
	echo "<input type='hidden' name='reoccur' value='Y'>\n";
	echo "<input type='hidden' name='cycle' value='".$xpterm."'>\n";
	echo "<input type='hidden' name='totalperiod' value='".$tpp_pro_period."'>\n";
	echo "<input type='hidden' name='total' value='".$sub_total."'>\n";
	echo "<input type='hidden' name='repeatamount' value='".sprintf("%01.2f", $total_due_reoccur)."'>\n";
	}
///// Internet Secure change 14/08/2004
else if ($payment_method=="9") 
	{ 
	$pay_image="internetsecure.gif"; 
	
	# -------------------------------------------------------------
	
	$query4="select ";
	$query4.="internetsecure_merchant_id, ";
	$query4.="internetsecure_language, ";
	$query4.="internetsecure_return_cgi ";
	$query4.="from ";
	$query4.="payment_process ";
	$query4.="where pid='".addslashes(trim($payment_method))."'";

	$rs4=mysql_fetch_row(mysql_query($query4));

	$internetsecure_merchant_id=stripslashes(trim($rs4[0]));
	$internetsecure_language=stripslashes(trim($rs4[1]));
	$internetsecure_return_cgi=stripslashes(trim($rs4[2]));

	# -------------------------------------------------------------

	$query5="select ";
	$query5.="internetsecure_period ";
	$query5.="from ";
	$query5.="plan_specs ";
	$query5.="where pid='".addslashes(trim($pid))."'";

	$rs5=mysql_fetch_row(mysql_query($query5));

	$period=stripslashes(trim($rs5[0]));

	# -------------------------------------------------------------

		// Get the days of payment cycle
	if ($term==1) {$xpterm="monthly";
	$rm_start = "startmonth=+1";	}
	else if ($term==3) {$xpterm="quarterly"; $rm_start = "startmonth=+3";}
	else if ($term==6) {$xpterm="semiannually"; $rm_start = "startmonth=+6";}
	else if ($term==12) {$xpterm="annually"; $rm_start = "startyear=+1";}

	$internetsecure_form.="<form action='https://secure.internetsecure.com/process.cgi' method='POST'>\n";
	$internetsecure_form.="<input type='hidden' name='MerchantNumber' value='".trim($internetsecure_merchant_id)."'>\n";
	$internetsecure_form.="<input type='hidden' name='language' value='".trim($internetsecure_language)."'>\n";
	$internetsecure_form.="<input type='hidden' name='ReturnCGI' value='".trim($http_web."/invoice_success.php")."'>\n";
	$internetsecure_form.="<input type=hidden name='Products' value='$sub_total::1::$package_name::".$package_name." [".$domain_name."]"."::{RB amount=$total_due_reoccur $rm_start frequency=$xpterm duration=$period email=2}'>\n";
	$internetsecure_form.="<input type='hidden' name='xxxName' value='$first_name $last_name'>\n";
	$internetsecure_form.="<input type='hidden' name='xxxCompany' value='$organization_name'>\n";
	$internetsecure_form.="<input type='hidden' name='xxxAddress' value='$address_1'>\n";
	$internetsecure_form.="<input type='hidden' name='xxxCity' value='$city'>\n";
	$internetsecure_form.="<input type='hidden' name='xxxProvince' value='$state'>\n";
	$internetsecure_form.="<input type='hidden' name='xxxCountry' value='$country'>\n";
	$internetsecure_form.="<input type='hidden' name='xxxPostal' value='$zip_code'>\n"; 
	$internetsecure_form.="<input type='hidden' name='xxxEmail' value='$email'>\n"; 
	$internetsecure_form.="<input type='hidden' name='xxxPhone' value='$phone'>\n"; 
	$internetsecure_form.="<input type='hidden' name='xxxVar1' value='".$sid."'>\n";
	echo ($internetsecure_form);
	}

///// Internet Secure change 14/08/2004
else if ($payment_method=="6") { $pay_image="mailin.gif"; }
else if ($payment_method=="4") 
	{ 
	$pay_image="2checkout.gif"; 

	# -------------------------------------------------------------
	
	$query4="select ";
	$query4.="checkout_sid, ";
	$query4.="demo, ";
	$query4.="co_system ";
	$query4.="from ";
	$query4.="payment_process ";
	$query4.="where pid='".addslashes(trim($payment_method))."'";

	$rs4=mysql_fetch_row(mysql_query($query4));

	$checkout_id=stripslashes(trim($rs4[0]));
	$demo=stripslashes(trim($rs4[1]));
	$co_system=stripslashes(trim($rs4[2]));

	# -------------------------------------------------------------
	
	$query5="select ";
	$query5.="monthly_pid, ";
	$query5.="quarterly_pid, ";
	$query5.="semi_annual_pid, ";
	$query5.="annual_pid ";
	$query5.="from ";
	$query5.="plan_specs ";
	$query5.="where pid='".addslashes(trim($pid))."'";

	$rs5=mysql_fetch_row(mysql_query($query5));

	# -------------------------------------------------------------
	
	if ($term==1) { $mqsaa_pid=$rs5[0]; }
	else if ($term==3) { $mqsaa_pid=$rs5[1]; }
	else if ($term==6) { $mqsaa_pid=$rs5[2]; }
	else if ($term==12) { $mqsaa_pid=$rs5[3]; }

	if ($rs4[2]==0) 
		{ 
		echo "<form action='https://www.2checkout.com/cgi-bin/crbuyers/recpurchase.2c' method='POST'>\n"; 
		echo "<input type='hidden' name='merchant_order_id' value='".$sid."|1"."'>\n";
		}
	else 
		{ 
		echo "<form action='https://www2.2checkout.com/2co/buyer/purchase' method='POST'>\n"; 
		echo "<input type='hidden' name='quantity' value='1'>\n";
		echo "<input type='hidden' name='merchant_product_id' value='".$sid."|1"."'>\n";
		}

	echo "<input type='hidden' name='product_id' value='".$mqsaa_pid."'>\n";
	echo "<input type='hidden' name='sid' value='".$checkout_id."'>\n";

	/*
	echo "<form action='https://www.2checkout.com/cgi-bin/crbuyers/recpurchase.2c' method='POST'>\n";
	echo "<input type='hidden' name='sid' value='".$paysystems_companyid."'>\n";
	echo "<input type='hidden' name='product_id' value='".$mqsaa_pid."'>\n";
	echo "<input type='hidden' name='merchant_order_id' value='".$sid."|1"."'>\n";
	*/

	if ($demo==1) { echo "<input type='hidden' name='demo' value='Y'>\n"; }
	}
else if ($payment_method=="2") 
	{ 
	$pay_image="worldpay.gif"; 

	$query4="select ";
	$query4.="worldpay_id, ";
	$query4.="worldpay_cc, ";
	$query4.="worldpay_demo ";
	$query4.="from ";
	$query4.="payment_process ";
	$query4.="where ";
	$query4.="pid='".addslashes(trim($payment_method))."'";

	$rs4=mysql_fetch_row(mysql_query($query4));

	$worldpay_id=stripslashes(trim($rs4[0]));
	$worldpay_cc=stripslashes(trim($rs4[1]));
	$worldpay_demo=stripslashes(trim($rs4[2]));

	// Get the link id
	if ($term==1)  { $intrval=1; }
	else if ($term==3) { $intrval=3; }
	else if ($term==6) { $intrval=6; }
	else if ($term==12) { $intrval=12; }

	echo "<form action='https://select.worldpay.com/wcc/purchase' method='POST'>\n";
	echo "<input type='hidden' name='desc' value='".$package_name." [".$domain_name."]'>\n";
	echo "<input type='hidden' name='cartId' value='".$sid."'>\n";
	echo "<input type='hidden' name='instId' value='".$worldpay_id."'>\n";
	echo "<input type='hidden' name='currency' value='".$worldpay_cc."'>\n";
	echo "<input type='hidden' name='futurePayType' value='regular'>\n";
	echo "<input type='hidden' name='option' value='1'>\n";
	echo "<input type='hidden' name='startDelayUnit' value='3'>\n";
	echo "<input type='hidden' name='startDelayMult' value='".$intrval."'>\n";
	echo "<input type='hidden' name='intervalUnit' value='3'>\n";
	echo "<input type='hidden' name='intervalMult' value='".$intrval."'>\n";
	$xlink=str_replace("http://", "", strtolower($http_web));
	$xlink=str_replace("https://", "", strtolower($xlink));
	echo "<input type='hidden' name='MC_callback' value='".$xlink."/invoice_success.php'>\n";
	echo "<input type='hidden' name='testMode' value='".$worldpay_demo."'>\n";
	echo "<input type='hidden' name='amount' value='".$sub_total."'>\n";
	echo "<input type='hidden' name='normalAmount' value='".sprintf("%01.2f", $total_due_reoccur)."'>\n";
	}
else if ($payment_method=="13") 
	{ 
	$pay_image="worldpay.gif"; 

	$query4="select ";
	$query4.="worldpay_id, ";
	$query4.="worldpay_cc, ";
	$query4.="worldpay_demo ";
	$query4.="from ";
	$query4.="payment_process ";
	$query4.="where ";
	$query4.="pid='".addslashes(trim($payment_method))."'";

	$rs4=mysql_fetch_row(mysql_query($query4));

	$worldpay_id=stripslashes(trim($rs4[0]));
	$worldpay_cc=stripslashes(trim($rs4[1]));
	$worldpay_demo=stripslashes(trim($rs4[2]));

	// Get the link id
	if ($term==1)  { $intrval=1; }
	else if ($term==3) { $intrval=3; }
	else if ($term==6) { $intrval=6; }
	else if ($term==12) { $intrval=12; }

	echo "<form action='https://select.worldpay.com/wcc/purchase' method='POST'>\n";
	echo "<input type='hidden' name='desc' value='".$package_name." [".$domain_name."]'>\n";
	echo "<input type='hidden' name='cartId' value='".$sid."'>\n";
	echo "<input type='hidden' name='instId' value='".$worldpay_id."'>\n";
	echo "<input type='hidden' name='currency' value='".$worldpay_cc."'>\n";
	echo "<input type='hidden' name='futurePayType' value='regular'>\n";
	echo "<input type='hidden' name='option' value='1'>\n";
	echo "<input type='hidden' name='startDelayUnit' value='3'>\n";
	echo "<input type='hidden' name='startDelayMult' value='".$intrval."'>\n";
	echo "<input type='hidden' name='intervalUnit' value='3'>\n";
	echo "<input type='hidden' name='intervalMult' value='".$intrval."'>\n";
	$xlink=str_replace("http://", "", strtolower($http_web));
	$xlink=str_replace("https://", "", strtolower($xlink));
	echo "<input type='hidden' name='MC_callback' value='".$xlink."/invoice_success.php'>\n";
	echo "<input type='hidden' name='testMode' value='".$worldpay_demo."'>\n";
	echo "<input type='hidden' name='amount' value='".$sub_total."'>\n";
	echo "<input type='hidden' name='normalAmount' value='".sprintf("%01.2f", $total_due_reoccur)."'>\n";
	}
else if ($payment_method=="8") 
	{ 
	$pay_image="authorize.gif"; 

	echo "<form action='".$http_web."/invoice_credit_card.php' method='POST'>\n";
	echo "<input type='hidden' name='sid' value='".$sid."'>\n";
	}
else if ($payment_method=="10") 
	{ 
	$pay_image="linkpoint.gif"; 

	echo "<form action='".$http_web."/invoice_lcredit_card.php' method='POST'>\n";
	echo "<input type='hidden' name='sid' value='".$sid."'>\n";
	}
else if ($payment_method=="15") 
	{ 
	$pay_image="offlinecc.gif"; 

	echo "<form action='".$http_web."/invoice_ocredit_card.php' method='POST'>\n";
	echo "<input type='hidden' name='sid' value='".$sid."'>\n";
	}
else if ($payment_method=="14")
	{
	$pay_image="cybersource.gif";

	include("inc/mod_HOP.php");
	
	# -------------------------------------------------------------------------

	$hop=hop_values();
	$getMerchantID=$hop['merchant_id'];
	$getPublicKey=$hop['public_key'];
	$getPrivateKey=$hop['private_key'];

	if ($total_due_today==0) { $total_due_today=$total_due_reoccur; }
	
	# -------------------------------------------------------------------------
	
	$parse_out0="<form action='https://orderpage.ic3.com/hop/orderform.jsp' method='post'>";
	$parse_out0.=InsertSignature($total_due_today);
	$parse_out0.="<input type='hidden' name='comments' value='".$total_due_today;
	$parse_out0.="::Invoice Payment for [".$domain_name."]'>";
	$parse_out0.="<input type='hidden' name='invoicetype' value='hosting'>";
	echo $parse_out0.="<input type='hidden' name='sid' value='".trim($sid)."'>";
	}
else if ($payment_method=="11") 
	{ 
	$pay_image="psigate.gif"; 

	echo "<form action='".$http_web."/invoice_pcredit_card.php' method='POST'>\n";
	echo "<input type='hidden' name='sid' value='".$sid."'>\n";
	}

echo "<".(($payment_method=="6")?"img ":"input type='image' ")."src='".$http_images."/".$pay_image."' border='0' alt='".$text_clicktopaynow."'>";
echo "</form>";
echo("
					</td>
				</tr>
			</table>
			</td>
		</tr>
	</table>
	<table width='85%' cellpadding='8' cellspacing='0' border='0' align='center'>
		<tr>
			<td align='left' valign='top'><br></td>
		</tr>
	</table>
	<table width='85%' cellpadding='8' cellspacing='0' border='1' align='center'>
		<tr>
			<td colspan='5' align='left' valign='top' bgcolor='#F7F3F7'>&nbsp;<b>".$text_invoicedetails."</b></td>
		</tr>
		<tr>
			<td align='left' valign='top'>&nbsp;<b>".$text_domainname."</b></td>
			<td align='left' valign='top'>&nbsp;<b>".$text_package."</b></td>
			<td align='left' valign='top'>&nbsp;<b>".$text_onetimefees."</b></td>
			<td align='left' valign='top'>&nbsp;<b>".$text_recurringfees."</b></td>
			<td align='left' valign='top'>&nbsp;<b>".$text_subtotal."</b></td>
		</tr>
		<tr>
			<td align='left' valign='top'>&nbsp;".$domain_name."</td>
			<td align='left' valign='top'>&nbsp;".$package_name."</td>
			<td align='left' valign='top'>&nbsp;
			");
	
	/*
	if ($total_due_today==0&&$total_due_reoccur==0) { echo $text_none; }
	else if ($total_due_today==0) { echo $currency."".$total_due_reoccur." ".$currency_type; }
	else { echo $currency."".$total_due_today." ".$currency_type; }
	*/
	if ($total_due_today==0) { echo $text_none; }
	else { echo $currency."".$total_due_today." ".$currency_type; }

	echo ("
			</td>
			<td align='left' valign='top'>&nbsp;
			");

	/*
	if ($total_due_today==0&&$total_due_reoccur==0) { echo "None"; }
	else if ($total_due_today==0) { echo $sub_total=$currency."".$total_due_reoccur." ".$currency_type; }
	else { echo $sub_total=$currency."".$total_due_today." ".$currency_type; }
	*/

	echo $currency."".$total_due_reoccur." ".$currency_type;

	echo ("
			</td>
			<td align='left' valign='top'>&nbsp;
			");

	if ($total_due_today==0&&$total_due_reoccur==0) { echo "None"; }
	else if ($total_due_today==0) { echo $sub_total=$currency."".$total_due_reoccur." ".$currency_type; }
	else { echo $sub_total=$currency."".$total_due_today." ".$currency_type; }

	echo ("
			</td>
		</tr>
		<tr>
			<td colspan='5'>
			<table width='100%' cellpadding='2' cellspacing='0' border='0'>
				<tr>
					<td width='79%' align='left' valign='top'>
					<table width='100%' cellpadding='4' cellspacing='0' border='0'>
						<tr>
							<td align='left' valign='top'><b>".$text_addonsordered.":</b></td>
						</tr>
						<tr>
							<td align='left' valign='top' bgcolor='#F7F3F7'>".((trim($extras)=="")?$text_none:"".nl2br($extras)."")."</td>
						</tr>
					</table>
					</td>
					<td width='1%' align='right' valign='top'><img src='".$http_images."/space.gif' width='15' height='1'></td>
					<td width='20%' align='right' valign='top'>
					<table width='100%' cellpadding='4' cellspacing='0' border='0'>
						<tr>
							<td align='right' valign='top'><b>".$text_invoiceamount.":</b></td>
							<td align='left' valign='top'>&nbsp;&nbsp;<b>".$sub_total."</b></td>
						</tr>
						<tr>
							<td align='right' valign='top'><b>".$text_invoicestatus.":</b></td>
							<td align='left' valign='top'>&nbsp;&nbsp;".invoice_status($status)."</td>
						</tr>
						<tr>
							<td align='right' valign='top'><img src='".$http_images."/space.gif' width='150' height='1'></td>
							<td align='left' valign='top'><img src='".$http_images."/space.gif' width='100' height='1'></td>
						</tr>
					</table>
					</td>
				</tr>
			</table>
			</td>
		</tr>
	</table>
	<table width='85%' cellpadding='8' cellspacing='0' border='0' align='center'>
		<tr>
			<td align='left' valign='middle'>* One time fees are made up of setup fees, coupons, domain registrations and one time addons.</td>
		</tr>
	</table>
	</body>
	</html>
	");
mysql_close($dblink);
?>