<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/whm_functions.php";
include "inc/invoice_functions.php";

# Decode ID
# ---------------------------------------------------------------------------------
if (!isset($c)) { die("invalid invoice"); }
else { $iid=urldecode(d("576cb7f68040520768bf51c75f7f4c84", $c)); }
# ---------------------------------------------------------------------------------
# END: Decode ID

# Pull out company variable
# ---------------------------------------------------------------------------------
$query0="select ";
$query0.="logo_path, ";
$query0.="company_contact, ";
$query0.="payable_to ";
$query0.="from ";
$query0.="invoice_config ";
$query0.="limit 0, 1";

$rs0=mysql_fetch_row(mysql_query($query0));

$logo_path=stripslashes(trim($rs0[0]));
$company_contact=stripslashes(trim($rs0[1]));
$payable_to=stripslashes(trim($rs0[2]));
# ---------------------------------------------------------------------------------
# END: Pull out company variable

# Pull out invoice details
# ---------------------------------------------------------------------------------
$query1="select ";
$query1.="iid, ";				// 0
$query1.="due_date, ";			// 1
$query1.="payment_method, ";	// 2
$query1.="status, ";			// 3
$query1.="created, ";			// 4
$query1.="date_paid, ";			// 5
$query1.="invoice_number, ";	// 6
$query1.="total_due_today, ";	// 7
$query1.="total_due_reoccur, ";	// 8
$query1.="extras, ";			// 9
$query1.="oid ";				// 10
$query1.="from ";
$query1.="invoice ";
$query1.="where ";
$query1.="iid='".addslashes(trim($iid))."' ";

$rs1=mysql_fetch_row(mysql_query($query1));

$iid=stripslashes(trim($rs1[0]));
$due_date=stripslashes(trim($rs1[1]));
$payment_method=stripslashes(trim($rs1[2]));
$status=stripslashes(trim($rs1[3]));
$created=stripslashes(trim($rs1[4]));
$date_paid=stripslashes(trim($rs1[5]));
$invoice_number=stripslashes(trim($rs1[6]));
$total_due_today=stripslashes(trim($rs1[7]));
$total_due_today=sprintf("%01.2f", $total_due_today);
$total_due_reoccur=stripslashes(trim($rs1[8]));
$total_due_reoccur=sprintf("%01.2f", $total_due_reoccur);
$extras=stripslashes(trim($rs1[9]));
$oid=stripslashes(trim($rs1[10]));
# ---------------------------------------------------------------------------------
# END: Pull out invoice details

# Client details
# ---------------------------------------------------------------------------------
$query2="select ";
$query2.="user.first_name, ";					// 0
$query2.="user.last_name,  ";					// 1
$query2.="user.street_address_1,  ";			// 2
$query2.="user.city,  ";						// 3
$query2.="user.state,  ";						// 4
$query2.="user.zip_code,  ";					// 5
$query2.="user.country,  ";						// 6
$query2.="user.phone,  ";						// 7
$query2.="user.fax,  ";							// 8
$query2.="user.email,  ";						// 9
$query2.="user.street_address_2, ";				// 10
$query2.="hosting_order.domain_name, ";			// 11
$query2.="hosting_order.pid, ";					// 12
$query2.="user.organization_name ";				// 13
$query2.="from ";
$query2.="user, hosting_order ";
$query2.="where ";
$query2.="hosting_order.uid=user.uid ";
$query2.="and ";
$query2.="hosting_order.oid='".addslashes(trim($oid))."'";

$rs2=mysql_fetch_row(mysql_query($query2));

$first_name=stripslashes(trim($rs2[0]));
$last_name=stripslashes(trim($rs2[1]));
$address_1=stripslashes(trim($rs2[2]));
$city=stripslashes(trim($rs2[3]));
$state=stripslashes(trim($rs2[4]));
$zip_code=stripslashes(trim($rs2[5]));
$country=stripslashes(trim($rs2[6]));
$phone=stripslashes(trim($rs2[7]));
$fax=stripslashes(trim($rs2[8]));
$email=stripslashes(trim($rs2[9]));
$address_2=stripslashes(trim($rs2[10]));
$domain_name=stripslashes(trim($rs2[11]));
$pid=stripslashes(trim($rs2[12]));
$organization_name=stripslashes(trim($rs2[13]));
# ---------------------------------------------------------------------------------
# END: Client details

# Package details
# ---------------------------------------------------------------------------------
$query5="select ";
$query5.="package_name, ";		// 0
$query5.="setup_cost, ";		// 1
$query5.="monthly_cost, ";		// 2
$query5.="quarterly_cost, ";	// 3
$query5.="semi_annual_cost, ";	// 4
$query5.="annual_cost ";		// 5
$query5.="from ";
$query5.="plan_specs ";
$query5.="where ";
$query5.="pid='".addslashes(trim($pid))."'";

$rs5=mysql_fetch_row(mysql_query($query5));

$package_name=stripslashes(trim($rs5[0]));
$setup_cost=stripslashes(trim($rs5[1]));
$monthly_cost=stripslashes(trim($rs5[2]));
$quarterly_cost=stripslashes(trim($rs5[3]));
$semi_annual_cost=stripslashes(trim($rs5[4]));
$annual_cost=stripslashes(trim($rs5[5]));
# ---------------------------------------------------------------------------------
# END: Package details

# Processor name
# ---------------------------------------------------------------------------------
$query3="select ";
$query3.="name ";		// 0
$query3.="from ";
$query3.="payment_process ";
$query3.="where ";
$query3.="pid='".addslashes(trim($payment_method))."'";

$rs3=mysql_fetch_row(mysql_query($query3));

$payment_method_name=stripslashes(trim($rs3[0]));
# ---------------------------------------------------------------------------------
# END: Processor name

echo("
	<html>
	<head>
	<title>".$text_readonlyinvoice." ".$first_name." ".$last_name." [".$domain_name."]</title>
	<style>
	 td{ font-family:tahoma,Tahoma; font-size:8pt; } 
	</style>
	<style>
		 body, td, center, p {font-family:tahoma, arial, helvetica; font-size: 11px; color: #000000} div {font-family:tahoma, arial, helvetica; font-size: 11px} A:link { text-decoration: underline: none; none; color:#000000;} A:visited { text-decoration: underline: none; none; color:#000000;} A:hover { text-decoration: underline; font-weight: none;color:#990000;} .linkTable { PADDING-LEFT: 5px } 
	</style>
	</head>
	<body>
	");
if (trim($logo_path)!="")
		{
		echo("
			<table width='85%' cellpadding='8' cellspacing='0' border='0' align='center'>
				<tr>
					<td align='left' valign='middle'><img src='".$logo_path."'></td>
				</tr>
			</table>
			");
		}
echo("
	<table width='85%' cellpadding='4' cellspacing='0' border='1' align='center'>
		<tr>
			<td width='50%' align='left' valign='top'>
			<table width='100%' cellpadding='2' cellspacing='0' border='0'>
				<tr>
					<td align='left' valign='top'><b>".$text_remitpayment.":</b></td>
				</tr>
				<tr>
					<td align='left' valign='top'>&nbsp;</td>
				</tr>
				<tr>
					<td align='left' valign='top'>".nl2br($company_contact)."</td>
				</tr>
			</table>
			</td>
			<td width='50%' align='left' valign='top'>
			<table width='100%' cellpadding='2' cellspacing='1' border='0'>
				<tr>
					<td align='left' valign='top'><b>".$text_invoicedate.":</b></td>
					<td align='left' valign='top'>".date("m/d/Y", $created)."</td>
				</tr>
				<tr>
					<td align='left' valign='top' bgcolor='#F7F3F7'><b>".$text_invoicenumber.":</b></td>
					<td align='left' valign='top' bgcolor='#F7F3F7'>".$invoice_number."</td>
				</tr>
				<tr>
					<td align='left' valign='top'><b>".$text_invoicedue.":</b></td>
					<td align='left' valign='top'>".date("m/d/Y", $due_date)."</td>
				</tr>
				<tr>
					<td align='left' valign='top' bgcolor='#F7F3F7'><b>".$text_terms.":</b></td>
					<td align='left' valign='top' bgcolor='#F7F3F7'>".$text_autobilling ."</td>
				</tr>
				<tr>
					<td align='left' valign='top'><b>".$text_payableto.":</b></td>
					<td align='left' valign='top'>".$payable_to."</td>
				</tr>
			</table>
			</td>
		</tr>
	</table>
	<table width='85%' cellpadding='8' cellspacing='0' border='0' align='center'>
		<tr>
			<td align='left' valign='top'><br></td>
		</tr>
	</table>
	<table width='85%' cellpadding='4' cellspacing='0' border='1' align='center'>
		<tr>
			<td width='50%' align='left' valign='top'>
			<table width='100%' cellpadding='2' cellspacing='0' border='0'>
				<tr>
					<td align='left' valign='top'><b>".$text_invoicedto.":</b></td>
				</tr>
				<tr>
					<td align='left' valign='top'>&nbsp;</td>
				</tr>
		");
if (trim($organization_name)!="")
	{
	echo("
			<tr>
				<td align='left' valign='top'><B>".$organization_name."</b></td>
			</tr>
		");
	}
echo("
				<tr>
					<td align='left' valign='top'><font color='#990000'>".$first_name." ".$last_name."</font></td>
				</tr>
				<tr>
					<td align='left' valign='top'>".$address_1."</td>
				</tr>
		");
if (trim($address_2)!="")
	{
	echo("
			<tr>
				<td align='left' valign='top'>".$address_2."</td>
			</tr>
		");
	}
echo("
				<tr>
					<td align='left' valign='top'>".$city.", ".$state." ".$zip_code." ".$country."</td>
				</tr>
				<tr>
					<td align='left' valign='top'>".$text_phone.": ".$phone."</td>
				</tr>
		");
if (trim($fax)!="")
	{
	echo("
			<tr>
				<td align='left' valign='top'>".$text_fax.": ".$fax."</td>
			</tr>
		");
	}

if ($payment_method=="1") { $pay_image="paypal.gif"; }
else if ($payment_method=="3") { $pay_image="paysystems.gif"; }
else if ($payment_method=="12") { $pay_image="paypal.gif"; }
else if ($payment_method=="6") { $pay_image="mailin.gif"; }
else if ($payment_method=="4") { $pay_image="2checkout.gif"; }
else if ($payment_method=="2") { $pay_image="worldpay.gif"; }
else if ($payment_method=="13") { $pay_image="worldpay.gif"; }
else if ($payment_method=="8") { $pay_image="authorize.gif"; }
///// Internet Secure change 14/08/2004
else if ($payment_method=="9") { $pay_image="internetsecure.gif"; }
else if ($payment_method=="10") { $pay_image="linkpoint.gif"; }
else if ($payment_method=="11") { $pay_image="psigate.gif"; }
else if ($payment_method=="14") { $pay_image="cybersource.gif"; }
else if ($payment_method=="15") { $pay_image="offlinecc.gif"; }
///// Internet Secure change 14/08/2004


echo("
				<tr>
					<td align='left' valign='top'>".$email."</td>
				</tr>
			</table>
			</td>
			<td width='50%' align='left' valign='top'>
			<table width='100%' cellpadding='2' cellspacing='1' border='0'>
				<tr>
					<td align='left' valign='top'><font color='#COCOCO'><b>". $text_thisinvoice .(($status==1)?$text_was:$text_willbe) . $text_paidusing ."</b></font></td>
				</tr>
				<tr>
					<td align='left' valign='top'>&nbsp;</td>
				</tr>
				<tr>
					<td align='center' valign='middle'><br><br><img src='".$http_images."/$pay_image' border='0' alt='".$text_altpaymentmethod."'></td>
				</tr>
			</table>
			</td>
		</tr>
	</table>
	<table width='85%' cellpadding='8' cellspacing='0' border='0' align='center'>
		<tr>
			<td align='left' valign='top'><br></td>
		</tr>
	</table>
	<table width='85%' cellpadding='8' cellspacing='0' border='1' align='center'>
		<tr>
			<td colspan='5' align='left' valign='top' bgcolor='#F7F3F7'>&nbsp;<b>".$text_invoicedetails."</b></td>
		</tr>
		<tr>
			<td align='left' valign='top'>&nbsp;<b>".$text_domainname."</b></td>
			<td align='left' valign='top'>&nbsp;<b>".$text_package ."</b></td>
			<td align='left' valign='top'>&nbsp;<b>".$text_onetimefees."</b></td>
			<td align='left' valign='top'>&nbsp;<b>".$text_recurringfees."</b></td>
			<td align='left' valign='top'>&nbsp;<b>".$text_subtotal."</b></td>
		</tr>
		<tr>
			<td align='left' valign='top'>&nbsp;".$domain_name."</td>
			<td align='left' valign='top'>&nbsp;".$package_name."</td>
			<td align='left' valign='top'>&nbsp;
			");
	
	/*
	if ($total_due_today==0&&$total_due_reoccur==0) { echo $text_none; }
	else if ($total_due_today==0) { echo $currency."".$total_due_reoccur." ".$currency_type; }
	else { echo $currency."".$total_due_today." ".$currency_type; }
	*/
	if ($total_due_today==0) { echo $text_none; }
	else { echo $currency."".$total_due_today." ".$currency_type; }

	echo ("
			</td>
			<td align='left' valign='top'>&nbsp;
			");

	/*
	if ($total_due_today==0&&$total_due_reoccur==0) { echo "None"; }
	else if ($total_due_today==0) { echo $sub_total=$currency."".$total_due_reoccur." ".$currency_type; }
	else { echo $sub_total=$currency."".$total_due_today." ".$currency_type; }
	*/

	echo $currency."".$total_due_reoccur." ".$currency_type;

	echo ("
			</td>
			<td align='left' valign='top'>&nbsp;
			");

	if ($total_due_today==0&&$total_due_reoccur==0) { echo "None"; }
	else if ($total_due_today==0) { echo $sub_total=$currency."".$total_due_reoccur." ".$currency_type; }
	else { echo $sub_total=$currency."".$total_due_today." ".$currency_type; }

	echo ("
			</td>
		</tr>
		<tr>
			<td colspan='5'>
			<table width='100%' cellpadding='2' cellspacing='0' border='0'>
				<tr>
					<td width='79%' align='left' valign='top'>
					<table width='100%' cellpadding='4' cellspacing='0' border='0'>
						<tr>
							<td align='left' valign='top'><b>".$text_addonsordered.":</b></td>
						</tr>
						<tr>
							<td align='left' valign='top' bgcolor='#F7F3F7'>".((trim($extras)=="")?$text_none:"".nl2br($extras)."")."</td>
						</tr>
					</table>
					</td>
					<td width='1%' align='right' valign='top'><img src='".$http_images."/space.gif' width='15' height='1'></td>
					<td width='20%' align='right' valign='top'>
					<table width='100%' cellpadding='4' cellspacing='0' border='0'>
						<tr>
							<td align='right' valign='top'><b>".$text_invoiceamount.":</b></td>
							<td align='left' valign='top'>&nbsp;&nbsp;<b>".$sub_total."</b></td>
						</tr>
						<tr>
							<td align='right' valign='top'><b>".$text_invoicestatus.":</b></td>
							<td align='left' valign='top'>&nbsp;&nbsp;".invoice_status($status)."</td>
						</tr>
						<tr>
							<td align='right' valign='top'><img src='".$http_images."/space.gif' width='150' height='1'></td>
							<td align='left' valign='top'><img src='".$http_images."/space.gif' width='100' height='1'></td>
						</tr>
					</table>
					</td>
				</tr>
			</table>
			</td>
		</tr>
	</table>
	<table width='85%' cellpadding='8' cellspacing='0' border='0' align='center'>
		<tr>
			<td align='left' valign='middle'>* One time fees are made up of setup fees, coupons, domain registrations and one time addons.</td>
		</tr>
	</table>
	</body>
	</html>
	");
mysql_close($dblink);
?>