<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/select.php";
include "inc/client_functions.php";
include "inc/affiliate_functions.php";

// start form handler

if (isset($submit))
	{
	if (strlen(trim($first_name))==0) {$err0=true;} else {$n0=true;}
	if (strlen(trim($last_name))==0) {$err1=true;} else {$n1=true;}
	if (strlen(trim($street_address_1))==0) {$err2=true;} else {$n2=true;}
	if (strlen(trim($city))==0) {$err3=true;} else {$n3=true;}
	if (strlen(trim($state))==0) {$err4=true;} else {$n4=true;}
	if (strlen(trim($zip_code))==0) {$err5=true;} else {$n5=true;}
	if (strlen(trim($country))==0) {$err6=true;} else {$n6=true;}
	if (strlen(trim($phone))==0) {$err7=true;} else {$n7=true;}
	if (strlen(trim($email))==0) {$err8=true;} else {$n8=true;}
	if (strlen(trim($payable_to))==0) {$err16=true;} else {$n16=true;}
	if (strlen(trim($ssn_tax_id))==0) {$err17=true;} else {$n17=true;}

	# ssn_tax_id payable_to

	// is this user already a user?
	if (!isset($exist))
		{
		if (strlen(trim($username))==0) {$err9=true;} else {$n9=true;}
		}
	else
		{
		$n9=true;
		}

	// is this user already a user?
	if (!isset($exist))
		{
		if (strcmp($password, $password2)!=0||strlen(trim($password))==0) {$err10=true;} else {$n10=true;}
		}
	else
		{
		$n10=true;
		}

	if (trim($advert)=="x") 
		{
		$err11=true;
		} 
	else 
		{
		if (trim($advert)=="OTHER")
			{
			if (strlen(trim($advert_other))==0)
				{
				$err12=true;
				}
			else
				{
				$n11=true;
				$n12=true;
				}
			}
		else
			{
			$n11=true;
			$n12=true;
			}
		}
	if (!isset($tos)) {$err13=true;} else {$n13=true;}


	// is this user already a user?
	if (!isset($exist))
		{
		if (check_user($username)==1) {$err14=true;} else {$n14=true;}
		if (check_email($email)==1) {$err15=true;} else {$n15=true;}
		}
	else
		{
		$n14=true;
		$n15=true;
		}

	if (isset($n0)&&isset($n1)&&isset($n2)&&isset($n3)&&isset($n4)&&isset($n5)&&isset($n6)&&isset($n7)&&isset($n8)&&isset($n9)&&isset($n10)&&isset($n11)&&isset($n12)&&isset($n13)&&isset($n14)&&isset($n15)&&isset($n16)&&isset($n17))
		{
		// Start Session Management

		// update history - only the parts that are relevant though
		$insert="insert into user set ";
		$insert.="first_name='".addslashes(trim($first_name))."', ";
		$insert.="last_name='".addslashes(trim($last_name))."', ";
		$insert.="organization_name='".addslashes(trim($organization_name))."', ";
		$insert.="street_address_1='".addslashes(trim($street_address_1))."', ";
		$insert.="street_address_2='".addslashes(trim($street_address_2))."', ";
		$insert.="city='".addslashes(trim($city))."', ";
		$insert.="state='".addslashes(trim($state))."', ";
		$insert.="zip_code='".addslashes(trim($zip_code))."', ";
		$insert.="country='".addslashes(trim($country))."', ";
		$insert.="phone='".addslashes(trim($phone))."', ";
		$insert.="fax='".addslashes(trim($fax))."', ";
		$insert.="email='".addslashes(trim($email))."', ";
		$insert.="username='".addslashes(trim($username))."', "; 
		
		# added 6/24/2004
		$enc_pw=base64_encode(clogin_e($password));
		$insert.="password='".$enc_pw."', ";

		# $insert.="password='".md5(trim(strtolower($password)))."', "; 

		$insert.="advert='".addslashes(trim($advert))."', ";
		$insert.="advert_other='".addslashes(trim($advert_other))."', ";
		$insert.="tos='".addslashes(trim($tos))."', ";
		$insert.="sid='".md5(microtime())."', ";
		$insert.="ogcreate='".time()."'";
	
		mysql_query($insert);

		$uid=mysql_insert_id();

		mysql_query("insert into affiliate_user set uid='".addslashes(trim($uid))."', ogcreate='".time()."', status='2', payable_to='".addslashes(trim($payable_to))."', ssn_tax_id='".addslashes(trim($ssn_tax_id))."'");

		// send out email to admin - notify of request
		affiliate_request($email_admin, $uid);
		
		header("Location: ".$http_web."/clogin.php");
		}
	}

// end form handler

include "inc/header.php";
echo("
	<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
		<tr>
			<td><img src='".$http_images."/menu_arrow.gif'><b>".$text_becomeaffiliate."</b></td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='15' height='9'>".$text_commisionratesasof .date("m/d/y h:i:s a").":</td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='1' height='1'></td>
		</tr>
	</table>
	<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
		<tr>
			<td width='1%' align='left' valign='center'><img src='".$http_images."/the_space.gif' width='13' height='9'></td>
			<td width='99%' align='left' valign='center'>
			<table width='100%' cellpadding='2' cellspacing='1' border='0'>
				<tr>
					<td align='left' valign='center' bgcolor='#E5E7E9'>".$text_packagename."</td>
					<td align='left' valign='center' bgcolor='#E5E7E9'>".$text_commissiontype."</td>
					<td align='left' valign='center' bgcolor='#E5E7E9'>".$text_commissionamount."</td>
				</tr>
		");
$y=1;
$row1=mysql_query("select package_name, com_type, com_rate_month, com_rate_onetime, monthly_cost from plan_specs where plan_status='1'");
while ($rs1=mysql_fetch_row($row1))
	{
	if ($rs1[1]!=0)
		{
		$monthly_cost=$rs1[4];
		$com_monthly=$rs1[2];
		if ($y==1) {$bgcolor="#F2F4F6"; $y=0;} else {$bgcolor="#ECEEF0"; $y=1;}
		echo("
			<tr>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>".$rs1[0]."</td>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>".(($rs1[1]==0)?"No Plan Defined":"".(($rs1[1]==1)?"One Time":"Percent")."")."</td>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>".(($rs1[1]==1)?"&nbsp;&nbsp;".$currency."".$rs1[3]."".$currency_type."":"".(($rs1[1]!=0)?"&nbsp;&nbsp;".$rs1[2]."%&nbsp;&nbsp;&nbsp;[".affiliate_month_percentage($currency, $currency_type, $monthly_cost, $com_monthly)." / Month]":"N/A")."")."</td>
			</tr>
			");
		}
	}
echo("
			</table>
			</td>
		</tr>
	</table>
	<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
		<tr>
			<td colspan='2'><hr color='#F0EFED'></td>
		</tr>
		<tr>
			<td><img src='".$http_images."/the_space.gif' width='1' height='9'></td>
			<td>".stripslashes(grab_aff_para($below_public))."</td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='1' height='1'></td>
		</tr>
	</table>");
echo "<form action='".$PHP_SELF."' method='POST'>";
if (isset($err0))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$error_nofirstname."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		</table>
		");
	}
if (isset($err1))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$error_nolastname."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		</table>
		");
	}
if (isset($err2))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'></td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		</table>
		");
	}
if (isset($err3))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$error_nocity."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		</table>
		");
	}
if (isset($err4))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$error_nostate."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		</table>
		");
	}
if (isset($err5))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$error_nopostalcode."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		</table>
		");
	}
if (isset($err7))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$error_nophone."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		</table>
		");
	}
if (isset($err8))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$error_noemail."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		</table>
		");
	}
if (isset($err9))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$error_nousername."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		</table>
		");
	}
if (isset($err10))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$error_nopassword."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		</table>
		");
	}
if (isset($err11))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$error_nospecify."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		</table>
		");
	}
if (isset($err12))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$error_nochoseother."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		</table>
		");
	}
if (isset($err13))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$error_mustacceptterms."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		</table>
		");
	}
if (isset($err14))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$error_usernametaken."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		</table>
		");
	}
if (isset($err15))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$error_emailaddressinuse."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		</table>
		");
	}
if (isset($err16))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$error_nopayablefield."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		</table>
		");
	}
if (isset($err17))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$error_noSSN."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		</table>
		");
	}
if (isset($err0)||
isset($err1)||
isset($err2)||
isset($err3)||
isset($err4)||
isset($err5)||
isset($err6)||
isset($err7)||
isset($err8)||
isset($err9)||
isset($err10)||
isset($err11)||
isset($err12)||
isset($err13)||
isset($err14)||
isset($err15)||
isset($err16)||
isset($err17))
	{
	echo("
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td><img src='".$http_images."/space.gif' width='1' height='8'></td>
	</tr>
</table>
		");
	}
echo("
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td colspan='3' align='left' valign='top'></td> 
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><b>".$text_affiliateinfo."</b></td>
	</tr>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err16))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_payableto.":</td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='payable_to' value='".((isset($payable_to))?"".trim(stripslashes($payable_to))."":"")."'> ".$text_required."</td>
	</tr>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err17))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_SSN.":</td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='ssn_tax_id' value='".((isset($ssn_tax_id))?"".trim(stripslashes($ssn_tax_id))."":"")."'> ".$text_required."</td>
	</tr>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err0))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_firstname.":</td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='first_name' value='".((isset($first_name))?"".trim(stripslashes($first_name))."":"")."'> ".$text_required."</td>
	</tr>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err1))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_lastname.":</td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='last_name' value='".((isset($last_name))?"".trim(stripslashes($last_name))."":"")."'> ".$text_required."</td>
	</tr>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_companyname.":</td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='organization_name' value='".((isset($organization_name))?"".trim(stripslashes($organization_name))."":"")."'> ".$text_optional."</td>
	</tr>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err2))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_address1.":</td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='street_address_1' value='".((isset($street_address_1))?"".trim(stripslashes($street_address_1))."":"")."'> ".$text_required."</td>
	</tr>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'></td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='street_address_2' value='".((isset($street_address_2))?"".trim(stripslashes($street_address_2))."":"")."'> ".$text_optional."</td>
	</tr>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err3))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_city.":</td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='city' value='".((isset($city))?"".trim(stripslashes($city))."":"")."'> ".$text_required."</td>
	</tr>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err4))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_state.":</td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='state' value='".((isset($state))?"".trim(stripslashes($state))."":"")."'> ".$text_required."</td>
	</tr>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err5))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_postalcode.":</td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='zip_code' value='".((isset($zip_code))?"".trim(stripslashes($zip_code))."":"")."'> ".$text_required."</td>
	</tr>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err6))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_country.":</td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'>
	");
@country($country,$orderinput_style);
echo("
		<img src='".$http_images."/space.gif' width='5' height='9'>".$text_required."</td>
	</tr>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err7))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_phone.":</td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='phone' value='".((isset($phone))?"".trim(stripslashes($phone))."":"")."'> ".$text_required."</td>
	</tr>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_fax.":</td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='fax' value='".((isset($fax))?"".trim(stripslashes($fax))."":"")."'> ".$text_optional."</td>
	</tr>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err8))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_emailaddress.":</td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='email' value='".((isset($email))?"".trim(stripslashes($email))."":"")."'> ".$text_required."</td>
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'></td>
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'>".$text_clientarealogininfo."</td> 
	</tr>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err9))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_chooseusername.":</td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='username' value='".((isset($username))?"".trim(stripslashes($username))."":"")."'> ".$text_required."</td>
	</tr>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err10))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_choosepassword.":</td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='password' value='".((isset($password))?"".trim(stripslashes($password))."":"")."'> ".$text_required."</td>
	</tr>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err10))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_verifypassword.":</td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='password2' value='".((isset($password2))?"".trim(stripslashes($password2))."":"")."'> ".$text_required."</td>
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'></td>
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'>".$text_advertisinginfo."</td> 
	</tr>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err11)||isset($err12))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_howfound."</td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'>
		");
	@advert($advert,$orderinput_style);
	echo("
		 ".$text_required."</td>
	</tr>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'><img src='".$http_images."/".((isset($err12))?"error_arrow.gif":"space.gif")."' width='15' height='9'>".$text_ifother.":</td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'><input ".$orderinput_style." size='30' maxlength='255' type='text' name='advert_other' value='".((isset($advert_other))?"".trim(stripslashes($advert_other))."":"")."'></td>
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'></td>
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'>".$text_termsofservice."</td> 
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/".((isset($err13))?"error_arrow.gif":"space.gif")."' width='15' height='9'><input type='checkbox' name='tos' value='1'".((isset($tos))?"".((trim($tos)=="1")?" checked":"")."":"").">  ".$text_termsofservice2."<img src='".$http_images."/space.gif' width='22' height='1'>".$text_required."</td>
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='40' height='1'><img src='".$http_images."/error_arrow.gif'><a href='".$tos_agreement."'>".$text_viewterms."</a></td>
	</tr>
</table>
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td><img src='".$http_images."/space.gif' width='1' height='20'></td>
	</tr>
</table>
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td width='".$affiliate_leftcolumn."' align='left' valign='top'></td>
		<td width='".$affiliate_rightcolumn."' align='left' valign='top'><input ".$orderbutton_style." type='submit' name='submit' value='".$text_clicktorequestaffiliatestatus ."'></td>
	</tr>
</table>

</form>
	");
include "inc/footer.php";
mysql_close($dblink);
?>