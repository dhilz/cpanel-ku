<?PHP
include"inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/client_functions.php";
include "inc/whm_functions.php";
include "inc/affiliate_functions.php";

// authenicate sid 
if (auth_sid($sid)==1) { header("Location: ".$http_web."/clogin.php"); exit; }

// define status on entry
if (strlen(trim($status))==0)	{	$stats=0; $status=99; }
else if (!isset($status))		{ $stats=0; $status=99; }
else if (trim($status)=="99")	{ $stats=0; }
else if (trim($status)=="0")	{ $stats=1; }
else if (trim($status)=="1")	{ $stats=2; }
else if (trim($status)=="2")	{ $stats=3;}

if (isset($resend))
	{
	$query_rr="select ";
	$query_rr.="hosting_order.resolved, ";		// 0
	$query_rr.="hosting_order.addon_choices, "; // 1
	$query_rr.="plan_specs.rid, ";				// 2
	$query_rr.="plan_specs.dedicated ";			// 3
	$query_rr.="from ";
	$query_rr.="hosting_order, ";
	$query_rr.="plan_specs ";
	$query_rr.="where ";
	$query_rr.="hosting_order.oid='".addslashes(trim(base64_decode($c)))."' ";
	$query_rr.="and ";
	$query_rr.="hosting_order.pid=plan_specs.pid ";
	$query_rr.="order by hosting_order.oid asc ";
	$query_rr.="limit 0, 1";

	$rr=mysql_fetch_row(mysql_query($query_rr));

	if ($rr[3]==1) { send_dedicated_activation(36, base64_decode($c), 0); }
	else if ($rr[2]>0) { send_reseller_welcome_email(34,  base64_decode($c), 0); }
	else { resend_welcome_email_ip($email_admin, base64_decode($c), unique_ip_ordered($rr[1])); }
	}

// close trouble ticket
if (isset($tid))
	{
	if (trim($re)=="1")
		{
		// close the ticket
		$rsu=mysql_fetch_row(mysql_query("select uid from ticket where id='".addslashes(trim($tid))."'"));
		$rsux=mysql_fetch_row(mysql_query("select email from user where uid='".addslashes(trim($rsu[0]))."'"));
		$reply=$rsux[0];
			
		// build email 
		$headers="From: ".$reply."\n";
		$headers.="Reply-To: ".$reply."\n";
		$headers.="X-Mailer: PHP/".phpversion();
		
		// build message
		$message="This message was generated on: ".date("m/d/Y h:i:s a");

		// send the email
		mail($email_admin, "Ticket #: ".$tid." Closed", $message, $headers);

		mysql_query("update ticket set status='1', ogcreate='".addslashes(trim($og))."' where id='".addslashes(trim($tid))."'"); 
		}
	else if (trim($re)=="0")
		{
		// open the ticket
		$rsu=mysql_fetch_row(mysql_query("select uid from ticket where id='".addslashes(trim($tid))."'"));
		$rsux=mysql_fetch_row(mysql_query("select email from user where uid='".addslashes(trim($rsu[0]))."'"));
		$reply=$rsux[0];
			
		// build email 
		$headers="From: ".$reply."\n";
		$headers.="Reply-To: ".$reply."\n";
		$headers.="X-Mailer: PHP/".phpversion();
		
		// build message
		$message="This message was generated on: ".date("m/d/Y h:i:s a");

		// send the email
		mail($email_admin, "Ticket #: ".$tid." Re-Opened", $message, $headers);

		mysql_query("update ticket set status='0', ogcreate='".addslashes(trim($og))."' where id='".addslashes(trim($tid))."'"); 
		}
	else if (trim($re)=="2")
		{
		// delete the ticket
		mysql_query("delete from ticket where id='".addslashes(trim($tid))."'");
		mysql_query("delete from ticket_reply where id='".addslashes(trim($tid))."'"); 
		}
	}

// change the password
if (isset($change_password)) 
	{ 
	mysql_query("update user set password='".base64_encode(clogin_e($password))."' where uid='".addslashes(trim($uid))."'"); 
	
	// update the session
	# $sid=create_sid();
	# update_sid_w_uid($uid, $sid);
	}

// change the email addr
if (isset($change_email)) 
	{ 
	mysql_query("update user set email='".addslashes(trim($email))."' where uid='".addslashes(trim($uid))."'");
	
	// update the session
	# $sid=create_sid();
	# update_sid_w_uid($uid, $sid); 
	}

// affil: change ssn/tax id
if (isset($change_ssn_tax_id))
	{
	$ars0=mysql_fetch_row(mysql_query("select ogcreate from affiliate_user where uid='".addslashes(trim($uid))."'"));
	mysql_query("update affiliate_user set ogcreate='".addslashes(trim($ars[0]))."', ssn_tax_id='".addslashes(trim($ssn_tax_id))."' where uid='".addslashes(trim($uid))."'");
	}

// affil: change payalbe to
if (isset($change_payable_to))
	{
	$ars0=mysql_fetch_row(mysql_query("select ogcreate from affiliate_user where uid='".addslashes(trim($uid))."'"));
	mysql_query("update affiliate_user set ogcreate='".addslashes(trim($ars[0]))."', payable_to='".addslashes(trim($payable_to))."' where uid='".addslashes(trim($uid))."'");
	}

include "inc/header.php";

// build CLIENT INFORMATION query
$query="select ";
$query.="uid, ";				// 0
$query.="first_name, ";			// 1
$query.="last_name, ";			// 2
$query.="street_address_1, ";	// 3
$query.="street_address_2, ";	// 4
$query.="city, ";				// 5
$query.="state, ";				// 6
$query.="zip_code, ";			// 7
$query.="country, ";			// 8
$query.="phone, ";				// 9
$query.="fax, ";				// 10
$query.="email, ";				// 11
$query.="organization_name, ";	// 12
$query.="phone ";				// 13
$query.="from user ";
$query.="where sid='".addslashes(trim(cleanse_sid($sid)))."'";

// execute CLIENT INFORMATION query
$rs=mysql_fetch_row(mysql_query($query));

// define variables
$uid=stripslashes($rs[0]);
$first_name=stripslashes($rs[1]);
$last_name=stripslashes($rs[2]);
$street_address_1=stripslashes($rs[3]);
$street_address_2=stripslashes($rs[4]);
$city=stripslashes($rs[5]);
$state=stripslashes($rs[6]);
$zip=stripslashes($rs[7]);
$country=stripslashes($rs[8]);
$phone=stripslashes($rs[9]);
$fax=stripslashes($rs[10]);
$email=stripslashes($rs[11]);
$organization_name=stripslashes($rs[12]);
$phone=stripslashes($rs[13]);

echo("
<table width='100%' cellpadding='0' cellspacing='0' border='0'>
	<tr>
		<td width='50%' align='left' valign='top'>
	");
include $server_tools."/client_view_info.php";
echo("
		</td>
		<td width='50%' align='left' valign='top'>
		<table width='100%' border='0' cellspacing='1' cellpadding='2'>
			<tr>
				<td colspan='3' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><b>Admin / Site News</b></td></td>
			</tr>
			<tr>
				<td width='1%' align='left' valign='top'><img src='".$http_images."/space.gif' width='10' height='9'></td>
				<td width='98%' align='left' valign='top'><iframe src='".$http_web."/tools/client_view_news.php' frameborder='0' width='300' height='129' scrolling='yes'></iframe></td>
				<td width='1%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'></td>
			</tr>
		</table>
	");
include $server_tools."/client_view_new_order.php";

echo show_affiliate_client($http_images, $uid, $sid, $http_web);

echo("
		</td>
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'>$text_becomeaffiliate<hr color='#F0EFED'></td>
	</tr>
</table>
	");

if (strcmp($activate_support, "yes")==0)
	{
	include $server_tools."/client_view_trouble_ticket.php";
	}

echo("
<table width='100%' cellpadding='0' cellspacing='0' border='0'>
	<tr>
		<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='14'></td>
	</tr>
	<tr>
		<td align='left' valign='top'><hr color='#F0EFED'></td>
	</tr>
</table>
	");
include $server_tools."/client_view_domains.php";
echo("
<table width='100%' cellpadding='0' cellspacing='0' border='0'>
	<tr>
		<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='14'></td>
	</tr>
	<tr>
		<td align='left' valign='top'><hr color='#F0EFED'></td>
	</tr>
</table>
	");
$oid=base64_decode($c);
include $server_tools."/billable_service_history.php";
include "inc/footer.php";
mysql_close($dblink);
?>