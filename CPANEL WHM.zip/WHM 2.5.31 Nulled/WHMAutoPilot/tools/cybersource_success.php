<?php
include "inc/var.php";
include "inc/connect.php";
include "inc/client_functions.php";
include "inc/whm_functions.php";
include "inc/affiliate_functions.php";
include "inc/invoice_functions.php";
include "inc/varilogix_functions.php";

$sid=$_POST['ordtrack'];
/*
print_r($_POST);
echo "<BR><BR>";
#die;
#echo "<BR><BR>";
echo $_POST['invoicetype'];
echo "<BR>above is the invoice type<BR><BR>";

if ($sid=="") { $sid=$_POST['sid']; }
echo $sid."<-- session carried";
#die;
*/
$cybersource_validator=$_POST['decision'];
$cybersource_reference=$_POST['requestID'];
$cybersource_ordernumber=$_POST['orderNumber'];
$cybersource_authcode=$_POST['ccAuthReply_authorizationCode'];
$txn_id=$_POST['orderNumber'];
/*
$debug=true;
if ($debug) 
    { 
    echo "<br><br>The code: <br><br>"; 
    show_source("/home/demotest/public_html/isecure/cybersource_success.php");
    } 
die;
/*/
## if there is no reference number, fail the order
if (ereg($_POST['invoicetype'], "hosting"))
    {
	$sid=$_POST['sid'];
	header("Location: ".$http_web."/invoice_success.php?c=".$sid."");
	exit;
    }
if (ereg($_POST['invoicetype'], "service"))
    {
	$sid=$_POST['sid'];
	header("Location: ".$http_web."/invoice_success_service.php?c=".$sid."");
	exit;
    }
if (ereg($_POST['requestID'], "")) 
    { 
    raw_post_details($email_admin, "ERROR[77] There was no referenece number with this order!", "unknown", "cybersource");

	header("Location: ".$http_web."/step_one.php"); 
	exit; 
    } 
## if there is no order number, fail the order
if (ereg($_POST['orderNumber'], "")) 
    { 
     raw_post_details($email_admin, "ERROR[78] There was no order number with this order!", "unknown", "cybersource");

	header("Location: ".$http_web."/step_one.php"); 
	exit;  
    } 
# if there is no merchant ID, fail the order
if (ereg($_POST['ccAuthReply_authorizationCode'], "")) 
    { 
     raw_post_details($email_admin, "ERROR[81] Authorization Code was blank, this is an invalid order!", "unknown", "cybersource");

	header("Location: ".$http_web."/step_one.php"); 
	exit;  
    } 
/*
$_POST['decision']=strtolower($_POST['decision']);
if (!ereg("accept", $_POST['decision'])) 
	{ 
    echo "andy - this sucker failed"; 
    } 

if ($debug) 
    { 
    echo "<br><br>The code: <br><br>"; 
    show_source("/home/demotest/public_html/isecure/cybersource_success.php");
    } 
#die;
*/
## validate the session is a valid session, if not, fail the order
$cksid=mysql_fetch_row(mysql_query("select count(*) from session_history where sid='".addslashes(trim($sid))."'"));
if ($cksid[0]<=0) 
	{ 
	# added 6/2/2004
	raw_post_details($email_admin, "ERROR[41] SID was not in the database!", "unknown", "cybersource");

	header("Location: ".$http_web."/step_one.php"); 
	exit; 
	}

#die;
## revalidate the session one more time ?
$cksid=mysql_fetch_row(mysql_query("select count(*) from session_history where sid='".addslashes(trim($sid))."'"));
if ($cksid[0]<=0) { header("Location: ".$http_web."/step_one.php"); exit; }
else if (!isset($sid)) { header("Location: ".$http_web."/step_one.php"); exit; }

$query0="select ";
$query0.="first_name, ";		// 0
$query0.="last_name, ";			// 1
$query0.="organization_name, ";	// 2
$query0.="street_address_1, ";	// 3
$query0.="street_address_2, ";	// 4
$query0.="city, ";				// 5
$query0.="state, ";				// 6
$query0.="zip_code, ";			// 7
$query0.="country, ";			// 8
$query0.="phone, ";				// 9
$query0.="fax, ";				// 10
$query0.="email, ";				// 11
$query0.="username, ";			// 12
$query0.="password, ";			// 13
$query0.="advert, ";			// 14
$query0.="advert_other, ";		// 15
$query0.="tos, ";				// 16
$query0.="pid, ";				// 17
$query0.="payment_term, ";		// 18
$query0.="domain_name, ";		// 19
$query0.="payment_method, ";	// 20
$query0.="domain_registration, ";	// 21
$query0.="domain_expire, ";		// 22
$query0.="whm_username, ";		// 23
$query0.="whm_password, ";		// 24
$query0.="promotion_code, ";	// 25
$query0.="referrer_id, ";		// 26
$query0.="client_ip, ";			// 27
$query0.="total_due_today, ";	// 28
$query0.="total_due_reoccur, ";	// 29
$query0.="uid, ";				// 30
$query0.="addon_choices, ";		// 31
$query0.="client_notes, ";		// 32
$query0.="pns1, ";				// 33
$query0.="pns2, ";				// 34
$query0.="server_hostname, ";	// 35
$query0.="root_pw, ";			// 36
$query0.="tld, ";				// 37
$query0.="sorp, ";				// 38
$query0.="fraudcall_api_response, ";// 39
$query0.="fraudcall_score, ";	// 40
$query0.="lpid ";				// 41
$query0.="from session_history ";
$query0.="where sid='".addslashes(trim($sid))."'";

$rs0=mysql_fetch_row(mysql_query($query0));

$first_name=stripslashes(trim($rs0[0]));
$last_name=stripslashes(trim($rs0[1]));
$organization_name=stripslashes(trim($rs0[2]));
$street_address_1=stripslashes(trim($rs0[3]));
$street_address_2=stripslashes(trim($rs0[4]));
$city=stripslashes(trim($rs0[5]));
$state=stripslashes(trim($rs0[6]));
$zip_code=stripslashes(trim($rs0[7]));
$country=stripslashes(trim($rs0[8]));
$phone=stripslashes(trim($rs0[9]));
$fax=stripslashes(trim($rs0[10]));
$email=stripslashes(trim($rs0[11]));
$username=stripslashes(trim($rs0[12]));
$password=stripslashes(trim($rs0[13]));
$advert=stripslashes(trim($rs0[14]));
$advert_other=stripslashes(trim($rs0[15]));
$tos=stripslashes(trim($rs0[16]));
$pid=stripslashes(trim($rs0[17]));
$payment_term=stripslashes(trim($rs0[18]));
$domain_name=stripslashes(trim($rs0[19]));
$payment_method=stripslashes(trim($rs0[20]));
$domain_registration=stripslashes(trim($rs0[21]));
$domain_expire=stripslashes(trim($rs0[22]));
$whm_username=stripslashes(trim($rs0[23]));
$whm_password=stripslashes(trim($rs0[24]));
$promotion_code=stripslashes(trim($rs0[25]));
$referrer_id=stripslashes(trim($rs0[26]));
$client_ip=stripslashes(trim($rs0[27]));
$total_due_today=stripslashes(trim($rs0[28]));
$total_due_reoccur=stripslashes(trim($rs0[29]));
$uid=stripslashes(trim($rs0[30]));
$addon_choices=stripslashes(trim($rs0[31]));
$client_notes=stripslashes(trim($rs0[32]));
$pns1=stripslashes(trim($rs0[33]));
$pns2=stripslashes(trim($rs0[34]));
$server_hostname=stripslashes(trim($rs0[35]));
$root_pw=stripslashes(trim($rs0[36]));

# added 11/24/2003
# -----------------------------------------
$tld_id=stripslashes(trim($rs0[37]));
# -----------------------------------------
# added 11/24/2003

$sorp=stripslashes(trim($rs0[38]));

# added for linkpoint
$lpid=stripslashes(trim($rs0[41]));

# added 7/9/2004
# -----------------------------------------
$fraudcall_api_response=stripslashes(trim($rs0[39]));
$fraudcall_score=stripslashes(trim($rs0[40]));
$fc_transaction=$fraudcall_api_response."|".$fraudcall_score;

# using fraud call?
$query="select ";
$query.="fraudcall_value ";
$query.="from ";
$query.="autopilot_fraudcall ";
$query.="where ";
$query.="fraudcall_key='activate_fraud_call' ";
$query.="limit 0, 1";

$rs=mysql_fetch_row(mysql_query($query));

$using_FC=$rs[0];
if (strcmp($using_FC, "yes")==0) 
	{
	# process api response
	$fraudcall_key="install_".clean_number($fraudcall_api_response);

	# rewrite the fraudcall_key
	if ($fraudcall_score<=3.50
		&&strcmp($fraudcall_api_response, "3.1.0")==0) { $fraudcall_key="fraud_low"; }
	else if ($fraudcall_score>=3.51
		&&$fraudcall_score<=7
		&&strcmp($fraudcall_api_response, "3.1.0")==0) { $fraudcall_key="fraud_mid"; }
	else if ($fraudcall_score>=7
		&&strcmp($fraudcall_api_response, "3.1.0")==0) { $fraudcall_key="fraud_high"; }

	$query="select ";
	$query.="fraudcall_value, ";
	$query.="fraudcall_message ";
	$query.="from ";
	$query.="autopilot_fraudcall ";
	$query.="where ";
	$query.="fraudcall_key='".addslashes(trim($fraudcall_key))."' ";
	$query.="limit 0, 1";

	$rs=mysql_fetch_row(mysql_query($query));
	
	if (strcmp($rs[0], "no")==0) { $stop_says_fraudcall=true; }
	}

# -----------------------------------------
# added 7/9/2004

list($w_domain, $wo_domain)=explode("{}", $description);

if ($domain_registration==1)
	{
	$query_tld="select ";
	$query_tld.="tld ";
	$query_tld.="from ";
	$query_tld.="tld_chart ";
	$query_tld.="where ";
	$query_tld.="tld_id='".addslashes(trim($tld_id))."'";

	$rs_tld=mysql_fetch_row(mysql_query($query_tld));

	$domain_name.=".".$rs_tld[0];
	$description=$wo_domain." [".$domain_name."]";
	}
else { $description=$w_domain; }

// find the active server
$current_server=current_server($sid, 1);

// get the server details
$query1="select ";
$query1.="server_ip, ";		// 0
$query1.="whm_id, ";		// 1
$query1.="reseller, ";		// 2
$query1.="primary_ns, ";	// 3
$query1.="secondary_ns, ";	// 4 

# added 7/2/2003
# -----------------------------------------
$query1.="primary_ns_ip, ";	// 5
$query1.="secondary_ns_ip ";// 6
# -----------------------------------------
# added 7/2/2003

$query1.="from server_config ";

if ($current_server==99)
	{
	$query_nsip="select ";
	$query_nsip.="whm_id ";
	$query_nsip.="from ";
	$query_nsip.="server_config ";
	$query_nsip.="order by whm_id desc ";
	$query_nsip.="limit 0, 1";

	$rs_nsip=mysql_fetch_row(mysql_query($query_nsip));

	$query1.="where whm_id='".addslashes(trim($rs_nsip[0]))."'";

	$temp=@read_log($rs_nsip[0], $below_public);
	}
else 
	{ 
	$query1.="where whm_id='".addslashes(trim($current_server))."'";
	
	$temp=@read_log($current_server, $below_public); 
	}

$rs1=mysql_fetch_row(mysql_query($query1));

$server_ip=stripslashes(trim($rs1[0]));
$whm_id=stripslashes(trim($rs1[1]));
$reseller=stripslashes(trim($rs1[2]));
$primary_ns=stripslashes(trim($rs1[3]));
$secondary_ns=stripslashes(trim($rs1[4]));

list($xwhm_username, $xwhm_password)=split("[|]", $temp);

// get the IP for the account or use the shared
if ($reseller==0) 
	{ 
	$unique_ip_ordered=unique_ip_ordered($addon_choices);
	if ($unique_ip_ordered==1) { $default_ip=get_free_ips($server_ip, $xwhm_username, $xwhm_password); }
	else { $default_ip=$server_ip; }
	}
else { $default_ip=$server_ip; }

// it's a valid auto install
if ($current_server!=99&&!isset($stop_says_fraudcall))
	{	
	// extra space ordered?
	$extra_space=extra_webspace_ordered($addon_choices);

	$query2="select ";
	$query2.="cgi_access, ";		// 0
	$query2.="web_space, ";			// 1
	$query2.="frontpage, ";			// 2
	$query2.="cpanel_theme, ";		// 3
	$query2.="ftp, ";				// 4
	$query2.="sql, ";				// 5 
	$query2.="email, ";				// 6
	$query2.="email_list, ";		// 7
	$query2.="sub_domain, ";		// 8
	$query2.="bandwidth, ";			// 9
	$query2.="shell_access, ";		// 10
	$query2.="parked_domain, ";		// 11
	$query2.="addon_domain, ";		// 12
	$query2.="gid, ";				// 13
	$query2.="whm_package_name, ";	// 14
	$query2.="rid, ";	// 15
	$query2.="dedicated ";	// 16
	$query2.="from plan_specs ";		
	$query2.="where pid='".addslashes(trim($pid))."'";

	$rs2=mysql_fetch_row(mysql_query($query2));

	$cgi=stripslashes($rs2[0]);
	if (trim($extra_space)=="0") { $quota=stripslashes($rs2[1]); }
	else { $quota=stripslashes($rs2[1]+$extra_space); }
	$frontpage=stripslashes($rs2[2]);
	$cpmod=stripslashes($rs2[3]);
	$maxftp=stripslashes($rs2[4]);
	$maxsql=stripslashes($rs2[5]);
	$maxpop=stripslashes($rs2[6]);
	$maxlst=stripslashes($rs2[7]);
	$maxsub=stripslashes($rs2[8]);
	$bwlimit=stripslashes($rs2[9]);
	$hasshell=stripslashes($rs2[10]);
	$maxpark=stripslashes($rspd[11]);
	$maxaddon=stripslashes($rs2[12]);
	$gid=stripslashes($rs2[13]);
	$whm_package_name=stripslashes($rs2[14]);
	$rid=stripslashes($rs2[15]);
	$dedicated=stripslashes($rs2[16]);
	
	if ($dedicated==0)
		{
		if ($reseller==0)
			{
			$account_creation_status=create_account($server_ip, $xwhm_username, $xwhm_password, $domain_name, $whm_username, $whm_password, $unique_ip_ordered, $cgi, $quota, $frontpage, $cpmod, $maxftp, $maxsql, $maxpop, $maxlst, $maxsub, $bwlimit, $hasshell, $maxpark, $maxaddon, $whm_package_name, $default_ip);
			}
		else
			{
			$account_creation_status=create_account($server_ip, $xwhm_username, $xwhm_password, $domain_name, $whm_username, $whm_password, 0, $cgi, $quota, $frontpage, $cpmod, $maxftp, $maxsql, $maxpop, $maxlst, $maxsub, $bwlimit, $hasshell, $maxpark, $maxaddon, $whm_package_name, $default_ip);
			}
		}

	// account installed successful
	if ($account_creation_status==99)
		{
		if ($uid==0)
			{
			$insert="insert into user set ";
			$insert.="first_name='".addslashes(trim($first_name))."', ";
			$insert.="last_name='".addslashes(trim($last_name))."', ";
			if (strlen(trim($organization_name))!=0) { $insert.="organization_name='".addslashes(trim($organization_name))."', "; }
			$insert.="street_address_1='".addslashes(trim($street_address_1))."', ";
			if (strlen(trim($street_address_2))!=0) { $insert.="street_address_2='".addslashes(trim($street_address_2))."', "; }
			$insert.="city='".addslashes(trim($city))."', ";
			$insert.="state='".addslashes(trim($state))."', ";
			$insert.="zip_code='".addslashes(trim($zip_code))."', ";
			$insert.="country='".addslashes(trim($country))."', ";
			$insert.="phone='".addslashes(trim($phone))."', ";
			$insert.="fax='".addslashes(trim($fax))."', ";
			$insert.="email='".addslashes(trim($email))."', ";
			$insert.="username='".addslashes(trim($username))."', ";

			$enc_pw=base64_encode(clogin_e($password));
			$insert.="password='".$enc_pw."', ";

			$insert.="advert='".addslashes(trim($advert))."', ";
			$insert.="advert_other='".addslashes(trim($advert_other))."', ";
			$insert.="temp_pw='".addslashes(trim($password))."', "; // delete this at first login
			$insert.="tos='1',";
			$insert.="sid='".create_sid()."',";
			$insert.="ogcreate='".time()."'";

			mysql_query($insert);
			$uid=mysql_insert_id();
			
			if ($phpbb_active=="yes") { migrate_user_to_phpbb($username, $enc_pw, $email); }

			$write_master_batch=true;
			}
		else
			{			
			$update="update user set ";
			$update.="first_name='".addslashes(trim($first_name))."', ";
			$update.="last_name='".addslashes(trim($last_name))."', ";
			if (strlen(trim($organization_name))!=0) { $update.="organization_name='".addslashes(trim($organization_name))."', "; }
			$update.="street_address_1='".addslashes(trim($street_address_1))."', ";
			if (strlen(trim($street_address_2))!=0) { $update.="street_address_2='".addslashes(trim($street_address_2))."', "; }
			$update.="city='".addslashes(trim($city))."', ";
			$update.="state='".addslashes(trim($state))."', ";
			$update.="zip_code='".addslashes(trim($zip_code))."', ";
			$update.="country='".addslashes(trim($country))."', ";
			$update.="phone='".addslashes(trim($phone))."', ";
			$update.="fax='".addslashes(trim($fax))."', ";
			$update.="email='".addslashes(trim($email))."', ";
			$update.="advert='".addslashes(trim($advert))."', ";
			$update.="advert_other='".addslashes(trim($advert_other))."', ";
			$update.="tos='1' ";
			$update.="where uid='".addslashes(trim($uid))."'";

			mysql_query($update);
			}
		
		# calc next due date
		# -------------------------------------------------------------------------------------------------------
		# which == 0 == return timestamp from todays date
		# which == 1 == use hosting order ogcreate to build next due date
		$next_due_date=find_next_due($payment_term, 0, 0);
		list($proc_bit, $other)=explode("|", $next_due_date);
		if ($proc_bit==0) 
			{ 
			$subject="[AutoPilot System] Possible Invalid Start Date";
			$message="Please check that the start date for ".$other." is correct. We could not create a next due date for this order.";
			mail($email_admin, $subject, $message, "From: ".$email_admin."\nReply-To: ".$email_admin."\nX-Mailer: PHP/".phpversion());
			$next_due_date="";  
			}
		else { $next_due_date=$other; }
		# -------------------------------------------------------------------------------------------------------
		# END calc next due date

		$insert_order="insert into hosting_order set ";
		$insert_order.="sorp='".addslashes(trim($sorp))."', ";
		$insert_order.="uid='".addslashes(trim($uid))."', ";
		# $insert_order.="next_due_date='".addslashes(trim($next_due_date))."', ";
		$insert_order.="pid='".addslashes(trim($pid))."', ";
		$insert_order.="domain_name='".addslashes(trim($domain_name))."', ";
		$insert_order.="domain_registration='".addslashes(trim($domain_registration))."', ";
		$insert_order.="domain_expire='".addslashes(trim($domain_expire))."', ";
		$insert_order.="payment_method='".addslashes(trim($payment_method))."', ";
		$insert_order.="payment_term='".addslashes(trim($payment_term))."', ";
		$insert_order.="addon_choices='".addslashes(trim($addon_choices))."', ";
		$insert_order.="ns1='".addslashes(trim($primary_ns))."', "; 
		$insert_order.="ns2='".addslashes(trim($secondary_ns))."', ";
		$insert_order.="ip='".addslashes(trim($default_ip))."', ";
		$insert_order.="total_due_today='".addslashes(trim($total_due_today))."', ";
		$insert_order.="total_due_reoccur='".addslashes(trim($total_due_reoccur))."', ";
		$insert_order.="promotion_code='".addslashes(trim($promotion_code))."', ";
		$insert_order.="referrer_id='".addslashes(trim($referrer_id))."', ";
		$insert_order.="whm_username='".addslashes(trim($whm_username))."', ";
		$insert_order.="whm_password='".addslashes(trim($whm_password))."', ";
		$insert_order.="whm_id='".addslashes(trim($current_server))."', ";
		$insert_order.="client_notes='".addslashes(trim($client_notes))."', ";
		$insert_order.="pns1='".addslashes(trim($pns1))."', ";
		$insert_order.="pns2='".addslashes(trim($pns2))."', ";
		$insert_order.="server_hostname='".addslashes(trim($server_hostname))."', ";
		$insert_order.="root_pw='".addslashes(trim($root_pw))."', ";
		$insert_order.="status='1', ";
		
		# added 7/9/2004
		if (strcmp($using_FC, "yes")==0) { $insert_order.="fraudcall_score='".addslashes(trim($fraudcall_score))."', "; }

		if ($dedicated==1) { $insert_order.="resolved='1', "; }
		if ($domain_registration==1) { $insert_order.="tld_id='".addslashes(trim($tld_id))."', "; }
		
		if (getenv('HTTP_X_FORWARDED_FOR')) { $client_ip=getenv('HTTP_X_FORWARD_FOR'); } 
		else { $client_ip=getenv('REMOTE_ADDR'); }

		$insert_order.="client_ip='".addslashes(trim($client_ip))."', ";
		$insert_order.="client_host='".@gethostbyaddr($client_ip)."', ";
		$insert_order.="next_due_date='".time()."', ";
		$insert_order.="ogcreate='".time()."', ";
		$insert_order.="txn_id='".addslashes(trim($txn_id))."'";

		mysql_query($insert_order);

		$oid=mysql_insert_id();
		
		$invoice_number=create_new_invoice($oid, 1);
		if ($domain_registration==1&&$use_enom==0) { domain_reg_notice($oid); }

		# added 10/16/2003
		$nq2="update ";
		$nq2.="hosting_order ";
		$nq2.="set ";
		$nq2.="next_due_date='".create_next_due(time(), convert_payment_term_to_number($payment_term))."' ";
		$nq2.="where ";
		$nq2.="oid='".addslashes(trim($oid))."'";
		
		mysql_query($nq2);

		# added 10/16/2003

		# ---------------------------------------------------------------------------------
		if ($ccid==0)
			{
			
			}
/*
		# create the batch
		$query="insert into ";
		$query.="authnet_batch ";
		$query.="set ";
		$query.="customer_ip_address='".$customer_ip_address."', ";
		$query.="description='".$description."', ";
		$query.="currency_code='".addslashes(trim($currency_code))."', ";
		$query.="transaction_type='".addslashes(trim($transaction_type))."', ";
		$query.="recurring_billing='YES', ";
		$query.="payment_method='CC', ";
		# not being marked as paid in demo b/c only live trans return batch status
		$query.="batch_status='".addslashes(trim($batch_status))."', "; 
		$query.="response_reason_text='".addslashes(trim($response_reason_text))."', ";
		$query.="oid='".addslashes(trim($oid))."', ";
		$query.="uid='".addslashes(trim($uid))."', ";
		$query.="master_batch='1', ";
		$query.="ogcreate='".time()."', ";
		$query.="invoice_number='".addslashes(trim($invoice_number))."', ";
		$query.="txn_id='".addslashes(trim($txn_id))."', ";
		$query.="ccid='".addslashes(trim($ccid))."'";

		mysql_query($query);
*/
		# $bid=mysql_insert_id();
		# mysql_query("update authnet_batch set invoice_number='".addslashes(trim($invoice_number))."' where bid='".$bid."'");
		# ---------------------------------------------------------------------------------
		
		# START EDITED FOR RESELLER 7/2/2003
		# -----------------------------------------------------------------------------------------
		if ($rid!=0&&trim($rid)!=""&&$dedicated==0)
			{
			# 1a. set resellers primary domain to the order id
			$rq0="select ";
			$rq0.="reseller_primary_domain, ";
			$rq0.="ogcreate ";
			$rq0.="from ";
			$rq0.="user ";
			$rq0.="where ";
			$rq0.="uid='".addslashes(trim($uid))."'";
			$mrd=mysql_fetch_row(mysql_query($rq0));

			if ($mrd[0]==0)
				{
				$rq1="update ";
				$rq1.="user ";
				$rq1.="set ";
				$rq1.="reseller_primary_domain='".addslashes(trim($oid))."', ";
				$rq1.="reseller='1' ";
				$rq1.="where ";
				$rq1.="uid='".addslashes(trim($uid))."'";
				mysql_query($rq1);
				}

			# 1b. set the reseller flag in the hosting order to 1
			$rq2="update ";
			$rq2.="hosting_order ";
			$rq2.="set ";
			$rq2.="reseller='1', ";
			$rq2.="ogcreate='".time()."' ";
			$rq2.="where ";
			$rq2.="oid='".addslashes(trim($oid))."'";

			mysql_query($rq2);
			
			create_reseller($server_ip, $xwhm_username, $xwhm_password, $whm_username, $rid);

			# add a entries if private ns are ordered - going to introduce later 7/4/2003
			
			send_reseller_welcome_email(34, $oid);
			}
		else { send_welcome_email_ip($email_admin, $oid, $unique_ip_ordered); }

		// send emails 
		send_dns_config($email_admin, $oid);
		new_account_installed($email_admin, $oid, $currency, $currency_type, $addon_choices);

		# -----------------------------------------------------------------------------------------
		# END EDITED FOR RESELLER 7/2/2003

		// check server status
		auto_switch_server($below_public, $email_admin);
		
		// affiliate functions
		if (strlen(trim($referrer_id))!=0)
			{
			// add the affiliate details
			add_new_referred_client($pid, $referrer_id, $uid, $oid);

			// send out affiliate email
			affiliate_notification_to_client($uid, $oid, $email_admin);
			}

		// delete the session for security
		mysql_query("delete from session_history where sid='".addslashes(trim($sid))."'");
	
		// redirect to the next step
		$data=base64_encode($gid."|".$oid);

		$read=fopen($below_public."/".$data."_invoice.log", "w");
		fwrite($read, $data);
		fclose($read);
		
		// redirect to the next step
		header("Location: ".$http_web."/".(($use_enom==1&&$domain_registration==1)?"register_enom":"invoice_new").".php?c=".$data."".(($dedicated==0)?"":"&dedicated=1")."");
		exit;
		}

	// account failed to auto install
	else
		{
		if ($uid==0)
			{
			$insert="insert into user set ";
			$insert.="first_name='".addslashes(trim($first_name))."', ";
			$insert.="last_name='".addslashes(trim($last_name))."', ";
			if (strlen(trim($organization_name))!=0) { $insert.="organization_name='".addslashes(trim($organization_name))."', "; }
			$insert.="street_address_1='".addslashes(trim($street_address_1))."', ";
			if (strlen(trim($street_address_2))!=0) { $insert.="street_address_2='".addslashes(trim($street_address_2))."', "; }
			$insert.="city='".addslashes(trim($city))."', ";
			$insert.="state='".addslashes(trim($state))."', ";
			$insert.="zip_code='".addslashes(trim($zip_code))."', ";
			$insert.="country='".addslashes(trim($country))."', ";
			$insert.="phone='".addslashes(trim($phone))."', ";
			$insert.="fax='".addslashes(trim($fax))."', ";
			$insert.="email='".addslashes(trim($email))."', ";
			$insert.="username='".addslashes(trim($username))."', ";
			$enc_pw=base64_encode(clogin_e($password));
			$insert.="password='".$enc_pw."', ";
			$insert.="advert='".addslashes(trim($advert))."', ";
			$insert.="advert_other='".addslashes(trim($advert_other))."', ";
			$insert.="temp_pw='".addslashes(trim($password))."', "; // delete this at first login
			$insert.="tos='1',";
			$insert.="sid='".create_sid()."',";
			$insert.="ogcreate='".time()."'";

			mysql_query($insert);

			$uid=mysql_insert_id();
			}
		else
			{			
			$update="update user set ";
			$update.="first_name='".addslashes(trim($first_name))."', ";
			$update.="last_name='".addslashes(trim($last_name))."', ";
			if (strlen(trim($organization_name))!=0) { $update.="organization_name='".addslashes(trim($organization_name))."', "; }
			$update.="street_address_1='".addslashes(trim($street_address_1))."', ";
			if (strlen(trim($street_address_2))!=0) { $update.="street_address_2='".addslashes(trim($street_address_2))."', "; }
			$update.="city='".addslashes(trim($city))."', ";
			$update.="state='".addslashes(trim($state))."', ";
			$update.="zip_code='".addslashes(trim($zip_code))."', ";
			$update.="country='".addslashes(trim($country))."', ";
			$update.="phone='".addslashes(trim($phone))."', ";
			$update.="fax='".addslashes(trim($fax))."', ";
			$update.="email='".addslashes(trim($email))."', ";
			$update.="advert='".addslashes(trim($advert))."', ";
			$update.="advert_other='".addslashes(trim($advert_other))."', ";
			$update.="tos='1' ";
			$update.="where uid='".addslashes(trim($uid))."'";

			mysql_query($update);
			}

		$insert_order="insert into hosting_order set ";
		$insert_order.="sorp='".addslashes(trim($sorp))."', ";
		$insert_order.="uid='".addslashes(trim($uid))."', ";
		$insert_order.="pid='".addslashes(trim($pid))."', ";
		$insert_order.="domain_name='".addslashes(trim($domain_name))."', ";
		$insert_order.="domain_registration='".addslashes(trim($domain_registration))."', ";
		$insert_order.="domain_expire='".addslashes(trim($domain_expire))."', ";
		$insert_order.="payment_method='".addslashes(trim($payment_method))."', ";
		$insert_order.="payment_term='".addslashes(trim($payment_term))."', ";
		$insert_order.="addon_choices='".addslashes(trim($addon_choices))."', ";
		$insert_order.="ns1='".addslashes(trim($primary_ns))."', "; 
		$insert_order.="ns2='".addslashes(trim($secondary_ns))."', ";
		$insert_order.="ip='".addslashes(trim($default_ip))."', ";
		$insert_order.="total_due_today='".addslashes(trim($total_due_today))."', ";
		$insert_order.="total_due_reoccur='".addslashes(trim($total_due_reoccur))."', ";
		$insert_order.="promotion_code='".addslashes(trim($promotion_code))."', ";
		$insert_order.="referrer_id='".addslashes(trim($referrer_id))."', ";
		$insert_order.="whm_username='".addslashes(trim($whm_username))."', ";
		$insert_order.="whm_password='".addslashes(trim($whm_password))."', ";
		$insert_order.="whm_id='".addslashes(trim($current_server))."', ";
		$insert_order.="client_notes='".addslashes(trim($client_notes))."', ";
		$insert_order.="pns1='".addslashes(trim($pns1))."', ";
		$insert_order.="pns2='".addslashes(trim($pns2))."', ";
		$insert_order.="server_hostname='".addslashes(trim($server_hostname))."', ";
		$insert_order.="root_pw='".addslashes(trim($root_pw))."', ";
		$insert_order.="status='0', ";
		
		# added 7/9/2004
		if (strcmp($using_FC, "yes")==0) { $insert_order.="fraudcall_score='".addslashes(trim($fraudcall_score))."', "; }

		if ($dedicated==1) { $insert_order.="resolved='1', "; }
		if ($domain_registration==1) { $insert_order.="tld_id='".addslashes(trim($tld_id))."', "; }
		
		if (getenv('HTTP_X_FORWARDED_FOR')) { $client_ip=getenv('HTTP_X_FORWARD_FOR'); } 
		else { $client_ip=getenv('REMOTE_ADDR'); }

		$insert_order.="client_ip='".addslashes(trim($client_ip))."', ";
		$insert_order.="client_host='".@gethostbyaddr($client_ip)."', ";
		$insert_order.="next_due_date='".time()."', ";
		$insert_order.="ogcreate='".time()."'";
		
		mysql_query($insert_order);

		$oid=mysql_insert_id();

		$invoice_number=create_new_invoice($oid, 1);
		if ($domain_registration==1&&$use_enom==0) { domain_reg_notice($oid); }

		# added 10/16/2003
		$nq2="update ";
		$nq2.="hosting_order ";
		$nq2.="set ";
		$nq2.="next_due_date='".create_next_due(time(), convert_payment_term_to_number($payment_term))."' ";
		$nq2.="where ";
		$nq2.="oid='".addslashes(trim($oid))."'";
		
		mysql_query($nq2);

		# added 10/16/2003

		# ---------------------------------------------------------------------------------

		if ($ccid==0)
			{
			
			}
/*
		# create the batch
		$query="insert into ";
		$query.="authnet_batch ";
		$query.="set ";
		$query.="customer_ip_address='".$customer_ip_address."', ";
		$query.="description='".$description."', ";
		$query.="currency_code='".addslashes(trim($currency_code))."', ";
		$query.="transaction_type='".addslashes(trim($transaction_type))."', ";
		$query.="recurring_billing='YES', ";
		$query.="payment_method='CC', ";
		$query.="batch_status='".addslashes(trim($batch_status))."', ";
		$query.="response_reason_text='".addslashes(trim($response_reason_text))."', ";
		$query.="oid='".addslashes(trim($oid))."', ";
		$query.="uid='".addslashes(trim($uid))."', ";
		$query.="master_batch='1', ";
		$query.="ogcreate='".time()."', ";
		$query.="invoice_number='".addslashes(trim($invoice_number))."', ";
		$query.="txn_id='".addslashes(trim($txn_id))."', ";
		$query.="ccid='".addslashes(trim($ccid))."'";

		mysql_query($query);
*/
		# $bid=mysql_insert_id();
		# mysql_query("update authnet_batch set invoice_number='".addslashes(trim($invoice_number))."' where bid='".$bid."'");
		# ---------------------------------------------------------------------------------
		
		// affiliate functions
		if (strlen(trim($referrer_id))!=0)
			{
			// add the affiliate details
			add_new_referred_client($pid, $referrer_id, $uid, $oid);
			}
		
		// send out new order rec. email to clients
#		new_order_received($email_admin, $sid, $currency, $currency_type, $addon_choices);
		
		// send out email to notify admin
		new_account_installed($email_admin, $oid, $currency, $currency_type, $addon_choices);
		
		if ($dedicated==0)
			{
			$xmessage=("Greetings,\nThe recent order for ".$domain_name." failed. Web Host Manager returned: ".parse_whm_error($account_creation_status)."\n\nThanks,\nYour AutoPilot\n\nThis message was generated on: ".date("m/d/Y h:i:s a")."");
			mail($email_admin, "WHM Automation Error", $xmessage, "From: ".$email_admin."\nReply-To: ".$email_admin."\nX-Mailer: PHP/" . phpversion());
			}

		// delete the session for security
		mysql_query("delete from session_history where sid='".addslashes(trim($sid))."'");
	
		// redirect to the next step
		$data=base64_encode($gid."|".$oid);

		$read=fopen($below_public."/".$data."_invoice.log", "w");
		fwrite($read, $data);
		fclose($read);
		
		// redirect to the next step
		header("Location: ".$http_web."/".(($use_enom==1&&$domain_registration==1)?"register_enom":"invoice_new").".php?c=".$data."".(($dedicated==0)?"&auto_create_error=5":"&dedicated=1")."");
		exit;
		}
	}



// account is manual install
else
	{
	if ($uid==0)
		{
		$insert="insert into user set ";
		$insert.="first_name='".addslashes(trim($first_name))."', ";
		$insert.="last_name='".addslashes(trim($last_name))."', ";
		if (strlen(trim($organization_name))!=0) { $insert.="organization_name='".addslashes(trim($organization_name))."', "; }
		$insert.="street_address_1='".addslashes(trim($street_address_1))."', ";
		if (strlen(trim($street_address_2))!=0) { $insert.="street_address_2='".addslashes(trim($street_address_2))."', "; }
		$insert.="city='".addslashes(trim($city))."', ";
		$insert.="state='".addslashes(trim($state))."', ";
		$insert.="zip_code='".addslashes(trim($zip_code))."', ";
		$insert.="country='".addslashes(trim($country))."', ";
		$insert.="phone='".addslashes(trim($phone))."', ";
		$insert.="fax='".addslashes(trim($fax))."', ";
		$insert.="email='".addslashes(trim($email))."', ";
		$insert.="username='".addslashes(trim($username))."', ";
		$enc_pw=base64_encode(clogin_e($password));
		$insert.="password='".$enc_pw."', ";
		$insert.="advert='".addslashes(trim($advert))."', ";
		$insert.="advert_other='".addslashes(trim($advert_other))."', ";
		$insert.="temp_pw='".addslashes(trim($password))."', "; // delete this at first login
		$insert.="tos='1',";
		$insert.="sid='".create_sid()."',";
		$insert.="ogcreate='".time()."'";

		mysql_query($insert);
		$uid=mysql_insert_id();
		}
	else
		{			
		$update="update user set ";
		$update.="first_name='".addslashes(trim($first_name))."', ";
		$update.="last_name='".addslashes(trim($last_name))."', ";
		if (strlen(trim($organization_name))!=0) { $update.="organization_name='".addslashes(trim($organization_name))."', "; }
		$update.="street_address_1='".addslashes(trim($street_address_1))."', ";
		if (strlen(trim($street_address_2))!=0) { $update.="street_address_2='".addslashes(trim($street_address_2))."', "; }
		$update.="city='".addslashes(trim($city))."', ";
		$update.="state='".addslashes(trim($state))."', ";
		$update.="zip_code='".addslashes(trim($zip_code))."', ";
		$update.="country='".addslashes(trim($country))."', ";
		$update.="phone='".addslashes(trim($phone))."', ";
		$update.="fax='".addslashes(trim($fax))."', ";
		$update.="email='".addslashes(trim($email))."', ";
		$update.="advert='".addslashes(trim($advert))."', ";
		$update.="advert_other='".addslashes(trim($advert_other))."', ";
		$update.="tos='1' ";
		$update.="where uid='".addslashes(trim($uid))."'";

		mysql_query($update);
		}

	$insert_order="insert into hosting_order set ";
	$insert_order.="sorp='".addslashes(trim($sorp))."', ";
	$insert_order.="uid='".addslashes(trim($uid))."', ";
	$insert_order.="pid='".addslashes(trim($pid))."', ";
	$insert_order.="domain_name='".addslashes(trim($domain_name))."', ";
	$insert_order.="domain_registration='".addslashes(trim($domain_registration))."', ";
	$insert_order.="domain_expire='".addslashes(trim($domain_expire))."', ";
	$insert_order.="payment_method='".addslashes(trim($payment_method))."', ";
	$insert_order.="payment_term='".addslashes(trim($payment_term))."', ";
	$insert_order.="addon_choices='".addslashes(trim($addon_choices))."', ";
	$insert_order.="ns1='".addslashes(trim($primary_ns))."', "; 
	$insert_order.="ns2='".addslashes(trim($secondary_ns))."', ";
	$insert_order.="ip='".addslashes(trim($default_ip))."', ";
	$insert_order.="whm_id='0', ";
	$insert_order.="total_due_today='".addslashes(trim($total_due_today))."', ";
	$insert_order.="total_due_reoccur='".addslashes(trim($total_due_reoccur))."', ";
	$insert_order.="promotion_code='".addslashes(trim($promotion_code))."', ";
	$insert_order.="referrer_id='".addslashes(trim($referrer_id))."', ";
	$insert_order.="whm_username='".addslashes(trim($whm_username))."', ";
	$insert_order.="whm_password='".addslashes(trim($whm_password))."', ";
	$insert_order.="client_notes='".addslashes(trim($client_notes))."', ";
	$insert_order.="pns1='".addslashes(trim($pns1))."', ";
	$insert_order.="pns2='".addslashes(trim($pns2))."', ";
	$insert_order.="server_hostname='".addslashes(trim($server_hostname))."', ";
	$insert_order.="root_pw='".addslashes(trim($root_pw))."', ";
	$insert_order.="status='0', ";
		
	# added 7/9/2004
	if (strcmp($using_FC, "yes")==0) { $insert_order.="fraudcall_score='".addslashes(trim($fraudcall_score))."', "; }

	if ($dedicated==1) { $insert_order.="resolved='1', "; }
	if ($domain_registration==1) { $insert_order.="tld_id='".addslashes(trim($tld_id))."', "; }
		
	if (getenv('HTTP_X_FORWARDED_FOR')) { $client_ip=getenv('HTTP_X_FORWARD_FOR'); } 
	else { $client_ip=getenv('REMOTE_ADDR'); }

	$insert_order.="client_ip='".addslashes(trim($client_ip))."', ";
	$insert_order.="client_host='".@gethostbyaddr($client_ip)."', ";
	$insert_order.="next_due_date='".time()."', ";
	$insert_order.="ogcreate='".time()."'";

	mysql_query($insert_order);
	$oid=mysql_insert_id();

	$invoice_number=create_new_invoice($oid, 1);
	if ($domain_registration==1&&$use_enom==0) { domain_reg_notice($oid); }

	# added 10/16/2003
	$nq2="update ";
	$nq2.="hosting_order ";
	$nq2.="set ";
	$nq2.="next_due_date='".create_next_due(time(), convert_payment_term_to_number($payment_term))."' ";
	$nq2.="where ";
	$nq2.="oid='".addslashes(trim($oid))."'";
	
	mysql_query($nq2);

	# added 10/16/2003

	# ---------------------------------------------------------------------------------
	# get the next due date from database

	$query_getnext="select ";
	$query_getnext.="next_due_date ";
	$query_getnext.="from ";
	$query_getnext.="hosting_order ";
	$query_getnext.="where ";
	$query_getnext.="oid='".addslashes(trim($oid))."'";

	$rsgetnext=mysql_fetch_row(mysql_query($query_getnext));
	$next_due_date=stripslashes(trim($rsgetnext[0]));
	# need to update the linkpoint queue with the oid and next due date

	function convert2linpoint_ndd($next_due_date)
		{
		$m=date("m", $next_due_date);
		$d=date("d", $next_due_date);
		$y=date("Y", $next_due_date);
		$next_due_date=mktime(0, 0, 0, $m, $d, $y);

		return date("Ymd", $next_due_date);
		}

	$startdate=convert2linpoint_ndd($next_due_date);

	$query_uplpid="update ";
	$query_uplpid.="linkpoint_holding_queue ";
	$query_uplpid.="set ";
	$query_uplpid.="startdate='".addslashes(trim($startdate))."', ";
	$query_uplpid.="oid='".addslashes(trim($oid))."' ";
	$query_uplpid.="where ";
	$query_uplpid.="lpid='".addslashes(trim($lpid))."'";

	mysql_query($query_uplpid);

	
	if ($ccid==0)
		{
		
		}
/*
	# create the batch
	$query="insert into ";
	$query.="authnet_batch ";
	$query.="set ";
	$query.="customer_ip_address='".$customer_ip_address."', ";
	$query.="description='".$description."', ";
	$query.="currency_code='".addslashes(trim($currency_code))."', ";
	$query.="transaction_type='".addslashes(trim($transaction_type))."', ";
	$query.="recurring_billing='YES', ";
	$query.="payment_method='CC', ";
	$query.="batch_status='".addslashes(trim($batch_status))."', ";
	$query.="response_reason_text='".addslashes(trim($response_reason_text))."', ";
	$query.="oid='".addslashes(trim($oid))."', ";
	$query.="uid='".addslashes(trim($uid))."', ";
	$query.="master_batch='1', ";
	$query.="ogcreate='".time()."', ";
	$query.="invoice_number='".addslashes(trim($invoice_number))."', ";
	$query.="txn_id='".addslashes(trim($txn_id))."', ";
	$query.="ccid='".addslashes(trim($ccid))."'";

	mysql_query($query);
*/
	# $bid=mysql_insert_id();
	# mysql_query("update authnet_batch set invoice_number='".addslashes(trim($invoice_number))."' where bid='".$bid."'");

	# ---------------------------------------------------------------------------------
		
	// affiliate functions
	if (strlen(trim($referrer_id))!=0)
		{
		// add the affiliate details
		add_new_referred_client($pid, $referrer_id, $uid, $oid);
		}
		
	// send out new order rec. email to clients
	new_order_received($email_admin, $sid, $currency, $currency_type, $addon_choices);
		
	// send out email to notify admin
	new_account_installed($email_admin, $oid, $currency, $currency_type, $addon_choices);

	// delete the session for security
	mysql_query("delete from session_history where sid='".addslashes(trim($sid))."'");
	
	// redirect to the next step
	$data=base64_encode($gid."|".$oid);

	$read=fopen($below_public."/".$data."_invoice.log", "w");
	fwrite($read, $data);
	fclose($read);
	
	// redirect to the next step
	header("Location: ".$http_web."/".(($use_enom==1&&$domain_registration==1)?"register_enom":"invoice_new").".php?c=".$data."".(($dedicated==0)?"":"&dedicated=1")."");
	exit;
	}

mysql_close($dblink);
?>