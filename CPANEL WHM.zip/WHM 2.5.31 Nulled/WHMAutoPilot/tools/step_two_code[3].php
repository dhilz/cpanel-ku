<?PHP
# new doamin
echo("
<form action='".$PHP_SELF."' method='POST'>
<input type='hidden' name='sid' value='".$sid."'>
<input type='hidden' name='gid' value='".$gid."'>
<input type='hidden' name='domain_registration' value='1'>
	");

if (isset($pid)) { echo "<input type='hidden' name='pid' value='".$pid."'>"; }

if (isset($err))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$steptwo_nodomainerror."</td> 
			</tr>
			
		</table>
		");
	}

if ($domain==-1)
	{
	echo("
	<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
		<tr>
			<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$steptwo_startwhypen."</td> 
		</tr>
		
	</table>
		");
	}
if ($domain==-2)
	{
	echo("
	<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
		<tr>
			<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$steptwo_endwhypen."</td> 
		</tr>
		
	</table>
		");
	}
if ($domain==-3)
	{
	echo("
	<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
		<tr>
			<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$steptwo_dash."</td> 
		</tr>
		
	</table>
		");
	}
if ($domain==-4)
	{
	echo("
	<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
		<tr>
			<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$steptwo_invalid_char."</td> 
		</tr>
		
	</table>
		");
	}
if (isset($err1))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$steptwo_domain_taken_error."</td> 
			</tr>
		</table><br>
		");
	}

if (isset($err_username))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$steptwo_domainalreadyinuse."</td> 
			</tr>
			
		</table><br>
		");
	}

echo("
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td width='1%' align='left' valign='top'>
		<table width='100%' cellpadding='6' cellspacing='0' border='0'>
			<tr>
				<td><img border='0' src='".$http_images."/order_arrow.gif'></td>
			</tr>
		</table>
		</td>
		<td align='left' valign='top'>
		<table width='100%' cellpadding='0' cellspacing='0' border='0'>
			<tr>
				<td>".$steptwo_enterdomain."</td>
			</tr>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='8'></td>
			</tr>
			<tr>
				<td align='left' valign='middle'>http://www.&nbsp;<input ".$orderinput_style." type='text' name='domain_name' size='60' maxlength='255' value='".((isset($domain_name))?"".$domain_name."":"")."'></td>
			</tr>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='20'></td>
			</tr>
			</table>
			<table width='100%' cellpadding='2' cellspacing='0' border='0'>
				");

			$query="select ";
			$query.="tld_id, ";
			$query.="tld, ";
			$query.="cost, ";
			$query.="reg_period ";
			$query.="from ";
			$query.="tld_chart ";
			$query.="order by ";
			$query.="tld asc";

			$x=1;
			$div_buffer="";
			$row=mysql_query($query);
			while ($rs=mysql_fetch_row($row)) 
				{
				$g+=1;
				
				if (trim($tld_id)=="") { $tld_id=$rs[0]; }
				
				$content="<input type='radio' name='tld_id' value='".$rs[0]."' id='tld_id".$rs[0]."'".((isset($tld_id))?"".(($tld_id==$rs[0])?" checked":"")."":"").">&nbsp;";
				$content.="<label for='tld_id".$rs[0]."'>";
				$content.="<b>.".$rs[1]."</b>&nbsp;";
				$content.=$currency.sprintf("%01.2f", $rs[2])."&nbsp;".$currency_type."&nbsp;";

				if ($rs[3]==1) { $content.="1 year";	}
				else if ($rs[3]==2) { $content.="2 years";	}
				else if ($rs[3]==3) { $content.="5 years";	}
				else if ($rs[3]==4) { $content.="10 years";	}

				$content.="</label>";

				if ($x==1)
					{
					echo("
							<tr>
								<td width='50%' align='left' valign='middle'>".$content."<td>
						");
					$x=2;
					}
				else if ($x==2)
					{
					echo("
								<td width='50%' align='left' valign='middle'>".$content."<td>
							</tr>
						");
					$x=1;
					}
				}

			if (isset($g)&&$x==2)
				{
					echo("
								<td width='50%' align='left' valign='middle'><td>
							</tr>
						");
				}

			echo("
			<tr>
				<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'></td>
			</tr>
		</table>
		</td>
	</tr>
</table>
	");
?>
