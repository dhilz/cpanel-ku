<?PHP
if(phpversion()<="4.0.6") { $_POST=$HTTP_POST_VARS; }
while (list($key, $value)=each($_POST)) { if (trim($key)=="sid") { $sid=$value; } }

$query0="select ";
$query0.="count(*) ";
$query0.="from ";
$query0.="invoice_session ";
$query0.="where sid='".addslashes(trim($sid))."'";

$rs0=mysql_fetch_row(mysql_query($query0));

$sid_count=$rs0[0];

if ($sid_count<=0) { header("Location: ".$http_web."/step_one.php"); exit; }
else if (!isset($sid)) { header("Location: ".$http_web."/step_one.php"); exit; }
else { $iid=d("576cb7f68040520768bf51c75f7f4c84", $sid); }


if (isset($_POST['x_Submit']))
	{
	if ($_POST['ccid']!=0)
		{
		$query="select ";
		$query.="customer_first_name, ";	// 0
		$query.="customer_last_name, ";		// 1
		$query.="customer_address, ";		// 2
		$query.="customer_city, ";			// 3
		$query.="customer_state, ";			// 4
		$query.="customer_zip, ";			// 5
		$query.="customer_country, ";		// 6
		$query.="customer_phone, ";			// 7
		$query.="customer_fax, ";			// 8
		$query.="customer_email, ";			// 9
		$query.="card_info ";				// 10
		$query.="from ";
		$query.="authnet_master_cc ";
		$query.="where ccid='".addslashes(trim($ccid))."' ";
		$query.="group by customer_first_name";

		$rs=mysql_fetch_row(mysql_query($query));

		$_POST['x_First_Name']=stripslashes(trim($rs[0]));
		$_POST['x_Last_Name']=stripslashes(trim($rs[1]));
		$_POST['x_Address']=stripslashes(trim($rs[2]));
		$_POST['x_City']=stripslashes(trim($rs[3]));
		$_POST['x_state']=stripslashes(trim($rs[4]));
		$_POST['x_Zip']=stripslashes(trim($rs[5]));
		$_POST['x_Country']=stripslashes(trim($rs[6]));
		$_POST['x_Phone']=stripslashes(trim($rs[7]));
		$_POST['x_Fax']=stripslashes(trim($rs[8]));
		$_POST['x_Email']=stripslashes(trim($rs[9]));
		$card_info=stripslashes(trim($rs[10]));
		
		$xcard_info=d("576cb7f68040520768bf51c75f7f4c84", $card_info);
		$var=explode("|", $xcard_info);
		$_POST['x_Card_Num']=$var[0];
		$_POST['x_Exp_Date_m']=substr($var[1], 0, 2);
		$_POST['x_Exp_Date_y']=substr($var[1], -2);
		}
	else
		{ 
		if (strlen(trim($_POST['x_First_Name']))==0) { $e0=true; }
		if (strlen(trim($_POST['x_Last_Name']))==0) { $e1=true; }
		if (strlen(trim($_POST['x_Address']))==0) { $e2=true; }
		if (strlen(trim($_POST['x_City']))==0) { $e3=true; }
		if (strlen(trim($_POST['x_Zip']))==0) { $e4=true; }
		if (strlen(trim($_POST['x_Phone']))<10) { $e5=true; }
		if (strlen(trim($_POST['x_Card_Num']))==0) { $e6=true; }
		if (strlen(trim($_POST['x_Exp_Date_m']))==0||strlen(trim($_POST['x_Exp_Date_y']))==0) { $e7=true; }
		if (strlen(trim($_POST['x_Card_Code']))==0) { $e8=true; }
		}
	
	if (!isset($e0)&&!isset($e1)&&!isset($e2)&&!isset($e3)&&!isset($e4)&&!isset($e5)&&!isset($e6)&&!isset($e7)&&!isset($e8))
		{
		$query0="select ";
		$query0.="x_gateway, ";			// 0
		$query0.="x_Login, ";			// 1
		$query0.="x_Password, ";		// 2
		$query0.="x_Currency_Code, ";	// 3
		$query0.="demo ";				// 4
		$query0.="from ";
		$query0.="payment_process ";
		$query0.="where pid='8'";

		$rs0=mysql_fetch_row(mysql_query($query0));

		$authnet_gateway=stripslashes(trim($rs0[0]));
		$x_Login=d("576cb7f68040520768bf51c75f7f4c84", $rs0[1]);
		$x_Password=d("576cb7f68040520768bf51c75f7f4c84", $rs0[2]);
		$x_Currency_Code=stripslashes(trim($rs0[3]));
		$demo=stripslashes(trim($rs0[4]));

		# ---------------------------------------------------------

		# Pull out invoice details
		# ---------------------------------------------------------------------------------
		$query1="select ";
		$query1.="total_due_today, ";	// 0
		$query1.="total_due_reoccur, ";	// 1
		$query1.="oid, ";				// 2
		$query1.="invoice_number ";		// 3
		$query1.="from ";
		$query1.="invoice ";
		$query1.="where ";
		$query1.="iid='".addslashes(trim($iid))."' ";

		$rs1=mysql_fetch_row(mysql_query($query1));

		$total_due_today=stripslashes(trim($rs1[0]));
		$total_due_reoccur=stripslashes(trim($rs1[1]));
		$invoice_number=stripslashes(trim($rs1[3]));
		// added by brandee on 2/4/04
		if ($total_due_today==0&&$total_due_reoccur==0) { $onesub_total=0; }
		else if ($total_due_today==0) { $onesub_total=$total_due_reoccur; }
		else { $onesub_total=$total_due_today; }
		$sub_total=sprintf("%01.2f", ($onesub_total));
		$oid=stripslashes(trim($rs1[2]));
		# ---------------------------------------------------------------------------------
		# END: Pull out invoice details

		# Client details
		# ---------------------------------------------------------------------------------
		$query2="select ";
		$query2.="domain_name, ";	// 0
		$query2.="pid, ";			// 1
		$query2.="uid ";			// 2
		$query2.="from ";
		$query2.="hosting_order ";
		$query2.="where ";
		$query2.="oid='".addslashes(trim($oid))."'";

		$rs2=mysql_fetch_row(mysql_query($query2));

		$domain_name=stripslashes(trim($rs2[0]));
		$pid=stripslashes(trim($rs2[1]));
		$uid=stripslashes(trim($rs2[2]));
		# ---------------------------------------------------------
		# END: Client details

		$query2="select ";
		$query2.="package_name ";	// 0
		$query2.="from plan_specs ";
		$query2.="where pid='".addslashes(trim($pid))."'";

		$rs2=mysql_fetch_row(mysql_query($query2));

		$package_name=stripslashes(trim($rs2[0]));

		# ---------------------------------------------------------

		if ($authnet_gateway=="authorize") { $processor="https://secure.authorize.net/gateway/transact.dll"; }
		else if ($authnet_gateway=="planetpayment") { $processor="https://secure.planetpayment.com/gateway/transact.dll"; }
		else if ($authnet_gateway=="ecx") { $processor="https://secure.quickcommerce.net/gateway/transact.dll"; }
		else if ($authnet_gateway=="epn") { $processor="https://www.eprocessingnetwork.com/cgi-bin/an/order.pl"; /*$parse_return=true;*/ }
		else if ($authnet_gateway=="rtware") { $processor="https://www.rtware.com/cgi-bin/an/order.pl"; }
		else if ($authnet_gateway=="mcps") { $processor="https://secure.merchantcommerce.net/gateway/transact.dll"; }
		else if ($authnet_gateway=="mplus") { $processor="https://gateway.merchantplus.com/cgi-bin/PAWebClient.cgi"; }
		else { $processor="https://secure.authorize.net/gateway/transact.dll"; }

		$link_out="x_Login=".$x_Login;
		$link_out.="&x_Password=".$x_Password;
		$link_out.="&x_Amount=".$sub_total;
		$link_out.="&x_Customer_IP=".$_SERVER['REMOTE_ADDR'];
		$link_out.="&x_Description=".$package_name." [".$domain_name."] Invoice #".$invoice_number;
		$link_out.="&x_Currency_Code=".$x_Currency_Code;
		$link_out.="&x_Test_Request=".(($demo==0)?"False":"True")."";

		$link_out.="&x_Version=3.1";
		$link_out.="&x_Delim_Data=True";
		$link_out.="&x_Delim_Char=|";
		$link_out.="&x_Encap_Char=";
		$link_out.="&x_Type=AUTH_CAPTURE";
		$link_out.="&x_Recurring_Billing=NO";
		$link_out.="&x_Email_Customer=True";
		$link_out.="&x_Method=CC";
		$link_out.="&x_Merchant_Email=".$email_admin;
		
		$link_out.="&x_invoice_num=".$invoice_number;
		$link_out.="&x_First_Name=".$_POST['x_First_Name'];
		$link_out.="&x_Last_Name=".$_POST['x_Last_Name'];
		$link_out.="&x_Address=".$_POST['x_Address'];
		$link_out.="&x_City=".$_POST['x_City'];
		$link_out.="&x_State=".$_POST['x_state'];
		$link_out.="&x_Zip=".$_POST['x_Zip'];
		$link_out.="&x_Country=".$_POST['x_Country'];
		$link_out.="&x_Phone=".$_POST['x_Phone'];
		$link_out.="&x_Fax=".$_POST['x_Fax'];
		$link_out.="&x_Email=".$_POST['x_Email'];
		$link_out.="&x_Card_Num=".$_POST['x_Card_Num'];
		$link_out.="&x_Exp_Date=".$_POST['x_Exp_Date_m'].$_POST['x_Exp_Date_y'];
		$link_out.="&x_Card_Code=".$_POST['x_Card_Code'];
		
		# $curl_root="/usr/bin/curl";
		if ($curl_root=="") 
			{
			$link=curl_init();
			curl_setopt($link, CURLOPT_URL, $processor);
			curl_setopt($link, CURLOPT_VERBOSE, 0);
			curl_setopt($link, CURLOPT_POST, 1);
			curl_setopt($link, CURLOPT_POSTFIELDS, $link_out);
			curl_setopt($link, CURLOPT_RETURNTRANSFER,1);
			$xresult=curl_exec($link);
			curl_close($link);
			$result=split("\,", $xresult);
			} 
		else 
			{
			@exec($curl_root." -d '".$link_out."' ".$processor, $xresult, $return);
			$result = split("\,", $xresult[0]);
			}
		
		if (isset($parse_return))
			{
			$res=strip_tags($result[0]);
			if (eregi("successfully processed", $res)) 
				{ 
				$response_code=1;
				$response_reason_text="Charged Successfully";

				list($junk, $good)=explode(":", $res);
				$res1=explode(" ", $good);
				$transaction_id=$res1[0]." ";
				$transaction_id.=str_replace("This", "", $res1[2]);
				}
			else 
				{ 
				$response_code=0;
				$response_reason_text="Transaction Failed or the card was declined. Please contact support";
				}
			}
		else
			{
			// list out result
			list($response_code, 
				$response_subcode, 
				$response_reason_code,
				$response_reason_text,
				$approval_code,
				$avs_result_code,
				$transaction_id,
				$xinvoice_number,
				$xdescription,
				$xamount,
				$method,
				$transaction_type,
				$customer_id,
				$cardholder_first_name,
				$cardholder_last_name,
				$company,
				$xaddress,
				$xcity,
				$xstate,
				$xzip,
				$xcountry,
				$xphone,
				$xfax,
				$xemail,
				$ship_to_first_name,
				$ship_to_last_name,
				$ship_to_company,
				$ship_to_address,
				$ship_to_city,
				$ship_to_state,
				$ship_to_zip,
				$ship_to_country,
				$tax_amount,
				$duty_amount,
				$freight_amount,
				$tax_exempt_flag,
				$po_number,
				$md5_hash,
				$xcard_code)=explode("|", $result[0]);
			}
	
		$response_code=str_replace("'", "", $response_code);

		if ($response_code==1)
			{
			// build vars
			if ($_POST['ccid']==0)
				{
				$card_info=$_POST['x_Card_Num']."|".$_POST['x_Exp_Date_m'].$_POST['x_Exp_Date_y']."|0|";
				$card_info=e("576cb7f68040520768bf51c75f7f4c84", $card_info);
				}
			$description=$package_name." [".$domain_name."]";

			if ($_POST['ccid']==0)
				{
				$query2="update ";
				$query2.="authnet_master_cc ";
				$query2.="set ";
				$query2.="master_cc='0' ";
				$query2.="where ";
				$query2.="uid='".addslashes(trim($uid))."' ";

				mysql_query($query2);

				# create the cc record in the database
				$query="insert into ";
				$query.="authnet_master_cc ";
				$query.="set ";
				$query.="customer_first_name='".addslashes(trim($cardholder_first_name))."', ";
				$query.="customer_last_name='".addslashes(trim($cardholder_last_name))."', ";
				$query.="customer_address='".addslashes(trim($xaddress))."', ";
				$query.="customer_city='".addslashes(trim($xcity))."', ";
				$query.="customer_state='".addslashes(trim($xstate))."', ";
				$query.="customer_zip='".addslashes(trim($xzip))."', ";
				$query.="customer_country='".addslashes(trim($xcountry))."', ";
				$query.="customer_phone='".addslashes(trim($xphone))."', ";
				$query.="customer_fax='".addslashes(trim($xfax))."', ";
				$query.="customer_email='".addslashes(trim($xemail))."', ";
				$query.="uid='".addslashes(trim($uid))."', ";
				$query.="card_info='".addslashes(trim($card_info))."', ";
				$query.="master_cc='1', ";
				$query.="ogcreate='".time()."'";

				mysql_query($query);

				$ccid=mysql_insert_id();
				}

			# create the batch
			$query="insert into ";
			$query.="authnet_batch ";
			$query.="set ";
			$query.="customer_ip_address='".$_SERVER['REMOTE_ADDR']."', ";
			$query.="description='".$site_name." [Invoice #".$invoice_number."]', ";
			$query.="currency_code='".addslashes(trim($x_Currency_Code))."', ";
			$query.="transaction_type='".addslashes(trim($transaction_type))."', ";
			$query.="recurring_billing='NO', ";
			$query.="payment_method='CC', ";
			$query.="batch_status='".addslashes(trim($response_code))."', ";
			$query.="response_reason_text='".addslashes(trim($response_reason_text))."', ";
			$query.="oid='".addslashes(trim($oid))."', ";
			$query.="uid='".addslashes(trim($uid))."', ";
			$query.="master_batch='1', ";
			$query.="ogcreate='".time()."', ";
			$query.="invoice_number='".addslashes(trim($invoice_number))."', ";
			$query.="txn_id='".addslashes(trim($transaction_id))."', ";
			$query.="ccid='".addslashes(trim($ccid))."'";

			mysql_query($query);

			$query1="update ";
			$query1.="invoice ";
			$query1.="set ";
			$query1.="txn_id='".addslashes(trim($transaction_id))."' ";
			$query1.="where iid='".addslashes(trim($iid))."'";
			
			mysql_query($query1);

			// redirect out!
			header("Location: ".$http_web."/invoice_success.php?c=".$sid);
			exit;
			}
		else
			{
			$e69=$response_reason_text.".";
			}
		}
	}
?>