<?PHP
if(phpversion()<="4.0.6") { $_POST=$HTTP_POST_VARS; }
while (list($key, $value)=each($_POST)) { if (trim($key)=="sid") { $sid=$value; } }

$query0="select ";
$query0.="count(*) ";
$query0.="from ";
$query0.="invoice_session ";
$query0.="where sid='".addslashes(trim($sid))."'";

$rs0=mysql_fetch_row(mysql_query($query0));

$sid_count=$rs0[0];

if ($sid_count<=0) { header("Location: ".$http_web."/step_one.php"); exit; }
else if (!isset($sid)) { header("Location: ".$http_web."/step_one.php"); exit; }
else { $iid=d("576cb7f68040520768bf51c75f7f4c84", $sid); }


if (isset($_POST['x_Submit']))
	{
	if ($_POST['ccid']!=0)
		{

		}
	else
		{ 
		if (strlen(trim($_POST['x_First_Name']))==0) { $e0=true; }
		if (strlen(trim($_POST['x_Last_Name']))==0) { $e1=true; }
		if (strlen(trim($_POST['x_Address']))==0) { $e2=true; }
		if (strlen(trim($_POST['x_City']))==0) { $e3=true; }
		if (strlen(trim($_POST['x_Zip']))==0) { $e4=true; }
		if (strlen(trim($_POST['x_Phone']))<10) { $e5=true; }
		if (strlen(trim($_POST['x_Card_Num']))==0) { $e6=true; }
		if (strlen(trim($_POST['x_Exp_Date_m']))==0||strlen(trim($_POST['x_Exp_Date_y']))==0) { $e7=true; }
		if (strlen(trim($_POST['x_Card_Code']))==0) { $e8=true; }
		}
	
	if (!isset($e0)&&!isset($e1)&&!isset($e2)&&!isset($e3)&&!isset($e4)&&!isset($e5)&&!isset($e6)&&!isset($e7)&&!isset($e8))
		{
		$query0="select ";
		$query0.="psigate_merchant, ";			// 0
		$query0.="psigate_chargetype, ";		// 1
		$query0.="psigate_emailclient ";		// 2
		$query0.="from ";
		$query0.="payment_process ";
		$query0.="where pid='11'";

		$rs0=mysql_fetch_row(mysql_query($query0));

		$psigate_merchant=stripslashes(trim($rs0[0]));
		$psigate_chargetype=stripslashes(trim($rs0[1]));
		$psigate_emailclient=stripslashes(trim($rs0[2]));

		# ---------------------------------------------------------

		# Pull out invoice details
		# ---------------------------------------------------------------------------------
		$query1="select ";
		$query1.="total_due_today, ";	// 0
		$query1.="total_due_reoccur, ";	// 1
		$query1.="oid, ";				// 2
		$query1.="invoice_number ";		// 3
		$query1.="from ";
		$query1.="invoice ";
		$query1.="where ";
		$query1.="iid='".addslashes(trim($iid))."' ";

		$rs1=mysql_fetch_row(mysql_query($query1));

		$total_due_today=stripslashes(trim($rs1[0]));
		$total_due_reoccur=stripslashes(trim($rs1[1]));
		$invoice_number=stripslashes(trim($rs1[3]));
		// added by brandee on 2/4/04
		if ($total_due_today==0&&$total_due_reoccur==0) { $onesub_total=0; }
		else if ($total_due_today==0) { $onesub_total=$total_due_reoccur; }
		else { $onesub_total=$total_due_today; }
		$sub_total=sprintf("%01.2f", ($onesub_total));
		$oid=stripslashes(trim($rs1[2]));
		# ---------------------------------------------------------------------------------
		# END: Pull out invoice details

		# Client details
		# ---------------------------------------------------------------------------------
		$query2="select ";
		$query2.="domain_name, ";	// 0
		$query2.="pid, ";			// 1
		$query2.="uid, ";			// 2
		$query2.="payment_term ";	//3
		$query2.="from ";
		$query2.="hosting_order ";
		$query2.="where ";
		$query2.="oid='".addslashes(trim($oid))."'";

		$rs2=mysql_fetch_row(mysql_query($query2));

		$domain_name=stripslashes(trim($rs2[0]));
		$pid=stripslashes(trim($rs2[1]));
		$uid=stripslashes(trim($rs2[2]));
		$recurring_cycle=stripslashes(trim($rs2[3]));

		if ($recurring_cycle=="monthly") { $interval_0="M"; }
		else if ($recurring_cycle=="quarterly") { $interval_0="Q"; }
		else if ($recurring_cycle=="semi_annual") { $interval_0="S"; }
		else if ($recurring_cycle=="annual") { $interval_0="A"; }
		# ---------------------------------------------------------
		# END: Client details

		$query2="select ";
		$query2.="package_name ";	// 0
		$query2.="from plan_specs ";
		$query2.="where pid='".addslashes(trim($pid))."'";

		$rs2=mysql_fetch_row(mysql_query($query2));
		$package_name=stripslashes(trim($rs2[0]));
		$invoicenumberinid=$invoice_number;

		function generate_id()
			{
			srand;   
			settype($random, "Integer");
			$random=rand(0, 100000);    
			$epoch=time();    
			$moid=$epoch^$random;

			return $moid;
			}
		$thisgoesin="Rec ".$domain_name;
		$myoidisthis="Invoiced Payment for ".$domain_name." to reoccur ".$recurring_cycle." at ".$total_due_reoccur;

		# ---------------------------------------------------------

		$processor="https://order.psigate.com/rb/psigaterb.asp";
		##-----start merchant information-----##
		$link_out.="MerchantID=".$psigate_merchant;
		$link_out.="&ChargeType=".$psigate_chargetype;
		$link_out.="&Userid=HTML Posting";
		$link_out.="&ThanksURL=".$http_web."/psigate_invoice_success.php?c=".$sid;
		$link_out.="&NoThanksURL=".$http_web."/psigate_invoice_errors.php?sid=".$sid;
		##-----start variable send into psigateway-----##
		$link_out.="&FullTotal=".$total_due_today;
		##-----start descriptions-----##		
		$link_out.="&Description1=".$invoicenumberinid." for [".$domain_name."]";
		$link_out.="&ItemID1=".$package_name." [".$domain_name."]";
		$link_out.="&Price1=".$total_due_reoccur;
		$link_out.="&Quantity1=1";
		$link_out.="&I1Option1=".$sid;
		$link_out.="&SoftFile1=";
		$link_out.="&Esdtype1=0";
		$link_out.="&Serial1=";
		##-----start recurring information-----##
		$link_out.="&RecurringOn=1";
		$link_out.="&RecurringProductNo=".$thisgoesin;
		$link_out.="&RecurringDescription=".$domain_name;
		$link_out.="&RecurringInterval=".$interval_0;
		$link_out.="&RecurringValue=".$total_due_reoccur;
		$link_out.="&RecurringEmail=".$psigate_emailclient;
		$link_out.="&RecurringConfirmationEmail=1";
		##-----customer information-----##
		$link_out.="&x_Customer_IP=".$_SERVER['REMOTE_ADDR'];
		$link_out.="&Bname=".$_POST["x_First_Name"]." ".$_POST['x_Last_Name'];
		$link_out.="&Baddr1=".$_POST['x_Address'];
		$link_out.="&Bcity=".$_POST['x_City'];
		$link_out.="&Bstate=".$_POST['x_state'];
		$link_out.="&Bzip=".$_POST['x_Zip'];
		$link_out.="&Bcountry=".$_POST['x_Country'];
		$link_out.="&Phone=".$_POST['x_Phone'];
		$link_out.="&Email=".$_POST['x_Email'];
		$link_out.="&CardNumber=".$_POST['x_Card_Num'];
		$link_out.="&ExpMonth=".$_POST['x_Exp_Date_m'];
		$link_out.="&ExpYear=".$_POST['x_Exp_Date_y'];
		#print_r($link_out);
		#echo "<BR><BR>";
		#echo $sid;
		$insertthis="insert into psigate_logging set sid='".$sid."' , iid='".$iid."' , oid='".$oid."'";
		mysql_query($insertthis);

		# $curl_root="/usr/bin/curl";
		if ($curl_root=="") 
			{
			$link=curl_init();
			curl_setopt($link, CURLOPT_URL, $processor);
			curl_setopt($link, CURLOPT_VERBOSE, 0);
			curl_setopt($link, CURLOPT_POST, 1);
			curl_setopt($link, CURLOPT_POSTFIELDS, $link_out);
			curl_setopt($link, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($link, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($link, CURLOPT_RETURNTRANSFER, 0);
			curl_setopt($link, CURLOPT_FOLLOWLOCATION, 1);
			$xresult=curl_exec($link);
			curl_close($link);
			$result=split("\,", $xresult);
			}
		}
	}
?>