<?PHP
// start the domain menu
echo("
<table width='725' border='0' cellspacing='1' cellpadding='2'>
	");
if (trim($show_domain)=="1")
	{
	echo("
		<form action='".$PHP_SELF."' method='POST'>
		<input type='hidden' name='sid' value='".trim($sid)."'>
		<input type='hidden' name='oid' value='".trim($oid)."'>
		<input type='hidden' name='sid' value='".trim($sid)."'>
		<input type='hidden' name='show_client' value='".trim($show_client)."'>
		<input type='hidden' name='show_domain' value='".trim($show_domain)."'>
		<input type='hidden' name='show_account' value='".trim($show_account)."'>
		<input type='hidden' name='uid' value='".trim($uid)."'>
		<input type='hidden' name='ogcreate' value='".trim($xogcreate)."'>
		<input type='hidden' name='ogcreate_hosting' value='".trim($xhogcreate)."'>
		<input type='hidden' name='resolved_date' value='".trim($resolved_date)."'>
		<input type='hidden' name='whm_id' value='".trim($whm_id)."'>
		<input type='hidden' name='status' value='".trim($status)."'>
		");
	}
echo("
	<tr>
		<td width='49%' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><b>Domain Information</b><img src='".$http_images."/space.gif' width='200' height='1'></td>
		<td width='51%' align='left' valign='top'>[<a href='".$http_admin."/client_view.php?sid=".trim($sid)."&oid=".trim($oid)."".((trim($show_domain)=="1")?"&show_domain=0":"&show_domain=1")."&show_client=".trim($show_client)."&show_account=".trim($show_account)."'>".((trim($show_domain)=="0")?"Show":"Hide")."</a>]</td>
	</tr>
</table>
	");
if (trim($show_domain)=="1")
	{
	echo("
	<table width='725' border='0' cellspacing='1' cellpadding='2'>
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>Domain Name:</td>
			<td width='75%' align='left' valign='top'>http:// <input ".$orderinput_style." size='35' maxlength='255' type='text' name='domain_name' value='".trim($domain_name)."'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>Domain Expires:</td>
			<td width='75%' align='left' valign='top'><input ".$orderinput_style." size='15' maxlength='255' type='text' name='domain_expire' value='".((strlen(trim(str_replace("/", "", $domain_expire)))!=0)?"".$domain_expire."":"")."'> ex. MM/DD/YYYY</td>
		</tr>
		</tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>Resolve Status:</td>
			<td width='75%' align='left' valign='top'><input type='checkbox' name='resolved' value='1'".((isset($resolved))?"".((trim($resolved)=="1")?" checked":"")."":"")."> Check to mark as resolved.</td>
		</tr>
	");
if ($resolved==1)
	{
echo("
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>Resolved on:</td>
			<td width='75%' align='left' valign='top'>".date("m/d/Y", $resolved_date)."</td>
		</tr>
	");
	}
else
	{
echo("
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>Resolver last ran on:</td>
			<td width='75%' align='left' valign='top'>".((trim($ur_date)=="00000000000000")?"Not yet ran.":"".date("m/d/Y", $ur_date)."")."</td>
		</tr>
	");
	}
echo("
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='200' height='2'></td>
			<td width='75%' align='left' valign='top'><img src='".$http_images."/space.gif' width='400' height='2'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'></td>
			<td width='75%' align='left' valign='top'><input ".$orderbutton_style." type='submit' name='edit_domain' value='Update Domain Information Now'></td>
		</tr>
	</table>
	</form>
	");
	}
// end the domain menu
?>