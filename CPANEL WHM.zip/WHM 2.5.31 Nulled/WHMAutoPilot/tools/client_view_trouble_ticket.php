<?PHP
echo("
	<table width='92%' cellpadding='4' cellspacing='1' border='0'>
		<tr>
			<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='1'></td>
		</tr>
		<tr>
			<td align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><b>$text_opentroubletickets</b><img src='".$http_images."/space.gif' width='25' height='9'>[<a href='".$http_web."/trouble_ticket_submit.php?sid=".trim($sid)."&c=".base64_encode(clogin_e($uid."|".$email))."'>$text_newticket</a>]</td>
		</tr>
	</table>
	");

// do we have any tickets in the system?
$ctt=mysql_fetch_row(mysql_query("select count(*) from ticket"));
if ($ctt[0]<=0)
	{
	echo("
	<table width='92%' cellpadding='2' cellspacing='1' border='0'>
		<tr>
			<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'><img src='".$http_images."/drop_arrow.gif'>$text_noopentickets</td>
		</tr>
	</table>
	");
	}
else
	{
	echo("
		<table width='92%' cellpadding='3' cellspacing='1' border='0'>
			<tr>
				<td width='5%' align='center' valign='top' bgcolor='#E5E7E9'>#</td>
				<td width='50%' align='left' valign='top' bgcolor='#E5E7E9'>$text_issuesubject</td>
				<td width='20%' align='left' valign='top' bgcolor='#E5E7E9'>$text_submitted</td>
				<td width='25%' align='center' valign='top' bgcolor='#E5E7E9'>$text_status</td>
			</tr>
		");
	$y=1;
	# $row2=mysql_query("select id, subject, UNIX_TIMESTAMP(ogcreate), status, ogcreate from ticket where uid='".addslashes(trim($uid))."'");
	$row2=mysql_query("select id, subject, ogcreate, status, ogcreate from ticket where uid='".addslashes(trim($uid))."'");
	while ($rs2=mysql_fetch_row($row2))
		{
		if ($y==1) {$bgcolor="#F2F4F6"; $y=0;} else {$bgcolor="#ECEEF0"; $y=1;}
		echo("
				<tr>
					<td align='center' valign='middle' bgcolor='".$bgcolor."'>".$rs2[0]."</td>
					<td align='left' valign='middle' bgcolor='".$bgcolor."'>
					<table width='100%' cellpadding='0' cellspacing='0' border='0'>
						<tr>
							<td width='8%' align='center' valign='top'><a href='".$http_web."/trouble_ticket_view.php?sid=".trim($sid)."&id=".trim($rs2[0])."&status=".trim($status)."'><img border='0' src='".$http_images."/icon_view.gif'></a></td>
							<td width='92%' align='left' valign='top'><a href='".$http_web."/trouble_ticket_view.php?sid=".trim($sid)."&id=".trim($rs2[0])."&status=".trim($status)."'>".stripslashes($rs2[1])."</a></td>
						</tr>
					</table>
					</td>
					<td align='left' valign='middle' bgcolor='".$bgcolor."'><font size='1'>".date("m/d/Y h:i:s a", $rs2[2])."</font></td>
					<td align='center' valign='middle' bgcolor='".$bgcolor."'>
			");
		if (trim($rs2[3])=="0")
			{
			echo"$text_openticket [<a href='".$PHP_SELF."?sid=".trim($sid)."&tid=".trim($rs2[0])."&re=1&og=".$rs2[4]."'>$text_close</a>] [<a href='".$PHP_SELF."?sid=".trim($sid)."&tid=".trim($rs2[0])."&re=2'>$text_delete </a>]";
			}
		else if (trim($rs2[3])=="1")
			{
			echo"$text_closedticket [<a href='".$PHP_SELF."?sid=".trim($sid)."&tid=".trim($rs2[0])."&re=0&og=".$rs2[4]."'>$text_reopen</a>] [<a href='".$PHP_SELF."?sid=".trim($sid)."&tid=".trim($rs2[0])."&re=2'>$text_delete </a>]";
			}
		echo("
					</td>
				</tr>
			");
		}
	}
echo"";
?>