<?PHP
// start the News/New Order Menu
echo("
<form action='".$PHP_SELF."' method='POST'>
<table width='100%' border='0' cellspacing='1' cellpadding='2'>
	<tr>
		<td align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><b>$text_neworder</b><img src='".$http_images."/space.gif' width='15' height='9'><a href='".$http_web."/step_one.php?c=".base64_encode($uid)."'>$text_clickhere</a></td>
	</tr>
</table>
</form>
	");
// end the News/New Order Menu
?>