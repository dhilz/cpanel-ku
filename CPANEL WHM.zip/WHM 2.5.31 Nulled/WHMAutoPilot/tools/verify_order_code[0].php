<?PHP
include $server_inc."/languages/".$local_lang.".php";
include $server_inc."/languages/".$local_lang."/step_fraudgate.php";

$cksid=mysql_fetch_row(mysql_query("select count(*) from session_history where sid='".addslashes(trim($sid))."'"));

if ($cksid[0]<=0) {	header("Location: ".$http_web."/step_one.php");	exit; }
else if (!isset($sid)) { header("Location: ".$http_web."/step_one.php"); exit; }
else if (isset($ul))
	{
	if ($ul==0) 
		{ 
		mysql_query("update session_history set locked='0' where sid='".addslashes(trim($sid))."'");
		header("Location: ".$http_web."/step_one.php?sid=".trim($sid)."&gid=".trim($gid));
		exit;
		}
	else if ($ul==1) 
		{ 
		mysql_query("update session_history set locked='0' where sid='".addslashes(trim($sid))."'");
		header("Location: ".$http_web."/step_two.php?sid=".trim($sid)."&gid=".trim($gid));
		exit;
		}
	else if ($ul==2) 
		{ 
		mysql_query("update session_history set locked='0' where sid='".addslashes(trim($sid))."'");
		header("Location: ".$http_web."/step_three.php?sid=".trim($sid)."&gid=".trim($gid)."&addon_gid=".$addon_gid);
		exit;
		}
	else if ($ul==3) 
		{ 
		mysql_query("update session_history set locked='0' where sid='".addslashes(trim($sid))."'");
		header("Location: ".$http_web."/step_four.php?sid=".trim($sid)."&gid=".trim($gid));
		exit;
		}
	}

$query="select ";
$query.="first_name, ";			// 0
$query.="last_name, ";			// 1
$query.="organization_name, ";	// 2
$query.="street_address_1, ";	// 3
$query.="street_address_2, ";	// 4
$query.="city, ";				// 5
$query.="state, ";				// 6
$query.="zip_code, ";			// 7
$query.="country, ";			// 8
$query.="phone, ";				// 9
$query.="fax, ";				// 10
$query.="email, ";				// 11
$query.="username, ";			// 12
$query.="password, ";			// 13
$query.="advert, ";				// 14
$query.="advert_other, ";		// 15
$query.="tos, ";				// 16
$query.="pid, ";				// 17
$query.="payment_term, ";		// 18
$query.="domain_name, ";		// 19
$query.="domain_registration, ";// 20
$query.="domain_expire, ";		// 21
$query.="payment_method, ";		// 22
$query.="whm_username, ";		// 23
$query.="whm_password, ";		// 24
$query.="promotion_code, ";		// 25
$query.="referrer_id, ";		// 26
$query.="uid, ";				// 27
$query.="client_ip, ";			// 28
$query.="addon_choices, ";		// 29
$query.="client_notes, ";		// 30
$query.="whm_id, ";				// 31
$query.="pns1, ";				// 32
$query.="pns2, ";				// 33
$query.="server_hostname, ";	// 34
$query.="root_pw, ";			// 35
$query.="tld ";					// 35
$query.="from session_history ";
$query.="where sid='".addslashes(trim($sid))."'";

$rs=mysql_fetch_row(mysql_query($query));

$first_name=stripslashes(trim($rs[0]));
$last_name=stripslashes(trim($rs[1]));
$organization_name=stripslashes(trim($rs[2]));
$street_address_1=stripslashes(trim($rs[3]));
$street_address_2=stripslashes(trim($rs[4]));
$city=stripslashes(trim($rs[5]));
$state=stripslashes(trim($rs[6]));
$zip_code=stripslashes(trim($rs[7]));
$country=stripslashes(trim($rs[8]));
$phone=stripslashes(trim($rs[9]));
$fax=stripslashes(trim($rs[10]));
$email=stripslashes(trim($rs[11]));
$username=stripslashes(trim($rs[12]));
$password=stripslashes(trim($rs[13]));
$advert=stripslashes(trim($rs[14]));
$advert_other=stripslashes(trim($rs[15]));
$tos=stripslashes(trim($rs[16]));
$pid=stripslashes(trim($rs[17]));
$payment_term=stripslashes(trim($rs[18]));
$payment_term=strtolower($payment_term);
$domain_expire=stripslashes(trim($rs[21]));
$payment_method=stripslashes(trim($rs[22]));
$whm_username=stripslashes(trim($rs[23]));
$whm_password=stripslashes(trim($rs[24]));
$coupon_code=stripslashes(trim($rs[25]));
$referrer_id=stripslashes(trim($rs[26]));
$uid=stripslashes(trim($rs[27]));
$client_ip=stripslashes(trim($rs[28]));
$addon_choices=stripslashes(trim($rs[29]));
$client_notes=stripslashes(trim($rs[30]));
$whm_id=stripslashes(trim($rs[31]));
$pns1=stripslashes(trim($rs[32]));
$pns2=stripslashes(trim($rs[33]));
$server_hostname=stripslashes(trim($rs[34]));
$root_pw=stripslashes(trim($rs[35]));
$domain_name=stripslashes(trim($rs[19]));
$domain_registration=stripslashes(trim($rs[20]));
$tld_id=stripslashes(trim($rs[36]));

if ($domain_registration==1)
	{
	$query_tld="select ";
	$query_tld.="tld, ";
	$query_tld.="cost, ";
	$query_tld.="reg_period ";
	$query_tld.="from ";
	$query_tld.="tld_chart ";
	$query_tld.="where ";
	$query_tld.="tld_id='".addslashes(trim($tld_id))."'";
	
	$rs_tld=mysql_fetch_row(mysql_query($query_tld));

	$domain_name=$domain_name.".".stripslashes(trim($rs_tld[0]));
	$cost_per_tld=stripslashes(trim($rs_tld[1]));
	$reg_period=stripslashes(trim($rs_tld[2]));
	$text_peryear=$currency.sprintf("%01.2f", $cost_per_tld)." ".$currency_type;
	$text_peryear.=" per ";
	if ($reg_period==1) { $text_peryear.="1 year"; }
	else if ($reg_period==2) { $text_peryear.="2 years"; }
	else if ($reg_period==3) { $text_peryear.="5 years"; }
	else if ($reg_period==4) { $text_peryear.="10 years"; }
	}

if (isset($submit))
	{
	if (trim($uid)=="0")
		{
		$insert="insert into user set ";
		$insert.="first_name='".addslashes(trim($first_name))."', ";
		$insert.="last_name='".addslashes(trim($last_name))."', ";
		if (strlen(trim($organization_name))!=0) { $insert.="organization_name='".addslashes(trim($organization_name))."', "; }
		$insert.="street_address_1='".addslashes(trim($street_address_1))."', ";
		if (strlen(trim($street_address_2))!=0) { $insert.="street_address_2='".addslashes(trim($street_address_2))."', "; }
		$insert.="city='".addslashes(trim($city))."', ";
		$insert.="state='".addslashes(trim($state))."', ";
		$insert.="zip_code='".addslashes(trim($zip_code))."', ";
		$insert.="country='".addslashes(trim($country))."', ";
		$insert.="phone='".addslashes(trim($phone))."', ";
		$insert.="fax='".addslashes(trim($fax))."', ";
		$insert.="email='".addslashes(trim($email))."', ";
		$insert.="username='".addslashes(trim($username))."', ";
		
		# added 7/3/2004
		$enc_pw=base64_encode(clogin_e($password));
		$insert.="password='".$enc_pw."', ";

		# $insert.="password='".md5(strtolower(trim($password)))."', ";
		$insert.="advert='".addslashes(trim($advert))."', ";
		$insert.="advert_other='".addslashes(trim($advert_other))."', ";
		$insert.="temp_pw='".addslashes(trim($password))."', "; // delete this at first login
		$insert.="tos='1',";
		$insert.="sid='".create_sid()."', ";
		$insert.="ogcreate='".time()."'";

		mysql_query($insert);
		$uid=mysql_insert_id();
		}
	else
		{
		$update="update user set ";
		$update.="first_name='".addslashes(trim($first_name))."', ";
		$update.="last_name='".addslashes(trim($last_name))."', ";
		if (strlen(trim($organization_name))!=0) { $update.="organization_name='".addslashes(trim($organization_name))."', "; }
		$update.="street_address_1='".addslashes(trim($street_address_1))."', ";
		if (strlen(trim($street_address_2))!=0) { $update.="street_address_2='".addslashes(trim($street_address_2))."', "; }
		$update.="city='".addslashes(trim($city))."', ";
		$update.="state='".addslashes(trim($state))."', ";
		$update.="zip_code='".addslashes(trim($zip_code))."', ";
		$update.="country='".addslashes(trim($country))."', ";
		$update.="phone='".addslashes(trim($phone))."', ";
		$update.="fax='".addslashes(trim($fax))."', ";
		$update.="email='".addslashes(trim($email))."', ";
		$update.="advert='".addslashes(trim($advert))."', ";
		$update.="advert_other='".addslashes(trim($advert_other))."', ";
		$update.="tos='1' ";
		$update.="where uid='".addslashes(trim($uid))."'";

		mysql_query($update);
		}
	
	# added 7/21/2004
	$query2="select ";
	$query2.="dedicated ";
	$query2.="from plan_specs ";		
	$query2.="where pid='".addslashes(trim($pid))."'";
	$rs2=mysql_fetch_row(mysql_query($query2));
	$dedicated=stripslashes($rs2[0]);
	# end added 7/21/2004

	if ($dedicated=="")
		{
		// insert hosting order
		$insert_order="insert into hosting_order set ";
		$insert_order.="uid='".addslashes(trim($uid))."', ";
		$insert_order.="pid='".addslashes(trim($pid))."', ";
		$insert_order.="domain_name='".addslashes(trim($domain_name))."', ";
		$insert_order.="payment_method='".addslashes(trim($payment_method))."', ";
		$insert_order.="payment_term='".addslashes(trim($payment_term))."', ";
		$insert_order.="pns1='".addslashes(trim($pns1))."', ";
		$insert_order.="pns2='".addslashes(trim($pns1))."', ";
		$insert_order.="total_due_today='".addslashes(trim(base64_decode($total_due_today)))."', ";
		$insert_order.="total_due_reoccur='".addslashes(trim(base64_decode($total_due_reoccur)))."', ";
		$insert_order.="promotion_code='".addslashes(trim($promotion_code))."', ";
		$insert_order.="referrer_id='".addslashes(trim($referrer_id))."', ";
		$insert_order.="addon_choices='".addslashes(trim($addon_choices))."', ";
		$insert_order.="client_notes='".addslashes(trim($client_notes))."', ";
		$insert_order.="root_pw='".addslashes(trim($root_pw))."', ";
		$insert_order.="server_hostname='".addslashes(trim($server_hostname))."', ";
		$insert_order.="status='0', ";
		$insert_order.="cont_resolve='0', ";
		$insert_order.="client_ip='".addslashes(trim($client_ip))."', ";
		$insert_order.="tld_id='".addslashes(trim($tld_id))."', ";
		$insert_order.="next_due_date='".time()."', ";
		$insert_order.="ogcreate='".time()."'";

		mysql_query($insert_order);

		$oid=mysql_insert_id();
		
		create_new_invoice($oid, 0);

		# added 10/16/2003
		$nq2="update ";
		$nq2.="hosting_order ";
		$nq2.="set ";
		$nq2.="next_due_date='".create_next_due(time(), convert_payment_term_to_number($payment_term))."' ";
		$nq2.="where ";
		$nq2.="oid='".addslashes(trim($oid))."'";
		
		mysql_query($nq2);
		# added 10/16/2003

		
		if (strlen(trim($referrer_id))!=0) { add_new_referred_client($pid, $referrer_id, $uid, $oid); }
		
		// send out new order rec. email to clients
		new_order_received($email_admin, $sid, $currency, $currency_type, $addon_choices);
		
		// send out email to notify admin
		new_account_installed($email_admin, $oid, $currency, $currency_type, $addon_choices);
		}
	else
		{
		// grab whm package name
		$whm_package_name=mysql_fetch_row(mysql_query("select whm_package_name from plan_specs where pid='".addslashes(trim($pid))."'"));
		$whm_package_name=$whm_package_name[0];

		// get the server IP
		if (current_server($sid, 1)==99) { $current_server=current_server_internal(); }
		else { $current_server=current_server($sid, 1);	}

		$rsip=mysql_fetch_row(mysql_query("select server_ip, primary_ns, secondary_ns, reseller from server_config where whm_id='".addslashes(trim($current_server))."'"));

		$ip=$rsip[0];
		$ns1=$rsip[1];
		$ns2=$rsip[2];
		$reseller=$rsip[3];
		
		// get the IP for the account or use the shared
		if ($reseller==0) 
			{ 
			$unique_ip_ordered=unique_ip_ordered($addon_choices);

			$temp=@read_log($current_server, $below_public);
			list($xwhm_username, $xwhm_password)=split("[|]", $temp);

			if ($unique_ip_ordered==1) { $default_ip=get_free_ips($ip, $xwhm_username, $xwhm_password); }
			else { $default_ip=$server_ip; }
			}
		else { $default_ip=$server_ip; }

		// insert hosting order
		$insert_order="insert into hosting_order set ";
		$insert_order.="uid='".addslashes(trim($uid))."', ";
		$insert_order.="pid='".addslashes(trim($pid))."', ";

		$insert_order.="domain_name='".addslashes(trim($domain_name))."', ";
		$insert_order.="domain_registration='".addslashes(trim($domain_registration))."', ";
		$insert_order.="domain_expire='".addslashes(trim($domain_expire))."', ";
		$insert_order.="payment_method='".addslashes(trim($payment_method))."', ";
		$insert_order.="payment_term='".addslashes(trim($payment_term))."', ";
		$insert_order.="ns1='".addslashes(trim($ns1))."', ";
		$insert_order.="ns2='".addslashes(trim($ns2))."', ";
		$insert_order.="ip='".addslashes(trim($ip))."', ";
		$insert_order.="total_due_today='".addslashes(trim(base64_decode($total_due_today)))."', ";
		$insert_order.="total_due_reoccur='".addslashes(trim(base64_decode($total_due_reoccur)))."', ";
		$insert_order.="promotion_code='".addslashes(trim($promotion_code))."', ";
		$insert_order.="referrer_id='".addslashes(trim($referrer_id))."', ";
		$insert_order.="whm_username='".addslashes(trim($whm_username))."', ";
		$insert_order.="whm_password='".addslashes(trim($whm_password))."', ";
		$insert_order.="addon_choices='".addslashes(trim($addon_choices))."', ";
		$insert_order.="client_notes='".addslashes(trim($client_notes))."', ";
		$insert_order.="status='0', ";
		$insert_order.="client_ip='".addslashes(trim($client_ip))."', ";
		$insert_order.="client_host='".gethostbyaddr($client_ip)."', ";
		$insert_order.="next_due_date='".time()."', ";
		$insert_order.="tld_id='".addslashes(trim($tld_id))."', ";
		$insert_order.="ogcreate='".time()."'";

		mysql_query($insert_order);
		
		$oid=mysql_insert_id();
		
		create_new_invoice($oid, 0);
		if ($domain_registration==1&&$use_enom==0) { domain_reg_notice($oid); }

		# added 10/16/2003
		$nq2="update ";
		$nq2.="hosting_order ";
		$nq2.="set ";
		$nq2.="next_due_date='".create_next_due(time(), convert_payment_term_to_number($payment_term))."' ";
		$nq2.="where ";
		$nq2.="oid='".addslashes(trim($oid))."'";
		
		mysql_query($nq2);
		# added 10/16/2003


		if (strlen(trim($referrer_id))!=0) { add_new_referred_client($pid, $referrer_id, $uid, $oid); }
		
		// send out new order rec. email to clients
		new_order_received($email_admin, $sid, $currency, $currency_type, $addon_choices);
		
		// send out email to notify admin
		new_account_installed($email_admin, $oid, $currency, $currency_type, $addon_choices);
		}

	// delete the session for security
	mysql_query("delete from session_history where sid='".addslashes(trim($sid))."'");
	
	// redirect to the next step
	$data=base64_encode($gid."|".$oid);
	$read=fopen($below_public."/".$data."_invoice.log", "w");
	fwrite($read, $data);
	fclose($read);

	header("Location: ".$http_web."/mail_payment.php?c=".$data); exit;
	}

// --------------------------------------------------------------------------------------------------------------------

$query0="select ";
$query0.="package_name, ";		// 0
$query0.="monthly_cost, ";		// 1
$query0.="quarterly_cost, ";	// 2
$query0.="semi_annual_cost, ";	// 3
$query0.="annual_cost, ";		// 4
$query0.="setup_cost, ";		// 5
$query0.="web_space, ";			// 6
$query0.="bandwidth, ";			// 7
$query0.="email, ";				// 8
$query0.="gid, ";				// 9
$query0.="addon_gid, ";			// 10
$query0.="free_trial, ";		// 11
$query0.="free_trial_length, ";	// 12
$query0.="dedicated ";			// 13
$query0.="from plan_specs ";
$query0.="where pid='".addslashes(trim($pid))."'";

$rs0=mysql_fetch_row(mysql_query($query0));

$package_name=stripslashes(trim($rs0[0]));
$monthly_cost=stripslashes(trim($rs0[1]));
$quarterly_cost=stripslashes(trim($rs0[2]));
$semi_annual_cost=stripslashes(trim($rs0[3]));
$annual_cost=stripslashes(trim($rs0[4]));
$setup_cost=stripslashes(trim($rs0[5]));
$web_space=stripslashes(trim($rs0[6]));
$bandwidth=stripslashes(trim($rs0[7]));
$email_wp=stripslashes(trim($rs0[8]));
$gid=stripslashes(trim($rs0[9]));
$addon_gid=stripslashes(trim($rs0[10]));
$free_trial=stripslashes(trim($rs0[11]));
$free_trial_length=stripslashes(trim($rs0[12]));
$dedicated=stripslashes(trim($rs0[13]));

$rs1=mysql_fetch_row(mysql_query("select name from plan_groups where gid='".addslashes(trim($gid))."'"));
$plan_group_name=stripslashes(trim($rs1[0]));

$rs2=mysql_fetch_row(mysql_query("select name from payment_process where pid='".addslashes(trim($payment_method))."'"));
$payment_type_name=stripslashes(trim($rs2[0]));

if (strcmp("monthly", $payment_term)==0)
	{
	$payment_term="Monthly";
	$formatted_cost=$currency.sprintf("%01.2f", $monthly_cost)." ".$currency_type;
	$term=1;
	}
else if (strcmp("quarterly", $payment_term)==0)
	{
	$payment_term="Quarterly";
	$formatted_cost=$currency.sprintf("%01.2f", $quarterly_cost)." ".$currency_type;
	$term=3;
	}
else if (strcmp("semi_annual", $payment_term)==0)
	{
	$payment_term="Semi-Annual";
	$formatted_cost=$currency.sprintf("%01.2f", $semi_annual_cost)." ".$currency_type;
	$term=6;
	}
else if (strcmp("annual", $payment_term)==0)
	{
	$payment_term="Annual";
	$formatted_cost=$currency.sprintf("%01.2f", $annual_cost)." ".$currency_type;
	$term=12;
	}

list($total_due_today, $total_reoccur, $payment_term)=split("[|]", calc_totals($payment_term, $domain_registration, $domain_fee, $pid, $addon_choices));

// --------------------------------------------------------------------------------------------------------------------

if (is_locked($sid)==1) { header("Location: ".$http_web."/step_one.php"); exit;	}

# start new ---------------------------------------------------------------------------------------

# added 7/2/2004
$query="select ";
$query.="fraudcall_value ";
$query.="from ";
$query.="autopilot_fraudcall ";
$query.="where ";
$query.="fraudcall_key='activate_fraud_call' ";
$query.="limit 0, 1";

$rs=mysql_fetch_row(mysql_query($query));
# end 7/2/2004
	// --- FRAUDGATE --- //
	$fg_data = mysql_query("SELECT fg_value FROM autopilot_fraudgate WHERE fg_variable='stepCall'");
	$fg_row = mysql_fetch_array($fg_data);
	$fg_data = mysql_query("SELECT fg_value FROM autopilot_fraudgate WHERE fg_variable='activate'");
	$fg_row2 = mysql_fetch_array($fg_data);
	// --- END FRAUDGATE --- //
	
$parse_out0="";
// --- FRAUDGATE --- //
if ($fg_row['fg_value'] == 1 && $fg_row2['fg_value'] == 1)
{
	$parse_out0.="<form action='".$http_web."/step_fraudgate_one.php' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='sid' value='".trim($sid)."'>\n";
    if (isset($gid))
		$parse_out0.="<input type='hidden' name='gid' value='".trim($gid)."'>\n";
    $verifyorder_submitbutton=$fg_step_text;
    $fg_enabled = 1;
}
// --- END FRAUDGATE --- //
else if (strcmp($rs[0], "yes")==0)
	{
	$parse_out0.="<form action='".$http_web."/validate_phone.php' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='sid' value='".trim($sid)."'>\n";
	if (isset($gid)) { $parse_out0.="<input type='hidden' name='gid' value='".trim($gid)."'>\n"; }

	$verifyorder_submitbutton=$verifyorder_submitbutton_fraudcall;
	$varilogix=true;
	}
else if (strcmp("authorize.net", strtolower($payment_type_name))==0)
	{
	$parse_out0.="<form action='".$http_web."/credit_card.php' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='sid' value='".trim($sid)."'>\n";
	$parse_out0.="<input type='hidden' name='gid' value='".trim($gid)."'>\n";
	}
else if (strcmp("credit card", strtolower($payment_type_name))==0)
	{
	$parse_out0.="<form action='".$http_web."/credit_card_off.php' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='sid' value='".trim($sid)."'>\n";
	$parse_out0.="<input type='hidden' name='gid' value='".trim($gid)."'>\n";
	}
else if (strcmp("linkpoint", strtolower($payment_type_name))==0)
	{
	$parse_out0.="<form action='".$http_web."/lcredit_card.php' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='sid' value='".trim($sid)."'>\n";
	$parse_out0.="<input type='hidden' name='gid' value='".trim($gid)."'>\n";
	}
else if (strcmp("14", strtolower($payment_method))==0)
	{
	include("inc/mod_HOP.php");
	
	# -------------------------------------------------------------------------

	$hop=hop_values();
	$getMerchantID=$hop['merchant_id'];
	$getPublicKey=$hop['public_key'];
	$getPrivateKey=$hop['private_key'];
	
	# -------------------------------------------------------------------------
	
	$parse_out0="<form action='https://orderpage.ic3.com/hop/orderform.jsp' method='post'>";
	$parse_out0.="<input type='hidden' name='ordtrack' value='".trim($sid)."'>";
	$parse_out0.="<input type='hidden' name='invoicetype' value='neworder'>";
	}
else if (strcmp("psigate", strtolower($payment_type_name))==0)
	{
	$parse_out0.="<form action='".$http_web."/pcredit_card.php' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='sid' value='".trim($sid)."'>\n";
	$parse_out0.="<input type='hidden' name='gid' value='".trim($gid)."'>\n";
	}
else if (strcmp("mail in payment", strtolower($payment_type_name))==0)
	{
	$parse_out0.="<form action='".$PHP_SELF."' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='pay_mod' value='mail_in_payment'>\n";
	$parse_out0.="<input type='hidden' name='sid' value='".trim($sid)."'>\n";
	$parse_out0.="<input type='hidden' name='gid' value='".trim($gid)."'>\n";
	}
else if (strcmp("paypal", strtolower($payment_type_name))==0)
	{
	$rsp=mysql_fetch_row(mysql_query("select paypal_address, paypal_image_url from payment_process where pid='".addslashes(trim($payment_method))."'"));

	$parse_out0.="<form action='https://www.paypal.com/cgi-bin/webscr' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='cmd' value='_xclick-subscriptions'>\n";
	$parse_out0.="<input type='hidden' name='business' value='".trim($rsp[0])."'>\n";
	$parse_out0.="<input type='hidden' name='item_name' value='".$package_name." [".$domain_name."]'>\n";
	$parse_out0.="<input type='hidden' name='custom' value='".$sid."'>\n";
	$parse_out0.="<input type='hidden' name='return' value='".$http_web."/paypal_success.php'>\n";
	$parse_out0.="<input type='hidden' name='cancel_return' value='".$http_web."/step_one.php'>\n";

	$parse_out0.="<input type='hidden' name='p3' value='".$term."'>\n";
	$parse_out0.="<input type='hidden' name='t3' value='M'>\n";
	$parse_out0.="<input type='hidden' name='src' value='1'>\n";
	$parse_out0.="<input type='hidden' name='sra' value='1'>\n";
	$parse_out0.="<input type='hidden' name='currency_code' value='".trim($currency_type)."'>\n";
	$parse_out0.="<input type='hidden' name='no_shipping' value='1'>\n";
	$parse_out0.="<input type='hidden' name='rm' value='2'>\n";
	$parse_out0.="<input type='hidden' name='no_note' value='1'>\n";
	if (trim($rsp[1])!="") { $parse_out0.="<input type='hidden' name='image_url' value='".$rsp[1]."'>\n"; }
	}
else if (strcmp("12", strtolower($payment_method))==0)
	{
	$rsp=mysql_fetch_row(mysql_query("select paypal_address, paypal_image_url from payment_process where pid='".addslashes(trim($payment_method))."'"));

	$parse_out0.="<form action='https://www.paypal.com/cgi-bin/webscr' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='cmd' value='_xclick-subscriptions'>\n";
	$parse_out0.="<input type='hidden' name='business' value='".trim($rsp[0])."'>\n";
	$parse_out0.="<input type='hidden' name='item_name' value='".$package_name." [".$domain_name."]'>\n";
	$parse_out0.="<input type='hidden' name='custom' value='".$sid."'>\n";
	$parse_out0.="<input type='hidden' name='return' value='".$http_web."/paypal_success.php'>\n";
	$parse_out0.="<input type='hidden' name='cancel_return' value='".$http_web."/step_one.php'>\n";

	$parse_out0.="<input type='hidden' name='p3' value='".$term."'>\n";
	$parse_out0.="<input type='hidden' name='t3' value='M'>\n";
	$parse_out0.="<input type='hidden' name='src' value='1'>\n";
	$parse_out0.="<input type='hidden' name='sra' value='1'>\n";
	$parse_out0.="<input type='hidden' name='currency_code' value='".trim($currency_type)."'>\n";
	$parse_out0.="<input type='hidden' name='no_shipping' value='1'>\n";
	$parse_out0.="<input type='hidden' name='rm' value='2'>\n";
	$parse_out0.="<input type='hidden' name='no_note' value='1'>\n";
	if (trim($rsp[1])!="") { $parse_out0.="<input type='hidden' name='image_url' value='".$rsp[1]."'>\n"; }
	}
else if (strcmp("paysystems tpp-pro", strtolower($payment_type_name))==0)
	{
	$rsp=mysql_fetch_row(mysql_query("select paysystems_companyid from payment_process where pid='".addslashes(trim($payment_method))."'"));

	$rspd=mysql_fetch_row(mysql_query("select tpp_pro_period from plan_specs where pid='".addslashes(trim($pid))."'"));

	// Get the days of payment cycle
	if ($term==1) {$xpterm=30;}
	else if ($term==3) {$xpterm=90;}
	else if ($term==6) {$xpterm=180;}
	else if ($term==12) {$xpterm=360;}


	
	$parse_out0.="<form action='https://secure.paysystems1.com/cgi-v310/payment/onlinesale-tpppro.asp' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='companyid' value='".trim($rsp[0])."'>\n";
	$parse_out0.="<input type='hidden' name='product1' value='".$package_name." [".$domain_name."]'>\n";
	$parse_out0.="<input type='hidden' name='formget' value='N'>\n";
	$parse_out0.="<input type='hidden' name='redirect' value='".$http_web."/tpp_pro_success.php'>\n";
	$parse_out0.="<input type='hidden' name='redirectfail' value='".$http_web."/index.php'>\n";
	$parse_out0.="<input type='hidden' name='option1' value='".base64_encode(e("576cb7f68040520768bf51c75f7f4c84", $sid))."'>\n";
	$parse_out0.="<input type='hidden' name='reoccur' value='Y'>\n";
	$parse_out0.="<input type='hidden' name='cycle' value='".$xpterm."'>\n";
	$parse_out0.="<input type='hidden' name='totalperiod' value='".$rspd[0]."'>\n";
	}
///// Internet Secure change 13/08/2004
else if (strcmp("internet secure", strtolower($payment_type_name))==0)
	{
	$rsp=mysql_fetch_row(mysql_query("select internetsecure_merchant_id, internetsecure_language, internetsecure_return_cgi from payment_process where pid='".addslashes(trim($payment_method))."'"));

	$parse_out0.="<form action='https://secure.internetsecure.com/process.cgi' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='MerchantNumber' value='".trim($rsp[0])."'>\n";
	$parse_out0.="<input type='hidden' name='language' value='".trim($rsp[1])."'>\n";
	$parse_out0.="<input type='hidden' name='ReturnCGI' value='".$http_web."/internet_secure_success.php"."'>\n";
	$parse_out0.="<input type='hidden' name='xxxName' value='$first_name $last_name'>\n";
	$parse_out0.="<input type='hidden' name='xxxCompany' value='$organization_name'>\n";
	$parse_out0.="<input type='hidden' name='xxxAddress' value='$street_address_1'>\n";
	$parse_out0.="<input type='hidden' name='xxxCity' value='$city'>\n";
	$parse_out0.="<input type='hidden' name='xxxProvince' value='$state'>\n";
	$parse_out0.="<input type='hidden' name='xxxCountry' value='$country'>\n";
	$parse_out0.="<input type='hidden' name='xxxPostal' value='$zip_code'>\n"; 
	$parse_out0.="<input type='hidden' name='xxxEmail' value='$email'>\n"; 
	$parse_out0.="<input type='hidden' name='xxxPhone' value='$phone'>\n"; 
	$parse_out0.="<input type='hidden' name='xxxVar1' value='".base64_encode(e("576cb7f68040520768bf51c75f7f4c84", $sid))."'>\n";
	
	}


///// Internet Secure change 13/08/2004
	
else if (strcmp("2checkout", strtolower($payment_type_name))==0)
	{
	$rsp=mysql_fetch_row(mysql_query("select checkout_sid, demo, co_system from payment_process where pid='".addslashes(trim($payment_method))."'"));
	# $rsp=mysql_fetch_row(mysql_query("select checkout_sid, demo from payment_process where pid='".addslashes(trim($payment_method))."'"));

	$rspd=mysql_fetch_row(mysql_query("select monthly_pid, quarterly_pid, semi_annual_pid, annual_pid from plan_specs where pid='".addslashes(trim($pid))."'"));

	if ($term==1) { $mqsaa_pid=$rspd[0]; }
	else if ($term==3) { $mqsaa_pid=$rspd[1]; }
	else if ($term==6) { $mqsaa_pid=$rspd[2]; }
	else if ($term==12) { $mqsaa_pid=$rspd[3]; }
	
	if ($rsp[2]==0) 
		{ 
		$parse_out0.="<form action='https://www.2checkout.com/cgi-bin/crbuyers/recpurchase.2c' method='POST'>\n"; 
		$parse_out0.="<input type='hidden' name='merchant_order_id' value='".trim($sid."|0")."'>\n";
		}
	else 
		{ 
		$parse_out0.="<form action='https://www2.2checkout.com/2co/buyer/purchase' method='POST'>\n"; 
		$parse_out0.="<input type='hidden' name='quantity' value='1'>\n";
		$parse_out0.="<input type='hidden' name='merchant_product_id' value='".trim($sid."|0")."'>\n";
		}
	
	
	$parse_out0.="<input type='hidden' name='sid' value='".trim($rsp[0])."'>\n";
	$parse_out0.="<input type='hidden' name='product_id' value='".$mqsaa_pid."'>\n";

	if (trim($rsp[1])==1) { $parse_out0.="<input type='hidden' name='demo' value='Y'>\n"; }
	if ($domain_registration==1)
		{
		$getcoid=mysql_fetch_row(mysql_query("select coid from tld_chart where tld_id='".addslashes(trim($tld_id))."'"));
		$parse_out0.="<input type='hidden' name='quantity1' value='1'>\n";
		$parse_out0.="<input type='hidden' name='product_id1' value='".addslashes(trim($getcoid[0]))."'>\n";
		}

	}
else if (strcmp("worldpay future pay", strtolower($payment_type_name))==0)
	{	
	// get the paypal addr from the payment_process table
	$rsp=mysql_fetch_row(mysql_query("select worldpay_id, worldpay_cc, worldpay_demo from payment_process where pid='".addslashes(trim($payment_method))."'"));

	// Get the link id
	if ($term==1)  { $intrval=1; }
	else if ($term==3) { $intrval=3; }
	else if ($term==6) { $intrval=6; }
	else if ($term==12) { $intrval=12; }

	$parse_out0.="<form action='https://select.worldpay.com/wcc/purchase' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='desc' value='".$package_name." [".$domain_name."]'>\n";
	$parse_out0.="<input type='hidden' name='cartId' value='".trim($sid)."'>\n";
	$parse_out0.="<input type='hidden' name='instId' value='".trim($rsp[0])."'>\n";
	$parse_out0.="<input type='hidden' name='currency' value='".trim($rsp[1])."'>\n";
	$parse_out0.="<input type='hidden' name='futurePayType' value='regular'>\n";
	$parse_out0.="<input type='hidden' name='option' value='1'>\n";
	$parse_out0.="<input type='hidden' name='startDelayUnit' value='3'>\n";
	$parse_out0.="<input type='hidden' name='startDelayMult' value='".$intrval."'>\n";
	$parse_out0.="<input type='hidden' name='intervalUnit' value='3'>\n";
	$parse_out0.="<input type='hidden' name='intervalMult' value='".$intrval."'>\n";
	$xlink=str_replace("http://", "", strtolower($http_web));
	$xlink=str_replace("https://", "", $xlink);
	$parse_out0.="<input type='hidden' name='MC_callback' value='".trim($xlink)."/worldpay_success.php'>\n";
	$parse_out0.="<input type='hidden' name='testMode' value='".$rsp[2]."'>\n";
	}
else if (strcmp("13", strtolower($payment_method))==0)
	{	
	// get the paypal addr from the payment_process table
	$rsp=mysql_fetch_row(mysql_query("select worldpay_id, worldpay_cc, worldpay_demo from payment_process where pid='".addslashes(trim($payment_method))."'"));

	// Get the link id
	if ($term==1)  { $intrval=1; }
	else if ($term==3) { $intrval=3; }
	else if ($term==6) { $intrval=6; }
	else if ($term==12) { $intrval=12; }

	$parse_out0.="<form action='https://select.worldpay.com/wcc/purchase' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='desc' value='".$package_name." [".$domain_name."]'>\n";
	$parse_out0.="<input type='hidden' name='cartId' value='".trim($sid)."'>\n";
	$parse_out0.="<input type='hidden' name='instId' value='".trim($rsp[0])."'>\n";
	$parse_out0.="<input type='hidden' name='currency' value='".trim($rsp[1])."'>\n";
	$parse_out0.="<input type='hidden' name='futurePayType' value='regular'>\n";
	$parse_out0.="<input type='hidden' name='option' value='1'>\n";
	$parse_out0.="<input type='hidden' name='startDelayUnit' value='3'>\n";
	$parse_out0.="<input type='hidden' name='startDelayMult' value='".$intrval."'>\n";
	$parse_out0.="<input type='hidden' name='intervalUnit' value='3'>\n";
	$parse_out0.="<input type='hidden' name='intervalMult' value='".$intrval."'>\n";
	$xlink=str_replace("http://", "", strtolower($http_web));
	$xlink=str_replace("https://", "", $xlink);
	$parse_out0.="<input type='hidden' name='MC_callback' value='".trim($xlink)."/worldpay_success.php'>\n";
	$parse_out0.="<input type='hidden' name='testMode' value='".$rsp[2]."'>\n";
	}

if ($dedicated==1) { echo "<input type='hidden' name='dedicated' value='1'>\n"; }

# start new -------------------------------------------------------------------------------------------------
$parse_out1="";

$count=substr_count($addon_choices, "|");
$explode=explode("|", $addon_choices);


$tok=strtok($group_addons, "|");
while ($tok)
	{
	for ($i=0; $i<=$count; $i++) 
		{ 
		if ($explode[$i]==$tok) 
			{ 
			$query2="select ";
			$query2.="addon_name, ";				// 0
			$query2.="setup_cost, ";				// 1
			$query2.="setup_activate, ";			// 2
			$query2.="addon_cost, ";				// 3
			$query2.="addon_state, ";				// 4
			$query2.="addon_activate, ";			// 5
			$query2.="private_ns ";					// 6
			$query2.="from addon_specs ";
			$query2.="where aid='".addslashes(trim($tok))."' ";
			$query2.="and ";
			$query2.="coupon='0'";

			$rs2=mysql_fetch_row(mysql_query($query2));

			$addon_name=stripslashes(trim($rs2[0])); 
			$setup_cost=stripslashes(trim($rs2[1])); 
			$setup_activate=stripslashes(trim($rs2[2]));
			$addon_cost=stripslashes(trim($rs2[3]));
			$addon_state=stripslashes(trim($rs2[4]));
			$addon_activate=stripslashes(trim($rs2[5]));
			$private_ns=stripslashes(trim($rs2[6]));

			$parse_out1.=("
				<tr>
					<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$addon_name."</td>
					<td width='65%' align='left' valign='top'>
					<table width='100%' cellpadding='0' cellspacing='0' border='0'>
						<tr>
							<td width='1%' align='left' valign='top'>Setup Fee:</td>
							<td width='99%' align='left' valign='top'>
						");
					if ($setup_activate==1) { $parse_out1.= $currency."".sprintf("%01.2f", $setup_cost)." ".$currency_type; }
					else { $parse_out1.= "No Cost"; }
					$parse_out1.=("
							</td>
						</tr>
						<tr>
							<td width='1%' align='left' valign='top'>$text_cost</td>
							<td width='99%' align='left' valign='top'>
						");
					if ($addon_activate==1) 
						{ 
						$parse_out1.= $currency.sprintf("%01.2f", $addon_cost)." ".$currency_type; 
						
						if ($addon_state==1) { $parse_out1.= $text_onetimefee; }
						else if ($addon_state==2) { $parse_out1.= $text_permonth; }
						else if ($addon_state==3) { $parse_out1.= $text_peryear; }
						}
					else { $parse_out1.= "No Cost"; }
					$parse_out1.=("
							</td>
						</tr>
						");
					if ($private_ns==1)
						{
						if (trim($pns1)!=""&&trim($pns2)!="")
							{
							$parse_out1.=("
								<tr>
									<td width='1%' align='left' valign='top'>$text_setupfee</td>
									<td width='99%' align='left' valign='top'>
								");
							$parse_out1.= "<b>".$pns1."</b>.".$domain_name."<br>";
							$parse_out1.= "<b>".$pns2."</b>.".$domain_name."<br>";
							$parse_out1.=("
									</td>
								</tr>
								");
							}
						}
					$parse_out1.=("
						<tr>
							<td width='1%' align='left' valign='top'><img src='".$http_images."/space.gif' width='100' height='12'></td>
							<td width='99%' align='left' valign='top'></td>
						</tr>
					</table>
					</td>
				</tr>
				");

			unset($addon_name);
			unset($setup_cost);
			unset($setup_activate);
			unset($addon_cost);
			unset($addon_state);
			unset($addon_activate);
			unset($query2);
			unset($rs2);
			} 
		}	
	$tok=strtok("|");
	}
?>
