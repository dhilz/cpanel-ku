<?PHP
$count=substr_count($addon_choices, "|");
$explode=explode("|", $addon_choices);


$tok=strtok($group_addons, "|");
while ($tok)
	{
	for ($i=0; $i<=$count; $i++) 
		{ 
		if ($explode[$i]==$tok) 
			{ 
			$query2="select ";
			$query2.="addon_name, ";				// 0
			$query2.="setup_cost, ";				// 1
			$query2.="setup_activate, ";			// 2
			$query2.="addon_cost, ";				// 3
			$query2.="addon_state, ";				// 4
			$query2.="addon_activate, ";			// 5
			$query2.="private_ns ";					// 6
			$query2.="from addon_specs ";
			$query2.="where aid='".addslashes(trim($tok))."' ";
			$query2.="and ";
			$query2.="coupon='0'";

			$rs2=mysql_fetch_row(mysql_query($query2));

			$addon_name=stripslashes(trim($rs2[0])); 
			$setup_cost=stripslashes(trim($rs2[1])); 
			$setup_activate=stripslashes(trim($rs2[2]));
			$addon_cost=stripslashes(trim($rs2[3]));
			$addon_state=stripslashes(trim($rs2[4]));
			$addon_activate=stripslashes(trim($rs2[5]));
			$private_ns=stripslashes(trim($rs2[6]));

			echo("
				<tr>
					<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$addon_name."</td>
					<td width='65%' align='left' valign='top'>
					<table width='100%' cellpadding='0' cellspacing='0' border='0'>
						<tr>
							<td width='1%' align='left' valign='top'>".$text_setupfee."</td>
							<td width='99%' align='left' valign='top'>
						");
					if ($setup_activate==1) { echo $currency."".sprintf("%01.2f", $setup_cost)." ".$currency_type; }
					else { echo "No Cost"; }
					echo("
							</td>
						</tr>
						<tr>
							<td width='1%' align='left' valign='top'>".$text_cost."</td>
							<td width='99%' align='left' valign='top'>
						");
					if ($addon_activate==1) 
						{ 
						echo $currency."".sprintf("%01.2f", $addon_cost)." ".$currency_type;
						echo " ";
						
						if ($addon_state==1) { echo $text_onetimefee; }
						else if ($addon_state==2) { echo $text_permonth; }
						else if ($addon_state==3) { echo $text_annual; }
						}
					else { echo "No Cost"; }
					echo("
							</td>
						</tr>
						");
					if ($private_ns==1)
						{
						if (trim($pns1)!=""&&trim($pns2)!="")
							{
							echo("
								<tr>
									<td width='1%' align='left' valign='top'>$text_nsprefix</td>
									<td width='99%' align='left' valign='top'>
								");
							echo "<b>".$pns1."</b>.".$domain_name."<br>";
							echo "<b>".$pns2."</b>.".$domain_name."<br>";
							echo("
									</td>
								</tr>
								");
							}
						}
					echo("
						<tr>
							<td width='1%' align='left' valign='top'><img src='".$http_images."/space.gif' width='100' height='12'></td>
							<td width='99%' align='left' valign='top'></td>
						</tr>
					</table>
					</td>
				</tr>
				");

			unset($addon_name);
			unset($setup_cost);
			unset($setup_activate);
			unset($addon_cost);
			unset($addon_state);
			unset($addon_activate);
			unset($query2);
			unset($rs2);
			} 
		}	
	$tok=strtok("|");
	}
?>