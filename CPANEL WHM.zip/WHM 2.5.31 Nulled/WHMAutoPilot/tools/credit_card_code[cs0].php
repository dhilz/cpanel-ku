<?PHP
echo addslashes(serialize($_POST));
if(phpversion() <= "4.0.6") { $_POST=$HTTP_POST_VARS; }
$sid=$_POST['sid'];

$cksid=mysql_fetch_row(mysql_query("select count(*) from session_history where sid='".addslashes(trim($sid))."'"));

if ($cksid[0]<=0) 
	{	
	# added 6/2/2004
	raw_post_details($email_admin, "ERROR[10] SID was not in the database!", "unknown", "cybersource.com Public Order System");

	header("Location: ".$http_web."/step_one.php");	
	exit; 
	}
else if (!isset($sid)) 
	{ 
	# added 6/2/2004
	raw_post_details($email_admin, "ERROR[18] Sid was not set!", "unknown", "CyberSource.com Public Order System");

	header("Location: ".$http_web."/step_one.php"); 
	exit; 
	}

if (isset($_POST['x_Submit']))
	{
	if (strlen(trim($_POST['x_First_Name']))==0) { $e0=true; }
		if (strlen(trim($_POST['x_Last_Name']))==0) { $e1=true; }
		if (strlen(trim($_POST['x_Address']))==0) { $e2=true; }
		if (strlen(trim($_POST['x_City']))==0) { $e3=true; }
		if (strlen(trim($_POST['x_Zip']))==0) { $e4=true; }
		if (strlen(trim($_POST['x_Phone']))<10) { $e5=true; }
		if (strlen(trim($_POST['x_Card_Num']))==0) { $e6=true; }
		if (strlen(trim($_POST['x_Exp_Date_m']))==0||strlen(trim($_POST['x_Exp_Date_y']))==0) { $e7=true; }
		if (strlen(trim($_POST['x_Card_Code']))==0) { $e8=true; }
		if (strlen(trim($_POST['x_Card_Code']))==6) { $e9=true; }

	if (!isset($e0)&&!isset($e1)&&!isset($e2)&&!isset($e3)&&!isset($e4)&&!isset($e5)&&!isset($e6)&&!isset($e7)&&!isset($e8)&&!isset($e9))
		{
		#include "inc/HOP.php";
		# ---------------------------------------------------------

		$query1="select ";
		$query1.="total_due_today, ";	// 0
		$query1.="pid, ";				// 1
		$query1.="domain_name, ";		// 2
		$query1.="total_due_reoccur, ";	// 3
		$query1.="payment_term, ";		// 4
		$query1.="uid ";				// 5
		$query1.="from session_history ";
		$query1.="where sid='".$_POST['sid']."'";

		$rs1=mysql_fetch_row(mysql_query($query1));

		$total_due_today=stripslashes(trim($rs1[0]));
		$pid=stripslashes(trim($rs1[1]));
		$domain_name=stripslashes(trim($rs1[2]));
		$total_due_reoccur=stripslashes(trim($rs1[3]));
		$recurring_cycle=stripslashes(trim($rs1[4]));
		$uid=stripslashes(trim($rs1[5]));

		if ($recurring_cycle=="monthly") { $interval_0="M"; }
		else if ($recurring_cycle=="quarterly") { $interval_0="Q"; }
		else if ($recurring_cycle=="semi_annual") { $interval_0="S"; }
		else if ($recurring_cycle=="annual") { $interval_0="A"; }
		
		# ---------------------------------------------------------

		$query2="select ";
		$query2.="package_name ";	// 0
		$query2.="from plan_specs ";
		$query2.="where pid='".addslashes(trim($pid))."'";

		$rs2=mysql_fetch_row(mysql_query($query2));

		function generate_id()
			{
			srand;   
			settype($random, "Integer");
			$random=rand(0, 100000);    
			$epoch=time();    
			$moid=$epoch^$random;

			return $moid;
			}
		$thisgoesin=generate_id();

		$package_name=stripslashes(trim($rs2[0]));
		$myoidisthis=$package_name." for ".$domain_name." to reoccur ".$recurring_cycle." at ".$total_due_reoccur;
		# ---------------[psigate processing]------------------------------
		$amount=$total_due_today;
		
		#include "inc/HOP.php";
		function php_hmacsha1($data, $key) {
		  $klen = strlen($key);
		  $blen = 64;
		  $ipad = str_pad("", $blen, chr(0x36));
		  $opad = str_pad("", $blen, chr(0x5c));

		  if ($klen <= $blen) {
			while (strlen($key) < $blen) {
			  $key .= "\0";
			}				#zero-fill to blocksize
		  } else {
			$key = cybs_sha1($key);	#if longer, pre-hash key
		  }
		  $key = str_pad($key, strlen($ipad) + strlen($data), "\0");
		  return cybs_sha1(($key ^ $opad) . cybs_sha1($key ^ $ipad . $data));
		}

		# calculates SHA-1 digest of the input string
		# cleaned up from John Allen's "SHA in 8 lines of perl5"
		# at http://www.cypherspace.org/~adam/rsa/sha.html
		#
		# returns the hash in a (binary) string

		function cybs_sha1($in) {
		  $indx = 0;
		  $chunk = "";

		  $A = array(1732584193, 4023233417, 2562383102,  271733878, 3285377520);
		  $K = array(1518500249, 1859775393, 2400959708, 3395469782);
		  $a = $b = $c = $d = $e = 0;
		  $l = $p = $r = $t = 0;

		  do{
			$chunk = substr($in, $l, 64);
			$r = strlen($chunk);
			$l += $r;

			if ($r<64 && !$p++) {
			  $r++;
			  $chunk .= "\x80";
			}
			$chunk .= "\0\0\0\0";
			while (strlen($chunk) % 4 > 0) { 
			  $chunk .= "\0";
			}
			$len = strlen($chunk) / 4;
			if ($len > 16) $len = 16;
			$fmt = "N" . $len;
			$W = array_values(unpack($fmt, $chunk));
			if ($r < 57 ) { 
			  while (count($W) < 15) {
			array_push($W, "\0");
			  }
			  $W[15] = $l*8;
			}

			for ($i = 16; $i <= 79; $i++) {
			  $v1 = da($W, $i-3);
			  $v2 = da($W, $i-8);
			  $v3 = da($W, $i-14);
			  $v4 = da($W, $i-16);
			  array_push($W, L($v1 ^ $v2 ^ $v3 ^ $v4, 1));
			}

			list($a,$b,$c,$d,$e)=$A;

			for ($i = 0; $i<=79; $i++) {
			  $t0 = 0;
			  switch(intval($i/20)) {
			case 1:
			case 3:
			$t0 = F1($b, $c, $d);
			break;
			case 2:
			$t0 = F2($b, $c, $d);
			break;
			  default:
			$t0 = F0($b, $c, $d);
			break;
			  }
			  $t = M($t0 + $e  + d($W, $i) + d($K, $i/20) + L($a, 5));
			  $e = $d;
			  $d = $c;
			  $c = L($b,30);
			  $b = $a;
			  $a = $t;
			}

			$A[0] = M($A[0] + $a);
			$A[1] = M($A[1] + $b);
			$A[2] = M($A[2] + $c);
			$A[3] = M($A[3] + $d);
			$A[4] = M($A[4] + $e);

		  }while ($r>56);
		  $v = pack("N*", $A[0], $A[1], $A[2], $A[3], $A[4]);
		  return $v;
		}

		#### Ancillary routines used by sha1

		function dd($x) {
		  if (defined($x)) return $x;
		  return 0;
		}

		function da($arr, $x) {
		  if ($x < count($arr)) return $arr[$x];
		  return 0;
		}

		function F0($b, $c, $d) {
		  return $b & ($c ^ $d) ^ $d;
		}

		function F1($b, $c, $d) {
		  return $b ^ $c ^ $d;
		}

		function F2($b, $c, $d) {
		  return ($b | $c) & $d | $b & $c;
		}

		# ($num)
		function M($x) {
		  $m = 1+~0;
		  if ($m == 0) return $x;
		  return($x - $m * intval($x/$m));
		}

		# ($string, $count)
		function L($x, $n) { 
		  return ( ($x<<$n) | ((pow(2, $n) - 1) & ($x>>(32-$n))) );
		}

		####
		#### end of HMAC SHA1 implementation #####




		####
		#### HOP functions
		#### Copyright 2003, CyberSource Corporation.  All rights reserved.
		####

		function getmicrotime(){ 
		  list($usec, $sec) = explode(" ",microtime());
		  $usec = (int)((float)$usec * 1000);
		  while (strlen($usec) < 3) { $usec = "0" . $usec; }
		  return $sec . $usec;
		}


		function hopHash($data, $key) {
			return base64_encode(php_hmacsha1($data, $key));
		}

		function getMerchantID() { return  "1image"; }
		function getPublicKey()  { return "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDQdcP/XwtKPp6uLO8vaGhbejPWY93yQ+rvXqJ/O5yGc5kkuEeubGial4SaMOjlBQQ7pAwRfkfx9WmAPW3WqadbplRfAagExqkyCuLroEh1GU3cEf5coEqqffFYxSwKhh+Jn9DRkF1WWo3lGZX4b2rVI/4l7Q1LUV+oa+KWqKXk8QIDAQAB"; }
		function getPrivateKey() { return "MIICdQIBADANBgkqhkiG9w0BAQEFAASCAl8wggJbAgEAAoGBANB1w/9fC0o+nq4s7y9oaFt6M9Zj3fJD6u9eon87nIZzmSS4R65saJqXhJow6OUFBDukDBF+R/H1aYA9bdapp1umVF8BqATGqTIK4uugSHUZTdwR/lygSqp98VjFLAqGH4mf0NGQXVZajeUZlfhvatUj/iXtDUtRX6hr4paopeTxAgMBAAECgYB2jgNiARPSrbphJH0DYUW4gM9qZnGbjrTWXePcqHJkpOm70HIz6MO05+cqKhbJ6Qh3Qtz6Ne+E1CWkIUuOgf4DQfsolq2WHiDt5AWpsOgjze8TLB93V9qThGrVjMgVNLVVuws8b7vrs5HbqC0l6D2oubFny3dyBNcvF6+37pNeAQJBAPqX9Hr4eILFVea7sPLwCo+aEUWdpIMDFukzi0loXuFxUSgHx4D6rq8Ba+5HbeGY+vMHJUT+OO2G1QHIaVxET+kCQQDU9Rqsxt4cf9P5mXsHxrfctUSmVgkcjVYoHyft9hk6/8z8+KCYegn5ex2AvpeYLihGp4nToywhhGZL8bz/YI/JAkBbFZJyhA/hkHKpvD0UAHYGPjza7fLW/+968hZFp18dWH/kKfe1BOkriTu+z028O0uzvDwquLDefSy9SigptlbJAkBHc5mooO0DOOyBkbqS6FzmY7eN684Q02c1/QYjtG/QuOUpd65CmqfgGivS95/bgpkm46294cC72jWMg6Z7NQXpAkAYSn4aXfDvM0faYXfh0FJzKC66Masmma7688ixJonQ3SB6AFGZAitwvrsJvdp/FI7MziBLg8DBC6J7DL2lC9Lh"; }


		#### HOP integration function
		  $merchantID = getMerchantID();
		  $timestamp = getmicrotime();
		  $data = $merchantID.$amount.$timestamp;
		 #  $data = $merchantID.$amount.microtime(); # no effect
		  $pub = getPublicKey();
		  $pvt = getPrivateKey();
		
		  $pub_digest = hopHash($data, $pub);
		  $pvt_digest = hopHash($data, $pvt);
		
		function VerifySignature($data, $signature) {
		$pub = getPublicKey();
		$pub_digest = hopHash($data, $pub);
		return strcmp($pub_digest, $signature) == 0;
		}

		$card_num=$_POST["x_Card_Num"];
		$cardtype=substr($card_num, 0, 1);
		if ($cardtype=="5") { $cardtype="002"; }
		else if ($cardtype=="4") { $cardtype="001"; }
		else if ($cardtype=="3") { $cardtype="003"; }
		else if ($cardtype=="6") { $cardtype="004"; }

		// live
		#$processor="https://orderpage.ic3.com/hop/ProcessOrder.do";
		// test
		#$processor="https://orderpage.ic3.com/hop/orderform.jsp";
		// debug output
		$processor="https://orderpage.ic3.com/hop/CheckOrderData.do";

		$link_out.="&orderPage_timestamp=".$timestamp;
		$link_out.="&merchantID=".$merchantID;
		$link_out.="&orderPage_signaturePublic=".$pub_digest;
		$link_out.="&orderPage_signaturePrivate=".$pvt_digest;

		##-----start credit card info-----##		
		$link_out.="&card_accountNumber=".$_POST['x_Card_Num'];
		$link_out.="&card_expirationMonth=".$_POST['x_Exp_Date_m'];
		$link_out.="&card_expirationYear=".$_POST['x_Exp_Date_y'];
		$link_out.="&card_cvNumber=".$_POST['x_Card_Code'];
		$link_out.="&card_cardType=".$cardtype;
		
		#$link_out.="$signature=".InsertSignature("10.00");

		##-----start description stuff-----##
		$link_out.="&comments=".$myoidisthis;
		$link_out.="&orderNumber=".$domain_name;
		$link_out.="&amount=".$total_due_today;
		#$link_out.="&VerifySignature=".$http_web."/cybersource_success.php";

		##-----customer information-----##
		$link_out.="&billTo_firstName=".$_POST["x_First_Name"];
		$link_out.="&billTo_lastName=".$_POST['x_Last_Name'];
		$link_out.="&billTo_street1=".$_POST['x_Address'];
		$link_out.="&billTo_city=".$_POST['x_City'];
		$link_out.="&billTo_state=".$_POST['x_state'];
		$link_out.="&billTo_postalCode=".$_POST['x_Zip'];
		$link_out.="&billTo_country=".$_POST['x_Country'];
		$link_out.="&billTo_phoneNumber=".$_POST['x_Phone'];
		$link_out.="&billTo_email=".$_POST['x_Email'];
		
		print_r($link_out);

		# $curl_root="/usr/bin/curl";
		if ($curl_root=="") 
			{
			$link=curl_init();
			curl_setopt($link, CURLOPT_URL, $processor);
			curl_setopt($link, CURLOPT_VERBOSE, 0);
			curl_setopt($link, CURLOPT_POST, 1);
			curl_setopt($link, CURLOPT_POSTFIELDS, $link_out);
			#curl_setopt($link, CURLOPT_SSL_VERIFYPEER, 0);
			#curl_setopt($link, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($link, CURLOPT_RETURNTRANSFER, 1);
			#curl_setopt($link, CURLOPT_FOLLOWLOCATION, 1);
			$xresult=curl_exec($link);
			curl_close($link);
			$result=split("\,", $xresult);
			print_r($xresult); die;
			}
		}
	}

?>