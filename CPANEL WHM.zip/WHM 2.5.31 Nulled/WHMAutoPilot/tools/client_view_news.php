<?PHP
include"../inc/var.php";
include"../inc/connect.php";

// read in news file	
@$read = fopen ($below_public."/news.nfo", "r");
@$news = fread ($read, filesize($below_public."/news.nfo"));
@fclose ($read);

$news=wordwrap($news, 45);
echo("<html>
<head>
	<title>".$site_title." News</title>
	<style>
		body, td, center, p 
			{
			font-family:verdana, arial, helvetica; 
			font-size: 13px; 
			color: #000000;
			scrollbar-3d-light-color:WHITE;
			scrollbar-arrow-color:#CE4100;
			scrollbar-base-color:WHITE;
			scrollbar-dark-shadow-color:WHITE;
			scrollbar-face-color:#F2EEEC;
			scrollbar-highlight-color:WHITE;
			scrollbar-shadow-color:WHITE;
			}
		div {font-family:verdana, arial, helvetica; font-size: 11px}
		A:link { 
		text-decoration: underline: none; none; color:#000000;
		}
		A:visited { 
		text-decoration: underline: none; none; color:#000000;
		}
		A:hover { 
		text-decoration: underline; font-weight: none;color:#990000;
		}
		.linkTable
		{
		 PADDING-LEFT: 5px
		}
	</style>
</head>
<body marginheight='0' topmargin='0' marginwidth='0' leftmargin='0' style='margin:0; padding:0;' bgcolor='#ffffff'>
	");
echo nl2br(stripslashes(trim($news)));
echo("</body>
</html>
	");
?>