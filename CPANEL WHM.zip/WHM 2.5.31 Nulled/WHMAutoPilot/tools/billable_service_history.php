<?PHP
include "inc/invoice_functions.php";
$buffer=("
<table width='92%' border='0' cellspacing='1' cellpadding='2'>
	<tr>
		<td colspan='6' valign='middle'><img src='".$http_images."/menu_arrow.gif'><b>$text_billableheader</b></td>
	</tr>
	<tr>
		<td width='10%' align='center' valign='middle' bgcolor='#E5E7E9'>&nbsp;<b>$text_view</b></td>
		<td width='10%' align='left' valign='middle' bgcolor='#E5E7E9'>&nbsp;<b>$text_invoice</b></td>
		<td width='38%' align='left' valign='middle' bgcolor='#E5E7E9'>&nbsp;<b>$text_clientname</b></td>
		<td width='15%' align='left' valign='middle' bgcolor='#E5E7E9'>&nbsp;<b>$text_created</b></td>
		<td width='18%' align='left' valign='middle' bgcolor='#E5E7E9'>&nbsp;<b>$text_invoiceterms</b></td>
		<td width='10%' align='left' valign='middle' bgcolor='#E5E7E9'>&nbsp;<b>$text_status</b></td>
	</tr>
	");

$query0="select ";
$query0.="uid, ";
$query0.="first_name, ";
$query0.="last_name, ";
$query0.="email ";
$query0.="from user ";
$query0.="where ";
$query0.="uid='".addslashes(trim($uid))."'";

$rs0=mysql_fetch_row(mysql_query($query0));

$uid=stripslashes(trim($rs0[0]));
$first_name=stripslashes(trim($rs0[1]));
$last_name=stripslashes(trim($rs0[2]));
$email=stripslashes(trim($rs0[3]));

$x=1;
$y=1;
$query="select ";
$query.="iid, ";			// 0
$query.="invoice_number, ";	// 1
$query.="created, ";		// 2
$query.="due_date, ";		// 3
$query.="status, ";			// 4
$query.="date_paid, ";		// 5
$query.="uid, ";			// 6
$query.="invoice_terms ";	// 7
$query.="from invoice ";
$query.="where ";
$query.="invoice_type='1' ";
$query.="and ";
$query.="uid='".addslashes(trim($uid))."' ";
$query.="order by created desc";

$row=mysql_query($query);
while ($rs=mysql_fetch_row($row))
	{
	$iid=stripslashes(trim($rs[0]));
	$invoice_number=stripslashes(trim($rs[1]));
	$created=stripslashes(trim($rs[2]));
	$due_date=stripslashes(trim($rs[3]));
	$invoice_status=stripslashes(trim($rs[4]));
	$date_paid=stripslashes(trim($rs[5]));
	$uid=stripslashes(trim($rs[6]));
	$invoice_terms=stripslashes(trim($rs[7]));
	$invoice_terms_displayed=translate_invoice_terms($invoice_terms);

	$client_name="<a href='mailto:".$email."'>";
	$client_name.=$first_name." ".$last_name."</a>";
	
	if ($y==1) { $bgcolor="#F2F4F6"; $y=0; } else { $bgcolor="#ECEEF0"; $y=1; }

	$buffer.=("
		<tr>
			<td align='center' valign='top' bgcolor='".$bgcolor."'><a href='".$http_web."/invoice_service.php?c=".urlencode(e("576cb7f68040520768bf51c75f7f4c84", $iid))."' target='_blank'><img alt='$text_printableinvoice' src='".$http_images."/view_formatted.gif' border='0'></a></td>
			<td align='left' valign='top' bgcolor='".$bgcolor."'>&nbsp;#".$invoice_number."</td>
			<td align='left' valign='top' bgcolor='".$bgcolor."'>&nbsp;".$client_name."</td>
			<td align='left' valign='top' bgcolor='".$bgcolor."'>&nbsp;".date("m/d/Y", $created)."</td>
			<td align='left' valign='top' bgcolor='".$bgcolor."'>&nbsp;".$invoice_terms_displayed."</td>
			<td align='left' valign='top' bgcolor='".$bgcolor."'>&nbsp;".invoice_status($invoice_status)."</td>
		</tr>
		");
	$x++;
	}

if ($x==1)
	{
	echo("
		<table width='".$standard_table_width."' border='0' cellspacing='1' cellpadding='2'>
			<tr>
				<td colspan='6'><img src='".$http_images."/space.gif' width='1' height='4'></td>
			</tr>
			<tr>
				<td colspan='6'><font color='#990000'>$text_nobillableservices</font></td>
			</tr>
		</table>
	");
	}
else
	{
	echo $buffer;
	echo("
			<tr>
				<td colspan='6'><img src='".$http_images."/space.gif' width='1' height='16'></td>
			</tr>
		</table>
		");
	}
?>