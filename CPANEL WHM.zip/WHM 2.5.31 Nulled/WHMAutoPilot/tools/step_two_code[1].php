<?PHP
# dedicated module
echo("
	<form action='".$PHP_SELF."' method='POST'>
	<input type='hidden' name='sid' value='".trim($sid)."'>
	<input type='hidden' name='gid' value='".trim($gid)."'>
	<input type='hidden' name='xdedicated' value='1'>
	<input type='hidden' name='dedicated' value='1'>
	".((isset($pid))?"<input type='hidden' name='pid' value='".trim($pid)."'>":"")."
	");
if (isset($e0)||isset($e1)||$domain==-1||$domain==-2||$domain==-3)
	{
	echo("
	<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
		<tr>
			<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$steptwo_serverhostname."</td> 
		</tr>
		
	</table>
		");
	}
if (isset($e2))
	{
	echo("
	<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
		<tr>
			<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$steptwo_serverrootpass."</td> 
		</tr>
		
	</table>
		");
	}
if ($domain==-1)
	{
	echo("
	<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
		<tr>
			<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$steptwo_startwhypen."</td> 
		</tr>
		
	</table>
		");
	}
if ($domain==-2)
	{
	echo("
	<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
		<tr>
			<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$steptwo_endwhypen."</td> 
		</tr>
		
	</table>
		");
	}
if ($domain==-3)
	{
	echo("
	<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
		<tr>
			<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$steptwo_dash."</td> 
		</tr>
		
	</table>
		");
	}
if ($domain==-4)
	{
	echo("
	<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
		<tr>
			<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$steptwo_invalid_char."</td> 
		</tr>
		
	</table>
		");
	}
if (isset($e3)||isset($e4)||$domain==-1||$domain==-2||$domain==-3||$domain==-4)
	{
	echo("
	<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
		<tr>
			<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$steptwo_nameserversmissing."</td> 
		</tr>
		
	</table>
		");
	}

echo("
	<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
		<tr>
			<td colspan='2' align='left' valign='middle'><img border='0' src='".$http_images."/order_arrow.gif'>".$steptwo_dedicatedoptions."</td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='middle'><img src='".$http_images."/space.gif' width='1' height='4'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='32' height='1'>".$steptwo_serverhostname."</td>
			<td width='75%' align='left' valign='middle'><input size='10' maxlength='255' ".$orderinput_style." type='text' name='server_hostname' value='".((isset($server_hostname))?"".((trim($server_hostname)!="")?"".$server_hostname."":"server1")."":"server1")."'>&nbsp;<b>.</b>&nbsp;<input size='30' maxlength='255' ".$orderinput_style." type='text' name='domain_name' value='".((isset($domain_name))?"".((trim($domain_name)!="")?"".$domain_name."":"replace-with-your-domain.net")."":"replace-with-your-domain.net")."'><br><img src='".$http_images."/drop_arrow.gif'><font size='1' color='#990000'>".$steptwo_dednameserverprefix."</font></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='middle'><img src='".$http_images."/space.gif' width='32' height='1'>".$steptwo_serverrootpass."</td>
			<td width='75%' align='left' valign='middle'><input size='45' maxlength='255' ".$orderinput_style." type='text' name='root_pw' value='".((isset($root_pw))?"".$root_pw."":"")."'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='middle'><img src='".$http_images."/space.gif' width='32' height='1'>".$steptwo_nameserverprefix."</td>
			<td width='75%' align='left' valign='middle'><font color='#990000'>".$steptwo_primaryprefix."</font> <input size='10' maxlength='255' ".$orderinput_style." type='text' name='pns1' value='".((isset($pns1))?"".((trim($pns1)!="")?"".$pns1."":"ns1")."":"ns1")."'>&nbsp;&nbsp;&nbsp;<font color='#990000'>".$steptwo_secondaryprefix."</font> <input size='10' maxlength='255' ".$orderinput_style." type='text' name='pns2' value='".((isset($pns2))?"".((trim($pns2)!="")?"".$pns2."":"ns1")."":"ns2")."'></td>
		</tr>
	</table>
	");
?>