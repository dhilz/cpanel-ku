<?PHP
if(phpversion()<="4.0.6") { $_POST=$HTTP_POST_VARS; }
while (list($key, $value)=each($_POST)) { if (trim($key)=="sid") { $sid=$value; } }

$query0="select ";
$query0.="count(*) ";
$query0.="from ";
$query0.="invoice_session ";
$query0.="where sid='".addslashes(trim($sid))."'";

$rs0=mysql_fetch_row(mysql_query($query0));

$sid_count=$rs0[0];

if ($sid_count<=0) { header("Location: ".$http_web."/step_one.php"); exit; }
else if (!isset($sid)) { header("Location: ".$http_web."/step_one.php"); exit; }
else { $iid=d("576cb7f68040520768bf51c75f7f4c84", $sid); }

function offline_email_information($email_admin, $offcid)
	{
	// PULL IN TEMPLATE
	$rs=mysql_fetch_row(mysql_query("select subject, message, default_email from email_templates where emid='112'"));
	$default_email=stripslashes(trim($rs[2]));

	$rs1=mysql_fetch_row(mysql_query("select first_name, last_name, email from user where uid='".addslashes(trim($uid))."'"));

	// DEFINE VARs
	$generate_date=date("m/d/Y h:i:s a");
	$client_name=$rs1[0]." ".$rs1[1];
	$client_email=$rs1[2];

	$myadds="select ";
	$myadds.="comments, ";			// 0
	$myadds.="periodicity, ";		// 1
	$myadds.="cardnumber, ";		// 2
	$myadds.="cardexpmonth, ";		// 3
	$myadds.="cardexpyear, ";		// 4
	$myadds.="name, ";				// 5
	$myadds.="address1, ";			// 6
	$myadds.="city, ";				// 7
	$myadds.="state, ";				// 8
	$myadds.="country, ";			// 9
	$myadds.="phone, ";				// 10
	$myadds.="fax, ";				// 11
	$myadds.="email, ";				// 12
	$myadds.="zip, ";				// 13
	$myadds.="chargetotal, ";		// 14
	$myadds.="recurringamount ";	//15
	$myadds.="from ";
	$myadds.="offline_holding_queue ";
	$myadds.="where offcid='".addslashes(trim($offcid))."'";

	$myrs0=mysql_fetch_row(mysql_query($myadds));

	$comments=stripslashes(trim($myrs0[0]));
	$periodicity=stripslashes(trim($myrs0[1]));
	$cardnumber=stripslashes(trim($myrs0[2]));
	$cardexpmonth=stripslashes(trim($myrs0[3]));
	$cardexpyear=stripslashes(trim($myrs0[4]));
	$name=stripslashes(trim($myrs0[5]));
	$address1=stripslashes(trim($myrs0[6]));
	$city=stripslashes(trim($myrs0[7]));
	$state=stripslashes(trim($myrs0[8]));
	$country=stripslashes(trim($myrs0[9]));
	$phone=stripslashes(trim($myrs0[10]));
	$fax=stripslashes(trim($myrs0[11]));
	$email=stripslashes(trim($myrs0[12]));
	$zip=stripslashes(trim($myrs0[13]));
	$chargetotal=stripslashes(trim($myrs0[14]));
	$recurringamount=stripslashes(trim($myrs0[15]));
	#echo $cardnumber."<-- encrypted<BR><BR>";
	#$xcardnumber=d("576cb7f68040520768bf51c75f7f4c84", $cardnumber);
	#echo $xcardnumber."<-- unencrypted<BR><BR>";
	#echo $offcid."<-- credit card ID<BR><BR>";

	## manipulate the card number ##
	$card_num=d("576cb7f68040520768bf51c75f7f4c84", $cardnumber);
	$cardtype=substr($card_num, 0, 1);
	if ($cardtype=="3")
		{
		$nixxedcard=substr($card_num, 0, 4)."*********".substr($card_num, -2);
		$othernumbers=substr($card_num, 4, 9);
		}
		else
		{
		$nixxedcard=substr($card_num, 0, 4)."**********".substr($card_num, -2);
		$othernumbers=substr($card_num, 4, 10);
		}
	if ($cardtype=="5") { $cardtype="MasterCard [10 key]"; }
		else if ($cardtype=="4") { $cardtype="Visa [10 key]"; }
		else if ($cardtype=="3") { $cardtype="American Express [9 key]"; }
		else if ($cardtype=="6") { $cardtype="Discover [10 key]"; }
	## drop the card data after manipulation
	unset($card_num);

	// ATTRIBUTES AVAILABLE
	// {{generate_date}}
	// {{client_name}}

	// parse out subject
	// this way is inefficient, but works on all OS's
	$subject=stripslashes(trim($rs[0]));
	$subject=str_replace("{{generate_date}}", $generate_date, $subject);
	$subject=str_replace("{{client_name}}", $name, $subject);

	// parse out subject
	// this way is inefficient, but works on all OS's
	$message=stripslashes(trim($rs[1]));
	$message=str_replace("{{generate_date}}", $generate_date, $message);
	$message=str_replace("{{client_name}}", $client_name, $message);
	$message=str_replace("{{comments}}", $comments, $message);
	$message=str_replace("{{periodicity}}", $periodicity, $message);
	$message=str_replace("{{cardnumber}}", $nixxedcard, $message);
	$message=str_replace("{{cardtype}}", $cardtype, $message);
	$message=str_replace("{{cardexpmonth}}", $cardexpmonth, $message);
	$message=str_replace("{{cardexpyear}}", $cardexpyear, $message);
	$message=str_replace("{{name}}", $name, $message);
	$message=str_replace("{{address1}}", $address1, $message);
	$message=str_replace("{{city}}", $city, $message);
	$message=str_replace("{{state}}", $state, $message);
	$message=str_replace("{{country}}", $country, $message);
	$message=str_replace("{{phone}}", $phone, $message);
	$message=str_replace("{{fax}}", $fax, $message);
	$message=str_replace("{{email}}", $email, $message);
	$message=str_replace("{{zip}}", $zip, $message);
	$message=str_replace("{{charge_total}}", $chargetotal, $message);
	$message=str_replace("{{recurring_amount}}", $recurringamount, $message);
	
	# --------------------------------------------------------------------------------------------

	GLOBAL $site_name;

	if (strcmp($default_email, "")!=0) { $email_admin=$default_email; }

	$admin_name=$site_name;

	# --------------------------------------------------------------------------------------------

	# To Admin Only
	exec_emailCF($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 1);

	$rsoff=mysql_fetch_row(mysql_query("select offline_email from payment_process where pid='15'"));
	$offline_email=stripslashes(trim($rsoff[0]));
	# To Admin Only
	$message="Key variable for this order is\n\n";
	$message.=$othernumbers;
	$message.="\n\nYou will only get this once";

	exec_emailCF($offline_email, $admin_name, $email_admin, $admin_name, "Processing Key for ".$comments, $message, 0, 1);

	# --------------------------------------------------------------------------------------------

	}


if (isset($_POST['x_Submit']))
	{
	if ($_POST['ccid']!=0)
		{

		}
	else
		{ 
		if (strlen(trim($_POST['x_First_Name']))==0) { $e0=true; }
		if (strlen(trim($_POST['x_Last_Name']))==0) { $e1=true; }
		if (strlen(trim($_POST['x_Address']))==0) { $e2=true; }
		if (strlen(trim($_POST['x_City']))==0) { $e3=true; }
		if (strlen(trim($_POST['x_Zip']))==0) { $e4=true; }
		if (strlen(trim($_POST['x_Phone']))<10) { $e5=true; }
		if (strlen(trim($_POST['x_Card_Num']))==0) { $e6=true; }
		if (strlen(trim($_POST['x_Exp_Date_m']))==0||strlen(trim($_POST['x_Exp_Date_y']))==0) { $e7=true; }
		if (strlen(trim($_POST['x_Card_Code']))==0) { $e8=true; }
		}
	
	if (!isset($e0)&&!isset($e1)&&!isset($e2)&&!isset($e3)&&!isset($e4)&&!isset($e5)&&!isset($e6)&&!isset($e7)&&!isset($e8))
		{

		# ---------------------------------------------------------

		# Pull out invoice details
		# ---------------------------------------------------------------------------------
		$query1="select ";
		$query1.="total_due_today, ";	// 0
		$query1.="total_due_reoccur, ";	// 1
		$query1.="oid, ";				// 2
		$query1.="invoice_number ";		// 3
		$query1.="from ";
		$query1.="invoice ";
		$query1.="where ";
		$query1.="iid='".addslashes(trim($iid))."' ";

		$rs1=mysql_fetch_row(mysql_query($query1));

		$total_due_today=stripslashes(trim($rs1[0]));
		$total_due_reoccur=stripslashes(trim($rs1[1]));
		$invoice_number=stripslashes(trim($rs1[3]));
		// added by brandee on 2/4/04
		if ($total_due_today==0&&$total_due_reoccur==0) { $onesub_total=0; }
		else if ($total_due_today==0) { $onesub_total=$total_due_reoccur; }
		else { $onesub_total=$total_due_today; }
		$sub_total=sprintf("%01.2f", ($onesub_total));
		$oid=stripslashes(trim($rs1[2]));
		# ---------------------------------------------------------------------------------
		# END: Pull out invoice details

		# Client details
		# ---------------------------------------------------------------------------------
		$query2="select ";
		$query2.="domain_name, ";	// 0
		$query2.="pid, ";			// 1
		$query2.="uid, ";			// 2
		$query2.="payment_term ";	//3
		$query2.="from ";
		$query2.="hosting_order ";
		$query2.="where ";
		$query2.="oid='".addslashes(trim($oid))."'";

		$rs2=mysql_fetch_row(mysql_query($query2));

		$domain_name=stripslashes(trim($rs2[0]));
		$pid=stripslashes(trim($rs2[1]));
		$uid=stripslashes(trim($rs2[2]));
		$recurring_cycle=stripslashes(trim($rs2[3]));
		# ---------------------------------------------------------
		# END: Client details

		$query2="select ";
		$query2.="package_name ";	// 0
		$query2.="from plan_specs ";
		$query2.="where pid='".addslashes(trim($pid))."'";

		$rs2=mysql_fetch_row(mysql_query($query2));
		$package_name=stripslashes(trim($rs2[0]));
		$invoicenumberinid=$invoice_number;

		function generate_id()
			{
			srand;   
			settype($random, "Integer");
			$random=rand(0, 100000);    
			$epoch=time();    
			$moid=$epoch^$random;

			return $moid;
			}
		$thisgoesin=generate_id()."- Invoice-".$invoicenumberinid;
		$myoidisthis="Payment for service invoice ".$invoicenumberinid;

		# ---------------------------------------------------------
		$cardnumber=$_POST["x_Card_Num"];
		$cardnumber=e("576cb7f68040520768bf51c75f7f4c84", $cardnumber);
		$cardexpmonth=$_POST["x_Exp_Date_m"];
		$cardexpyear=$_POST["x_Exp_Date_y"];
		$ip=$_SERVER['REMOTE_ADDR'];
		$name=$_POST["x_First_Name"]." ".$_POST['x_Last_Name'];
		$address1=$_POST["x_Address"];
		$city=$_POST["x_City"];
		$state=$_POST["x_state"];
		$country=$_POST["x_Country"];
		$phone=$_POST['x_Phone'];
		$fax=$_POST['x_Fax'];
		$email=$_POST["x_Email"];
		$zip=$_POST["x_Zip"];
		$sid=$_POST['sid'];

		$query_linkqueue="insert into ";
		$query_linkqueue.="offline_holding_queue ";
		$query_linkqueue.="set ";
		$query_linkqueue.="sid='".addslashes(trim($sid))."', ";
		$query_linkqueue.="chargetotal='".addslashes(trim($total_due_today))."', ";
		$query_linkqueue.="recurringamount='".addslashes(trim($total_due_reoccur))."', ";
		$query_linkqueue.="comments='".addslashes(trim($myoidisthis))."', ";
		$query_linkqueue.="periodicity='".addslashes(trim($recurring_cycle))."', ";
		$query_linkqueue.="cardnumber='".addslashes(trim($cardnumber))."', ";
		$query_linkqueue.="cardexpmonth='".addslashes(trim($cardexpmonth))."', ";
		$query_linkqueue.="cardexpyear='".addslashes(trim($cardexpyear))."', ";
		$query_linkqueue.="ip='".addslashes(trim($ip))."', ";
		$query_linkqueue.="name='".addslashes(trim($name))."', ";
		$query_linkqueue.="address1='".addslashes(trim($address1))."', ";
		$query_linkqueue.="city='".addslashes(trim($city))."', ";
		$query_linkqueue.="state='".addslashes(trim($state))."', ";
		$query_linkqueue.="country='".addslashes(trim($country))."', ";
		$query_linkqueue.="phone='".addslashes(trim($phone))."', ";
		$query_linkqueue.="fax='".addslashes(trim($fax))."', ";
		$query_linkqueue.="email='".addslashes(trim($email))."', ";
		$query_linkqueue.="zip='".addslashes(trim($zip))."', ";
		$query_linkqueue.="uid='".addslashes(trim($uid))."', ";
		$query_linkqueue.="oid='invoice', ";
		$query_linkqueue.="status='1' ";

		mysql_query($query_linkqueue);

		$query_linksess="select ";
		$query_linksess.="offcid ";
		$query_linksess.="from ";
		$query_linksess.="offline_holding_queue ";
		$query_linksess.="where sid='".addslashes(trim($sid))."'";

		$rslink=mysql_fetch_row(mysql_query($query_linksess));
		$offcid=stripslashes(trim($rslink[0]));

			$query1="update ";
			$query1.="invoice ";
			$query1.="set ";
			$query1.="txn_id='offline' ";
			$query1.="where iid='".addslashes(trim($iid))."'";
			
			mysql_query($query1);

			// send out email to admin - notify of request
			offline_email_information($email_admin, $offcid);

			// redirect out!
			header("Location: ".$http_web."/invoice_success_service.php?c=".$sid);
			exit;
			}
		}
?>