<?PHP
if (!isset($sid))
	{
	$sid=create_sid();
	if (isset($c))
		{
		$uid=base64_decode($c);
		$insert="insert into session_history set ";
		$insert.="sid='".addslashes(trim($sid))."', ";
		$insert.="uid='".addslashes(trim($uid))."', ";
		$insert.="ogcreate='".time()."' ";
		mysql_query($insert);
		}
	}
else if (is_locked($sid)==1) { header("Location: ".$http_web."/step_one.php"); exit; }
else
	{
	$query0="select ";
	$query0.="count(*) ";
	$query0.="from ";
	$query0.="session_history ";
	$query0.="where ";
	$query0.="sid='".addslashes(trim($sid))."'";
	$ct=mysql_fetch_row(mysql_query($query0));

	if ($ct[0]==1)
		{
		$query1="select ";
		$query1.="pid, ";
		$query1.="payment_term, ";
		$query1.="payment_method, ";
		$query1.="promotion_code, ";
		$query1.="referrer_id, ";
		$query1.="domain_registration ";
		$query1.="from ";
		$query1.="session_history ";
		$query1.="where ";
		$query1.="sid='".addslashes(trim($sid))."'";
		$rs1=mysql_fetch_row(mysql_query($query1));
		$xpid=stripslashes(trim($rs1[0]));
		$xpayment_term=stripslashes(trim($rs1[1]));
		$xpayment_method=stripslashes(trim($rs1[2]));
		$xpromotion_code=stripslashes(trim($rs1[3]));
		$xreferrer_id=stripslashes(trim($rs1[4]));
		$domain_switch=stripslashes(trim($rs1[5]));
		}
	}

if (isset($submit))
	{
	if (!isset($pid)) { $err=true; }
	else
		{
		$promotion_code=addslashes(trim(strtolower($promotion_code)));
		if ($promotion_code!="")
			{
			$query2="select ";
			$query2.="count(*) ";
			$query2.="from ";
			$query2.="addon_specs ";
			$query2.="where ";
			$query2.="coupon_code='".$promotion_code."'";

			$ct_=mysql_fetch_row(mysql_query($query2));

			if ($ct_[0]>=1)
				{
				$query3="select ";
				$query3.="expires, ";
				$query3.="aid ";
				$query3.="from ";
				$query3.="addon_specs ";
				$query3.="where ";
				$query3.="coupon_code='".$promotion_code."'";
				$rs3=mysql_fetch_row(mysql_query($query3));
				if ($rs3[0]!=0&&$rs3[0]<time()) { $e0=true; }

				$queryx="select ";
				$queryx.="addon_groups.group_addons ";
				$queryx.="from ";
				$queryx.="addon_groups, ";
				$queryx.="plan_specs ";
				$queryx.="where ";
				$queryx.="plan_specs.pid='".addslashes(trim($pid))."' ";
				$queryx.="and ";
				$queryx.="plan_specs.addon_gid=addon_groups.addon_gid ";
				$queryx.="limit 0, 1";
				
				$rsx=mysql_fetch_row(mysql_query($queryx));

				$ct_=substr_count($rsx[0], "|");
				$ex=explode("|", $rsx[0]);
				for($i=0; $i<=$ct_; $i++) { if ($rs3[1]===$ex[$i]) { $bit=true; } }
				if (!isset($bit)) { $e2=true; }
				}
			else { $e1=true; }
			}

		if (!isset($e0)&&!isset($e1)&&!isset($e2))
			{
			$query4="select ";
			$query4.="whm_id ";
			$query4.="from ";
			$query4.="plan_specs ";
			$query4.="where ";
			$query4.="pid='".addslashes(trim($pid))."'";
			$rs4=mysql_fetch_row(mysql_query($query4));

			if ($ct[0]<=0) { $query5="insert into "; }
			else { $query5="update "; } 
			$query5.="session_history  ";
			$query5.="set ";
			$query5.="whm_id='".addslashes(trim($rs4[0]))."', ";
			$query5.="sid='".addslashes(trim($sid))."', ";
			$query5.="pid='".addslashes(trim($pid))."', ";
			$query5.="payment_term='".addslashes(trim($payment_term[$pid]))."', ";
			$query5.="payment_method='".addslashes(trim($payment_method))."', ";
			$query5.="promotion_code='".addslashes(trim($promotion_code))."', ";
			$query5.="referrer_id='".addslashes(trim($referrer_id))."', ";

			# added 11/19/2003
			$query5.="domain_registration='".addslashes(trim($domain_registration))."', ";
			if (strcmp($domain_switch, $domain_registration)!=0) { $query5.="domain_name='', "; }
			# end added 11/19/2003

			$query5.="ogcreate='".time()."'";
			if ($ct[0]>=1) { $query5.=" where sid='".addslashes(trim($sid))."'"; }
			
			mysql_query($query5);
	
			$query6="delete ";
			$query6.="from ";
			$query6.="session_history ";
			$query6.="where ";
			# $query6.="(UNIX_TIMESTAMP(ogcreate) + ((3600*24)*3))<".time();
			$query6.="(ogcreate + (3600*".$session_expire."))<".time();
			mysql_query($query6);
			
			clean_dir($below_public);

			$xpayment_method=$payment_method;
			
			$link_out="Location: ";
			$link_out.=$http_web;
			$link_out.="/step_two.php?";
			$link_out.="sid=".$sid;
			$link_out.="&gid=".$gid;

			# added 11/19/2003
			if ($domain_registration==0) { $link_out.="&ds=0"; }
			else { $link_out.="&ds=1"; }
			# end added 11/19/2003

			header($link_out); exit;
			}
		}
	}

# in table -------------------------------------------------------------------------

if (trim($gid)=="") 
	{
	$query7="select ";
	$query7.="gid ";
	$query7.="from ";
	$query7.="plan_groups ";
	$query7.="where ";
	$query7.="group_status='1' ";
	$query7.="order by ";
	$query7.="gid desc ";
	$query7.="limit 0, 1";
	$r=mysql_fetch_row(mysql_query($query7));

	$gid=stripslashes(trim($r[0]));
	}

$query8="select ";
$query8.="group_status, ";	// 0
$query8.="gid, ";			// 1
$query8.="name, ";			// 2
$query8.="group_payment ";	// 3
$query8.="from ";
$query8.="plan_groups ";
$query8.="where ";
$query8.="gid='".addslashes(trim($gid))."'";
$r=mysql_fetch_row(mysql_query($query8));

if (trim($r[3])=="")
	{
	$query9="select ";
	$query9.="pid ";
	$query9.="from ";
	$query9.="payment_process ";
	$query9.="where ";
	$query9.="status='1'";
	$rbx=mysql_query($query9);

	while ($rb=mysql_fetch_row($rbx)) { $group_payment.=$rb[0]."|"; }
	
	$query10="update ";
	$query10.="plan_groups ";
	$query10.="set ";
	$query10.="group_payment='".$group_payment."' ";
	$query10.="where ";
	$query10.="gid='".$gid."'";
	mysql_query($query10);
	}
else { $group_payment=trim($r[3]); }


function parse_engine0($alt0, $alt1, $sid, $condition0, $condition1, $condition2)
	{
	if ($condition0==1)
		{
		$buffer="";
		$data=array();

		$query0="select ";
		$query0.="gid, ";
		$query0.="name ";
		$query0.="from ";
		$query0.="plan_groups ";
		$query0.="where ";
		$query0.="group_status='1' ";
		$query0.="order by ";
		$query0.="name asc";

		$row0=mysql_query($query0);

		while ($rs0=mysql_fetch_row($row0))	
			{ 
			$xalt0=$alt0;
			$buffer=str_replace("{{parse0}}", $PHP_SELF."?gid=".$rs0[0]."&sid=".$sid, $xalt0);
			$buffer=str_replace("{{parse1}}", stripslashes($rs0[1]), $buffer);
			$data[0].=$buffer;
			unset($xalt0);
			unset($buffer);
			}

		return $data[0];
		}
	else if ($condition0==0) 
		{ 
		$buffer=str_replace("{{parse2}}", $PHP_SELF."?gid=".$condition1."&sid=".$sid, $alt1); 
		$buffer=str_replace("{{parse3}}", stripslashes($condition2), $buffer);
		return $buffer;
		}
	}

$query11="select ";
$query11.="count(*) ";
$query11.="from ";
$query11.="plan_specs ";
$query11.="where ";
$query11.="gid='".addslashes(trim($gid))."' ";
$query11.="and ";
$query11.="plan_status='1'";
$ct=mysql_fetch_row(mysql_query($query11));


$i=0;
$buffer0="";
$query12="select ";
$query12.="package_name, ";			// 0
$query12.="monthly_cost, ";			// 1
$query12.="quarterly_cost, ";		// 2
$query12.="semi_annual_cost, ";		// 3
$query12.="annual_cost, ";			// 4
$query12.="setup_cost, ";			// 5
$query12.="web_space, ";			// 6
$query12.="bandwidth, ";			// 7
$query12.="email, ";				// 8
$query12.="pid, ";					// 9
$query12.="ip_addresses, ";			// 10
$query12.="memory, ";				// 11
$query12.="processor, ";			// 12
$query12.="os, ";					// 13
$query12.="display_text,  ";		// 14
$query12.="dedicated, ";			// 15
$query12.="in_stock, ";				// 16
$query12.="shell_access, ";			// 17
$query12.="cgi_access, ";			// 18
$query12.="frontpage, ";			// 19
$query12.="ftp, ";					// 20
$query12.="email_list, ";			// 21
$query12.="sql, ";					// 22
$query12.="sub_domain,  ";			// 23
$query12.="parked_domain,  ";		// 24
$query12.="addon_domain,  ";		// 25
$query12.="cpanel_theme  ";			// 26  
$query12.="from ";
$query12.="plan_specs ";
$query12.="where ";
$query12.="gid='".addslashes(trim($gid))."' ";
$query12.="and ";
$query12.="plan_status='1' ";
$query12.="order by pid asc";

$row=mysql_query($query12);
while ($rs=mysql_fetch_row($row))
	{
	$display_text=stripslashes(trim($rs[14]));
	$buffer0.=("
		<tr name='plan_row' id='plan_row".$i."'".(($ct[0]<=1)?"":"onClick='document.forms[".$default_formid."].pid[".$i."].checked = true; select_row(\"plan\", ".$i."); return true;'").">
			<td width='10%' align='center' valign='middle' valign='top' name='plan_left_cell' id='plan_left_cell".$i."'><input type='radio' name='pid' value='".$rs[9]."'".((isset($xpid))?"".(($xpid==$rs[9])?" checked":"")."":"".(($i==0)?" checked":"")."")."></td>
			<td align='left' valign='top' valign='top' width='90%'  name='plan_right_cell' id='plan_right_cell".$i."'>
			<table width='100%' cellpadding='4' cellspacing='0' border='0'>
				<tr>
					<td width='100%' align='left' valign='top'><b>".$rs[0]."</b> - ".(($rs[5]==0)?"".$text_nosetupfee."":"".$currency."".sprintf("%01.2f",$rs[5])." ".$currency_type." ".$text_setupfee."")."".(($rs[15]==1&&$rs[16]!=0)?"&nbsp;&nbsp;&nbsp;[".$rs[16]." ".$text_available."]":"")."</td>
				</tr>
				<tr>
					<td width='100%' align='left' valign='top'>
					".$stepone_choosepaymentterm.": <select name='payment_term[".$rs[9]."]' ".$orderinput_style.">
			");
if ($rs[1]!=-1)
		{
		$buffer0.=("
						<option value='monthly'".(($xpid==$rs[9])?"".(($xpayment_term=="monthly")?" selected":"")."":"").">".$currency."".sprintf("%01.2f", $rs[1])." ".$currency_type." ".$text_monthly."</option>
			");
		}
if ($rs[2]!=-1)
		{
		$buffer0.=("
						<option value='quarterly'".(($xpid==$rs[9])?"".(($xpayment_term=="quarterly")?" selected":"")."":"").">".$currency."".sprintf("%01.2f", $rs[2])." ".$currency_type." ".$text_quarterly."</option>
			");
		}
if ($rs[3]!=-1)
		{
		$buffer0.=("
						<option value='semi_annual'".(($xpid==$rs[9])?"".(($xpayment_term=="semi_annual")?" selected":"")."":"").">".$currency."".sprintf("%01.2f", $rs[3])." ".$currency_type." ".$text_semiannual."</option>
			");
		}
if ($rs[4]!=-1)
		{
		$buffer0.=("
						<option value='annual'".(($xpid==$rs[9])?"".(($xpayment_term=="annual")?" selected":"")."":"").">".$currency."".sprintf("%01.2f", $rs[4])." ".$currency_type." ".str_replace("Annualy", "Annually", $text_annual)."</option>
			");
		}
		$buffer0.=("
					</select>
					</td>
				</tr>
				<tr>
					<td width='100%' align='left' valign='top'>
				");
		if ($rs[15]==1)
			{
			$xbuff=str_replace("{{disk_space}}", $rs[6], $display_text);
			$xbuff=str_replace("{{bandwidth}}", $rs[7], $xbuff);
			$xbuff=str_replace("{{ip_addresses}}", $rs[10], $xbuff);
			$xbuff=str_replace("{{memory}}", $rs[11], $xbuff);
			$xbuff=str_replace("{{processor}}", $rs[12], $xbuff);
			$xbuff=str_replace("{{operating_system}}", $rs[13], $xbuff);
			$buffer0.=$xbuff;
			}
		else 
			{	
			if (trim($display_text)=="")
				{
				$buffer0.=$rs[6]." MB Web Space, ".$rs[7]." MB Transfer, ".((trim($rs[8])=="-1")?"Unlimited":"".$rs[8]."")." eMail Addresses";
				}
			else
				{
				if ($rs[6]==-1) { $rs[6]="Unlimited"; }
				if ($rs[7]==-1) { $rs[7]="Unlimited"; }
				if ($rs[8]==-1) { $rs[8]="Unlimited"; }
				if ($rs[17]==-1) { $rs[17]="Unlimited"; }
				if ($rs[18]==-1) { $rs[18]="Unlimited"; }
				if ($rs[19]==-1) { $rs[19]="Unlimited"; }
				if ($rs[20]==-1) { $rs[20]="Unlimited"; }
				if ($rs[21]==-1) { $rs[21]="Unlimited"; }
				if ($rs[22]==-1) { $rs[22]="Unlimited"; }
				if ($rs[23]==-1) { $rs[23]="Unlimited"; }
				if ($rs[24]==-1) { $rs[24]="Unlimited"; }
				if ($rs[25]==-1) { $rs[25]="Unlimited"; }
				if ($rs[26]==-1) { $rs[26]="Unlimited"; }
				$xbuff=str_replace("{{web_space}}", $rs[6], $display_text);
				$xbuff=str_replace("{{bandwidth}}", $rs[7], $xbuff);
				$xbuff=str_replace("{{shell}}", $rs[17], $xbuff);
				$xbuff=str_replace("{{cgi}}", $rs[18], $xbuff);
				$xbuff=str_replace("{{frontpage}}", $rs[19], $xbuff);
				$xbuff=str_replace("{{ftp}}", $rs[20], $xbuff);
				$xbuff=str_replace("{{email}}", $rs[8], $xbuff);
				$xbuff=str_replace("{{email_list}}", $rs[21], $xbuff);
				$xbuff=str_replace("{{sql}}", $rs[22], $xbuff);
				$xbuff=str_replace("{{sub_domain}}", $rs[23], $xbuff);
				$xbuff=str_replace("{{parked_domain}}", $rs[24], $xbuff);
				$xbuff=str_replace("{{addon_domain}}", $rs[25], $xbuff);
				$xbuff=str_replace("{{cpanel_theme}}", $rs[26], $xbuff);
				$buffer0.=$xbuff;
				}
			}
		$buffer0.=("
					</td>
				</tr>
			</table>
			</td>
		</tr>
		");
	$i++;
	}

$d=0;
$query14="select ";
$query14.="pid, "; //0
$query14.="name "; //1
$query14.="from "; 
$query14.="payment_process ";  
$query14.="where "; 
$query14.="status='1' ";
$query14.="order by pid desc";
$row3=mysql_query($query14);
while ($rs3=mysql_fetch_row($row3))
	{
	list($p1, $p2, $p3, $p4, $p5, $p6, $p7, $p8, $p9, $p10, $p11, $p12, $p13)=split("[|]", $group_payment);

	if ($p1==$rs3[0]||$p2==$rs3[0]||$p3==$rs3[0]||$p4==$rs3[0]||$p5==$rs3[0]||$p6==$rs3[0]||$p7==$rs3[0]||$p8==$rs3[0]||$p9==$rs3[0]||$p10==$rs3[0]||$p11==$rs3[0]||$p12==$rs3[0]||$p13==$rs3[0])
		{
		if (ereg("mail in payment", strtolower($rs3[1]))==true)
			{
			$data[0]=("
					<tr>
						<td width='5%' align='left' valign='middle'><img src='".$http_images."/space.gif' width='32' height='1'><input type='radio' name='payment_method' value='".$rs3[0]."'".((isset($xpayment_method))?"".(($xpayment_method==$rs3[0])?" checked":"")."":" checked")." id='o0'></td>
						<td width='95%' align='left' valign='middle'><img src='".$http_images."/mailin.gif' onclick='o0.checked=true'></td>
					</tr>
					");
			}
		if (ereg("authorize", strtolower($rs3[1]))==true)
			{
			$data[1]=("
					<tr>
						<td width='5%' align='left' valign='middle'><img src='".$http_images."/space.gif' width='32' height='1'><input type='radio' name='payment_method' value='".$rs3[0]."'".((isset($xpayment_method))?"".(($xpayment_method==$rs3[0])?" checked":"")."":" checked")." id='o1'></td>
						<td width='95%' align='left' valign='middle'><img src='".$http_images."/authorize.gif' onclick='o1.checked=true'></td>
					</tr>
					");
			}
		if (ereg("paypal", strtolower($rs3[1]))==true)
			{
			$data[2]=("
					<tr>
						<td width='5%' align='left' valign='middle'><img src='".$http_images."/space.gif' width='32' height='1'><input type='radio' name='payment_method' value='".$rs3[0]."'".((isset($xpayment_method))?"".(($xpayment_method==$rs3[0])?" checked":"")."":" checked")." id='o2'></td>
						<td width='95%' align='left' valign='middle'><img src='".$http_images."/paypal.gif' onclick='o2.checked=true'></td>
					</tr>
					");
			}
		if (ereg("tpp-pro", strtolower($rs3[1]))==true)
			{
			$data[3]=("
					<tr>
						<td width='5%' align='left' valign='middle'><img src='".$http_images."/space.gif' width='32' height='1'><input type='radio' name='payment_method' value='".$rs3[0]."'".((isset($xpayment_method))?"".(($xpayment_method==$rs3[0])?" checked":"")."":" checked")." id='o3'></td>
						<td width='95%' align='left' valign='middle'><img src='".$http_images."/paysystems.gif' onclick='o3.checked=true'></td>
					</tr>
					");
			}
		if (ereg("2checkout", strtolower($rs3[1]))==true)
			{
			$coisactive="1";
			$data[4]=("
					<tr>
						<td width='5%' align='left' valign='middle'><img src='".$http_images."/space.gif' width='32' height='1'><input type='radio' name='payment_method' value='".$rs3[0]."'".((isset($xpayment_method))?"".(($xpayment_method==$rs3[0])?" checked":"")."":" checked")." id='o4'></td>
						<td width='95%' align='left' valign='middle'><img src='".$http_images."/2checkout.gif'></td>
					</tr>
					");
			}
		if (ereg("worldpay", strtolower($rs3[1]))==true)
			{
			$data[5]=("
					<tr>
						<td width='5%' align='left' valign='middle'><img src='".$http_images."/space.gif' width='32' height='1'><input type='radio' name='payment_method' value='".$rs3[0]."'".((isset($xpayment_method))?"".(($xpayment_method==$rs3[0])?" checked":"")."":" checked")." id='o5'></td>
						<td width='95%' align='left' valign='middle'><img src='".$http_images."/worldpay.gif' onclick='o5.checked=true'></td>
					</tr>
					");
			}
///// Internet Secure change 13/08/2004
		if (ereg("internet secure", strtolower($rs3[1]))==true)
			{
			$data[6]=("
					<tr>
						<td width='5%' align='left' valign='middle'><img src='".$http_images."/space.gif' width='32' height='1'><input type='radio' name='payment_method' value='".$rs3[0]."'".((isset($xpayment_method))?"".(($xpayment_method==$rs3[0])?" checked":"")."":" checked")." id='o6'></td>
						<td width='95%' align='left' valign='middle'><img src='".$http_images."/internetsecure.gif' onclick='o6.checked=true'></td>
					</tr>
					");
			}
///// Internet Secure change 13/08/2004
		if (ereg("linkpoint", strtolower($rs3[1]))==true)
			{
			$data[7]=("
					<tr>
						<td width='5%' align='left' valign='middle'><img src='".$http_images."/space.gif' width='32' height='1'><input type='radio' name='payment_method' value='".$rs3[0]."'".((isset($xpayment_method))?"".(($xpayment_method==$rs3[0])?" checked":"")."":" checked")." id='o6'></td>
						<td width='95%' align='left' valign='middle'><img src='".$http_images."/linkpoint.gif' onclick='o6.checked=true'></td>
					</tr>
					");
			}
			##end add of linkpoint
		if (ereg("psigate", strtolower($rs3[1]))==true)
			{
			$data[8]=("
					<tr>
						<td width='5%' align='left' valign='middle'><img src='".$http_images."/space.gif' width='32' height='1'><input type='radio' name='payment_method' value='".$rs3[0]."'".((isset($xpayment_method))?"".(($xpayment_method==$rs3[0])?" checked":"")."":" checked")." id='o6'></td>
						<td width='95%' align='left' valign='middle'><img src='".$http_images."/psigate.gif' onclick='o6.checked=true'></td>
					</tr>
					");
			}
		if (ereg("12", strtolower($rs3[0]))==true)
			{
			$data[9]=("
					<tr>
						<td width='5%' align='left' valign='middle'><img src='".$http_images."/space.gif' width='32' height='1'><input type='radio' name='payment_method' value='".$rs3[0]."'".((isset($xpayment_method))?"".(($xpayment_method==$rs3[0])?" checked":"")."":" checked")." id='o2'></td>
						<td width='95%' align='left' valign='middle'><img src='".$http_images."/paypal.gif' onclick='o2.checked=true' title='PayPal Alternate'></td>
					</tr>
					");
			}
		if (ereg("13", strtolower($rs3[0]))==true)
			{
			$data[10]=("
					<tr>
						<td width='5%' align='left' valign='middle'><img src='".$http_images."/space.gif' width='32' height='1'><input type='radio' name='payment_method' value='".$rs3[0]."'".((isset($xpayment_method))?"".(($xpayment_method==$rs3[0])?" checked":"")."":" checked")." id='o5'></td>
						<td width='95%' align='left' valign='middle'><img src='".$http_images."/worldpay.gif' onclick='o5.checked=true' title='WorldPay Alternate'></td>
					</tr>
					");
			}
		if (ereg("14", strtolower($rs3[0]))==true)
			{
			$data[11]=("
					<tr>
						<td width='5%' align='left' valign='middle'><img src='".$http_images."/space.gif' width='32' height='1'><input type='radio' name='payment_method' value='".$rs3[0]."'".((isset($xpayment_method))?"".(($xpayment_method==$rs3[0])?" checked":"")."":" checked")." id='o5'></td>
						<td width='95%' align='left' valign='middle'><img src='".$http_images."/cybersource.gif' onclick='o5.checked=true' title='CyberSource'></td>
					</tr>
					");
			}
		if (ereg("15", strtolower($rs3[0]))==true)
			{
			$data[12]=("
					<tr>
						<td width='5%' align='left' valign='middle'><img src='".$http_images."/space.gif' width='32' height='1'><input type='radio' name='payment_method' value='".$rs3[0]."'".((isset($xpayment_method))?"".(($xpayment_method==$rs3[0])?" checked":"")."":" checked")." id='o5'></td>
						<td width='95%' align='left' valign='middle'><img src='".$http_images."/offlinecc.gif' onclick='o5.checked=true' title='Credit Card'></td>
					</tr>
					");
			}
		$d++;
		}
	}
?>