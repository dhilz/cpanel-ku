<?PHP
$cksid=mysql_fetch_row(mysql_query("select count(*) from session_history where sid='".addslashes(trim($sid))."'"));


if ($cksid[0]<=0) { header("Location: ".$http_web."/step_one.php");	exit; }
else if (!isset($sid)) { header("Location: ".$http_web."/step_one.php"); exit; }
else if (is_locked($sid)==1) { header("Location: ".$http_web."/step_one.php"); exit; }

if (isset($submit))
	{	
	$addon_choices="";
	if(phpversion() <= "4.0.6") { $_POST=$HTTP_POST_VARS; }
	while (list ($key, $value) = each ($HTTP_POST_VARS)) { if (ereg("aid", $key)==true) { $addon_choices.=$value."|"; } }

	// update history - only the parts that are relevant though
	$update="update session_history set ";
	if (!isset($dedicated))
		{
		$update.="addon_choices='".stripslashes(trim($addon_choices))."', ";
		$update.="pns1='".stripslashes(trim($pns1))."', ";
		$update.="pns2='".stripslashes(trim($pns2))."' ";
		}
	else { $update.="addon_choices='".stripslashes(trim($addon_choices))."' "; }

	$update.="where sid='".addslashes(trim($sid))."'";

	mysql_query($update);
	unset($submit);

	header("Location: ".$http_web."/step_four.php?sid=".trim($sid)."&gid=".trim($gid));	exit;
	}

# ----------------------------------------------
$display="";

// grab choices from db and break them up
$rs1=mysql_fetch_row(mysql_query("select session_history.addon_choices, plan_specs.dedicated from session_history, plan_specs where session_history.sid='".addslashes(trim($sid))."' and session_history.pid=plan_specs.pid order by session_history.sid asc limit 0, 1"));
if ($rs1[1]==1) { $display.="<input type='hidden' name='dedicated' value='1'>"; $dedicated=true;}

$addon_choices=$rs1[0];
$count=substr_count($addon_choices, "|");
$explode=explode("|", $addon_choices);

// select all addons for the set
$query="select ";
$query.="group_addons ";				// 0
$query.="from addon_groups ";
$query.="where addon_gid='".addslashes(trim(base64_decode($addon_gid)))."'";

$rs=mysql_fetch_row(mysql_query($query));
$group_addons=stripslashes(trim($rs[0]));

$ii=0;
$x=0;
$tok=strtok($group_addons, "|");
while ($tok)
	{
	if (trim($addon_choices)!="")
		{
		for ($i=0; $i<=$count; $i++) { if ($explode[$i]==$tok) { $bit=true; } }
		}

	$query0.="select ";
	$query0.="addon_name, ";				// 0
	$query0.="addon_description, ";			// 1
	$query0.="addon_show_description, ";	// 2
	$query0.="setup_cost, ";				// 3
	$query0.="setup_activate, ";			// 4
	$query0.="addon_cost, ";				// 5
	$query0.="addon_state, ";				// 6
	$query0.="addon_activate, ";			// 7
	$query0.="coupon, ";					// 8
	$query0.="private_ns ";					// 9
	$query0.="from addon_specs ";
	$query0.="where aid='".addslashes(trim($tok))."'";

	$rs0=mysql_fetch_row(mysql_query($query0));

	$addon_name=stripslashes(trim($rs0[0])); 
	$addon_description=stripslashes(trim($rs0[1]));
	$addon_show_description=stripslashes(trim($rs0[2]));
	$setup_cost=stripslashes(trim($rs0[3])); 
	$setup_activate=stripslashes(trim($rs0[4]));
	$addon_cost=stripslashes(trim($rs0[5]));
	$addon_state=stripslashes(trim($rs0[6]));
	$addon_activate=stripslashes(trim($rs0[7]));
	$coupon=stripslashes(trim($rs0[8]));
	$private_ns=stripslashes(trim($rs0[9]));
	
	if ($private_ns==1&&isset($dedicated)) { $skip_bit=true; }

	if (!isset($skip_bit))
		{
		if ($coupon==0)
			{	
			if ($setup_activate==0&&$addon_activate==0) { $free=true; }

			if ($addon_show_description==1)
				{
				$display.=("
					<tr id=\"xc".$ii."\" onClick='

					var myAgent=navigator.userAgent.toLowerCase();

					if (!myAgent.indexOf(\"mozilla\")==0) 
						{
						if (aid".$ii.".checked) { aid".$ii.".checked=false;} else { aid".$ii.".checked = true;} change_tr_color(document.all(\"xc".$ii."\").bgColor, \"xc".$ii."\", \"".$stepthree_highlight."\"); change_tr_color(document.all(\"xc".$ii."x\").bgColor, \"xc".$ii."x\", \"".$stepthree_highlight."\");
						}
						'".((isset($bit))?" bgcolor='".$stepthree_highlight."'":"").">
					");
				}
			else
				{
				$display.=("
					<tr id=\"xc".$ii."\" onClick='

					var myAgent=navigator.userAgent.toLowerCase();

					if (!myAgent.indexOf(\"mozilla\")==0) 
						{
						if (aid".$ii.".checked) { aid".$ii.".checked=false;} else { aid".$ii.".checked = true;} change_tr_color(document.all(\"xc".$ii."\").bgColor, \"xc".$ii."\", \"".$stepthree_highlight."\");
						}
						'".((isset($bit))?" bgcolor='".$stepthree_highlight."'":"").">
					");
				}

			$display.=("
					<td align='center' valign='top'><input id=\"c".$ii."\" type='checkbox' name='aid".$ii."' value='".$tok."'".((isset($bit))?" checked":"")." onclick='

					var myAgent=navigator.userAgent.toLowerCase();

					if (!myAgent.indexOf(\"mozilla\")==0) 
						{
						if (aid".$ii.".checked) { aid".$ii.".checked=false;} else { aid".$ii.".checked = true;}
						}
						'></td>
					<td align='left' valign='top'>&nbsp;".$addon_name."</td>
					<td align='left' valign='top'>&nbsp;
				");
			if ($setup_activate==1) { $display.= $currency.sprintf("%01.2f", $setup_cost).$currency_type; }
			else { $display.= "None"; }
			$display.=("
					</td>
					<td align='left' valign='top' bgcolor='".$bgcolor."'>&nbsp;
				");
			if ($addon_activate==1) 
				{
				$display.= $currency.sprintf("%01.2f", $addon_cost).$currency_type;
				if ($addon_state==1) { $display.= " One Time Fee"; }
				else if ($addon_state==2) { $display.= " Per Month"; }
				else if ($addon_state==3) { $display.= " Per Year"; }
				}
			else 
				{ 
				$display.= "None"; 
				}
			$display.=("
					</td>
				</tr>
				");
			
			# Reseller Code added 7/2/2003 - Rockwell
			# ---------------------------------------------------------------------------
			# private ns addon?
			if ($private_ns==1)
				{
				$sq="select ";
				$sq.="plan_specs.rid, ";
				$sq.="session_history.domain_name, ";
				$sq.="session_history.pns1, ";
				$sq.="session_history.pns2, ";
				$sq.="session_history.tld, ";
				$sq.="session_history.domain_registration ";
				$sq.="from ";
				$sq.="session_history, plan_specs ";
				$sq.="where ";
				$sq.="session_history.sid='".addslashes(trim($sid))."' ";
				$sq.="and ";
				$sq.="session_history.pid=plan_specs.pid ";
				$sq.="order by session_history.pid asc ";
				$sq.="limit 0, 1";
				
				$rsq=mysql_fetch_row(mysql_query($sq));
				
				# reseller package?
				if ($rsq[0]!=0)
					{
					# admin allow custom prefix?
					$qq="select ";
					$qq.="edit_ns ";
					$qq.="from ";
					$qq.="reseller_profile ";
					$qq.="where ";
					$qq.="rid='".addslashes(trim($rsq[0]))."' ";
					$qq.="limit 0, 1";
					
					$rqq=mysql_fetch_row(mysql_query($qq));
					
					if ($rqq[0]==1)
						{
						if ($rsq[5]==1)
							{
							$q2="select ";
							$q2.="tld ";
							$q2.="from ";
							$q2.="tld_chart ";
							$q2.="where ";
							$q2.="tld_id='".$rsq[4]."'";

							$r2=mysql_fetch_row(mysql_query($q2));
							$show_dot=true;
							}

						# good buffered code here
						$gbuffer=("
							<tr>
								<td><hr></td>
							</tr>
							<tr>
								<td>".$stepthree_nameserverchoices.":</td>
							</tr>
							<tr>
								<td>&nbsp;<input ".$orderinput_style." size='3' maxlength='25' type='text' name='pns1' value='".$rsq[2]."'>.".$rsq[1]."".((isset($show_dot))?".".$r2[0]."":"")."</td>
							</tr>
							<tr>
								<td>&nbsp;<input ".$orderinput_style." size='3' maxlength='25' type='text' name='pns2' value='".$rsq[3]."'>.".$rsq[1]."".((isset($show_dot))?".".$r2[0]."":"")."</td>
							</tr>
							");
						}
					}
				}

			# ---------------------------------------------------------------------------
			# Reseller Code added 7/2/2003 - Rockwell

			if ($addon_show_description==1||$private_ns==1)
				{
				$display.=("
					<tr id=\"xc".$ii."x\" onClick='

					var myAgent=navigator.userAgent.toLowerCase();

					if (!myAgent.indexOf(\"mozilla\")==0) 
						{
						if (aid".$ii.".checked) { aid".$ii.".checked=false;} else { aid".$ii.".checked = true;} change_tr_color(document.all(\"xc".$ii."\").bgColor, \"xc".$ii."\", \"#EEEEEE\"); change_tr_color(document.all(\"xc".$ii."x\").bgColor, \"xc".$ii."x\", \"#EEEEEE\");
						}
						'".((isset($bit))?" bgcolor='#EEEEEE'":"").">
						<td colspan='1' align='left' valign='top'></td>
						<td colspan='3' align='left' valign='top'>
						<table width='100%' cellpadding='2' cellspacing='0' border='0'>
					");
				if ($addon_show_description==1)
					{
					$display.=("
							<tr>
								<td ".$stepthree_descriptionstyle."".$addon_description."</td>
							</tr>
						");
					}
				if ($private_ns==1)	{ $display.=$gbuffer; }
				$display.=("
						</table>
					</td>
					</tr>
					");
				}


			$display.=("
				<tr>
					<td colspan='4'><img src='".$http_image."/space.gif' width='1' height='2'></td>
				</tr>
				");
			}
		}

	unset($skip_bit);
	unset($bit);
	unset($xtok);
	unset($addon_name);
	unset($addon_description);
	unset($addon_show_description);
	unset($setup_cost);
	unset($setup_activate);
	unset($addon_cost);
	unset($addon_state);
	unset($addon_activate);
	unset($query0);
	unset($rs0);

	$ii++;

	$tok=strtok("|");
	}
?>