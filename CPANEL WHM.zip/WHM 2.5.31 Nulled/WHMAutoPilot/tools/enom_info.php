<?PHP
$query="select ";
$query.="password ";
$query.="from ";
$query.="domains ";
$query.="where ";
$query.="";
$query.="";
$query.="";
$query.="";
$query.="";
$query.="";


echo("
	<table width='100%' border='0' cellspacing='1' cellpadding='2'>
		<tr>
			<td align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><b>Domain Registration Information</b></td>
		</tr>
	</table>
	<table width='100%' border='0' cellspacing='1' cellpadding='2'>
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>Registrar:</td>
			<td width='75%' align='left' valign='top'>Enom [<a href='http://www.enom.com' target='_blank'>http://www.enom.com</a>]</td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>Manage Domain:</td>
			<td width='75%' align='left' valign='top'><a href='http://access.enom.com' target='_blank'>Click Here</a></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>Enom Password:</td>
			<td width='75%' align='left' valign='top'>".stripslashes(trim($rs[0]))."</td>
		</tr>
	</table>
	");
?>