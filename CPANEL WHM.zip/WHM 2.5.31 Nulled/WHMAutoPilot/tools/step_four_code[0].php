<?PHP
$cksid=mysql_fetch_row(mysql_query("select count(*) from session_history where sid='".addslashes(trim($sid))."'"));

if ($cksid[0]<=0)
	{
	// make them start over for security
	header("Location: ".$http_web."/step_one.php");
	exit;
	}
else if (!isset($sid))
	{
	// make them start over for security
	header("Location: ".$http_web."/step_one.php");
	exit;
	}
else if (is_locked($sid)==1)
	{
	// check to see if the record is locked
	// prevents hijacked sessions
	// send back to step 1
	header("Location: ".$http_web."/step_one.php");
	exit;
	}
else if (isset($sid)&&!isset($submit))
	{
	// is user new or old
	$chu=mysql_fetch_row(mysql_query("select uid, bin_number, first_name from session_history where sid='".addslashes(trim($sid))."'"));
	$bin_number=$chu[1];
	$check_first_name=stripslashes(trim($first_name));

	if (trim($chu[0])!="0")
		{
		// gather the existing user data
		$rs=mysql_fetch_row(mysql_query("select first_name, last_name, organization_name, street_address_1, street_address_2, city, state, zip_code, country, phone, fax, email, username, advert, advert_other from user where uid='".addslashes(trim($chu[0]))."'"));

		$array=$rs[0]."|".$rs[1]."|".$rs[2]."|".$rs[3]."|".$rs[4]."|".$rs[5]."|";
		$array.=$rs[6]."|".$rs[7]."|".$rs[8]."|".$rs[9]."|".$rs[10]."|".$rs[11]."|";
		$array.=$rs[12]."|".$rs[13]."|".$rs[14]."|";

		list($first_name, $last_name, $organization_name, $street_address_1, $street_address_2, $city, $state, $zip_code, $country, $phone, $fax, $email, $username, $yadvert, $yadvert_other)=split("[|]", $array);


		// gather the data from session history
		$rsx=mysql_fetch_row(mysql_query("select advert, advert_other, tos, pid, client_notes, sorp from session_history where sid='".addslashes(trim($sid))."'"));

		$xarray=$rsx[0]."|".$rsx[1]."|".$rsx[2]."|".$rsx[3]."|".$rsx[4]."|".$rsx[5];

		list($xadvert, $xadvert_other, $tos, $pid, $client_notes, $sorp)=split("[|]", $xarray);
		
		if ($sorp==1) { $province=$state; unset($state); }
		
		if (trim($xadvert)=="") { $advert=$yadvert; $advert_other=$yadvert_other; }
		else { $advert=$xadvert; $advert_other=$xadvert_other; }
		// set bit to let know it's existing
		$exist=true;
		}
	else
		{
		// new users
		$rs=mysql_fetch_row(mysql_query("select first_name, last_name, organization_name, street_address_1, street_address_2, city, state, zip_code, country, phone, fax, email, username, password, advert, advert_other, tos, pid, client_notes, sorp from session_history where sid='".addslashes(trim($sid))."'"));

		$array=$rs[0]."|".$rs[1]."|".$rs[2]."|".$rs[3]."|".$rs[4]."|".$rs[5]."|";
		$array.=$rs[6]."|".$rs[7]."|".$rs[8]."|".$rs[9]."|".$rs[10]."|".$rs[11]."|";
		$array.=$rs[12]."|".$rs[13]."|".$rs[14]."|".$rs[15]."|".$rs[16]."|".$rs[17]."|".$rs[18]."|".$rs[19];

		list($first_name, $last_name, $organization_name, $street_address_1, $street_address_2, $city, $state, $zip_code, $country, $phone, $fax, $email, $username, $password, $advert, $advert_other, $tos, $pid, $client_notes, $sorp)=split("[|]", $array);

		if ($sorp==1) { $province=$state; unset($state); }

		$password2=$password;
		}
	}

// start form handler

if (isset($submit))
	{
	if (strlen(trim($first_name))==0) {$err0=true;} else {$n0=true;}
	if (strlen(trim($last_name))==0) {$err1=true;} else {$n1=true;}
	if (strlen(trim($street_address_1))==0) {$err2=true;} else {$n2=true;}
	if (strlen(trim($city))==0) {$err3=true;} else {$n3=true;}
	if (trim($state)=="") 
		{
		if (trim($province)=="") { $err4=true; } 
		else if (trim($province)=="Enter Province") { $err4=true; }
		else { $n4=true; }
		} 
	else {$n4=true;}
	if (strlen(trim($zip_code))==0) {$err5=true;} else {$n5=true;}
	if (strlen(trim($country))==0) {$err6=true;} else {$n6=true;}
	if (strlen(trim($phone))==0) {$err7=true;} else {$n7=true;}
	if (strlen(trim($email))==0) {$err8=true;} else {$n8=true;}

	// is this user already a user?
	if (!isset($exist))
		{
		if (strlen(trim($username))==0) {$err9=true;} else {$n9=true;}
		}
	else
		{
		$n9=true;
		}

	// is this user already a user?
	if (!isset($exist))
		{
		if (strcmp($password, $password2)!=0||strlen(trim($password))==0) {$err10=true;} else {$n10=true;}
		}
	else
		{
		$n10=true;
		}

	if (trim($advert)=="x") 
		{
		$err11=true;
		} 
	else 
		{
		if (trim($advert)=="OTHER")
			{
			if (strlen(trim($advert_other))==0)
				{
				$err12=true;
				}
			else
				{
				$n11=true;
				$n12=true;
				}
			}
		else
			{
			$n11=true;
			$n12=true;
			}
		}
	if (!isset($tos)) {$err13=true;} else {$n13=true;}


	// is this user already a user?
	if (!isset($exist))
		{
		if (check_user($username)==1) {$err14=true;} else {$n14=true;}
		if (check_email($email)==1) {$err15=true;} else {$n15=true;}
		}
	else
		{
		$n14=true;
		$n15=true;
		}
	
	if (isset($authnet)&&strcmp($HTTP_POST_VARS['bin_number'], "")==0) { $err16=true; }
	else { $n16=true; }

	if (isset($linkpint)&&strcmp($HTTP_POST_VARS['bin_number'], "")==0) { $err16=true; }
	else { $n16=true; }

	if (isset($n0)&&isset($n1)&&isset($n2)&&isset($n3)&&isset($n4)&&isset($n5)&&isset($n6)&&isset($n7)&&isset($n8)&&isset($n9)&&isset($n10)&&isset($n11)&&isset($n12)&&isset($n13)&&isset($n14)&&isset($n15)&&isset($n16))
		{
		// Start Session Management

		// update history - only the parts that are relevant though
		$update="update session_history set ";
		$update.="first_name='".addslashes(trim($first_name))."', ";
		$update.="last_name='".addslashes(trim($last_name))."', ";
		$update.="organization_name='".addslashes(trim($organization_name))."', ";
		$update.="street_address_1='".addslashes(trim($street_address_1))."', ";
		$update.="street_address_2='".addslashes(trim($street_address_2))."', ";
		$update.="city='".addslashes(trim($city))."', ";
		
		if (isset($authnet)) { $update.="bin_number='".addslashes(trim($HTTP_POST_VARS['bin_number']))."', "; }
		if ($sorp==1) { $state=$province; unset($province); }

		$update.="sorp='".addslashes(trim($sorp))."', ";
		$update.="state='".addslashes(trim($state))."', ";
		$update.="zip_code='".addslashes(trim($zip_code))."', ";
		$update.="country='".addslashes(trim($country))."', ";
		$update.="phone='".addslashes(trim($phone))."', ";
		$update.="fax='".addslashes(trim($fax))."', ";
		$update.="email='".addslashes(trim($email))."', ";
		$update.="username='".addslashes(trim($username))."', "; 
		$update.="password='".addslashes(trim($password))."', "; 
		$update.="advert='".addslashes(trim($advert))."', ";
		$update.="advert_other='".addslashes(trim($advert_other))."', ";
		$update.="tos='".addslashes(trim($tos))."', ";
		$update.="client_ip='".addslashes(trim($REMOTE_ADDR))."', ";
		$update.="client_notes='".addslashes(trim($client_notes))."', ";
		$update.="ogcreate='".time()."' ";
		$update.="where sid='".addslashes(trim($sid))."'";

		mysql_query($update);

		// End Session Management

		unset($submit);

		header("Location: ".$http_web."/verify_order.php?sid=".trim($sid)."&gid=".trim($gid));
		exit;
		}
	}

// end form handler

// 2co check
$rspc=mysql_fetch_row(mysql_query("select session_history.payment_method, plan_specs.addon_gid from session_history, plan_specs where session_history.sid='".addslashes(trim($sid))."' and session_history.pid=plan_specs.pid order by session_history.sid asc limit 0, 1"));

if ($rspc[0]==4) { $pcheck=1; } 
else if ($rspc[1]==0) { $pcheck=1; } 
else 
	{ 
	$rs_gpid=mysql_fetch_row(mysql_query("select plan_specs.addon_gid, addon_groups.group_addons from plan_specs, addon_groups where plan_specs.pid='".addslashes(trim($pid))."' and plan_specs.addon_gid=addon_groups.addon_gid and addon_groups.group_status='1' order by plan_specs.pid asc")); 
	
	# added 10/24/2003
	$proceed_ct_base=substr_count($rs_gpid[1], "|");
	$proceed_ct=$proceed_ct_base-1;
	$proceed_arr=explode("|", $rs_gpid[1]);
	for ($i=0; $i<=$proceed_ct; $i++)
		{
		$query0="select ";
		$query0.="coupon ";	
		$query0.="from addon_specs ";
		$query0.="where aid='".addslashes(trim($proceed_arr[$i]))."'";
		
		$rs0=mysql_fetch_row(mysql_query($query0));

		$coupon=stripslashes(trim($rs0[0]));

		if ($coupon==1) { $proceed_bit+=1; }
		}

	if ($proceed_ct_base<=$proceed_bit) { $pcheck=1; } else { $pcheck=0; }
	}
?>