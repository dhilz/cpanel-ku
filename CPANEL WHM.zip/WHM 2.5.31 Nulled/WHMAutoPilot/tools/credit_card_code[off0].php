<?PHP
if(phpversion() <= "4.0.6") { $_POST=$HTTP_POST_VARS; }
$sid=$_POST['sid'];

$cksid=mysql_fetch_row(mysql_query("select count(*) from session_history where sid='".addslashes(trim($sid))."'"));

if ($cksid[0]<=0) 
	{	
	# added 6/2/2004
	raw_post_details($email_admin, "ERROR[10] SID was not in the database!", "unknown", "Offline Credit Card Public Order System");

	header("Location: ".$http_web."/step_one.php");	
	exit; 
	}
else if (!isset($sid)) 
	{ 
	# added 6/2/2004
	raw_post_details($email_admin, "ERROR[18] Sid was not set!", "unknown", "Offline Credit Card Public Order System");

	header("Location: ".$http_web."/step_one.php"); 
	exit; 
	}
function offline_email_information($email_admin, $offcid)
	{
	// PULL IN TEMPLATE
	$rs=mysql_fetch_row(mysql_query("select subject, message, default_email from email_templates where emid='112'"));
	$default_email=stripslashes(trim($rs[2]));

	$rs1=mysql_fetch_row(mysql_query("select first_name, last_name, email from user where uid='".addslashes(trim($uid))."'"));

	// DEFINE VARs
	$generate_date=date("m/d/Y h:i:s a");
	$client_name=$rs1[0]." ".$rs1[1];
	$client_email=$rs1[2];

	$myadds="select ";
	$myadds.="comments, ";			// 0
	$myadds.="periodicity, ";		// 1
	$myadds.="cardnumber, ";		// 2
	$myadds.="cardexpmonth, ";		// 3
	$myadds.="cardexpyear, ";		// 4
	$myadds.="name, ";				// 5
	$myadds.="address1, ";			// 6
	$myadds.="city, ";				// 7
	$myadds.="state, ";				// 8
	$myadds.="country, ";			// 9
	$myadds.="phone, ";				// 10
	$myadds.="fax, ";				// 11
	$myadds.="email, ";				// 12
	$myadds.="zip, ";				// 13
	$myadds.="chargetotal, ";		// 14
	$myadds.="recurringamount ";	//15
	$myadds.="from ";
	$myadds.="offline_holding_queue ";
	$myadds.="where offcid='".addslashes(trim($offcid))."'";

	$myrs0=mysql_fetch_row(mysql_query($myadds));

	$comments=stripslashes(trim($myrs0[0]));
	$periodicity=stripslashes(trim($myrs0[1]));
	$cardnumber=stripslashes(trim($myrs0[2]));
	$cardexpmonth=stripslashes(trim($myrs0[3]));
	$cardexpyear=stripslashes(trim($myrs0[4]));
	$name=stripslashes(trim($myrs0[5]));
	$address1=stripslashes(trim($myrs0[6]));
	$city=stripslashes(trim($myrs0[7]));
	$state=stripslashes(trim($myrs0[8]));
	$country=stripslashes(trim($myrs0[9]));
	$phone=stripslashes(trim($myrs0[10]));
	$fax=stripslashes(trim($myrs0[11]));
	$email=stripslashes(trim($myrs0[12]));
	$zip=stripslashes(trim($myrs0[13]));
	$chargetotal=stripslashes(trim($myrs0[14]));
	$recurringamount=stripslashes(trim($myrs0[15]));
	#echo $cardnumber."<-- encrypted<BR><BR>";
	#$xcardnumber=d("576cb7f68040520768bf51c75f7f4c84", $cardnumber);
	#echo $xcardnumber."<-- unencrypted<BR><BR>";
	#echo $offcid."<-- credit card ID<BR><BR>";

	## manipulate the card number ##
	$card_num=d("576cb7f68040520768bf51c75f7f4c84", $cardnumber);
	$cardtype=substr($card_num, 0, 1);
	if ($cardtype=="3")
		{
		$nixxedcard=substr($card_num, 0, 4)."*********".substr($card_num, -2);
		$othernumbers=substr($card_num, 4, 9);
		}
		else
		{
		$nixxedcard=substr($card_num, 0, 4)."**********".substr($card_num, -2);
		$othernumbers=substr($card_num, 4, 10);
		}
	if ($cardtype=="5") { $cardtype="MasterCard [10 key]"; }
		else if ($cardtype=="4") { $cardtype="Visa [10 key]"; }
		else if ($cardtype=="3") { $cardtype="American Express [9 key]"; }
		else if ($cardtype=="6") { $cardtype="Discover [10 key]"; }
	## drop the card data after manipulation
	unset($card_num);

	// ATTRIBUTES AVAILABLE
	// {{generate_date}}
	// {{client_name}}

	// parse out subject
	// this way is inefficient, but works on all OS's
	$subject=stripslashes(trim($rs[0]));
	$subject=str_replace("{{generate_date}}", $generate_date, $subject);
	$subject=str_replace("{{client_name}}", $name, $subject);

	// parse out subject
	// this way is inefficient, but works on all OS's
	$message=stripslashes(trim($rs[1]));
	$message=str_replace("{{generate_date}}", $generate_date, $message);
	$message=str_replace("{{client_name}}", $client_name, $message);
	$message=str_replace("{{comments}}", $comments, $message);
	$message=str_replace("{{periodicity}}", $periodicity, $message);
	$message=str_replace("{{cardnumber}}", $nixxedcard, $message);
	$message=str_replace("{{cardtype}}", $cardtype, $message);
	$message=str_replace("{{cardexpmonth}}", $cardexpmonth, $message);
	$message=str_replace("{{cardexpyear}}", $cardexpyear, $message);
	$message=str_replace("{{name}}", $name, $message);
	$message=str_replace("{{address1}}", $address1, $message);
	$message=str_replace("{{city}}", $city, $message);
	$message=str_replace("{{state}}", $state, $message);
	$message=str_replace("{{country}}", $country, $message);
	$message=str_replace("{{phone}}", $phone, $message);
	$message=str_replace("{{fax}}", $fax, $message);
	$message=str_replace("{{email}}", $email, $message);
	$message=str_replace("{{zip}}", $zip, $message);
	$message=str_replace("{{charge_total}}", $chargetotal, $message);
	$message=str_replace("{{recurring_amount}}", $recurringamount, $message);
	
	# --------------------------------------------------------------------------------------------

	GLOBAL $site_name;

	if (strcmp($default_email, "")!=0) { $email_admin=$default_email; }

	$admin_name=$site_name;

	# --------------------------------------------------------------------------------------------

	# To Admin Only
	exec_emailCF($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 1);

	$rsoff=mysql_fetch_row(mysql_query("select offline_email from payment_process where pid='15'"));
	$offline_email=stripslashes(trim($rsoff[0]));
	# To Admin Only
	$message="Key variable for this order is\n\n";
	$message.=$othernumbers;
	$message.="\n\nYou will only get this once";

	exec_emailCF($offline_email, $admin_name, $email_admin, $admin_name, "Processing Key for ".$comments, $message, 0, 1);

	# --------------------------------------------------------------------------------------------

	}

if (isset($_POST['x_Submit']))
	{
	if (strlen(trim($_POST['x_First_Name']))==0) { $e0=true; }
		if (strlen(trim($_POST['x_Last_Name']))==0) { $e1=true; }
		if (strlen(trim($_POST['x_Address']))==0) { $e2=true; }
		if (strlen(trim($_POST['x_City']))==0) { $e3=true; }
		if (strlen(trim($_POST['x_Zip']))==0) { $e4=true; }
		if (strlen(trim($_POST['x_Phone']))<10) { $e5=true; }
		if (strlen(trim($_POST['x_Card_Num']))==0) { $e6=true; }
		if (strlen(trim($_POST['x_Exp_Date_m']))==0||strlen(trim($_POST['x_Exp_Date_y']))==0) { $e7=true; }
		if (strlen(trim($_POST['x_Card_Code']))==0) { $e8=true; }
		if (strlen(trim($_POST['x_Card_Code']))==6) { $e9=true; }

	if (!isset($e0)&&!isset($e1)&&!isset($e2)&&!isset($e3)&&!isset($e4)&&!isset($e5)&&!isset($e6)&&!isset($e7)&&!isset($e8)&&!isset($e9))
		{
		# ---------------------------------------------------------

		$query1="select ";
		$query1.="total_due_today, ";	// 0
		$query1.="pid, ";				// 1
		$query1.="domain_name, ";		// 2
		$query1.="total_due_reoccur, ";	// 3
		$query1.="payment_term, ";		// 4
		$query1.="uid ";				// 5
		$query1.="from session_history ";
		$query1.="where sid='".$_POST['sid']."'";

		$rs1=mysql_fetch_row(mysql_query($query1));

		$total_due_today=stripslashes(trim($rs1[0]));
		$pid=stripslashes(trim($rs1[1]));
		$domain_name=stripslashes(trim($rs1[2]));
		$total_due_reoccur=stripslashes(trim($rs1[3]));
		$recurring_cycle=stripslashes(trim($rs1[4]));
		$uid=stripslashes(trim($rs1[5]));
		
		# ---------------------------------------------------------

		$query2="select ";
		$query2.="package_name ";	// 0
		$query2.="from plan_specs ";
		$query2.="where pid='".addslashes(trim($pid))."'";

		$rs2=mysql_fetch_row(mysql_query($query2));

		function generate_id()
			{
			srand;   
			settype($random, "Integer");
			$random=rand(0, 100000);    
			$epoch=time();    
			$moid=$epoch^$random;

			return $moid;
			}
		$thisgoesin=generate_id()."-".$sid;

		$package_name=stripslashes(trim($rs2[0]));
		$myoidisthis=$package_name." for ".$domain_name." to reoccur ".$recurring_cycle." at ".$total_due_reoccur;
		# ---------------[linkpoint]------------------------------
		
		$cardnumber=$_POST["x_Card_Num"];
		$cardnumber=e("576cb7f68040520768bf51c75f7f4c84", $cardnumber);
		$cardexpmonth=$_POST["x_Exp_Date_m"];
		$cardexpyear=$_POST["x_Exp_Date_y"];
		$ip=$_SERVER['REMOTE_ADDR'];
		$name=$_POST["x_First_Name"]." ".$_POST['x_Last_Name'];
		$address1=$_POST["x_Address"];
		$city=$_POST["x_City"];
		$state=$_POST["x_state"];
		$country=$_POST["x_Country"];
		$phone=$_POST['x_Phone'];
		$fax=$_POST['x_Fax'];
		$email=$_POST["x_Email"];
		$zip=$_POST["x_Zip"];
		$sid=$_POST['sid'];

		$query_linkqueue="insert into ";
		$query_linkqueue.="offline_holding_queue ";
		$query_linkqueue.="set ";
		$query_linkqueue.="sid='".addslashes(trim($sid))."', ";
		$query_linkqueue.="chargetotal='".addslashes(trim($total_due_today))."', ";
		$query_linkqueue.="recurringamount='".addslashes(trim($total_due_reoccur))."', ";
		$query_linkqueue.="comments='".addslashes(trim($domain_name))."', ";
		$query_linkqueue.="periodicity='".addslashes(trim($recurring_cycle))."', ";
		$query_linkqueue.="cardnumber='".addslashes(trim($cardnumber))."', ";
		$query_linkqueue.="cardexpmonth='".addslashes(trim($cardexpmonth))."', ";
		$query_linkqueue.="cardexpyear='".addslashes(trim($cardexpyear))."', ";
		$query_linkqueue.="ip='".addslashes(trim($ip))."', ";
		$query_linkqueue.="name='".addslashes(trim($name))."', ";
		$query_linkqueue.="address1='".addslashes(trim($address1))."', ";
		$query_linkqueue.="city='".addslashes(trim($city))."', ";
		$query_linkqueue.="state='".addslashes(trim($state))."', ";
		$query_linkqueue.="country='".addslashes(trim($country))."', ";
		$query_linkqueue.="phone='".addslashes(trim($phone))."', ";
		$query_linkqueue.="fax='".addslashes(trim($fax))."', ";
		$query_linkqueue.="email='".addslashes(trim($email))."', ";
		$query_linkqueue.="zip='".addslashes(trim($zip))."', ";
		$query_linkqueue.="uid='".addslashes(trim($uid))."', ";
		$query_linkqueue.="oid='hold', ";
		$query_linkqueue.="status='1' ";

		mysql_query($query_linkqueue);
		}
### IT IS NOT GETTING THIS
		// get the LPID from the record
		$query_linksess="select ";
		$query_linksess.="offcid ";
		$query_linksess.="from ";
		$query_linksess.="offline_holding_queue ";
		$query_linksess.="where sid='".addslashes(trim($sid))."'";

		$rslink=mysql_fetch_row(mysql_query($query_linksess));

		$updatelinksess=stripslashes(trim($rslink[0]));
		$offcid=$updatelinksess;
		$sid=$_POST['sid'];
		#echo $updatelinksess."<BR>";
		#echo $sid."<BR>";
### AND IT IS NOT UPDATING THE SESSION WITH THE LPID			
		// update the session record with the LPID
		$query_updatesess="update ";
		$query_updatesess.="session_history ";
		$query_updatesess.="set ";
		$query_updatesess.="offcid='".addslashes(trim($updatelinksess))."'";
		$query_updatesess.="where sid='".addslashes(trim($sid))."'";

		mysql_query($query_updatesess);
		#echo $query_updatesess;die;
// have not changed the log function yet, working on session and queue
		if ($_POST['ccid']==0)
			{
			$card_info=$_POST['x_Card_Num']."|".$_POST['x_Exp_Date_m'].$_POST['x_Exp_Date_y']."|0|";
			$card_info=e("576cb7f68040520768bf51c75f7f4c84", $card_info);
				}

		$desc=$package_name." [".$domain_name."]{}".$package_name."{}";

		$batch_info=$_SERVER['REMOTE_ADDR']."|";	// customer_ip_address|
		$batch_info.=$desc."|";						// description|
		$batch_info.=$x_Currency_Code."|";			// currency_code|
		$batch_info.=$transaction_type."|";			// transaction_type|
		$batch_info.="YES"."|";						// recurring_billing|
		$batch_info.="CC"."|";						// payment_method|
		$batch_info.=$cardholder_first_name."|";	// customer_first_name|
		$batch_info.=$cardholder_last_name."|";		// customer_last_name|
		$batch_info.=$xaddress."|";					// customer_address|
		$batch_info.=$xcity."|";					// customer_city|
		$batch_info.=$xstate."|";					// customer_state|
		$batch_info.=$xzip."|";						// customer_zip|
		$batch_info.=$xcountry."|";					// customer_country|
		$batch_info.=$xphone."|";					// customer_phone|
		$batch_info.=$xfax."|";						// customer_fax|
		$batch_info.=$xemail."|";					// customer_email|
		$batch_info.=$card_info."|";				// card_info|
		$batch_info.=$response_code."|";			// batch_status|
		$batch_info.=$response_reason_text."|";		// response_reason_text|
		$batch_info.=$transaction_id."|";			// invoice_number|
		$batch_info.=$_POST['ccid']."|";			// ccid|

		// write marker
		$c=md5(microtime());

		// sid|batch_info
		$data=$sid."|".base64_encode($batch_info)."|";

		// write the file
		$read=fopen($below_public."/".$c, "w");
		$result=fwrite($read, $data);
		fclose($read);
			
		// chmod the file
		chmod($below_public."/".$c, 0777);

		// send out email to admin - notify of request
		offline_email_information($email_admin, $offcid);

		// redirect out!
		header("Location: ".$http_web."/offline_success.php?c=".$c);
		exit;
		}
	else
		{
		$e69=$response_reason_text.".";
		}
?>