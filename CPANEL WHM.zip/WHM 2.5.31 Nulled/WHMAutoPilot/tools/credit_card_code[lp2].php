<?PHP
if(phpversion()<="4.0.6") { $_POST=$HTTP_POST_VARS; }
while (list($key, $value)=each($_POST)) { if (trim($key)=="sid") { $sid=$value; } }

$query0="select ";
$query0.="count(*) ";
$query0.="from ";
$query0.="invoice_session ";
$query0.="where sid='".addslashes(trim($sid))."'";

$rs0=mysql_fetch_row(mysql_query($query0));

$sid_count=$rs0[0];

if ($sid_count<=0) { header("Location: ".$http_web."/step_one.php"); exit; }
else if (!isset($sid)) { header("Location: ".$http_web."/step_one.php"); exit; }
else { $iid=d("576cb7f68040520768bf51c75f7f4c84", $sid); }


if (isset($_POST['x_Submit']))
	{
	if ($_POST['ccid']!=0)
		{
		
		}
	else
		{
		if (strlen(trim($_POST['x_First_Name']))==0) { $e0=true; }
		if (strlen(trim($_POST['x_Last_Name']))==0) { $e1=true; }
		if (strlen(trim($_POST['x_Address']))==0) { $e2=true; }
		if (strlen(trim($_POST['x_City']))==0) { $e3=true; }
		if (strlen(trim($_POST['x_Zip']))==0) { $e4=true; }
		if (strlen(trim($_POST['x_Phone']))<10) { $e5=true; }
		if (strlen(trim($_POST['x_Card_Num']))==0) { $e6=true; }
		if (strlen(trim($_POST['x_Exp_Date_m']))==0||strlen(trim($_POST['x_Exp_Date_y']))==0) { $e7=true; }
		if (strlen(trim($_POST['x_Card_Code']))==0) { $e8=true; }
		}
	
	if (!isset($e0)&&!isset($e1)&&!isset($e2)&&!isset($e3)&&!isset($e4)&&!isset($e5)&&!isset($e6)&&!isset($e7)&&!isset($e8))
		{
		$query0="select ";
		$query0.="linkpoint_storeid, ";			// 0
		$query0.="linkpoint_type ";				// 1
		$query0.="from ";
		$query0.="payment_process ";
		$query0.="where pid='10'";

		$rs0=mysql_fetch_row(mysql_query($query0));

		$linkpoint_storeid=stripslashes(trim($rs0[0]));
		$linkpoint_type=stripslashes(trim($rs0[1]));

		# ---------------------------------------------------------

		# Pull out invoice details
		# ---------------------------------------------------------------------------------
		$query1="select ";
		$query1.="total_due_today, ";	// 0
		$query1.="uid, ";				// 1
		$query1.="invoice_number ";		// 2
		$query1.="from ";
		$query1.="invoice ";
		$query1.="where ";
		$query1.="iid='".addslashes(trim($iid))."' ";
		
		$rs1=mysql_fetch_row(mysql_query($query1));

		$total_due_today=stripslashes(trim($rs1[0]));
		$uid=stripslashes(trim($rs1[1]));
		$invoice_number=stripslashes(trim($rs1[2]));

		function generate_id()
			{
			srand;   
			settype($random, "Integer");
			$random=rand(0, 100000);    
			$epoch=time();    
			$moid=$epoch^$random;

			return $moid;
			}
		$thisgoesin=generate_id()."- Invoice-".$invoice_number;
		$myoidisthis="Service Invoice Payment for Invoice Number: ".$invoice_number;
		# ---------------------------------------------------------------------------------
		# END: Pull out invoice details

		include "inc/lphp.php";
		$mylphp=new lphp;

		# constants
		$myorder["host"]="secure.linkpt.net";
		# $myorder["host"]="staging.linkpt.net";
		$myorder["port"]="1129";
		$myorder["keyfile"]="inc/lpnt.pem";
		$myorder["configfile"]=$linkpoint_storeid;
// has to be this way since it cannot send in two different amounts
		$myorder["chargetotal"]=$total_due_today;
// will require the admin to login to linkpoint & make order 'recurring'
// now lets fill in the other goodies
		$myorder["oid"]=$thisgoesin;
		$myorder["comments"]=$myoidisthis;
		$myorder["cardnumber"]=$_POST["x_Card_Num"];
		$myorder["cardexpmonth"]=$_POST["x_Exp_Date_m"];
		$myorder["cardexpyear"]=$_POST["x_Exp_Date_y"];
		$myorder["cvmvalue"]=$_POST["x_Card_Code"];
		$myorder["ordertype"]=$linkpoint_type;
		$myorder["ip"]=$_SERVER['REMOTE_ADDR'];
		$myorder["name"]=$_POST["x_First_Name"]." ".$_POST['x_Last_Name'];
		$myorder["address1"]=$_POST["x_Address"];
		$myorder["city"]=$_POST["x_City"];
		$myorder["state"]=$_POST["x_state"];
		$myorder["country"]=$_POST["x_Country"];
		$myorder["phone"]=$_POST['x_Phone'];
		$myorder["fax"]=$_POST['x_Fax'];
		$myorder["email"]=$_POST["x_Email"];
		$myorder["zip"]=$_POST["x_Zip"];
		$myorder["debugging"]="false";

		$result=$mylphp->curl_process($myorder);
		
		if ($result["r_approved"]!="APPROVED")
			{
			$response_code=69;
			$response_reason_text="Status:  [".((trim($result[r_approved])=="")?"Unknown":"".$result[r_approved]."")."] ";
			$response_reason_text.=$result[r_error];
			}
		else { $response_code=1; }

		if ($response_code==1)
			{
			$query1="update ";
			$query1.="invoice ";
			$query1.="set ";
			$query1.="txn_id='".addslashes(trim($transaction_id))."' ";
			$query1.="where iid='".addslashes(trim($iid))."'";

			mysql_query($query1);

			// redirect out!
			header("Location: ".$http_web."/invoice_success_service.php?c=".$sid);
			exit;
			}
		else
			{
			$e69=$response_reason_text.".";
			}
		}
	}
?>