<?PHP
// start the client menu
echo("
<table width='100%' border='0' cellspacing='1' cellpadding='2'>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><b>$text_clientinfo</b>&nbsp;&nbsp;&nbsp;[ <a href='".$http_web."/logout.php?sid=".$sid."'>Logout</a> ]</td>
	</tr>
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_name</td>
		<td width='70%' align='left' valign='top'>".trim($first_name)." ".trim($last_name)."</td>
	</tr>
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_organization</td>
		<td width='70%' align='left' valign='top'>".trim($organization_name)."</td>
	</tr>
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_address</td>
		<td width='70%' align='left' valign='top'>".trim($street_address_1)."</td>
	</tr>
");
if (strlen(trim($street_address_2))!=0)
	{
echo("
	<tr>
		<td width='30%' align='left' valign='top'></td>
		<td width='70%' align='left' valign='top'>".trim($street_address_2)."</td>
	</tr>
");
	}
echo("
	<tr>
		<td width='30%' align='left' valign='top'></td>
		<td width='70%' align='left' valign='top'>".trim($city).", ".trim($state)." ".trim($zip)." ".trim($country)."</td>
	</tr>
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_phone</td>
		<td width='70%' align='left' valign='top'>".trim($phone)."</td>
	</tr>
");
if (strlen(trim($fax))!=0)
	{
echo("
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_fax</td>
		<td width='70%' align='left' valign='top'>".trim($fax)."</td>
	</tr>
	");
	}
echo("
<form action='".$PHP_SELF."' method='POST'>
<input type='hidden' name='sid' value='".trim($sid)."'>
<input type='hidden' name='uid' value='".trim($uid)."'>
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_changeemail</td>
		<td width='70%' align='left' valign='top'><input ".$orderinput_style." size='20' maxlength='255' type='text' name='email' value='".trim($email)."'> <input ".$orderbutton_style." type='submit' name='change_email' value='$text_update'></td>
	</tr>
</form>
<form action='".$PHP_SELF."' method='POST'>
<input type='hidden' name='sid' value='".trim($sid)."'>
<input type='hidden' name='uid' value='".trim($uid)."'>
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_changepass</td>
		<td width='70%' align='left' valign='top'><input ".$orderinput_style." size='20' maxlength='255' type='text' name='password'> <input ".$orderbutton_style." type='submit' name='change_password' value='$text_update'></td>
	</tr>
</form>
");
$ct=mysql_fetch_row(mysql_query("select count(*) from affiliate_user where uid='".addslashes(trim($uid))."'"));
if ($ct[0]>=1)
{
$ars=mysql_fetch_row(mysql_query("select payable_to, ssn_tax_id from affiliate_user where uid='".addslashes(trim($uid))."'"));
$paybable_to=$ars[0];
$ssn_tax_id=$ars[1];
echo("
<form action='".$PHP_SELF."' method='POST'>
<input type='hidden' name='sid' value='".trim($sid)."'>
<input type='hidden' name='uid' value='".trim($uid)."'>
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_SSN</td>
		<td width='70%' align='left' valign='top'><input ".$orderinput_style." size='20' maxlength='11' type='text' name='ssn_tax_id' value='".$ssn_tax_id."'> <input ".$orderbutton_style." type='submit' name='change_ssn_tax_id' value='$text_update'></td>
	</tr>
</form>
<form action='".$PHP_SELF."' method='POST'>
<input type='hidden' name='sid' value='".trim($sid)."'>
<input type='hidden' name='uid' value='".trim($uid)."'>
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_affiliatepaysto</td>
		<td width='70%' align='left' valign='top'><input ".$orderinput_style." size='20' maxlength='255' type='text' name='payable_to' value='".$paybable_to."'> <input ".$orderbutton_style." type='submit' name='change_payable_to' value='$text_update'></td>
	</tr>
</form>
	");
}
echo"</table>";
// end the client menu
?>