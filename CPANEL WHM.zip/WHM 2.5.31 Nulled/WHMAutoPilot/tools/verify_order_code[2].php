<?PHP
$query_c="select ";
$query_c.="coupon_terms, ";				// 0
$query_c.="coupon_discount_type, ";		// 1
$query_c.="coupon_discount_percent, ";	// 2
$query_c.="coupon_discount_whole, ";	// 3
$query_c.="aid ";						// 4
$query_c.="from ";
$query_c.="addon_specs ";
$query_c.="where ";
$query_c.="coupon_code='".addslashes(trim($coupon_code))."'";

$rs_c=mysql_fetch_row(mysql_query($query_c));

$coupon_terms=stripslashes(trim($rs_c[0])); # 1 == one time; 2 == monthly;
$coupon_discount_type=stripslashes(trim($rs_c[1])); # 1 == %; 2 == whole dollar amount;
$coupon_discount_percent=stripslashes(trim($rs_c[2]));
$coupon_discount_whole=stripslashes(trim($rs_c[3]));
$aid=stripslashes(trim($rs_c[4]));

$ct_=substr_count($group_addons, "|");
$ex=explode("|", $group_addons);
for($i=0; $i<=$ct_; $i++) { if ($aid===$ex[$i]) { $group_test=true; } }
#$setup_cost="5";

if (isset($group_test))
	{
	# 1. figure out one time or monthly
	if ($coupon_terms==1&&strcmp("2checkout", strtolower($payment_type_name))!=0) # one time
		{
		if ($coupon_discount_type==1) # %
			{
			#echo $cost_per_tld."<-- cost for domain registration<BR><BR>";
			#if ($setup_cost=='') { echo "sorry, bubba, the variable setup_cost is not able to be found here so I can't get setup cost amount to use with coupons<BR>"; } else {
			#echo $setup_cost."<-- setup cost found<BR><BR>"; }
			# - %
			$sub_total_due_today=($total_due_today);
			#echo $sub_total_due_today."<-- before removal of TLD cost<BR>";

			$sub_total_due_today=($total_due_today-$cost_per_tld);
			#echo $sub_total_due_today."<-- after removal of domain cost<BR>";

			$convert_to_percent=($coupon_discount_percent/100);
			#echo $convert_to_percent."<-- discount percentabe <BR>";
			$dis=$sub_total_due_today*$convert_to_percent;
			#echo $dis."<-- discount amount<BR>";
			#$discounted_total_due_today=$total_reoccur-($total_reoccur*$convert_to_percent);
			$discounted_total_due_today=$total_due_today-($sub_total_due_today*$convert_to_percent);
			#echo $discounted_total_due_today."<-- total discount hosting cost today<BR>";

			$new_total_due_today=$discounted_total_due_today;
			if ($discounted_total_due_today+$setup_cost<=0) { $invalid=true; } # added 7/23/2003 rockwell to fix bug (+$setup_cost) 
			else { $total_due_today=$new_total_due_today; $used_coupon="<font color='#990000'>* ".$text_reflectsonetimediscount." ".$coupon_discount_percent."% ".$text_offhostingfees.".</font>";}
			}
		else if ($coupon_discount_type==2) # whole dollar amount
			{
			# - WHOLE DOLLAR
			$sub_total_due_today=($total_due_today-$total_reoccur);
			$discounted_total_due_today=$total_reoccur-$coupon_discount_whole;
			$new_total_due_today=$sub_total_due_today+$discounted_total_due_today;
			if ($discounted_total_due_today+$setup_cost<=0) { $invalid=true; } # added 7/23/2003 rockwell to fix bug (+$setup_cost)
			else { $total_due_today=$new_total_due_today; $used_coupon="<font color='#990000'>* ".$text_reflectsonetimediscount." ".($currency.sprintf("%01.2f", $coupon_discount_whole).$currency_type).".$text_offhostingfees.</font>";}
			}
		}
	else if ($coupon_terms==2&&strcmp("2checkout", strtolower($payment_type_name))!=0) # monthly
		{
		if ($coupon_discount_type==1) # %
			{
			#echo $cost_per_tld."<-- domain cost<BR>";
			#echo $setup_cost."<-- setup cost<BR>";
			#echo "I am here<BR>";
			# - %
			# do today's totals
			$sub_total_due_today=($total_due_today);
			#echo $sub_total_due_today."<-- before removal of TLD cost<BR>";

			$sub_total_due_today=($total_due_today-$cost_per_tld);
			#echo $sub_total_due_today."<-- after removal of domain cost<BR>";

			$convert_to_percent=($coupon_discount_percent/100);

			$discounted_total_due_today=$total_reoccur-($total_reoccur*$convert_to_percent);
			#echo $discounted_total_due_today."<-- total reocurring base<BR>";

			$discounted_total_due=$total_due_today-($sub_total_due_today*$convert_to_percent);
			#echo $discounted_total_due."<-- discounted due today<BR>";

			$new_total_due_today=$discounted_total_due;
			#echo $new_total_due_today."<-- new total to be charged today<BR>";

			if ($discounted_total_due_today+$setup_cost<=0) { $invalid=true; } # added 7/23/2003 rockwell to fix bug (+$setup_cost)
			else 
				{ 
				$total_due_today=$new_total_due_today; 
				$total_reoccur=$discounted_total_due_today;
				$used_coupon="<font color='#990000'>* ".$text_reflectsdiscount." ".$coupon_discount_percent."% ".$text_offhostingfees.".</font>"; 
				$xused_coupon="<font color='#990000'>* ".$text_reflectsdiscount." ".$coupon_discount_percent."%.</font>"; 
				}
			}
		else if ($coupon_discount_type==2) # whole dollar amount
			{ 
			# - WHOLE DOLLAR 
			$sub_total_due_today=($total_due_today-$total_reoccur);
			$discounted_total_due_today=$total_reoccur-$coupon_discount_whole;
			$new_total_due_today=$sub_total_due_today+$discounted_total_due_today;
			if ($discounted_total_due_today+$setup_cost<=0) { $invalid=true; } # added 7/23/2003 rockwell to fix bug (+$setup_cost)
			else 
				{ 
				$total_due_today=$new_total_due_today; 
				$total_reoccur=$discounted_total_due_today;
				$used_coupon="<font color='#990000'>* ".$text_reflectsdiscount." ".($currency.sprintf("%01.2f", $coupon_discount_whole).$currency_type)." ".$text_offhostingfees.".</font>";
				$xused_coupon="<font color='#990000'>* ".$text_reflectsdiscount." ".($currency.sprintf("%01.2f", $coupon_discount_whole).$currency_type).".</font>";
				}
			}
		}
	}
# --------------------------------------------------------------------------------------------------------------

if (strcmp("14", strtolower($payment_method))==0&&!$varilogix && !$fraudgate)
	{
	echo InsertSignature($total_due_today);
	echo "<input type='hidden' name='comments' value=':: Hosting for ::".$plan_group_name."::".$package_name." [".$domain_name."]'>";
	}
else if (strcmp("mail in payment", strtolower($payment_type_name))==0&&!$varilogix && !$fraudgate)
	{
	echo"<input type='hidden' name='total_due_today' value='".base64_encode(trim($total_due_today))."'>\n";
	echo"<input type='hidden' name='total_due_reoccur' value='".base64_encode(trim($total_reoccur))."'>\n";
	}
else if (strcmp("paypal", strtolower($payment_type_name))==0&&!$varilogix && !$fraudgate)
	{
	if ($free_trial==1)
		{
		if ($cost_per_tld=="") { $cost_per_tld="0.00"; }
		echo"<input type='hidden' name='a1' value='".$cost_per_tld."'>\n";
		echo"<input type='hidden' name='p1' value='".$free_trial_length."'>\n";
		echo"<input type='hidden' name='t1' value='M'>\n";
		$total_due_today=$total_due_today-$cost_per_tld;
		echo"<input type='hidden' name='a2' value='".sprintf("%01.2f", $total_due_today)."'>\n";
		echo"<input type='hidden' name='p2' value='".trim($term)."'>\n";
		echo"<input type='hidden' name='t2' value='M'>\n";
		}
	else
		{
		echo"<input type='hidden' name='a1' value='".sprintf("%01.2f", $total_due_today)."'>\n";
		echo"<input type='hidden' name='p1' value='".trim($term)."'>\n";
		echo"<input type='hidden' name='t1' value='M'>\n";
		}

	echo"<input type='hidden' name='a3' value='".sprintf("%01.2f", $total_reoccur)."'>\n";
	}
else if (strcmp("12", strtolower($payment_method))==0&&!$varilogix && !$fraudgate)
	{
	if ($free_trial==1)
		{
		if ($cost_per_tld=="") { $cost_per_tld="0.00"; }
		echo"<input type='hidden' name='a1' value='".$cost_per_tld."'>\n";
		echo"<input type='hidden' name='p1' value='".$free_trial_length."'>\n";
		echo"<input type='hidden' name='t1' value='M'>\n";
		$total_due_today=$total_due_today-$cost_per_tld;
		echo"<input type='hidden' name='a2' value='".sprintf("%01.2f", $total_due_today)."'>\n";
		echo"<input type='hidden' name='p2' value='".trim($term)."'>\n";
		echo"<input type='hidden' name='t2' value='M'>\n";
		}
	else
		{
		echo"<input type='hidden' name='a1' value='".sprintf("%01.2f", $total_due_today)."'>\n";
		echo"<input type='hidden' name='p1' value='".trim($term)."'>\n";
		echo"<input type='hidden' name='t1' value='M'>\n";
		}

	echo"<input type='hidden' name='a3' value='".sprintf("%01.2f", $total_reoccur)."'>\n";
	}
else if (strcmp("paysystems tpp-pro", strtolower($payment_type_name))==0&&!$varilogix && !$fraudgate)
	{
	echo"<input type='hidden' name='total' value='".sprintf("%01.2f",($total_due_today))."'>\n";
	echo"<input type='hidden' name='repeatamount' value='".sprintf("%01.2f", $total_reoccur)."'>\n";
	}
else if (strcmp("worldpay future pay", strtolower($payment_type_name))==0&&!$varilogix && !$fraudgate)
	{	
	echo"<input type='hidden' name='amount' value='".sprintf("%01.2f",($total_due_today))."'>\n";
	echo"<input type='hidden' name='normalAmount' value='".sprintf("%01.2f", $total_reoccur)."'>\n";
	}
else if (strcmp("13", strtolower($payment_method))==0&&!$varilogix && !$fraudgate)
	{	
	echo"<input type='hidden' name='amount' value='".sprintf("%01.2f",($total_due_today))."'>\n";
	echo"<input type='hidden' name='normalAmount' value='".sprintf("%01.2f", $total_reoccur)."'>\n";
	}
else if (strcmp("9", strtolower($payment_method))==0&&!$varilogix && !$fraudgate)
	{
	$rspd=mysql_fetch_row(mysql_query("select internetsecure_period from plan_specs where pid='".addslashes(trim($pid))."'"));

	// Get the days of payment cycle
	if ($term==1) {$xpterm="monthly";
	$rm_start = "startmonth=+1";	}
	else if ($term==3) {$xpterm="quarterly"; $rm_start = "startmonth=+3";}
	else if ($term==6) {$xpterm="semiannually"; $rm_start = "startmonth=+6";}
	else if ($term==12) {$xpterm="annually"; $rm_start = "startyear=+1";}
	

	if (!$rspd[0]) $rspd[0] = 12;
	$total_due_today=sprintf("%01.2f",($total_due_today));
	$total_reoccur=sprintf("%01.2f",($total_reoccur));
	
	echo"<input type=hidden name='Products' value='$total_due_today::1::$plan_group_name::".$package_name." [".$domain_name."]"."::{RB amount=$total_reoccur $rm_start frequency=$xpterm duration=$rspd[0] email=2}'>\n";
	}
# --------------------------------------------------------------------------------------------------------------

// update totals in session history to save query later
$query1="update ";
$query1.="session_history ";
$query1.="set ";
$query1.="total_due_today='".addslashes(trim($total_due_today))."', ";
$query1.="total_due_reoccur='".addslashes(trim($total_reoccur))."', ";
$query1.="locked='1' ";
$query1.="where sid='".addslashes(trim($sid))."'";

mysql_query($query1);

# start new ----------------------------------------------------------------------------------------------------
if (strcmp("mail in payment", strtolower($payment_type_name))==0) { $parse_out2="<img src='".$http_images."/mailin.gif'>"; }
if (strcmp("paypal", strtolower($payment_type_name))==0) { $parse_out2="<img src='".$http_images."/paypal.gif'>"; }
if (strcmp("paysystems tpp-pro", strtolower($payment_type_name))==0) { $parse_out2="<img src='".$http_images."/paysystems.gif'>"; }
if (strcmp("2checkout", strtolower($payment_type_name))==0) { $parse_out2="<img src='".$http_images."/2checkout.gif'>"; }
if (strcmp("worldpay future pay", strtolower($payment_type_name))==0) { $parse_out2="<img src='".$http_images."/worldpay.gif'>"; }
if (strcmp("authorize.net", strtolower($payment_type_name))==0) { $parse_out2="<img src='".$http_images."/authorize.gif'>"; }
if (strcmp("linkpoint", strtolower($payment_type_name))==0) { $parse_out2="<img src='".$http_images."/linkpoint.gif'>"; }
if (strcmp("psigate", strtolower($payment_type_name))==0) { $parse_out2="<img src='".$http_images."/psigate.gif'>"; }
if (strcmp("12", strtolower($payment_method))==0) { $parse_out2="<img src='".$http_images."/paypal.gif'>"; }
if (strcmp("13", strtolower($payment_method))==0) { $parse_out2="<img src='".$http_images."/worldpay.gif'>"; }
if (strcmp("14", strtolower($payment_method))==0) { $parse_out2="<img src='".$http_images."/cybersource.gif'>"; }
if (strcmp("15", strtolower($payment_method))==0) { $parse_out2="<img src='".$http_images."/offlinecc.gif'>"; }
if (strcmp("9", strtolower($payment_method))==0) { $parse_out2="<img src='".$http_images."/internetsecure.gif'>"; }
?>
