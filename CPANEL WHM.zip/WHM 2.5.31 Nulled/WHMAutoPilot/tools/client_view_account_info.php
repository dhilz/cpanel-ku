<?PHP
// start the hosting account
echo("
	<table width='100%' border='0' cellspacing='1' cellpadding='2'>
		<tr>
			<td align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><b>$text_hostinginfo</b></td>
		</tr>
	</table>
	");

if (trim($order_status)=="0") { $installed_server=$text_accountispending; }
else
	{
	$rs2=mysql_fetch_row(mysql_query("select server_name from server_config where whm_id='".addslashes(trim($whm_id))."'"));
	$installed_server=$rs2[0];
	}

echo "<table width='100%' border='0' cellspacing='1' cellpadding='2'>";
if ($dedicated==0)
	{
	echo("
	<tr>
		<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_domainname</td>
		<td width='75%' align='left' valign='top'><a href='http://".trim($domain_name)."' target='_blank'>http://".trim($domain_name)."</a></td>
	</tr>
	<form action='".$PHP_SELF."' method='POST'>
	<input type='hidden' name='sid' value='".trim($sid)."'>
	<input type='hidden' name='c' value='".$c."'>
	<input type='hidden' name='status' value='".trim($status)."'>
	<input type='hidden' name='ogcreate_mysql' value='".trim($ogcreate_mysql)."'>
		");
	$domain_expire=$domain_expire."/";
	list($mm, $dd, $yyyy)=split("[/]", $domain_expire);
	echo("
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_domainexpires</td>
			<td width='75%' align='left' valign='top'><input ".$orderinput_style." name='mm' type='text' size='2' maxlength='2' value='".((isset($mm))?"".$mm."":"")."'> / <input ".$orderinput_style." name='dd' type='text' size='2' maxlength='2' value='".((isset($dd))?"".$dd."":"")."'> / <input ".$orderinput_style." name='yyyy' type='text' size='4' maxlength='4' value='".((isset($yyyy))?"".$yyyy."":"")."'> <input ".$orderbutton_style." type='submit' name='change_date' value='$text_update'> ex. MM/DD/YYYY</td>
		</tr>
	</form>
		");
	}
else
	{
	echo("
	<tr>
		<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_servername</td>
		<td width='75%' align='left' valign='top'>".$server_hostname.".".$domain_name."</td>
	</tr>
		");
	}
echo("
	<tr>
		<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_accountcreatedon</td>
		<td width='75%' align='left' valign='top'>".date("m/d/Y", $ogcreate_hosting)."</td>
	</tr>
	<tr>
		<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_hostingpackage</td>
		<td width='75%' align='left' valign='top'>
	");
$xpayment_term=strtolower(str_replace("-", "_", $payment_term));
$rs2=mysql_fetch_row(mysql_query("select package_name, ".addslashes(trim($xpayment_term))."_cost from plan_specs where pid='".addslashes(trim($pid))."'"));


echo ("".$rs2[0].": ".$currency."".$rs2[1]."".$currency_type." ".$rs2[2]." ".$payment_term."</td></tr>");

if ($dedicated==0)
	{
	if (trim($xstatus)=="0")
		{
		echo("
			<tr>
				<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_installon</td>
				<td width='75%' align='left' valign='top'>".trim($installed_server)."</td>
			</tr>
			");
		}
	else
		{
		echo("
			<tr>
				<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_installedon</td>
				<td width='75%' align='left' valign='top'>".trim($installed_server)."</td>
			</tr>
			");
		}
	}
echo("
	<tr>
		<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_currentpayment</td>
		<td width='75%' align='left' valign='top'>".$pay_image."</td>
	</tr>
	");

if ($dedicated==0&&strcmp($order_status, "1")==0)
	{
	echo("
		<form action='http://".$ip.":2082/login' method='POST'>
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_cpaneluser</td>
			<td width='75%' align='left' valign='top'><input type='text' name='user' value='".$whm_username."' ".$input_style."></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_cpanelpass</td>
			<td width='75%' align='left' valign='top'><input type='password' name='pass' value='".$whm_password."' ".$input_style."></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'></td>
			<td width='75%' align='left' valign='top'><input type='submit' name='submit' value='Access Cpanel' ".$button_style."></td>
		</tr>
		</form>
		");
	}

echo("
	<tr>
		<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_ipaddress</td>
		<td width='75%' align='left' valign='top'>".trim($ip)."</td>
	</tr>
	");
if ($dedicated==0)
	{
	echo("
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_primaryns</td>
			<td width='75%' align='left' valign='top'>".trim($ns1)."</td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_secondaryns</td>
			<td width='75%' align='left' valign='top'>".trim($ns2)."</td>
		</tr>
		");
	}
else
	{
	echo("
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_primaryns</td>
			<td width='75%' align='left' valign='top'>".$pns1.".".$domain_name."</td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_secondaryns</td>
			<td width='75%' align='left' valign='top'>".$pns2.".".$domain_name."</td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_serverspecs</td>
			<td width='75%' align='left' valign='top'>".$server_specs."</td>
		</tr>
		");
	}
echo("
	<tr>
		<td width='25%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>$text_notes</td>
		<td width='75%' align='left' valign='top'>".((trim($client_notes)!="")?"".$client_notes."":$text_nonerecorded)."</td>
	</tr>
</table>
	");
if (trim($addon_choices)!="") { display_addons_ordered_clientarea($addon_choices, $http_images); }
?>