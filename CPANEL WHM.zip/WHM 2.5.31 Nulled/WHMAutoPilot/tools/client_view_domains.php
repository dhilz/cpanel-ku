<?PHP
$rsxxx1=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from invoice where status='2' AND total_due_today='0' AND invoice_type='0' AND uid='".addslashes(trim($uid))."'"));
$total_recurring_balance=sprintf("%01.2f", $rsxxx1[0]);

$rsxxx2=mysql_fetch_row(mysql_query("select sum(total_due_today) from invoice where status='2' AND uid='".addslashes(trim($uid))."'"));
$total_starting_balance=sprintf("%01.2f", $rsxxx2[0]);

$current_balance=$total_recurring_balance+$total_starting_balance;
$current_balance=sprintf("%01.2f", $current_balance);
if($current_balance>0)
{
echo("
	<TABLE WIDTH='92%' BORDER='0' CELLSPACING='0'
CELLPADDING='0'>
  <TR>
    <TD WIDTH='100%'><TABLE WIDTH='100%' BORDER='0' CELLSPACING='0'
      CELLPADDING='0'>
        <TR>
          <TD WIDTH='50%'>&nbsp;</TD>
          <TD WIDTH='50%'>Current Overdue Balance</TD>
        </TR>
        <TR>
          <TD WIDTH='50%'>&nbsp;</TD>
          <TD ROWSPAN='2'><B><FONT SIZE='+3' COLOR='red'>$currency$current_balance</FONT></B></TD>
        </TR>
        <TR>
          <TD WIDTH='50%'>&nbsp;</TD>
        </TR>
        <TR>
          <TD WIDTH='50%'>&nbsp;</TD>
          <TD WIDTH='50%'>Click on the <img border='0' src='".$http_images."/view_invoice.gif' alt='$text_altclickhistory'>  to view your paid/unpaid invoices.</TD>
        </TR>
      </TABLE></TD>
  </TR>
</TABLE>
");
}
echo("
	<table width='92%' cellpadding='4' cellspacing='1' border='0'>
		<tr>
			<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='1'></td>
		</tr>
		<tr>
			<td align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><b>$text_currenthosted</b><img src='".$http_images."/space.gif' width='20' height='1'>[<a href='".$http_web."/client_area.php?&sid=".trim($sid)."&status=99'>".((trim($status)=="99")?"<font color='#990000'>$text_showall</font>":"$text_showall")."</a>] [<a href='".$http_web."/client_area.php?&sid=".trim($sid)."&status=0'>".((trim($status)=="0")?"<font color='#990000'>$text_pending</font>":"$text_pending")."</a>] [<a href='".$http_web."/client_area.php?&sid=".trim($sid)."&status=1'>".((trim($status)=="1")?"<font color='#990000'>$text_active</font>":"$text_active")."</a>] [<a href='".$http_web."/client_area.php?&sid=".trim($sid)."&status=2'>".((trim($status)=="2")?"<font color='#990000'>$text_suspended</font>":"$text_suspended")."</a>]</td>
		</tr>
	</table>
	");
echo("
<!--- Start Main --->
<table width='92%' border='0' cellspacing='1' cellpadding='3'>
		<tr>
			<td align='center' valign='top' bgcolor='#E5E7E9'><b>#</b></td>
			<td align='center' valign='top' bgcolor='#E5E7E9'><b>$text_view</b></td>
			<td align='left' valign='top' bgcolor='#E5E7E9'><a href='".$http_web."/client_area.php?&sid=".trim($sid)."&order=1&sort=".((isset($sort))?"".((trim($sort)=="0")?"1":"0")."":"0")."&status=".trim($status)."'><b>$text_domainname</b></a></td>
			<td align='left' valign='top' bgcolor='#E5E7E9'><a href='".$http_web."/client_area.php?&sid=".trim($sid)."&order=2&sort=".((isset($sort))?"".((trim($sort)=="0")?"1":"0")."":"0")."&status=".trim($status)."'><b>$text_created</b></a></td>
			<td align='center' valign='top' bgcolor='#E5E7E9'><b>$text_cancelacct</b></td>
		</tr>
	");

// define order by
if (!isset($order)) { $order_by="order by user.first_name"; }
else if (trim($order)=="0") { $order_by="order by user.first_name"; }
else if (trim($order)=="1") { $order_by="order by hosting_order.domain_name"; }
else if (trim($order)=="2") { $order_by="order by hosting_order.ogcreate"; }

// define sort on
if (!isset($sort)) { $sort_by="asc"; }
else if (trim($sort)=="0") { $sort_by="asc"; }
else if (trim($sort)=="1") { $sort_by="desc"; }

$x=1;
$y=1;
$query="select ";
$query.="user.first_name, ";				// 0
$query.="user.last_name, ";					// 1
$query.="user.email, ";						// 2
$query.="user.sid, ";						// 3
$query.="hosting_order.domain_name, ";		// 4
$query.="hosting_order.ogcreate, ";			// 5
$query.="hosting_order.status, ";			// 6
$query.="hosting_order.oid, ";				// 7
$query.="hosting_order.payment_method, ";	// 8
$query.="hosting_order.uid ";				// 9
$query.="from ";
$query.="user, ";
$query.="hosting_order ";
$query.="where ";
$query.="user.uid=hosting_order.uid ";
$query.="and ";
$query.="hosting_order.uid='".addslashes(trim($uid))."' ";
$query.=addslashes(trim($order_by))." ";
$query.=addslashes(trim($sort_by));

$row=mysql_query($query);
while ($rs=mysql_fetch_row($row))
	{
	if (trim($status)=="99")
		{
		if ($y==1) {$bgcolor="#F2F4F6"; $y=0;} else {$bgcolor="#ECEEF0"; $y=1;}
		$c=base64_encode($rs[7]);
		echo("
			<tr>
				<td align='center' valign='top' bgcolor='".$bgcolor."'>".$x.").</td>
				<td align='center' valign='top' bgcolor='".$bgcolor."'><a href='".$http_web."/billing_history.php?c=".$c."&sid=".$sid."&status=".$status."'><img border='0' src='".$http_images."/view_invoice.gif' alt='$text_altclickhistory'></a>&nbsp;<a href='".$http_web."/client_view.php?c=".$c."&sid=".trim($sid)."&status=".trim($status)."'><img border='0' src='".$http_images."/icon_view.gif'></a>
			");
		if ($rs[8]==8&&$rs[6]!=0)
			{
			$uc=base64_encode(e("576cb7f68040520768bf51c75f7f4c84", $rs[7]));
			$ud=base64_encode(e("576cb7f68040520768bf51c75f7f4c84", $rs[9]));
			echo "&nbsp;<a href='".$http_web."/cc_update.php?sid=".$sid."&uc=".$uc."&ud=".$ud."'><img border='0' src='".$http_images."/cc.gif'></a>";
			}
		echo("
				</td>
				<td align='left' valign='top' bgcolor='".$bgcolor."'>
				<table width='100%' cellpadding='0' cellspacing='0' border='0'>
					<tr>
						<td width='45%' align='left' valign='top'><a href='http://".$rs[4]."' target='_blank'>http://".stripslashes($rs[4])."</a></td>
						<td width='55%' align='center' valign='top'>
			");
		if (trim($rs[6])=="0") /* Pending */
			{
			echo $text_pending;
			}
		else if (trim($rs[6])=="1") /* active */
			{
			echo "[<a href='".$http_web."/client_area.php?sid=".trim($sid)."&resend=".base64_decode($c)."&c=".base64_encode($rs[7])."'>".((isset($resend))?"".(($resend==$rs[7])?"<font color='#990000'><b>$text_resendsuccesful</b></font>":$text_resendwelcome)."":$text_resendwelcome)."</a>]&nbsp;&nbsp;&nbsp;$text_active";
			}
		else if (trim($rs[6])=="2") /* suspended */
			{
			echo $text_suspended ;
			}
		else if (trim($rs[6])=="4") /* Pending cancel */
			{
			echo $text_pendingcancel;
			}
		else if (trim($rs[6])=="5") /* cancelled */
			{
			echo $text_canceled;
			}

		echo("
						</td>
					</tr>
				</table>
				</td>
				<td align='left' valign='top' bgcolor='".$bgcolor."'>".date("m/d/Y", $rs[5])."</td>
				<td align='center' valign='top' bgcolor='".$bgcolor."'>
			");
		if (trim($rs[6])=="1")
			{
			echo "[<a href='".$http_web."/cancel_account.php?sid=".trim($sid)."&c=".base64_encode($rs[7])."'>$text_cancel</a>]";
			}
		else if (trim($rs[6])=="4")
			{
			echo "[<a href='".$http_web."/cancel_revoke.php?sid=".trim($sid)."&c=".base64_encode($rs[7])."&status=".trim($status)."'>$text_revoke</a>]";
			}
		else if (trim($rs[6])=="5")
			{
			echo "[$text_cancelled]";
			}

		echo("
				</td>
			</tr>
			");
		$x++;
		}
	else if ($rs[6]==$status)
		{
		if ($y==1) {$bgcolor="#F2F4F6"; $y=0;} else {$bgcolor="#ECEEF0"; $y=1;}
		$c=base64_encode($rs[7]);
		echo("
			<tr>
				<td align='center' valign='top' bgcolor='".$bgcolor."'>".$x.").</td>
				<td align='center' valign='top' bgcolor='".$bgcolor."'><a href='".$http_web."/billing_history.php?c=".$c."&sid=".$sid."&status=".$status."'><img border='0' src='".$http_images."/view_invoice.gif' alt='$text_altclickhistory'></a>&nbsp;<a href='".$http_web."/client_view.php?c=".$c."&sid=".trim($sid)."&status=".trim($status)."'><img border='0' src='".$http_images."/icon_view.gif'></a>
			");
		if ($rs[8]==8&&$rs[6]!=0)
			{
			$uc=base64_encode(e("576cb7f68040520768bf51c75f7f4c84", $rs[7]));
			$ud=base64_encode(e("576cb7f68040520768bf51c75f7f4c84", $rs[9]));
			echo "&nbsp;<a href='".$http_web."/cc_update.php?sid=".$sid."&uc=".$uc."&ud=".$ud."'><img border='0' src='".$http_images."/cc.gif'></a>";
			}
		echo("
				</td>
				<td align='left' valign='top' bgcolor='".$bgcolor."'>
				<table width='100%' cellpadding='0' cellspacing='0' border='0'>
					<tr>
						<td width='80%' align='left' valign='top'><a href='http://".$rs[4]."' target='_blank'>http://".stripslashes($rs[4])."</a></td>
						<td width='20%' align='center' valign='top'>".((trim($rs[6])=="0")?$text_pendingcancel:"".((trim($rs[6])=="1")?$text_active:$text_suspended)."")."</td>
					</tr>
				</table>
				</td>
				<td align='left' valign='top' bgcolor='".$bgcolor."'>".date("m/d/Y", $rs[5])."</td>
			</tr>
			");
		$x++;
		}
	}
if ($x==1&&$stats==0)
	{
	echo("
		<tr>
			<td colspan='5'><img src='".$http_images."/space.gif' width='15' height='15'><img src='".$http_images."/drop_arrow.gif'>$text_noorders</td>
		</tr>
		");
	}
else if ($x==1&&$stats==1)
	{
	echo("
		<tr>
			<td colspan='5'><img src='".$http_images."/space.gif' width='15' height='15'><img src='".$http_images."/drop_arrow.gif'>$text_nopending</td>
		</tr>
		");
	}
else if ($x==1&&$stats==2)
	{
	echo("
		<tr>
			<td colspan='5'><img src='".$http_images."/space.gif' width='15' height='15'><img src='".$http_images."/drop_arrow.gif'>$text_noactive</td>
		</tr>
		");
	}
else if ($x==1&&$stats==3)
	{
	echo("
		<tr>
			<td colspan='5'><img src='".$http_images."/space.gif' width='15' height='15'><img src='".$http_images."/drop_arrow.gif'>$text_nosuspended</td>
		</tr>
		");
	}
echo("
</table>
<!--- End Main --->
	");
?>