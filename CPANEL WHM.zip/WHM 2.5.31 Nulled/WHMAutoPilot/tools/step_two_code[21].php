<?PHP
# transfer doamin
echo("
<form action='".$PHP_SELF."' method='POST'>
<input type='hidden' name='sid' value='".trim($sid)."'>
<input type='hidden' name='gid' value='".trim($gid)."'>
<input type='hidden' name='domain_registration' value='0'>
	");

if (isset($pid)) { echo "<input type='hidden' name='pid' value='".$pid."'>"; }

if (isset($err))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$steptwo_nodomainerror."</td> 
			</tr>
			
		</table>
		");
	}

if (isset($err_username))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$steptwo_domainalreadyinuse."</td> 
			</tr>
			
		</table>
		");
	}

echo("
	<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
		<tr>
			<td width='1%' align='left' valign='top'>
			<table width='100%' cellpadding='6' cellspacing='0' border='0'>
				<tr>
					<td><img border='0' src='".$http_images."/order_arrow.gif'></td>
				</tr>
			</table>
			</td>
			<td width='99%' align='left' valign='top'>
			<table width='100%' cellpadding='0' cellspacing='0' border='0'>
				<tr>
					<td>".$steptwo_enterdomain."</td>
				</tr>
				<tr>
					<td align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='8'></td>
				</tr>
				<tr>
					<td align='left' valign='middle'>http://www. <input ".$orderinput_style." type='text' name='domain_name' size='48' maxlength='255' value='".((isset($domain_name))?"".$domain_name."":"")."'></td>
				</tr>
				<tr>
					<td align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='20'></td>
				</tr>
			</table>

			<table width='100%' cellpadding='6' cellspacing='0' border='1' bordercolor='#393839' style='border: 1px;' bgcolor='#E7E7E7'>
				<tr>
					<td>
					<table width='100%' cellpadding='06' cellspacing='0' border='0'>
						<tr>
							<td align='left' valign='top'>".$steptwo_iwillregister1."".$steptwo_iwillregister2."</td>
						</tr>
						<tr>
							<td align='left' valign='top'>
							<table width='100%' cellpadding='0' cellspacing='0' border='0'>
								<tr>
									<td width='50%' align='left' valign='top'><img src='".$http_images."/space.gif' width='14' height='1'><img src='".$http_images."/drop_arrow.gif'>".$text_primarynameserver."</td>
									<td width='50%' align='left' valign='middle'>".stripslashes($primary_ns)." [".$primary_ns_ip."]</td>
								</tr>
								<tr>
									<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='6'></td>
								</tr>
								<tr>
									<td width='50%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='1'><img src='".$http_images."/drop_arrow.gif'>".$text_secondarynameserver."</td>
									<td width='50%' align='left' valign='middle'>".$secondary_ns." [".$secondary_ns_ip."]</td>
								</tr>
							</table>
							</td>
						</tr>
						<tr>
							<td align='left' valign='top'>".$steptwo_domainexpirytext."</td>
						</tr>
						<tr>
							<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='1'><img src='".$http_images."/drop_arrow.gif'><input ".$orderinput_style." name='domain_expire_m' type='text' size='2' maxlength='2' value='".((isset($domain_expire_m))?"".$domain_expire_m."":"")."'> / <input ".$orderinput_style." name='domain_expire_d' type='text' size='2' maxlength='2' value='".((isset($domain_expire_d))?"".$domain_expire_d."":"")."'> / <input ".$orderinput_style." name='domain_expire_y' type='text' size='4' maxlength='4' value='".((isset($domain_expire_y))?"".$domain_expire_y."":"")."'> ".$steptwo_expoptional."</td>
						</tr>
					</table>
					</td>
				</tr>
			</table>
			</td>
		</tr>
	</table>
	");
?>