<?PHP
// linkpoint_v1.0.2 dated august 15 2005 by bsd
if(phpversion() <= "4.0.6") { $_POST=$HTTP_POST_VARS; }
$sid=$_POST['sid'];

$cksid=mysql_fetch_row(mysql_query("select count(*) from session_history where sid='".addslashes(trim($sid))."'"));

if ($cksid[0]<=0) 
	{	
	# added 6/2/2004
	raw_post_details($email_admin, "ERROR[10] SID was not in the database!", "unknown", "Authorize.net Public Order System");

	header("Location: ".$http_web."/step_one.php");	
	exit; 
	}
else if (!isset($sid)) 
	{ 
	# added 6/2/2004
	raw_post_details($email_admin, "ERROR[18] Sid was not set!", "unknown", "Authorize.net Public Order System");

	header("Location: ".$http_web."/step_one.php"); 
	exit; 
	}

if (isset($_POST['x_Submit']))
	{
	if (strlen(trim($_POST['x_First_Name']))==0) { $e0=true; }
		if (strlen(trim($_POST['x_Last_Name']))==0) { $e1=true; }
		if (strlen(trim($_POST['x_Address']))==0) { $e2=true; }
		if (strlen(trim($_POST['x_City']))==0) { $e3=true; }
		if (strlen(trim($_POST['x_Zip']))==0) { $e4=true; }
		if (strlen(trim($_POST['x_Phone']))<10) { $e5=true; }
		if (strlen(trim($_POST['x_Card_Num']))==0) { $e6=true; }
		if (strlen(trim($_POST['x_Exp_Date_m']))==0||strlen(trim($_POST['x_Exp_Date_y']))==0) { $e7=true; }
		if (strlen(trim($_POST['x_Card_Code']))==0) { $e8=true; }
		if (strlen(trim($_POST['x_Card_Code']))==6) { $e9=true; }

	if (!isset($e0)&&!isset($e1)&&!isset($e2)&&!isset($e3)&&!isset($e4)&&!isset($e5)&&!isset($e6)&&!isset($e7)&&!isset($e8)&&!isset($e9))
		{
		$query0="select ";
		$query0.="linkpoint_storeid, ";			// 0
		$query0.="linkpoint_type ";				// 1
		$query0.="from ";
		$query0.="payment_process ";
		$query0.="where pid='10'";

		$rs0=mysql_fetch_row(mysql_query($query0));

		$linkpoint_storeid=stripslashes(trim($rs0[0]));
		$linkpoint_type=stripslashes(trim($rs0[1]));
		#$x_Login=d("576cb7f68040520768bf51c75f7f4c84", $rs0[1]);
		#$x_Password=d("576cb7f68040520768bf51c75f7f4c84", $rs0[2]);
		#$x_Currency_Code=stripslashes(trim($rs0[3]));
		#$demo=stripslashes(trim($rs0[4]));

		# ---------------------------------------------------------

		$query1="select ";
		$query1.="total_due_today, ";	// 0
		$query1.="pid, ";				// 1
		$query1.="domain_name, ";		// 2
		$query1.="total_due_reoccur, ";	// 3
		$query1.="payment_term, ";		// 4
		$query1.="uid ";				// 5
		$query1.="from session_history ";
		$query1.="where sid='".$_POST['sid']."'";

		$rs1=mysql_fetch_row(mysql_query($query1));

		$total_due_today=stripslashes(trim($rs1[0]));
		$pid=stripslashes(trim($rs1[1]));
		$domain_name=stripslashes(trim($rs1[2]));
		$total_due_reoccur=stripslashes(trim($rs1[3]));
		$recurring_cycle=stripslashes(trim($rs1[4]));
		$uid=stripslashes(trim($rs1[5]));
		
		# ---------------------------------------------------------

		$query2="select ";
		$query2.="package_name ";	// 0
		$query2.="from plan_specs ";
		$query2.="where pid='".addslashes(trim($pid))."'";

		$rs2=mysql_fetch_row(mysql_query($query2));

		function generate_id()
			{
			srand;   
			settype($random, "Integer");
			$random=rand(0, 100000);    
			$epoch=time();    
			$moid=$epoch^$random;

			return $moid;
			}
		$thisgoesin=generate_id()."-".$sid;

		$package_name=stripslashes(trim($rs2[0]));
		$myoidisthis=$package_name." for ".$domain_name." to reoccur ".$recurring_cycle." at ".$total_due_reoccur;
		# ---------------[linkpoint]------------------------------
		include "inc/lphp.php";
		$mylphp=new lphp;

		# constants
		$myorder["host"]="secure.linkpt.net";
		# $myorder["host"]="staging.linkpt.net"; // switch for testing
		$myorder["port"]="1129";
		$myorder["keyfile"]="inc/lpnt.pem";
		$myorder["configfile"]=$linkpoint_storeid;
		// has to be this way since it cannot send in two different amounts
		$myorder["chargetotal"]=$total_due_today;
		// will require the admin to login to linkpoint & make order 'recurring'
		// now lets fill in the other goodies
		$myorder["oid"]=$thisgoesin;
		$myorder["comments"]=$myoidisthis;
		$myorder["cardnumber"]=$_POST["x_Card_Num"];
		$myorder["cardexpmonth"]=$_POST["x_Exp_Date_m"];
		$myorder["cardexpyear"]=$_POST["x_Exp_Date_y"];
		$myorder["cvmvalue"]=$_POST["x_Card_Code"];
		$myorder["ordertype"]=$linkpoint_type;
		$myorder["ip"]=$_SERVER['REMOTE_ADDR'];
		$myorder["name"]=$_POST["x_First_Name"]." ".$_POST['x_Last_Name'];
		$myorder["address1"]=$_POST["x_Address"];
		$myorder["city"]=$_POST["x_City"];
		$myorder["state"]=$_POST["x_state"];
		$myorder["country"]=$_POST["x_Country"];
		$myorder["phone"]=$_POST['x_Phone'];
		$myorder["fax"]=$_POST['x_Fax'];
		$myorder["email"]=$_POST["x_Email"];
		$myorder["zip"]=$_POST["x_Zip"];
		$myorder["debugging"]="false"; // change to true for debug

		$result=$mylphp->curl_process($myorder);
		
		if ($result["r_message"]!="APPROVED")
			{
			$response_code=69;
			$response_reason_text="Status:  [".((trim($result[r_approved])=="")?"Unknown":"".$result[r_approved]."")."] ";
			$response_reason_text.=$result[r_error];
			}
	
		else { $response_code=1; }

		if ($result["r_message"]=="APPROVED")
			{
			
			if ($recurring_cycle=="monthly") { $interval_0="1"; }
			else if ($recurring_cycle=="quarterly") { $interval_0="3"; }
			else if ($recurring_cycle=="semi_annual") { $interval_0="6"; }
			else if ($recurring_cycle=="annual") { $interval_0="12"; }
			$t1="m";
			$periodicity=$t1.$interval_0;
			$cardnumber=$_POST["x_Card_Num"];
			$cardnumber=e("576cb7f68040520768bf51c75f7f4c84", $cardnumber);
			$cardexpmonth=$_POST["x_Exp_Date_m"];
			$cardexpyear=$_POST["x_Exp_Date_y"];
			$ip=$_SERVER['REMOTE_ADDR'];
			$name=$_POST["x_First_Name"]." ".$_POST['x_Last_Name'];
			$address1=$_POST["x_Address"];
			$city=$_POST["x_City"];
			$state=$_POST["x_state"];
			$country=$_POST["x_Country"];
			$phone=$_POST['x_Phone'];
			$fax=$_POST['x_Fax'];
			$email=$_POST["x_Email"];
			$zip=$_POST["x_Zip"];
			$sid=$_POST['sid'];

			$query_linkqueue="insert into ";
			$query_linkqueue.="linkpoint_holding_queue ";
			$query_linkqueue.="set ";
			$query_linkqueue.="sid='".addslashes(trim($sid))."', ";
			$query_linkqueue.="chargetotal='".addslashes(trim($total_due_reoccur))."', ";
			$query_linkqueue.="thisgoesin='".addslashes(trim($thisgoesin))."', ";
			$query_linkqueue.="comments='".addslashes(trim($myoidisthis))."', ";
			$query_linkqueue.="periodicity='".addslashes(trim($periodicity))."', ";
			$query_linkqueue.="cardnumber='".addslashes(trim($cardnumber))."', ";
			$query_linkqueue.="cardexpmonth='".addslashes(trim($cardexpmonth))."', ";
			$query_linkqueue.="cardexpyear='".addslashes(trim($cardexpyear))."', ";
			$query_linkqueue.="ip='".addslashes(trim($ip))."', ";
			$query_linkqueue.="name='".addslashes(trim($name))."', ";
			$query_linkqueue.="address1='".addslashes(trim($address1))."', ";
			$query_linkqueue.="city='".addslashes(trim($city))."', ";
			$query_linkqueue.="state='".addslashes(trim($state))."', ";
			$query_linkqueue.="country='".addslashes(trim($country))."', ";
			$query_linkqueue.="phone='".addslashes(trim($phone))."', ";
			$query_linkqueue.="fax='".addslashes(trim($fax))."', ";
			$query_linkqueue.="email='".addslashes(trim($email))."', ";
			$query_linkqueue.="zip='".addslashes(trim($zip))."', ";
			$query_linkqueue.="uid='".addslashes(trim($uid))."', ";
			$query_linkqueue.="oid='".addslashes(trim($oid))."', ";
			$query_linkqueue.="linkpoint_type='".addslashes(trim($linkpoint_type))."', ";
			$query_linkqueue.="status='1' ";
			#$query.="ogcreate='".time()."'";

			mysql_query($query_linkqueue);
			
			// get the LPID from the record
			
			$query_linksess="select ";
			$query_linksess.="lpid ";
			$query_linksess.="from ";
			$query_linksess.="linkpoint_holding_queue ";
			$query_linksess.="where sid='".addslashes(trim($sid))."'";

			$rslink=mysql_fetch_row(mysql_query($query_linksess));

			$updatelinksess=stripslashes(trim($rslink[0]));
			$sid=$_POST['sid'];
			// update the session record with the LPID
			$query_updatesess="update ";
			$query_updatesess.="session_history ";
			$query_updatesess.="set ";
			$query_updatesess.="lpid='".addslashes(trim($updatelinksess))."'";
			$query_updatesess.="where sid='".addslashes(trim($sid))."'";

			mysql_query($query_updatesess);
			// have not changed the log function yet, working on session and queue
			if ($_POST['ccid']==0)
				{
				$card_info=$_POST['x_Card_Num']."|".$_POST['x_Exp_Date_m'].$_POST['x_Exp_Date_y']."|0|";
				$card_info=e("576cb7f68040520768bf51c75f7f4c84", $card_info);
					}

			$desc=$package_name." [".$domain_name."]{}".$package_name."{}";

			$batch_info=$_SERVER['REMOTE_ADDR']."|";	// customer_ip_address|
			$batch_info.=$desc."|";						// description|
			$batch_info.=$x_Currency_Code."|";			// currency_code|
			$batch_info.=$transaction_type."|";			// transaction_type|
			$batch_info.="YES"."|";						// recurring_billing|
			$batch_info.="CC"."|";						// payment_method|
			$batch_info.=$cardholder_first_name."|";	// customer_first_name|
			$batch_info.=$cardholder_last_name."|";		// customer_last_name|
			$batch_info.=$xaddress."|";					// customer_address|
			$batch_info.=$xcity."|";					// customer_city|
			$batch_info.=$xstate."|";					// customer_state|
			$batch_info.=$xzip."|";						// customer_zip|
			$batch_info.=$xcountry."|";					// customer_country|
			$batch_info.=$xphone."|";					// customer_phone|
			$batch_info.=$xfax."|";						// customer_fax|
			$batch_info.=$xemail."|";					// customer_email|
			$batch_info.=$card_info."|";				// card_info|
			$batch_info.=$response_code."|";			// batch_status|
			$batch_info.=$response_reason_text."|";		// response_reason_text|
			$batch_info.=$transaction_id."|";			// invoice_number|
			$batch_info.=$_POST['ccid']."|";			// ccid|

			// write marker
			$c=md5(microtime());

			// sid|batch_info
			$data=$sid."|".base64_encode($batch_info)."|";

			// write the file
			$read=fopen($below_public."/".$c, "w");
			$result=fwrite($read, $data);
			fclose($read);
				
			// chmod the file
			chmod($below_public."/".$c, 0777);

			// redirect out!
			header("Location: ".$http_web."/linkpoint_success.php?c=".$c);
			exit;
			
			}
		else
			{
			$e69=$response_reason_text.".";
			}
		}
	}
?>