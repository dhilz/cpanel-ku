<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/languages/english.php";
include "inc/client_functions.php";
include "inc/whm_functions.php";
include "inc/affiliate_functions.php";
include "inc/invoice_functions.php";
include "inc/varilogix_functions.php";
include "inc/header.php";

$sid=$_GET['sid'];
#echo $sid;
#echo "<BR><BR>";
$iid=d("576cb7f68040520768bf51c75f7f4c84", $sid);
#echo $iid;
#echo "<BR><BR>";
#print_r($_GET);
#echo "<BR>should be errmsg below<BR>";
#echo $_GET['ErrMsg'];
#echo "<BR>should be err below<BR>";
#echo $_GET['Err'];
#echo "<BR><BR>";

$query1="select ";
$query1.="invoice_type ";
$query1.="from ";
$query1.="invoice ";
$query1.="where ";
$query1.="iid='".addslashes(trim($iid))."'";

$rs2=mysql_fetch_row(mysql_query($query1));
$whatcheck=$rs2[0];

$_GET['ErrMsg']=strtolower($_GET['ErrMsg']);
#echo $_GET['ErrMsg'];
if (ereg("unsupported", $_GET['ErrMsg'])) 
    { 
    raw_post_details($email_admin, $_GET['ErrMsg'], $domain_name, "PSiGate");
	
	echo "<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'><tr><td><BR><center><font color='#C60C08'><b>ERROR OCCURED! </b></font>"; 
	echo $_GET['ErrMsg']."<BR><BR></td></tr></b><br><br>";
	#echo "<tr><td><center><a href='".$http_web."/step_four.php?sid=".$sid."' target='_parent'><B>Click here</b></a> to correct your card information and try again.<br><BR></td></tr></table><BR><BR>";
	echo "<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'><tr><td>There were no charges placed on the card submitted due to an error during processing.<BR><BR>Please click below to be returned back to our order system to correct the credit card information submitted.<BR><BR>We greatly appreciate your patience and have been notified of the error message you encountered and will investigate it at the gateway upon success on your order<BR><BR>Thank You</td></tr></table>";
	echo "<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'><tr><td>";
	echo "<form action='".$http_web."/invoice_pcredit_card.php' method='POST'>";
	echo "<input type='hidden' name='sid' value='".trim($sid)."'>";
	if ($whatcheck==!0) { echo "<input type='hidden' name='one_time' value='1'>"; }
	echo "<center><input ".$orderbutton_style." type='submit' name='submit' value='Click To Return to the Payment Screen'></center></td></tr></table>";
	exit; 
    } 
#die;
include "inc/footer.php";
?>