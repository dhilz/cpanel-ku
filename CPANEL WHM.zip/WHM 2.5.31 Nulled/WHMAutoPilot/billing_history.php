<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/whm_functions.php";
include "inc/client_functions.php";
include "inc/affiliate_functions.php";
include "inc/invoice_functions.php";

// authenicate sid
if (auth_sid($sid)==1) { header("Location: ".$http_web."/clogin.php"); exit; }

include "inc/header.php";

echo("
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td align='left' valign='middle'><img src='".$http_images."/menu_arrow_back.gif'><a href='".$http_web."/client_area.php?sid=".$sid."&status=".$status."'>".$text_goback."</a></td>
	</tr>
	<tr>
		<td align='left' valign='middle'><hr color='#F0EFED'></td>
	</tr>
	<tr>
		<td align='left' valign='middle'>".$text_doamininvoicehistory."</td>
	</tr>
</table>
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td width='10%' align='center' valign='middle' bgcolor='#E5E7E9'>".$text_view."</td>
		<td width='10%' align='left' valign='middle' bgcolor='#E5E7E9'>".$text_invoice."</td>
		<td width='44%' align='left' valign='middle' bgcolor='#E5E7E9'>".$text_domainname."</td>
		<td width='18%' align='left' valign='middle' bgcolor='#E5E7E9'>".$text_created."</td>
		<td width='18%' align='left' valign='middle' bgcolor='#E5E7E9'>".$text_invoicedue."</td>
	</tr>
	");
$oid=base64_decode($c);
$x=1;
$y=1;
$query="select ";
$query.="iid, ";			// 0
$query.="invoice_number, ";	// 1
$query.="created, ";		// 2
$query.="due_date, ";		// 3
$query.="status, ";			// 4
$query.="date_paid ";		// 5
$query.="from invoice ";
$query.="where oid='".addslashes(trim($oid))."' ";
$query.="order by created desc";

$row=mysql_query($query);
while ($rs=mysql_fetch_row($row))
	{
	$iid=stripslashes(trim($rs[0]));
	$invoice_number=stripslashes(trim($rs[1]));
	$created=stripslashes(trim($rs[2]));
	$due_date=stripslashes(trim($rs[3]));
	$invoice_status=stripslashes(trim($rs[4]));
	$date_paid=stripslashes(trim($rs[5]));
	
	# -----------------------------------------------------------

	$query0="select ";
	$query0.="domain_name ";
	$query0.="from ";
	$query0.="hosting_order ";
	$query0.="where ";
	$query0.="oid='".addslashes(trim($oid))."' ";
	$query0.="limit 0, 1";
	
	$rs0=mysql_fetch_row(mysql_query($query0));

	$domain_name=stripslashes(trim($rs0[0]));
	
	# -----------------------------------------------------------

	if ($y==1) { $bgcolor="#F2F4F6"; $y=0; } else { $bgcolor="#ECEEF0"; $y=1; }

	echo("
		<tr>
			<td align='center' valign='top' bgcolor='".$bgcolor."'>
		");
		if ($invoice_status=="0")
			{ 
			echo "<a href='".$http_web."/invoice_hosting_payable.php?c=".urlencode(e("576cb7f68040520768bf51c75f7f4c84", $iid))."' target='_blank'><img alt='".$text_altviewformatted."' src='".$http_images."/view_formatted.gif' border='0'></a>&nbsp;";
			}
			else
			{
			echo" <a href='".$http_web."/invoice_hosting.php?c=".urlencode(e("576cb7f68040520768bf51c75f7f4c84", $iid))."' target='_blank'><img alt='".$text_altviewformatted."' src='".$http_images."/view_formatted.gif' border='0'></a>&nbsp;";
			}
		echo("
		</td>
			<td align='left' valign='top' bgcolor='".$bgcolor."'>&nbsp;#".$invoice_number."</td>
			<td align='left' valign='top' bgcolor='".$bgcolor."'>&nbsp;<a href='http://".$domain_name."' target='_blank'>http://".$domain_name."</a>
			");
			if ($invoice_status=="0") { echo "<font color='red'><B> [ unpaid ]</b>"; }
			echo("
			</td>
			<td align='left' valign='top' bgcolor='".$bgcolor."'>&nbsp;".date("m/d/Y", $created)."</td>
			<td align='left' valign='top' bgcolor='".$bgcolor."'>&nbsp;".date("m/d/Y", $due_date)."</td>
			<!--- <td width='10%' align='left' valign='top' bgcolor='".$bgcolor."'>".invoice_status($invoice_status)."</td> --->
		</tr>
		");
	$x++;
	}

if ($x==1)
	{
	echo("
				<tr>
					<td colspan='6'><img src='".$http_images."/space.gif' width='1' height='4'></td>
				</tr>
				<tr>
					<td colspan='6'><font color='#990000'>$text_noinvoicesfound.</font></td>
				</tr>
		");
	}

echo("
	<tr>
		<td colspan='6'><img src='".$http_images."/space.gif' width='1' height='16'></td>
	</tr>
</table>
	");

include "inc/footer.php";
?>