<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/languages/".$local_lang."/step_fraudgate.php";
include "inc/whm_functions.php";

if (isset($c))
	{
	if (file_exists($below_public."/".$c."_invoice.log"))
		{
		$read=file($below_public."/".$c."_invoice.log");
		list($change_gid, $change_oid)=split("[|]", base64_decode($c));
		}
	else
		{
		header("Location: ".$http_web);
		exit;
		}
	}
else
	{
	header("Location: ".$http_web);
	exit;
	}


include "inc/header.php";

// pull in order to information
$query="select ";
$query.="user.first_name, ";						// 0
$query.="user.last_name, ";							// 1
$query.="user.street_address_1, ";					// 2
$query.="user.street_address_2, ";					// 3
$query.="user.city, ";								// 4
$query.="user.state, ";								// 5
$query.="user.zip_code, ";							// 6
$query.="user.country, ";							// 7
$query.="user.phone, ";								// 8
$query.="user.fax, ";								// 9
$query.="user.email, ";								// 10
$query.="user.username, ";							// 11
$query.="user.password, ";							// 12
$query.="user.advert, ";							// 13
$query.="user.advert_other, ";						// 14
$query.="user.tos, ";								// 15
$query.="hosting_order.pid, ";						// 16
$query.="hosting_order.status, ";					// 17
$query.="hosting_order.domain_name, ";				// 18
$query.="hosting_order.domain_registration, ";		// 19
$query.="hosting_order.domain_expire, ";			// 20
$query.="hosting_order.payment_method, ";			// 21
$query.="hosting_order.payment_term, ";				// 22
$query.="hosting_order.ip, ";						// 23
$query.="hosting_order.ns1, ";						// 24
$query.="hosting_order.ns2, ";						// 25
$query.="hosting_order.total_due_today, ";			// 26
$query.="hosting_order.total_due_reoccur, ";		// 27
$query.="hosting_order.promotion_code, ";			// 28
$query.="hosting_order.referrer_id, ";				// 29
$query.="hosting_order.ogcreate, ";	// 30
$query.="user.temp_pw, ";							// 31
$query.="hosting_order.whm_username, ";				// 32
$query.="hosting_order.whm_password, ";				// 33
$query.="user.sid, ";								// 34
$query.="user.uid, ";								// 35
$query.="hosting_order.whm_id, ";					// 36
$query.="hosting_order.client_notes, ";				// 37
$query.="plan_specs.dedicated, ";					// 38
$query.="hosting_order.pns1, ";						// 39
$query.="hosting_order.pns2, ";						// 40
$query.="hosting_order.root_pw, ";					// 41
$query.="hosting_order.server_hostname, ";			// 42
$query.="hosting_order.tld_id ";					// 43
$query.="from user, hosting_order, plan_specs ";
$query.="where hosting_order.oid='".addslashes(trim($change_oid))."' ";
$query.="and hosting_order.uid=user.uid ";
$query.="and hosting_order.pid=plan_specs.pid ";
$query.="order by hosting_order.uid asc limit 0, 1";

// execute query
$rs1=mysql_fetch_row(mysql_query($query));

$first_name=stripslashes($rs1[0]);
$last_name=stripslashes($rs1[1]);
$street_address_1=stripslashes($rs1[2]);
$street_address_2=stripslashes($rs1[3]);
$city=stripslashes($rs1[4]);
$state=stripslashes($rs1[5]);
$zip_code=stripslashes($rs1[6]);
$country=stripslashes($rs1[7]);
$phone=stripslashes($rs1[8]);
$fax=stripslashes($rs1[9]);
$email=stripslashes($rs1[10]);
$username=stripslashes($rs1[11]);
$password=stripslashes($rs1[12]);
$advert=stripslashes($rs1[13]);
$advert_other=stripslashes($rs1[14]);
$tos=stripslashes($rs1[15]);
$pid=stripslashes($rs1[16]);
$status=stripslashes($rs1[17]);
$domain_name=stripslashes($rs1[18]);
$domain_registration=stripslashes($rs1[19]);
$domain_expire=stripslashes($rs1[20]);
$payment_method=stripslashes($rs1[21]);
$payment_term=stripslashes($rs1[22]);
$ip=stripslashes($rs1[23]);
$ns1=stripslashes($rs1[24]);
$ns2=stripslashes($rs1[25]);
$total_due_today=stripslashes($rs1[26]);
$total_due_reoccur=stripslashes($rs1[27]);
$promotion_code=stripslashes($rs1[28]);
$referrer_id=stripslashes($rs1[29]);
$ogcreate=stripslashes($rs1[30]);
$temp_pw=stripslashes($rs1[31]);
$whm_username=stripslashes($rs1[32]);
$whm_password=stripslashes($rs1[33]);
$sid=stripslashes($rs1[34]);
$uid=stripslashes($rs1[35]);
$whm_id=stripslashes($rs1[36]);
$client_notes=stripslashes($rs1[37]);
$dedicated=stripslashes($rs1[38]);
$pns1=stripslashes($rs1[39]);
$pns2=stripslashes($rs1[40]);
$root_pw=stripslashes($rs1[41]);
$server_hostname=stripslashes($rs1[42]);
$tld_id=stripslashes($rs1[43]);

$fg_data = mysql_query("SELECT fg_value FROM autopilot_fraudgate WHERE fg_variable='activate'");
$fg_row = mysql_fetch_array($fg_data);

        if($fg_row['fg_value'] == 1)
        {
            // start the FraudGate call
            $url = "https://secure.fraudgate.com/gateway/verify.dll";
            $postfields = array();

            unset($fg_data);
			$fg_data = mysql_query("SELECT fg_variable, fg_value FROM autopilot_fraudgate WHERE fg_variable <> 'activate'");
			while($fg_row = @mysql_fetch_array($fg_data))
			{
			    $value = $fg_row['fg_value'];
				if(strpos($fg_row['fg_variable'], "FG_INPUT_") !== FALSE) // it is an input variable
				{
					if(strtolower($value) == "order number")
                        $value = $change_oid;
					else if(strtolower($value) == "no input required")
					    $value = "";
				}
			    $postfields[$fg_row['fg_variable']] = $value;
			}

            // now add the customer information
            $domain = explode("@", $email);
            $postfields['FG_CITY'] = trim($city);
            $postfields['FG_STATE'] = trim($state);
            $postfields['FG_POSTAL'] = trim($zip_code);
            $postfields['FG_COUNTRY'] = trim($country);
            $postfields['FG_PHONE'] = trim($phone);
            $postfields['FG_DOMAIN'] = trim($domain[1]);
            $postfields['FG_IP'] = getenv("REMOTE_ADDR");
            $postfields['FG_TRANS_ID'] = $change_oid;

            // make the parameters
            $params = "";
            foreach($postfields as $key => $value)
            {
                $params .= "&" . $key . "=" . urlencode($value);
            }
			
            // start the call to the gateway
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_POST,1);
            curl_setopt($ch, CURLOPT_POSTFIELDS,$params);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);  // this line makes it work under https
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);

            $chresult=curl_exec($ch);
            curl_close ($ch);
            echo $invoice_page_notice;
            echo $order_number_text_begin.$change_oid.$order_number_text_end;

        }

if ($domain_registration==1)
	{
	$query_tld="select ";
	$query_tld.="cost, ";
	$query_tld.="reg_period ";
	$query_tld.="from ";
	$query_tld.="tld_chart ";
	$query_tld.="where ";
	$query_tld.="tld_id='".addslashes(trim($tld_id))."'";
	
	$rs_tld=mysql_fetch_row(mysql_query($query_tld));

	$tld_fee=stripslashes(trim($rs_tld[0]));
	$reg_period=stripslashes(trim($rs_tld[1]));

	$domain_details=$currency."".sprintf("%01.2f", $tld_fee)." ".$currency_type;
	if ($reg_period==1) { $domain_details.=" per Year."; }
	else if ($reg_period==2) { $domain_details.=" per 2 Years."; }
	else if ($reg_period==3) { $domain_details.=" per 5 Years."; }
	else if ($reg_period==4) { $domain_details.=" per 10 Years."; }
	}

// get plan data
$query1="select ";
$query1.="package_name, ";			// 0
$query1.="gid ";					// 1
$query1.="from plan_specs where pid='".addslashes(trim($pid))."'";

//execute query
$rs1=mysql_fetch_row(mysql_query($query1));

$package_name=stripslashes($rs1[0]);
$gid=stripslashes($rs1[1]);

//execute query
$rs2=mysql_fetch_row(mysql_query("select name from plan_groups where gid='".addslashes(trim($change_gid))."'"));

$group_name=stripslashes($rs2[0]);

if ($whm_id=="0")
	{
	$rsi_query="select ";
	$rsi_query.="server_ip,";
	$rsi_query.="primary_ns, ";
	$rsi_query.="primary_ns_ip, ";
	$rsi_query.="secondary_ns, ";
	$rsi_query.="secondary_ns_ip ";
	$rsi_query.="from ";
	$rsi_query.="server_config ";
	$rsi_query.="where ";
	$rsi_query.="active_server='1'";

	$rsi=mysql_fetch_row(mysql_query($rsi_query));

	$primary_ns=stripslashes(trim($rsi[1]));
	$primary_ns_ip=stripslashes(trim($rsi[2]));
	$secondary_ns=stripslashes(trim($rsi[3]));
	$secondary_ns_ip=stripslashes(trim($rsi[4]));
	}
	else
	{
	$rsi_query="select ";
	$rsi_query.="server_ip,";
	$rsi_query.="primary_ns, ";
	$rsi_query.="primary_ns_ip, ";
	$rsi_query.="secondary_ns, ";
	$rsi_query.="secondary_ns_ip ";
	$rsi_query.="from ";
	$rsi_query.="server_config ";
	$rsi_query.="where ";
	$rsi_query.="whm_id='".addslashes(trim($whm_id))."'";

	$rsi=mysql_fetch_row(mysql_query($rsi_query));

	$primary_ns=stripslashes(trim($rsi[1]));
	$primary_ns_ip=stripslashes(trim($rsi[2]));
	$secondary_ns=stripslashes(trim($rsi[3]));
	$secondary_ns_ip=stripslashes(trim($rsi[4]));
	}


$query_invoice="select ";
$query_invoice.="iid ";
$query_invoice.="from ";
$query_invoice.="invoice ";
$query_invoice.="where ";
$query_invoice.="invoice_type='0' ";
$query_invoice.="and ";
$query_invoice.="oid='".$change_oid."' ";
$query_invoice.="and ";
$query_invoice.="master='1'";
$query_invoice.="or ";
$query_invoice.="invoice_type='0' ";
$query_invoice.="and ";
$query_invoice.="oid='".$change_oid."' ";
$query_invoice.="and ";
$query_invoice.="master='69'";

$rs_invoice=mysql_fetch_row(mysql_query($query_invoice));

$iid=$rs_invoice[0];

echo("
<table width='85%' cellpadding='2' cellspacing='0' border='0' align='center'>
	<tr>
		<td><img src='".$http_images."/menu_arrow.gif'><b>".$etxt_orderreceived." ".date("m/d/Y", $ogcreate)." at ".date("h:i:s a", $ogcreate).".</b></td>
		<td><a href='".$http_web."/invoice_hosting.php?c=".urlencode(e("576cb7f68040520768bf51c75f7f4c84", $iid))."' target='_blank'><img border='0' src='".$http_images."/printer_friendly.gif'></a></td>
	</tr>
</table>
<table width='85%' cellpadding='2' cellspacing='0' border='0' align='center'>
	<tr>
		<td align='left' valign='top'><hr color='#F0EFED'></td>
	</tr>
	");
if (isset($auto_create_error))
	{
	echo("
	<tr>
		<td align='left' valign='top'>".$text_weexperiencedproblems.".</td>
	</tr>
	<tr>
		<td align='left' valign='top'>".$text_staffcontacted.".</td>
	</tr>
	<tr>
		<td align='left' valign='top'><b>".$text_thankspatience.".</b></td>
	</tr>
	<tr>
		<td align='left' valign='top'><hr color='#F0EFED'></td>
	</tr>
		");
	}
echo("
	<tr>
		<td align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><i>".$text_clientinfo.":</i></td>
	</tr>
	<tr>
		<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$first_name." ".$last_name."</td>
	</tr>
	<tr>
		<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$street_address_1."</td>
	</tr>
	");
if (strlen(trim($street_address_2))!=0)
	{
	echo("
	<tr>
		<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$street_address_2."</td>
	</tr>
		");
	}
echo("
	<tr>
		<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$city.", ".$state." ".$zip_code." ".$country."</td>
	</tr>
	<tr>
		<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_phone.": ".$phone."</td>
	</tr>
	");
if (strlen(trim($fax))!=0)
	{
	echo("
	<tr>
		<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_fax.": ".$fax."</td>
	</tr>
		");
	}
echo("
	<tr>
		<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_email.": ".$email."</td>
	</tr>
	<tr>
		<td><hr color='#F0EFED'></td>
	</tr>
</table>
<table width='85%' cellpadding='4' cellspacing='0' border='0' align='center'>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><i>".$text_orderdetails.":</i></td>
	</tr>
	");
if ($dedicated==1)
	{
	echo("
		<tr>
			<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_serverhostname.":</td>
			<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$server_hostname.".".$domain_name."</td>
		</tr>
		<tr>
			<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_nameservers.":</td>
			<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$pns1.".".$domain_name."</td>
		</tr>
		<tr>
			<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'></td>
			<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$pns2.".".$domain_name."</td>
		</tr>
		");
	}
else
	{
	echo("
		<tr>
			<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_domainname.":</td>
			<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>http://".$domain_name."</td>
		</tr>
		<tr>
			<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_domainregistration.":</td>
			<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".(($domain_registration=="1")?$text_wewillregister." ".$domain_details:$text_youwillregister)."</td>
		</tr>
		<tr>
			<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='18' height='9'><img src='".$http_images."/drop_arrow.gif'>".$text_usenameserver.":</td>
			<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".stripslashes($primary_ns)." [".$primary_ns_ip."]</td>
		</tr>
		<tr>
			<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='18' height='9'><img src='".$http_images."/drop_arrow.gif'>".$text_usenameserver.":</td>
			<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$secondary_ns." [".$secondary_ns_ip."]</td>
		</tr>
		");

	if ($domain_registration!="1")
		{
		/*
		// get current NS
		$current_ns=current_ns();
		if ($current_ns!=99)
			{
			list($primary_ns, $primary_ns_ip, $secondary_ns, $secondary_ns_ip)=split("[|]", $current_ns);

			echo("
				<tr>
					<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='18' height='9'><img src='".$http_images."/drop_arrow.gif'>".$text_usenameserver.":</td>
					<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".stripslashes($primary_ns)." [".$primary_ns_ip."]</td>
				</tr>
				<tr>
					<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='18' height='9'><img src='".$http_images."/drop_arrow.gif'>".$text_usenameserver.":</td>
					<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$secondary_ns." [".$secondary_ns_ip."]</td>
				</tr>
				");
			}
		*/
		if (strlen(trim(str_replace("/", "", $domain_expire)))!=0)
			{
			echo("
				<tr>
					<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='18' height='9'><img src='".$http_images."/drop_arrow.gif'>".$text_domainexpires.":</td>
					<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$domain_expire."</td>
				</tr>
				");
			}
		}
	}
echo("
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_packageordered.":</td>
		<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".((trim($group_name)!="")?"".$group_name.": ":"")."".$package_name."</td>
	</tr>
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='18' height='9'><img src='".$http_images."/drop_arrow.gif'>".$text_totalduenow.":</td>
		<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$currency."".$total_due_today."".$currency_type."</td>
	</tr>
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='18' height='9'><img src='".$http_images."/drop_arrow.gif'>".$text_totalrecurring.":</td>
		<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$currency."".$total_due_reoccur."".$currency_type."</td>
	</tr>
	");
$ctu=mysql_fetch_row(mysql_query("select count(*) from hosting_order where uid='".addslashes(trim($uid))."'"));
if ($ctu[0]<=1)
	{
	echo("
		<tr>
			<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_clientareausername.":</td>
			<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$username."</td>
		</tr>
		<tr>
			<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_clientareapassword.":</td>
			<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$temp_pw."</td>
		</tr>
		");
	}
echo("
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_pathtoclientarea.":</td>
		<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'><a href='".$http_web."/clogin.php' target='_blank'>".$http_web."/clogin.php</a> [<a href='".$http_web."/client_area.php?sid=".trim($sid)."'>click to access now</a>]</td>
	</tr>
	");
if (trim($status)!="0")
	{
	echo("
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_whmusername.":</td>
		<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$whm_username."</td>
	</tr>
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_whmpassword.":</td>
		<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$whm_password."</td>
	</tr>
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_pathtocpanel.":</td>
		<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'><a href='http://".$rsi[0]."/cpanel' target='_blank'>http://".$rsi[0]."/cpanel</a></td>
	</tr>
		");
	}
echo("
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_terms.":</td>
		<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_youhaveagreed.".</td>
	</tr>
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_notes.":</td>
		<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".((trim($client_notes)!="")?"".$client_notes."":$text_none)."</td>
	</tr>
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_paymentmethod.":</td>
		<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>
	");
if ($payment_method==6) { echo"<img src='".$http_images."/mailin.gif'>"; }
if ($payment_method==1) { echo"<img src='".$http_images."/paypal.gif'>"; }
if ($payment_method==3)	{ echo"<img src='".$http_images."/paysystems.gif'>"; }
if ($payment_method==8) { echo"<img src='".$http_images."/authorize.gif'>";	}
///// Internet Secure change 13/08/2004
if ($payment_method==9) { echo"<img src='".$http_images."/internetsecure.gif'>";	}
///// Internet Secure change 13/08/2004
if ($payment_method==2) { echo"<img src='".$http_images."/worldpay.gif'>"; }
if ($payment_method==4) { echo"<img src='".$http_images."/2checkout.gif'>"; }
if ($payment_method==10) { echo"<img src='".$http_images."/linkpoint.gif'>"; }
if ($payment_method==11) { echo"<img src='".$http_images."/psigate.gif'>"; }
if ($payment_method==12) { echo"<img src='".$http_images."/paypal.gif'>"; }
if ($payment_method==13) { echo"<img src='".$http_images."/worldpay.gif'>"; }
if ($payment_method==14) { echo"<img src='".$http_images."/cybersource.gif'>"; }
if ($payment_method==15) { echo"<img src='".$http_images."/offlinecc.gif'>"; }
echo("
		</td>
	</tr>
</table>
</form>
	");

include "inc/footer.php";
mysql_close($dblink);
?>
