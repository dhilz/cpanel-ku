<?PHP
echo("
<input type='hidden' name='sid' value='".trim($sid)."'>
<table width='530' border='0' cellspacing='0' cellpadding='0' bgcolor='40a3de' HEIGHT='25' style='border-top: solid; border-left: solid; border-right: solid; border-color: 53afe5; border-width: 1pxl'>
	<tr>
		<td width='100%'><B><FONT COLOR='#FFFFFF' SIZE='-2' FACE='Verdana'>(".$unresolved_total_count.") Domains Unresolved</FONT></B></td>
	</tr>
</table>
<table width='530' border='0' cellspacing='1' cellpadding='2' style='border-left: solid; border-right: solid; border-bottom: solid; border-color: #53afe5; border-width: 1pxl'>
	");
echo $resolved_details;
echo("
</table>
<table width='530' border='0' cellspacing='0' cellpadding='2' style='border-bottom: solid; border-left: solid; border-right: solid; border-color: 53afe5; border-width: 1pxl'>
	<tr>
		<td width='1%' align='left' valign='middle' BGCOLOR='#a5daf9'>
		<select name='xoid' ".$input_style.">
		<option value='0'>Run for all clients</option>
	");
$row=mysql_query("select oid, domain_name from hosting_order where status='1' and resolved='0' order by domain_name asc");
while ($rs=mysql_fetch_row($row))
	{
	echo"<option value='".$rs[0]."'>".$rs[1]."</option>\n";
	}
echo("
		</select>
		</td>
		<td width='99%' align='left' valign='middle' BGCOLOR='#a5daf9'><img src='".$http_images."/space.gif' width='10' height='1'><input ".$button_style." type='submit' name='submit_resolve' value='Resolve Now &gt'></td>
	</tr>
</table>
<table width='100%' cellpadding='0' cellspacing='0' border='0'>
	<tr>
		<td><img src='".$http_images."/space.gif' width='1' height='6'></td>
	</tr>
</table>
	");
?>