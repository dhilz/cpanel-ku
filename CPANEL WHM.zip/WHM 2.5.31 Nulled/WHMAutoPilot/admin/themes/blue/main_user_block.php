<?PHP
echo("
<table width='530' BORDER='0' CELLSPACING='0' CELLPADDING='0' bgcolor='40a3de' HEIGHT='25' style='border-top: solid; border-left: solid; border-right: solid; border-color: 53afe5; border-width: 1pxl'>
	<tr>
		<td width='100%'><B><font COLOR='#FFFFFF' SIZE='-2' FACE='Verdana'>(".$total_pending.") Pending Accounts waiting for Activation</font></B></td>
	</tr>
</table>
<table width='530' BORDER='0' CELLSPACING='1' CELLPADDING='2'	style='border-left: solid; border-right: solid; border-bottom: solid; border-color: #53afe5; border-width: 1pxl'>
	");
echo $pending_list;
echo("
</table>
<table width='530' BORDER='0' CELLSPACING='0' CELLPADDING='2' style='border-bottom: solid; border-left: solid; border-right: solid; border-color: 53afe5; border-width: 1pxl'>
	<tr>
		<td width='33%' align='left' valign='middle' BGCOLOR='#a5daf9'><font SIZE='-2' FACE='Verdana'><A HREF='".$http_admin."/client_view_edit.php?status=99&sid=".trim($sid)."'
		style='color:000000;'>Manage Accounts</A></font></td>
		<td width='34%' align='center' valign='middle' BGCOLOR='#a5daf9'><font SIZE='-2' FACE='Verdana'><A HREF='".$http_admin."/client_cancel_account.php?sid=".trim($sid)."'
		style='color:000000;'>Cancel Requests</A></font></td>
		<td width='33%' align='center' valign='middle' BGCOLOR='#a5daf9'><font SIZE='-2' FACE='Verdana'><A HREF='".$http_admin."/client_management.php?sid=".trim($sid)."'
		style='color:000000;'>Create New Account</A></font></td>
	</tr>
</table>
<table width='530' border='0' cellspacing='0' cellpadding='0'>
	<tr>
	  <td width='100%'><img src='".$http_images."/space.gif' width='1' height='10' ALIGN='bottom' border='0' naturalsizeflag='0'></td> 
	</tr>
</table>
	");
?>