<?PHP
function utime (){
$time = explode( " ", microtime());
$usec = (double)$time[0];
$sec = (double)$time[1];
return $sec + $usec;
}
$start = utime(); 

// build query
$query="select ";
$query.="first_name, ";
$query.="username ";
$query.="from user where sid='".addslashes(trim($sid))."'";

// execute query
$rs=mysql_fetch_row(mysql_query($query));

// define variables
$xifirst_name=stripslashes($rs[0]);
$xiusername=stripslashes($rs[1]);

echo("
<HTML>
<HEAD>
  <TITLE>:&lt;&gt;: WHM AutoPilot :&lt;&gt;: Web Host Client Management System - Nulled by VST</TITLE>
<style>
 td{ font-family:tahoma,Tahoma; font-size:8pt; } 
</style>
<style>
	 body, td, center, p {font-family:tahoma, arial, helvetica; font-size: 11px; color: #000000} div {font-family:tahoma, arial, helvetica; font-size: 11px} A:link { text-decoration: underline: none; none; color:#000000;} A:visited { text-decoration: underline: none; none; color:#000000;} A:hover { text-decoration: underline; font-weight: none;color:#990000;} .linkTable { PADDING-LEFT: 5px } 
	</style>
<script type=\"text/javascript\" language=\"JavaScript1.2\" src=\"".$http_web."/inc/stm31.js\"></script>
<SCRIPT language='JavaScript' src='".$http_web."/inc/overlib.js'></SCRIPT>
<DIV id=overDiv style='Z-INDEX: 1000; VISIBILITY: hidden; POSITION: absolute'></DIV>
	
<SCRIPT LANGUAGE=\"JavaScript\">
<!-- Begin
function NewWindow(mypage, myname, w, h, scroll) {
var winl = (screen.width - w) / 2;
var wint = (screen.height - h) / 2;
winprops = 'height='+h+',width='+w+',top='+wint+',left='+winl+',scrollbars='+scroll+',resizable'
win = window.open(mypage, myname, winprops)
if (parseInt(navigator.appVersion) >= 4) { win.window.focus(); }
}
//  End -->
</script>
</HEAD>
<BODY BGCOLOR='#ffffff' leftMargin='0' topMargin='0' bottomMargin='0'
rightMargin='0' MARGINWIDTH='0' MARGINHEIGHT='0'>

<TABLE WIDTH='100%' BORDER='0' CELLSPACING='0'
CELLPADDING='0'>
  <TR>
    <TD WIDTH='100%' BACKGROUND='".$http_images."/newnav2_tableback.jpg'>
	<TABLE WIDTH='780' BORDER='0' CELLPADDING='0' CELLSPACING='0'>
        <TR>
          <TD><IMG SRC='".$http_images."/newnav2_01.jpg' WIDTH='7' HEIGHT='40' NATURALSIZEFLAG='0'
            ALIGN='BOTTOM'><IMG SRC='".$http_images."/newnav2_02.jpg' WIDTH='71' HEIGHT='40' NATURALSIZEFLAG='0' ALIGN='BOTTOM'><IMG SRC='".$http_images."/newnav2_03.jpg' WIDTH='72' HEIGHT='40' NATURALSIZEFLAG='0' ALIGN='BOTTOM'><IMG SRC='".$http_images."/newnav2_04.jpg' WIDTH='72' HEIGHT='40' NATURALSIZEFLAG='0' ALIGN='BOTTOM'><IMG SRC='".$http_images."/newnav2_05.jpg' WIDTH='90' HEIGHT='40' NATURALSIZEFLAG='0' ALIGN='BOTTOM'><IMG SRC='".$http_images."/newnav2_06.jpg' WIDTH='79' HEIGHT='40' NATURALSIZEFLAG='0' ALIGN='BOTTOM'><IMG SRC='".$http_images."/newnav2_07.jpg' WIDTH='60' HEIGHT='40' NATURALSIZEFLAG='0' ALIGN='BOTTOM'><IMG SRC='".$http_images."/newnav2_08.jpg' WIDTH='75' HEIGHT='40' NATURALSIZEFLAG='0' ALIGN='BOTTOM'><IMG SRC='".$http_images."/newnav2_09.jpg' WIDTH='205' HEIGHT='40' NATURALSIZEFLAG='0' ALIGN='BOTTOM'><IMG SRC='".$http_images."/newnav2_10.jpg' WIDTH='41' HEIGHT='40' NATURALSIZEFLAG='0' ALIGN='BOTTOM'><IMG SRC='".$http_images."/newnav2_11.jpg' WIDTH='8' HEIGHT='40' NATURALSIZEFLAG='0' ALIGN='BOTTOM'></TD> 
        </TR>
		</table>");
?>
<TABLE WIDTH='780' BORDER='0' CELLPADDING='0' CELLSPACING='0'>
<TR>
  <TD><script type="text/javascript" language="JavaScript1.2">
<!--
beginSTM("yfatchr","static","0","0","none","false","false","310","20","0","250","","<?PHP echo $http_images; ?>/the_space.gif");
	
	beginSTMB("auto","0","0","horizontally","","0","0","0","0","#cccccc","","tiled","#000000","1","none","0","Normal","70","0","0","0","0","0","0","0","#ffffff","false","#ffffff","#ffffff","#ffffff","none");

	
	appendSTMI("false","<img border='0' src='<?PHP echo $http_images; ?>/newnav2_12.jpg'>","center","middle","","","130","19","5","normal","#ffffff","#cccccc","","0","-1","-1","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/the_space.gif","0","0","0","","","_self","Tahoma","9pt","#ffffff","normal","normal","none","Tahoma","9pt","#ffffff","normal","normal","none","0","solid","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/fade.gif","tiled","tiled");

	
	appendSTMI("false","<img border='0' src='<?PHP echo $http_images; ?>/newnav2_13.jpg'>","center","middle","","","130","19","5","normal","#ffffff","#cccccc","","0","-1","-1","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/the_space.gif","0","0","0","","","_self","Tahoma","9pt","#ffffff","normal","normal","none","Tahoma","9pt","#ffffff","normal","normal","none","0","solid","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/fade.gif","tiled","tiled");


		beginSTMB("auto","0","0","vertically","","0","0","0","1","#A5F34A","","tiled","#42A2DE","1","solid","0","Wipe down","25","8","0","0","0","0","0","0","#42A2DE","false","#42A2DE","#42A2DE","#42A2DE","none");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/server_config.php?sid=<?PHP echo $sid;?>'>Add New Server</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/server_edit.php?sid=<?PHP echo $sid;?>'>Manage All Servers</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/server_position.php?sid=<?PHP echo $sid;?>'>Server Rotation Setup</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/csv.php?sid=<?PHP echo $sid;?>'>Account Import Tools</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","","left","middle","","","11","11","0","normal","#42A2DE","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","9pt","#42A2DE","normal","normal","none","Tahoma","9pt","#42A2DE","normal","normal","none","0","none","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		endSTMB();

	appendSTMI("false","<a href='<?PHP echo $http_admin; ?>/payment_process.php?sid=<?PHP echo $sid; ?>'><img border='0' src='<?PHP echo $http_images; ?>/newnav2_14.jpg'></a>","center","middle","","","130","19","5","normal","#ffffff","#cccccc","","0","-1","-1","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/the_space.gif","0","0","0","","","_self","Tahoma","9pt","#ffffff","normal","normal","none","Tahoma","9pt","#ffffff","normal","normal","none","0","solid","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/fade.gif","tiled","tiled");

	appendSTMI("false","<img border='0' src='<?PHP echo $http_images; ?>/newnav2_15.jpg'>","center","middle","","","130","19","5","normal","#ffffff","#cccccc","","0","-1","-1","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/the_space.gif","0","0","0","","","_self","Tahoma","9pt","#ffffff","normal","normal","none","Tahoma","9pt","#ffffff","normal","normal","none","0","solid","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/fade.gif","tiled","tiled");


		beginSTMB("auto","3","0","vertically","","0","0","0","1","#A5F34A","","tiled","#42A2DE","1","solid","0","Wipe down","25","8","0","0","0","0","0","0","#42A2DE","false","#42A2DE","#42A2DE","#42A2DE","none");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/client_management.php?sid=<?PHP echo $sid;?>'>Add New Account</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/client_view_edit.php?sid=<?PHP echo $sid;?>&status=99'>View All Accounts</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/client_view_edit.php?sid=<?PHP echo $sid;?>&status=0'>View Pending Accounts</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/client_view_edit.php?sid=<?PHP echo $sid;?>&status=1'>View Active Accounts</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/client_view_edit.php?sid=<?PHP echo $sid;?>&status=2'>View Suspended Accounts</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/client_view_edit.php?sid=<?PHP echo $sid;?>&status=5'>View Cancelled Accounts</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/client_view_edit.php?sid=<?PHP echo $sid;?>&status=4'>View Pending Cancels</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/client_cancel_account.php?sid=<?PHP echo $sid;?>'>View Cancel Requests</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","","left","middle","","","11","11","0","normal","#42A2DE","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","9pt","#42A2DE","normal","normal","none","Tahoma","9pt","#42A2DE","normal","normal","none","0","none","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		endSTMB();

	appendSTMI("false","<img border='0' src='<?PHP echo $http_images; ?>/newnav2_16.jpg'>","center","middle","","","130","19","5","normal","#ffffff","#cccccc","","0","-1","-1","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/the_space.gif","0","0","0","","","_self","Tahoma","9pt","#ffffff","normal","normal","none","Tahoma","9pt","#ffffff","normal","normal","none","0","solid","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/fade.gif","tiled","tiled");

		beginSTMB("auto","3","0","vertically","","0","0","0","1","#A5F34A","","tiled","#42A2DE","1","solid","0","Wipe down","25","8","0","0","0","0","0","0","#42A2DE","false","#42A2DE","#42A2DE","#42A2DE","none");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/plan_build.php?sid=<?PHP echo $sid;?>'>Add Shared Package</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/plan_build_dedicated.php?sid=<?PHP echo $sid;?>'>Add Dedicated Package</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/plan_edit.php?sid=<?PHP echo $sid;?>'>Package Editor</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/group_editor.php?sid=<?PHP echo $sid;?>'>Package Group Editor</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","","left","middle","","","11","11","0","normal","#42A2DE","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","9pt","#42A2DE","normal","normal","none","Tahoma","9pt","#42A2DE","normal","normal","none","0","none","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/reseller_profile.php?sid=<?PHP echo $sid;?>'>Add Reseller Profile</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/reseller_profile_edit.php?sid=<?PHP echo $sid;?>'>Edit Reseller Profile</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","","left","middle","","","11","11","0","normal","#42A2DE","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","9pt","#42A2DE","normal","normal","none","Tahoma","9pt","#42A2DE","normal","normal","none","0","none","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/addon_build.php?sid=<?PHP echo $sid;?>'>Add New Addon</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/addon_edit.php?sid=<?PHP echo $sid;?>'>Addon Editor</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/addon_group_editor.php?sid=<?PHP echo $sid;?>'>Addon Group Editor</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","","left","middle","","","11","11","0","normal","#42A2DE","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","9pt","#42A2DE","normal","normal","none","Tahoma","9pt","#42A2DE","normal","normal","none","0","none","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/coupon_build.php?sid=<?PHP echo $sid;?>'>Add New Coupon</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/coupon_edit.php?sid=<?PHP echo $sid;?>'>Coupon Editor</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","","left","middle","","","11","11","0","normal","#42A2DE","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","9pt","#42A2DE","normal","normal","none","Tahoma","9pt","#42A2DE","normal","normal","none","0","none","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/domain_specs.php?sid=<?PHP echo $sid;?>'>Domain Pricing</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","","left","middle","","","11","11","0","normal","#42A2DE","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","9pt","#42A2DE","normal","normal","none","Tahoma","9pt","#42A2DE","normal","normal","none","0","none","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		endSTMB();

	appendSTMI("false","<img border='0' src='<?PHP echo $http_images; ?>/newnav2_17.jpg'>","center","middle","","","130","19","5","normal","#ffffff","#cccccc","","0","-1","-1","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/the_space.gif","0","0","0","","","_self","Tahoma","9pt","#ffffff","normal","normal","none","Tahoma","9pt","#ffffff","normal","normal","none","0","solid","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/fade.gif","tiled","tiled");

		beginSTMB("auto","3","0","vertically","","0","0","0","1","#A5F34A","","tiled","#42A2DE","1","solid","0","Wipe down","25","8","0","0","0","0","0","0","#42A2DE","false","#42A2DE","#42A2DE","#42A2DE","none");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/affiliate_accounting.php?sid=<?PHP echo $sid;?>'>Affiliate Accounting</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/affiliate_details.php?sid=<?PHP echo $sid;?>'>View Affiliate Details</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/affiliate_plan_edit.php?sid=<?PHP echo $sid;?>'>Affiliate Plan Editor</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/affiliate_approve.php?sid=<?PHP echo $sid;?>'>Affiliate User Requests</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","","left","middle","","","11","11","0","normal","#42A2DE","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","9pt","#42A2DE","normal","normal","none","Tahoma","9pt","#42A2DE","normal","normal","none","0","none","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		endSTMB();

	appendSTMI("false","<img border='0' src='<?PHP echo $http_images; ?>/newnav2_18.jpg'>","center","middle","","","130","19","5","normal","#ffffff","#cccccc","","0","-1","-1","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/the_space.gif","0","0","0","","","_self","Tahoma","9pt","#ffffff","normal","normal","none","Tahoma","9pt","#ffffff","normal","normal","none","0","solid","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/fade.gif","tiled","tiled");

		beginSTMB("auto","3","0","vertically","","0","0","0","1","#A5F34A","","tiled","#42A2DE","1","solid","0","Wipe down","25","8","0","0","0","0","0","0","#42A2DE","false","#42A2DE","#42A2DE","#42A2DE","none");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/reports_weekly_sales.php?sid=<?PHP echo $sid;?>'>Weekly Sales Report</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/reports_monthly_revenue.php?sid=<?PHP echo $sid;?>'>Recurring Revenue per Server</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/reports_new_signups.php?sid=<?PHP echo $sid;?>'>Monthly New Signups</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/reports_daily_invoice.php?sid=<?PHP echo $sid;?>'>Daily Invoice Report</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","<a href='<?PHP echo $http_admin;?>/reports_daily_invoice_service.php?sid=<?PHP echo $sid;?>'>Daily Service Invoice Report</a>","left","middle","","","11","11","0","normal","#F7F7F7","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","-2pt","#ffffff","normal","normal","none","Tahoma","-2pt","#ffffff","normal","normal","none","0","none","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","#cccc00","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		appendSTMI("false","","left","middle","","","11","11","0","normal","#42A2DE","transparent","","0","-1","-1","<?PHP echo $http_images; ?>/space.gif","<?PHP echo $http_images; ?>/space.gif","8","0","0","","","_self","Tahoma","9pt","#42A2DE","normal","normal","none","Tahoma","9pt","#42A2DE","normal","normal","none","0","none","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","#42A2DE","","<?PHP echo $http_images; ?>/space.gif","","tiled","tiled");

		endSTMB();

	appendSTMI("false","<a href='<?PHP echo $http_admin."/invoice.php?sid=".$sid; ?>'><img border='0' src='<?PHP echo $http_images; ?>/newnav2_19.jpg'></a>","center","middle","","","130","19","5","normal","#ffffff","#cccccc","","0","-1","-1","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/the_space.gif","0","0","0","","","_self","Tahoma","9pt","#ffffff","normal","normal","none","Tahoma","9pt","#ffffff","normal","normal","none","0","solid","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/fade.gif","tiled","tiled");


	appendSTMI("false","<img border='0' src='<?PHP echo $http_images; ?>/newnav2_20.jpg'>","center","middle","","","130","19","5","normal","#ffffff","#cccccc","","0","-1","-1","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/the_space.gif","0","0","0","","","_self","Tahoma","9pt","#ffffff","normal","normal","none","Tahoma","9pt","#ffffff","normal","normal","none","0","solid","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/fade.gif","tiled","tiled");

	appendSTMI("false","<a href='<?PHP echo $http_admin; ?>/index2.php?sid=<?PHP echo $sid; ?>'><img border='0' src='<?PHP echo $http_images; ?>/newnav2_21.jpg'></a>","center","middle","","","130","19","5","normal","#ffffff","#cccccc","","0","-1","-1","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/the_space.gif","0","0","0","","","_self","Tahoma","9pt","#ffffff","normal","normal","none","Tahoma","9pt","#ffffff","normal","normal","none","0","solid","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","#ffffff","","<?PHP echo $http_images; ?>/the_space.gif","<?PHP echo $http_images; ?>/fade.gif","tiled","tiled");


endSTM();
//-->
</script></TD> 
        </TR>
	</table>	
<?PHP
echo("
	<TABLE WIDTH='780' BORDER='0' CELLPADDING='0' CELLSPACING='0'>
        <TR>
          <TD><IMG SRC='".$http_images."/newnav2_23.jpg' WIDTH='7' HEIGHT='20' NATURALSIZEFLAG='0'
            ALIGN='BOTTOM'></TD> 
          <TD COLSPAN='7' BACKGROUND='".$http_images."/newnav2_bottom.jpg' WIDTH='519'
          HEIGHT='20'><B><FONT COLOR='#ffffff' SIZE='-2' FACE='Tahoma'>Logged
            in as:  ".trim($xiusername)."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;[<a href='".$http_admin."/logout.php?sid=".$sid."'><font color='#FFFFFF'>Logout</font></a>]&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Version ".$current_mib_version." - Nullified by VST</FONT></B></TD>
           
          <TD BACKGROUND='".$http_images."/newnav2_31.jpg' WIDTH='205' HEIGHT='20'>
            <P><CENTER><B><FONT COLOR='#ffffff' SIZE='-2' FACE='Tahoma'><SCRIPT language='JavaScript'><!--
			var dayNames = new Array('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
			var monthNames = new Array('January','February','March','April','May','June','July','August','September','October','November','December');
			// apparently there's a bug in netscape for y2k...
			var now = new Date();
			var IE4 = (document.all) ? true : false;
			var year = (IE4) ? now.getYear() : 1900 + now.getYear();
			document.write(dayNames[now.getDay()] + ', ' + monthNames[now.getMonth()] + ' ' + now.getDate() + ', ' + year);		
		//--></FONT></SCRIPT>&nbsp;&nbsp;&nbsp;</B></CENTER></TD>
          <TD><IMG SRC='".$http_images."/newnav2_32.jpg' WIDTH='41' HEIGHT='20' 
            NATURALSIZEFLAG='0' ALIGN='BOTTOM'></TD> 
          <TD><IMG SRC='".$http_images."/newnav2_33.jpg' WIDTH='8' HEIGHT='20' NATURALSIZEFLAG='0'
            ALIGN='BOTTOM'></TD> 
        </TR>
      </TABLE></TD>
  </TR>
</TABLE><BR>
");
?>