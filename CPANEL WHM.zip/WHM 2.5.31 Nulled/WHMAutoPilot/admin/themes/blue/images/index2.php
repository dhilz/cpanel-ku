<?PHP
if (!file_exists("../inc/var.php")) { header("Location: ../inc/install.php"); exit; }
include"../inc/var.php";
include "../inc/connect.php";

$error_display="";
//if (is_writable($server_inc)) { $stop=true; $error_display.="&nbsp;-&nbsp;Please chmod ".$server_inc." to 0755<br>"; }
if (!file_exists($below_public)) { $stop=true; $error_display.="&nbsp;-&nbsp;Please create the directory ".$below_public."<br>"; }
if (!is_writable($below_public)) { $stop=true; $error_display.="&nbsp;-&nbsp;Please chmod ".$below_public." to 0777<br>"; }
if (!file_exists($server_backup)) { $stop=true; $error_display.="&nbsp;-&nbsp;Please create the directory ".$server_backup."<br>"; }
if (!is_writable($server_backup)) { $stop=true; $error_display.="&nbsp;-&nbsp;Please chmod ".$server_backup." to 0777<br>"; }
if (!file_exists($resolver_log)) { $stop=true; $error_display.="&nbsp;-&nbsp;Please create the directory ".$resolver_log."<br>"; }
if (!is_writable($resolver_log)) { $stop=true; $error_display.="&nbsp;-&nbsp;Please chmod ".$resolver_log." to 0777<br>"; }

if (isset($stop)) 
	{
	echo "<font color='#990000'><b>The system detected the following errors:</b></font><br><br>";
	echo $error_display;
	echo "<br><br>Please <a href='".$http_admin."/index2.php?sid=".$sid."'><b>click here</b></a> to continue once the changes have been made.";
	die;
	}

include "../inc/whm_functions.php";
include "../inc/client_functions.php";

if (isset($define_admin)) {	include $server_admin_tools."/define_admin_check.php";	}

include "../inc/login_functions.php";

if (isset($submit_resolve)) { header("Location: ".$http_admin."/resolver.php?sid=".trim($sid)."&xoid=".trim($xoid)."");	}

// CALLS FOR THIS PAGE

// total active accounts
$ct0=mysql_fetch_row(mysql_query("select count(*) from hosting_order where reseller='0' and status='1'"));
$total_active_accounts=$ct0[0];

// total active reseller accounts
$active_resellers=mysql_fetch_row(mysql_query("select count(*) from hosting_order where reseller='1' and status='1'"));
$total_active_resellers=$active_resellers[0];

// total active resold accounts
$active_resold=mysql_fetch_row(mysql_query("select count(*) from hosting_order, user where hosting_order.reseller='1' and hosting_order.status='1' and user.reseller_primary_domain!=hosting_order.oid and hosting_order.uid=user.uid order by user.uid asc"));
$total_active_resold_accounts=$active_resold[0];

/*
$active_resold=mysql_fetch_row(mysql_query("select count(*) from hosting_order where reseller='1' and status='1'"));
# echo $total_active_resold_accounts=$active_resold[0]; die("<--- total_active_resold_accounts"); 
$total_active_resold_accounts=$active_resold[0];

if ($total_active_resellers==$total_active_resold_accounts) { $total_active_resold_accounts=0; }
else if ($total_active_resellers>$total_active_resold_accounts) 
	{
	$total_active_resold_accounts=$total_active_resellers-$total_active_resold_accounts;
	}
else { $total_active_resold_accounts=$total_active_resold_accounts-$total_active_resellers; }

# if ($ct0x[0]>=$ct0y[0]) { $total_active_resold_accounts=$ct0y[0]; }
# else { $total_active_resold_accounts=($ct0y[0]-$ct0x[0]); }
*/

$dc="select ";
$dc.="count(hosting_order.oid) ";
$dc.="from hosting_order, plan_specs ";
$dc.="where ";
$dc.="hosting_order.status='1' ";
$dc.="and ";
$dc.="hosting_order.pid=plan_specs.pid ";
$dc.="and ";
$dc.="plan_specs.dedicated='1' ";
$dc.="order by hosting_order.oid asc";

$dct=mysql_fetch_row(mysql_query($dc));

// total servers in db
$ct1=mysql_fetch_row(mysql_query("select count(*) from server_config"));
$total_servers=$ct1[0];

// total unresolved domains
$ct2=mysql_fetch_row(mysql_query("select count(*) from hosting_order, plan_specs where hosting_order.pid=plan_specs.pid and hosting_order.resolved='0' and hosting_order.status='1' and plan_specs.dedicated='0'"));
$total_unresolved=$ct2[0];

// total pending accounts
$ct3=mysql_fetch_row(mysql_query("select count(*) from hosting_order where status='0'"));
$total_pending=$ct3[0];

if ($total_pending<=0)
	{
	$pending_list=("
		<tr>
			<td colspan='2' BGCOLOR='#dbedf9'><img src='".$http_images."/drop_arrow.gif'><b>No pending orders in the database.</b></td>
		</tr>
		");
	}
else
	{
	$pending_list=("
		<tr>
			<td align='center' valign='middle' BGCOLOR='#asdaf9'><B><FONT COLOR='#3f3f3f' SIZE='-2' FACE='Verdana'>View</FONT></B></td>
			<td align='left' valign='middle' BGCOLOR='#asdaf9'><B><FONT COLOR='#3f3f3f' SIZE='-2' FACE='Verdana'>Client</FONT></B></td>
			<td align='left' valign='middle' BGCOLOR='#asdaf9'><B><FONT COLOR='#3f3f3f' SIZE='-2' FACE='Verdana'>Domain</FONT></B></td>
			<td align='center' valign='middle' BGCOLOR='#asdaf9'><B><FONT COLOR='#3f3f3f' SIZE='-2' FACE='Verdana'>Order Date</FONT></B></td>
		</tr>
		");
	$xq="select ";
	$xq.="user.first_name, ";							// 0
	$xq.="user.last_name, ";							// 1
	$xq.="user.email, ";								// 2
	$xq.="hosting_order.domain_name, ";					// 3
	# $xq.="UNIX_TIMESTAMP(hosting_order.ogcreate), ";	// 4
	$xq.="hosting_order.ogcreate, ";	// 4
	$xq.="hosting_order.oid, ";							// 5
	$xq.="plan_specs.dedicated, ";						// 6
	$xq.="hosting_order.payment_method, ";				// 7
	$xq.="hosting_order.reseller, ";					// 8
	$xq.="hosting_order.server_hostname ";				// 9
	$xq.="from ";
	$xq.="user, hosting_order, plan_specs ";
	$xq.="where ";
	$xq.="hosting_order.status='0' ";
	$xq.="and ";
	$xq.="user.uid=hosting_order.uid ";
	$xq.="and ";
	$xq.="hosting_order.pid=plan_specs.pid ";
	$xq.="order by user.uid asc";

	$row4=mysql_query($xq);
	while ($rs4=mysql_fetch_row($row4))
		{
		// build a list of pending accounts
		
		$pending_list.=("
			<tr>
				<td align='center' valign='middle' BGCOLOR='#dbedf9'><A HREF='".$http_admin."/client_view.php?oid=".trim($rs4[5])."&status=0&sid=".trim($sid)."'><img border='0' src='".$http_images."/icon_view.gif'></A></td>
				<td align='left' valign='middle' BGCOLOR='#dbedf9'><a href='mailto:".$rs4[2]."'>".$rs4[0]." ".$rs4[1]."</a></td>
				<td align='left' valign='middle' BGCOLOR='#dbedf9'>
				<table width='100%' cellpadding='0' cellspacing='0' border='0'>
					<tr>
						<td width='1%' align='left' valign='middle'>");
		if ($rs4[6]==1||$rs4[7]==6||$rs4[8]==1) { $resolved_details.="&nbsp;&nbsp;"; }
		if ($rs4[6]==1) { $pending_list.="<img src='".$http_images."/dedicated.gif' alt='Dedicated Server'>&nbsp;"; }
		if ($rs4[7]==6) { $pending_list.="<img src='".$http_images."/mailinpayment.gif' alt='Mail in Payment'>&nbsp;"; }
		if ($rs4[7]==1) { $pending_list.="<img src='".$http_images."/paypal_gif.gif' alt='PayPal'>&nbsp;"; }
		if ($rs4[7]==3) { $pending_list.="<img src='".$http_images."/paysystems_gif.gif' alt='PaySystems'>&nbsp;"; }
		if ($rs4[7]==9) { $pending_list.="<img src='".$http_images."/internetsecure_gif.gif' alt='Internet Secure'>&nbsp;"; }
		if ($rs4[7]==8) { $pending_list.="<img src='".$http_images."/auth_gif.gif' alt='Authorize.net'>&nbsp;"; }
		if ($rs4[7]==2) { $pending_list.="<img src='".$http_images."/wp_gif.gif' alt='WorldPay'>&nbsp;"; }
		if ($rs4[7]==4) { $pending_list.="<img src='".$http_images."/2co_gif.gif' alt='2Checkout'>&nbsp;"; }
		if ($rs4[7]==10) { $pending_list.="<img src='".$http_images."/lpoint_gif.gif' alt='LinkPoint'>&nbsp;"; }
		if ($rs4[7]==11) { $pending_list.="<img src='".$http_images."/psigate_gif.gif' alt='PSiGate'>&nbsp;"; }
		if ($rs4[7]==12) { $pending_list.="<img src='".$http_images."/paypal_gif.gif' alt='PayPal Alternate'>&nbsp;"; }
		if ($rs4[7]==13) { $pending_list.="<img src='".$http_images."/wp_gif.gif' alt='WorldPay Alternate'>&nbsp;"; }
		if ($rs4[7]==15) { $pending_list.="<img src='".$http_images."/offlinecc_gif.gif' alt='Offline Credit Card'>&nbsp;"; }
		if ($rs4[7]==14) { $pending_list.="<img src='".$http_images."/cybersource_gif.gif' alt='CyberSource HOP'>&nbsp;"; }
		if ($rs4[8]==1) { $pending_list.="<img src='".$http_images."/reseller.gif' alt='Reseller'>&nbsp;"; }
		unset($bit);
		$pending_list.=("</td>
						<td width='99%' align='left' valign='middle'><B>[<a href='http://".(($rs4[6]==1)?"".$rs4[6].".":"")."".$rs4[3]."' target='_blank'>http://".(($rs4[6]==1)?"".$rs4[9].".":"")."".$rs4[3]."</a>]</B></td>
					</tr>
				</table>
				</td>
				<td align='center' valign='middle' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Verdana'>".date("m/d/Y", $rs4[4])."</FONT></td>
			</tr>
			");
		}
	}

// get active server
$current_server=current_server_internal();
if ($current_server==99)
	{
	$current_server_name="Undefined";
	$current_server_name_main="No active server defined";
	}
else
	{
	$rs0=mysql_fetch_row(mysql_query("select server_name, server_ip from server_config where whm_id='".addslashes(trim($current_server))."'"));
	$current_server_name=$rs0[0];
	$current_server_name_main="Stats for ".$current_server_name." (".$current_server.")";
	$server_ip=$rs0[1];
	}

// total Monthly income
$rs1=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1'"));
$total_monthly_income=sprintf("%01.2f", $rs1[0]);

$row2=mysql_query("select payment_term, total_due_reoccur from hosting_order where status='1' order by payment_term asc");
while ($rs2=mysql_fetch_row($row2))
	{
	if (strtolower(trim($rs2[0]))=="monthly")
		{
		@$pmonthly+=$rs2[1];
		@$pmonthly_ct+=1;
		}
	else if (strtolower(trim($rs2[0]))=="quarterly")
		{
		@$pquarterly+=$rs2[1];
		@$pquarterly_ct+=1;
		}
	else if (strtolower(trim(str_replace("-", "_", $rs2[0])))=="semi_annual")
		{
		@$psemi_annual+=$rs2[1];
		@$psemi_annual_ct+=1;
		}
	else if (strtolower(trim($rs2[0]))=="annual")
		{
		@$pannual+=$rs2[1];
		@$pannual_ct+=1;
		}
	}

$tall=$pmonthly_ct+$pquarterly_ct+$psemi_annual_ct+$pannual_ct;
# $tallcash=$currency.sprintf("%01.2f", $pmonthly+$pquarterly+$psemi_annual+$pannual).$currency_type;
# bug fix: 0000277 1/16/2004
$tallcash=$currency.sprintf("%01.2f", ($pmonthly*12)+($pquarterly*4)+($psemi_annual*2)+$pannual)." ".$currency_type;
$payment_type_amount="<table width='100%' cellspacing='0' cellpadding='2' border='0'>";
$payment_type_amount.=("	
						<tr>
							<td>30-Day Records:</td>
							<td>".$pmonthly_ct."</td>
							<td>(".$currency."".sprintf("%01.2f", $pmonthly)."".$currency_type.")</td>
						</tr>
						");
$payment_type_amount.=("	
						<tr>
							<td>90-Day Records:</td>
							<td>".$pquarterly_ct."</td>
							<td>(".$currency."".sprintf("%01.2f", $pquarterly)."".$currency_type.")</td>
						</tr>
						");
$payment_type_amount.=("	
						<tr>
							<td>180-Day Records:</td>
							<td>".$psemi_annual_ct."</td>
							<td>(".$currency."".sprintf("%01.2f", $psemi_annual)."".$currency_type.")</td>
						</tr>
						");
$payment_type_amount.=("	
						<tr>
							<td>360-Day Records:</td>
							<td>".$pannual_ct."</td>
							<td>(".$currency."".sprintf("%01.2f", $pannual)."".$currency_type.")</td>
						</tr>
						");
$payment_type_amount.=("	
						<tr>
							<td><b>Total Records:</b><BR><div style='font-size:9px'>Est. Annual Income</td>
							<td><b>".$tall."</b></td>
							<td><b>(".$tallcash.")</b></td>
						</tr>
						");
$payment_type_amount.="</table>";


if ($current_server!=99&&$activate_serverstats=="yes")
	{
	// read in logins
	$temp=@read_log($current_server, $below_public);
	list($xwhm_username, $xwhm_password)=split("[|]", $temp);

	// get bandwidth usage
	$total_bandwidth_mb=show_bandwidth_usage($server_ip, $xwhm_username, $xwhm_password);
	$total_bandwidth_mb=sprintf("%01.4f", $total_bandwidth_mb/1000);

	// get cpanel/whm versions
	$parse_versions=show_cpanel_version($server_ip, $xwhm_username, $xwhm_password);
	list($whm_version, $cpanel_version)=split("[|]", $parse_versions);
	$current_version="<center><B>If Load is high - values may not show</b>";

	// get server status - apache, bind, server load
	$server_status=show_server_status($server_ip, $xwhm_username, $xwhm_password);
	list($xapache, $xbind, $xserver_load)=split("[|]", $server_status);
	list($apache, $apache_status)=split("[�]", $xapache);
	if ($apache_status==1) { $xapache_status="red_block.gif"; } else { $xapache_status="green_block.gif"; }

	list($bind, $bind_status)=split("[�]", $xbind);
	if ($bind_status==1) { $xbind_status="red_block.gif"; } else { $xbind_status="green_block.gif"; }

	list($server_load, $server_load_status)=split("[�]", $xserver_load);
	if ($server_load_status==1) { $xserver_load_status="red_block.gif"; } else { $xserver_load_status="green_block.gif"; }

	// get total active accounts on the server
	$total_active_on_server=list_accounts($server_ip, $xwhm_username, $xwhm_password, 1);
	}

// Build the trouble ticket block

// total active tickets
$ct4=mysql_fetch_row(mysql_query("select count(*) from ticket where status='0'"));
$open_trouble_tickets=$ct4[0];

if ($open_trouble_tickets<=0)
	{
	$active_ticket_details=("
		<tr>
			<td colspan='3' bGCOLOR='#dbedf9'><img src='".$http_images."/drop_arrow.gif'><b>No Pending Trouble Tickets found.</b></td>
		</tr>
		");
	}
else
	{
	$active_ticket_details=("
		<tr>
			<td width='15%' align='center' valign='middle' bGCOLOR='#asdaf9'><b><font COLOR='#3f3f3f' SIZE='-2' face='Verdana'>Ticket
			#</font></b></td>
			<td width='60%' align='left' valign='middle' bGCOLOR='#asdaf9'><b><font COLOR='#3f3f3f' SIZE='-2'
			face='Verdana'>Client Username </font></b></td> 
			<td width='25%' align='center' valign='middle' bGCOLOR='#asdaf9'><b><font COLOR='#3f3f3f' SIZE='-2' face='Verdana'>Date Opened</font></b></td>
		</tr>
		");
	// get the active ticket details
	# $row4=mysql_query("select user.first_name, user.last_name, user.email, ticket.id, UNIX_TIMESTAMP(ticket.ogcreate) from user, ticket where user.uid=ticket.uid and ticket.status='0' order by user.uid asc");
	$row4=mysql_query("select user.first_name, user.last_name, user.email, ticket.id, ticket.ogcreate from user, ticket where user.uid=ticket.uid and ticket.status='0' order by user.uid asc");
	while ($rs4=mysql_fetch_row($row4))
		{
		$active_ticket_details.=("
			<tr>
				<td width='15%' align='center' valign='middle' bGCOLOR='#dbedf9'><b><font SIZE='-2' face='Verdana'>".stripslashes($rs4[3])."</font></b></td>
				<td width='60%' align='left' valign='middle' bGCOLOR='#dbedf9'>
				<table width='100%' cellpadding='0' cellspacing='0' border='0'>
					<tr>
						<td width='10%' align='center' valign='middle'><a href='".$http_admin."/trouble_ticket_active.php?sid=".trim($sid)."&id=".trim($rs4[3])."'><img border='0' src='".$http_images."/icon_view.gif'></a></td>
						<td width='90%' align='left' valign='middle'><a href='mailto:".stripslashes($rs4[2])."'><font SIZE='-2' face='Verdana'>".stripslashes($rs4[0])." ".stripslashes($rs4[1])."</font></A></td>
					</tr>
				</table>
				</td> 
				<td width='25%' align='center' valign='middle' bGCOLOR='#dbedf9'><font SIZE='-2' face='Verdana'>".date("m/d/Y", $rs4[4])."</font></td>
			</tr>
			");
		$ctx++;
		}
	}

// build the resolver block
# $ct5=mysql_fetch_row(mysql_query("select count(*) from hosting_order where resolved='0'"));
$ct5=mysql_fetch_row(mysql_query("select count(hosting_order.oid) from hosting_order, plan_specs where hosting_order.pid=plan_specs.pid and hosting_order.resolved='0' and plan_specs.dedicated='0' and hosting_order.status='1' "));
$unresolved_total_count=$ct5[0];

if ($unresolved_total_count<=0)
	{
	$resolved_details=("
			<tr>
				<td colspan='4' BGCOLOR='#dbedf9'><img src='".$http_images."/drop_arrow.gif'><b>No unresolved accounts found.</b></FONT></td>
			</tr>
			");
	}
else
	{
	$resolved_details=("
		<tr>
			<td align='center' valign='middle' BGCOLOR='#asdaf9'><B><FONT COLOR='#000000' SIZE='-2' FACE='Verdana'>View</FONT></B></td>
			<td align='left' valign='middle' BGCOLOR='#asdaf9'><B><FONT COLOR='#000000' SIZE='-2' FACE='Verdana'>Client</FONT></B></td>
			<td align='left' valign='middle' BGCOLOR='#asdaf9'><B><FONT COLOR='#000000' SIZE='-2' FACE='Verdana'>Domain</FONT></B></td>
			<td align='center' valign='middle' BGCOLOR='#asdaf9'><B><FONT COLOR='#000000' SIZE='-2' FACE='Verdana'>Order Date</FONT></B></td>
		</tr>
		");
	$qy="select ";
	$qy.="user.first_name, ";							// 0
	$qy.="user.last_name, ";							// 1
	$qy.="user.email, ";								// 2
	$qy.="hosting_order.domain_name, ";					// 3
	# $qy.="UNIX_TIMESTAMP(hosting_order.ogcreate), ";	// 4
	$qy.="hosting_order.ogcreate, ";	// 4
	$qy.="hosting_order.oid, ";							// 5
	$qy.="plan_specs.dedicated, ";						// 6
	$qy.="hosting_order.payment_method, ";				// 7
	$qy.="hosting_order.reseller ";						// 8
	$qy.="from ";									
	$qy.="user, hosting_order, plan_specs ";
	$qy.="where ";
	$qy.="user.uid=hosting_order.uid ";
	$qy.="and ";
	$qy.="hosting_order.resolved='0' ";
	$qy.="and ";
	$qy.="plan_specs.dedicated='0' ";
	$qy.="and ";
	$qy.="hosting_order.pid=plan_specs.pid ";
	$qy.="and hosting_order.status='1' ";
	$qy.="order by hosting_order.ogcreate asc";

	$row5=mysql_query($qy);
	while ($rs5=mysql_fetch_row($row5))
		{
		$resolved_details.=("
			<tr>
				<td align='center' valign='middle' BGCOLOR='#dbedf9'><A HREF='".$http_admin."/client_view.php?oid=".trim($rs5[5])."&sid=".trim($sid)."'><img border='0' src='".$http_images."/icon_view.gif'></A></td>
				<td align='left' valign='middle' BGCOLOR='#dbedf9'><a href='mailto:".$rs5[2]."'>".$rs5[0]." ".$rs5[1]."</a></td>
				<td align='left' valign='middle' BGCOLOR='#dbedf9'>
				<table width='100%' cellpadding='0' cellspacing='0' border='0'>
					<tr>
						<td width='1%' align='left' valign='middle'>");
		if ($rs5[6]==1||$rs5[7]==6||$rs5[8]==1) { $resolved_details.="&nbsp;&nbsp;"; }
		if ($rs5[6]==1) { $resolved_details.="<img src='".$http_images."/dedicated.gif' alt='Dedicated Server'>&nbsp;"; }
		if ($rs5[7]==6) { $resolved_details.="<img src='".$http_images."/mailinpayment.gif' alt='Mail in Payment'>&nbsp;"; }
		if ($rs5[7]==1) { $resolved_details.="<img src='".$http_images."/paypal_gif.gif' alt='PayPal'>&nbsp;"; }
		if ($rs5[7]==3) { $resolved_details.="<img src='".$http_images."/paysystems_gif.gif' alt='PaySystems'>&nbsp;"; }
		if ($rs5[7]==9) { $resolved_details.="<img src='".$http_images."/internetsecure_gif.gif' alt='Internet Secure'>&nbsp;"; }
		if ($rs5[7]==8) { $resolved_details.="<img src='".$http_images."/auth_gif.gif' alt='Authorize.net'>&nbsp;"; }
		if ($rs5[7]==2) { $resolved_details.="<img src='".$http_images."/wp_gif.gif' alt='WorldPay'>&nbsp;"; }
		if ($rs5[7]==4) { $resolved_details.="<img src='".$http_images."/2co_gif.gif' alt='2Checkout'>&nbsp;"; }
		if ($rs5[7]==10) { $resolved_details.="<img src='".$http_images."/lpoint_gif.gif' alt='LinkPoint'>&nbsp;"; }
		if ($rs5[7]==11) { $resolved_details.="<img src='".$http_images."/psigate_gif.gif' alt='PSiGate'>&nbsp;"; }
		if ($rs5[7]==12) { $resolved_details.="<img src='".$http_images."/paypal_gif.gif' alt='PayPal Alternate'>&nbsp;"; }
		if ($rs5[7]==13) { $resolved_details.="<img src='".$http_images."/wp_gif.gif' alt='WorldPay Alternate'>&nbsp;"; }
		if ($rs5[7]==15) { $resolved_details.="<img src='".$http_images."/offlinecc_gif.gif' alt='Offline Credit Card'>&nbsp;"; }
		if ($rs5[7]==14) { $resolved_details.="<img src='".$http_images."/cybersource_gif.gif' alt='CyberSource HOP'>&nbsp;"; }
		if ($rs5[8]==1) { $resolved_details.="<img src='".$http_images."/reseller.gif' alt='Reseller'>&nbsp;"; }
		unset($bit);
		$resolved_details.=("</td>
						<td width='99%' align='left' valign='middle'><B>[<a href='http://".$rs5[3]."' target='_blank'>http://".$rs5[3]."</a>]</B></td>
					</tr>
				</table>
				</td>
				<td align='center' valign='middle' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Verdana'>".date("m/d/Y", $rs5[4])."</FONT></td>
			</tr>
			");
		}
	}

/*
$xheader="x=x\n\n";
$ct_len=@strlen($xheader);
$fp=@fsockopen("www.benchmarkdesigns.net", 80, $errno, $errstr, 5);
if ($fp)
	{
	$header="\n";
	$header.="GET /mib_news.nfo HTTP/1.1\n";
	$header.="Host: benchmarkdesigns.net\n";
	$header.="Content-Length: ".$ct_len."\n";
	$header.="Content-Type: application/x-www-form-urlencoded\n";
	$header.="Connection: Close\n\n";
	$header.=$xheader;
	
	@fputs ($fp, $header);
	while (@!feof($fp)) { $data.=trim(@fgets($fp, 1024))."\n";	}
	@fclose ($fp);

	@list($junk0, $ret)=@split("{{}}", $data);

	$read0=@fopen($below_public."/mib_news_cache.nfo", "w");
	$result0=@fwrite($read0, $ret);
	@fclose($read0);

	@chmod($below_public."/mib_news_cache.nfo", 0777);
	}
*/

	
/*

if ($read)
	{
	$read0=@fopen($below_public."/mib_news_cache.nfo", "w");
	$result0=@fwrite($read0, $result);
	@fclose($read0);

	@chmod($below_public."/mib_news_cache.nfo", 0777);
	}
*/

include $server_admin_inc."/header.php";
echo("
	<table width='100%' cellpadding='0' cellspacing='0' border='0'>
		<tr>
			<td width='1%' align='left' valign='top'><img src='".$http_images."/space.gif' width='6' height='230'></td>
			<td width='1%' align='left' valign='top'>
	");
include $server_admin_inc."/main_glance_block.php";
include $server_admin_inc."/income_breakdown.php";
include $server_admin_inc."/main_news_block.php";
//include $server_admin_inc."/main_version_block.php";
echo("
			</td>
			<td width='1%' align='left' valign='top'><img src='".$http_images."/space.gif' width='6' height='1'></td>
			<td width='97%' align='left' valign='top'>
			<form action='".$PHP_SELF."' method='POST'>
		");
// include the main server block
include $server_admin_inc."/main_general_block.php";
if ($activate_serverstats!=no)
{
include $server_admin_inc."/main_server_block.php";
}
include $server_admin_inc."/main_user_block.php";
if ($activate_support!=no)
{
include $server_admin_inc."/main_trouble_ticket_block.php";
}
include $server_admin_inc."/main_resolver_block.php";
echo("
			</form>
			</td>
		</tr>
	</table>
	");

// End Main Process
mysql_close($dblink);
include $server_admin_inc."/footer.php";
?>