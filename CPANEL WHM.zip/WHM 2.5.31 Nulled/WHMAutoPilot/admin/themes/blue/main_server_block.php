<?PHP
echo("
<!--- END OG THEME BLOCK --->
<table width='530' border='0' cellspacing='0' cellpadding='0' bgcolor='40a3de' HEIGHT='25' height='17' style='border-top: solid; border-left: solid; border-right: solid; border-color: 53afe5; border-width: 1pxl'>
	<tr>
	  <td width='100%'><b><FONT COLOR='#FFFFFF' SIZE='-2' face='Verdana'>Current
		Active Server Status</FONT></b></td>
	</tr>
</table>
	");
if ($current_server==99)
	{
	echo("
		<table width='530' border='0' cellspacing='1' cellpadding='2' style='border-left: solid; border-right: solid; border-bottom: solid; border-color: #53afe5; border-width: 1pxl'>
			<tr>
			  <td align='left' valign='top' BGCOLOR='#dbedf9'><img src='".$http_images."/drop_arrow.gif'><b>No active servers defined.</b></td>
			</tr>
		</table>
		");
	}
else
	{
	@$usagedisplay=sprintf("%01.0f",(($total_active_on_server/$max_accounts)*100));
	$cleanusage=$usagedisplay;
	if($usagedisplay>100) {$usagedisplay="98";}
	if($usagedisplay<65)
	{ $gif="sa"; }
	else if($usagedisplay>65&&$usagedisplay<90)
	{ $gif="q"; }
	else if($usagedisplay>90)
	{ $gif="m"; }

	echo("
	<table width='530' border='0' cellspacing='1' cellpadding='2' style='border-left: solid; border-right: solid; border-bottom: solid; border-color: #53afe5; border-width: 1pxl'>
		<tr>
		  <td width='60%' bgcolor='#asdaf9'><b><FONT COLOR='#000000' SIZE='-2' face='Verdana'>".$current_server_name_main."</FONT></b></td>
		  <td width='40%' bgcolor='#asdaf9'><b><FONT COLOR='#000000' SIZE='-2' face='Verdana'>Server Status</FONT></b></td>
		</tr>
		<tr>
		  <td width='60%' bgcolor='#dbedf9'><font size='-2' face='Verdana'>Total Accounts on Server <b>[".$total_active_on_server."]</b></FONT></td> 
		  <td width='40%' bgcolor='#dbedf9' NOWRAP>
			<table width='100%' border='0' cellspacing='0' cellpadding='1'>
			  <tr>
				<td width='94%'><font size='-2' face='Verdana'>Server Load <b>[".$server_load."]</b></FONT></td> 
				<td width='6%'><img src='".$http_images."/".$xserver_load_status."' width='10' height='10' ALIGN='bottom' border='0' naturalsizeflag='0'></td>
			  </tr>
			</table>
			</td>
		</tr>
		<tr>
			<td width='60%' bgcolor='#dbedf9'><TABLE BORDER='0' CELLSPACING='1'
            CELLPADDING='1'>
              <TR>
                <TD WIDTH='100' ALIGN='RIGHT' BGCOLOR='#dbedf9'><img src='".$http_images."/drop_arrow.gif'><font size='-2' face='Verdana'>".$cleanusage."% Usage:</FONT></TD>
                <TD WIDTH='190' background='".$http_images."/usage.gif'><IMG SRC='".$http_images."/".$gif."1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='".$http_images."/".$gif."2.gif' WIDTH='$usagedisplay%' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$cleanusage%'><IMG SRC='".$http_images."/".$gif."3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD>
              </TR>
			</table></td> 
			<td width='40%' bgcolor='#dbedf9' NOWRAP>
			<table width='100%' border='0' cellspacing='0' cellpadding='1'>
			  <tr>
				<td width='94%'><font size='-2' face='Verdana'>".$apache." <b>[".(($apache_status==0)?"UP":"DOWN")."]</b></FONT></td> 
				<td width='6%'><img src='".$http_images."/".$xapache_status."' width='10' height='10' ALIGN='bottom' border='0' naturalsizeflag='0'></td>
			  </tr>
			</table>
			</td>
		</tr>
		<tr>
		  <td width='60%' bgcolor='#dbedf9'><font size='-2' face='Verdana'>".$current_version."</FONT></td> 
		  <td width='40%' NOWRAP bgcolor='#dbedf9'>
			<table width='100%' border='0' cellspacing='0' cellpadding='1'>
			  <tr>
				<td width='94%'><font size='-2' face='Verdana'>".$bind." <b>[".(($bind_status==0)?"UP":"DOWN")."]</b></FONT></td> 
				<td width='6%'><img src='".$http_images."/".$xbind_status."' width='10' height='10' ALIGN='bottom' border='0' naturalsizeflag='0'></td>
			  </tr>
			</table>
			</td>
		</tr>
	</table>
		");
	}
echo("
<table width='530' border='0' cellspacing='0' cellpadding='2' style='border-bottom: solid; border-left: solid; border-right: solid; border-color: 53afe5; border-width: 1pxl'>
	<tr>
	  <td width='25%' bgcolor='#a5daf9' align='left' valign='middle'><font size='-2' face='Verdana'><A HREF='".$http_admin."/server_config.php?sid=".trim($sid)."' style='color:000000;'>Add New Server</A></FONT></td>
	  <td width='50%' bgcolor='#a5daf9' align='center' valign='middle'><font size='-2' face='Verdana'><A HREF='".$http_admin."/server_edit.php?sid=".trim($sid)."' style='color:000000;'>Manage All Servers</A></FONT></td>
	  <td width='25%' bgcolor='#a5daf9' align='center' valign='middle'><font size='-2' face='Verdana'><A HREF='https://".$server_ip.":2087' target='_blank' style='color:000000;'>Open WHM</A></FONT></td>
	</tr>
</table>
<table width='530' border='0' cellspacing='0' cellpadding='0'>
	<tr>
	  <td width='100%'><img src='".$http_images."/space.gif' width='1' height='10' ALIGN='bottom' border='0' naturalsizeflag='0'></td> 
	</tr>
</table>
<!--- END OG THEME BLOCK --->
	");
?>