<?PHP
echo("
<!--- START SIDE BAR BLOCK --->
<table width='230' BORDER='0' CELLSPACING='0' CELLPADDING='0'>
	<tr>
		<td width='100%'><IMG SRC='".$http_images."/licenseinfo.jpg'
		width='230' HEIGHT='34' ALIGN='BOTTOM' BORDER='0' NATURALsizeFLAG='3'></td> 
	</tr>
	<tr>
		<td width='100%'>
		<table width='230' BORDER='0' CELLSPACING='0' CELLPADDING='0' style='border-bottom: solid; border-left: solid; border-right: solid; border-color: #53afe5; border-width: 1pxl'>
			<tr>
				<td width='100%' BGCOLOR='#dbedf9'>
				<table width='100%' BORDER='0' CELLSPACING='2' CELLPADDING='2'>
					<tr>
						<td width='225'><font size='-2' FACE='Verdana'>Current Script Version: <B>".$current_mib_version."</B></font></td> 
					</tr>
					<tr>
						<td width='225'><font size='-2' FACE='Verdana'>License Type: <B>".$current_mib_license_type."</B></font></td> 
					</tr>
					<tr>
						<td width='225'><font size='-2' FACE='Verdana'>License Number: <B>".$current_mib_license_number."</B></font></td> 
					</tr>
				</table>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
<table width='100%' cellpadding='0' cellspacing='0' border='0'>
	<tr>
		<td><img src='".$http_images."/space.gif' width='1' height='6'></td>
	</tr>
</table>
<!--- END SIDE BAR BLOCK --->
	");
?>