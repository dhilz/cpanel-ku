<?PHP
echo("
<TABLE WIDTH='780' BORDER='0' CELLSPACING='0' CELLPADDING='0'
bgcolor='40a3de' HEIGHT='17' style='border-top: solid; border-bottom: solid; border-right: solid; border-color: 53afe5; border-width: 1pxl'>
  <TR>
    <TD WIDTH='100%'>
	<TABLE WIDTH='100%' BORDER='0' CELLSPACING='0' CELLPADDING='2'>
        <TR>
          <TD WIDTH='50%'><B><FONT COLOR='#ffffff' SIZE='-2' FACE='Verdana'>
		  	");
$end = utime(); $run = $end - $start; echo "Page Load Time: " . substr($run, 0, 5) . " secs.";
echo("
</FONT></B></TD> 
          <TD WIDTH='50%' align='right'><B><FONT COLOR=\"#ffffff\" SIZE=\"-2\" FACE=\"Verdana\">� 2001-2005 <B>OPEN</b> Management Group, LLC. Nulled by VST</FONT></B></TD> 
        </TR>
      </TABLE>
	  </TD>
  </TR>
</TABLE>
</BODY>
</HTML>
	");
?>