<?PHP
echo("
<table width='230' BORDER='0' CELLSPACING='0' CELLPADDING='0'>
	<tr>
		<td width='100%'><IMG SRC='".$http_images."/gateways_header.jpg'
		width='230' HEIGHT='34' ALIGN='BOTTOM' BORDER='0' NATURALsizeFLAG='3'></td> 
	</tr>
	<tr>
		<td width='100%'>
		<table width='230' BORDER='0' CELLSPACING='0' CELLPADDING='0' style='border-bottom: solid; border-left: solid; border-right: solid; border-color: #53afe5; border-width: 1pxl'>
			<tr>
				<td width='100%' BGCOLOR='#dbedf9'>
				<table width='100%' BORDER='0' CELLSPACING='0' CELLPADDING='0'>
					<tr>
						<td width='230'>
						");
// PAYPAL CONFIGURATION 
$rs1=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='1' AND payment_term='monthly'"));
$total_monthly_income_paypal=sprintf("%01.2f", $rs1[0]);

$rs2=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='1' AND payment_term='quarterly'"));
$total_quarterly_income_paypal=sprintf("%01.2f", $rs2[0]);

$rs3=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='1' AND payment_term='semi-annual'"));
$total_semiannual_income_paypal=sprintf("%01.2f", $rs3[0]);

$rs4=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='1' AND payment_term='annual'"));
$total_annual_income_paypal=sprintf("%01.2f", $rs4[0]);

$rs44=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='1'"));
$total_annual_income_combined_paypal=sprintf("%01.2f", $rs44[0]);

$allcycles_paypal=($total_monthly_income_paypal*12)+($total_quarterly_income_paypal*4)+($total_semiannual_income_paypal*2)+$total_annual_income_paypal;
$allcycles_paypal=sprintf("%01.2f", $allcycles_paypal);

if($total_annual_income_combined_paypal>0)
	{
//lets try percentages
$permonth_paypal=($total_monthly_income_paypal/$total_annual_income_combined_paypal);
$permonth_paypal=sprintf("%01.2f", $permonth_paypal);
$permonth_paypal=($permonth_paypal*100);

$perquarter_paypal=($total_quarterly_income_paypal/$total_annual_income_combined_paypal);
$perquarter_paypal=sprintf("%01.2f", $perquarter_paypal);
$perquarter_paypal=($perquarter_paypal*100);

$persemi_paypal=($total_semiannual_income_paypal/$total_annual_income_combined_paypal);
$persemi_paypal=sprintf("%01.2f", $persemi_paypal);
$persemi_paypal=($persemi_paypal*100);

$perannual_paypal=($total_annual_income_paypal/$total_annual_income_combined_paypal);
$perannual_paypal=sprintf("%01.2f", $perannual_paypal);
$perannual_paypal=($perannual_paypal*100);


	echo("
	<TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
CELLPADDING='0'>
  <TR>
    <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
      CELLPADDING='0'>
        <TR>
          <TD WIDTH='100%'><B><FONT SIZE='-1' FACE='Tahoma'><center>PayPal Breakdown</FONT></B></TD> 
        </TR>
        <TR>
          <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='1'
            CELLPADDING='1'>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Monthly</FONT></TD>
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='m1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='m2.gif' WIDTH='$permonth_paypal' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$permonth_paypal%'><IMG SRC='m3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD>
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_monthly_income_paypal</FONT></TD>
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Quarterly</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='q1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='q2.gif' WIDTH='$perquarter_paypal' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$perquarter_paypal%'><IMG SRC='q3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_quarterly_income_paypal</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Semi-Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='sa1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='sa2.gif' WIDTH='$persemi_paypal' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$persemi_paypal%'><IMG SRC='sa3.gif' WIDTH='2' HEIGHT='10'
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_semiannual_income_paypal</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='a1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='a2.gif' WIDTH='$perannual_paypal' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$perannual_paypal%'><IMG SRC='a3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_annual_income_paypal</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><B><FONT SIZE='-2'
                   FACE='Tahoma'>All Cycles:</FONT></B></TD> 
                <TD COLSPAN='2' BGCOLOR='#dbedf9'><B><FONT SIZE='-2' FACE='Tahoma'>$currency$allcycles_paypal</FONT></B></TD> 
                 
              </TR>
              <TR>
                <TD COLSPAN='3' BGCOLOR='#dbedf9'><img src='".$http_images."/space.gif' width='1' height='6'></TD> 
                 
              </TR>
            </TABLE></TD>
        </TR>
      </TABLE></TD>
  </TR>
</TABLE>
		");
	}
// END PAYPAL CONFIGURATION
// START PAYSYSTEMS CONFIGURATION

$rs5=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='3' AND payment_term='monthly'"));
$total_monthly_income_paysystems=sprintf("%01.2f", $rs5[0]);

$rs6=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='3' AND payment_term='quarterly'"));
$total_quarterly_income_paysystems=sprintf("%01.2f", $rs6[0]);

$rs7=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='3' AND payment_term='semi-annual'"));
$total_semiannual_income_paysystems=sprintf("%01.2f", $rs7[0]);

$rs8=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='3' AND payment_term='annual'"));
$total_annual_income_paysystems=sprintf("%01.2f", $rs8[0]);

$rs9=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='3'"));
$total_annual_income_combined_paysystems=sprintf("%01.2f", $rs9[0]);

$allcycles_paysystems=($total_monthly_income_paysystems*12)+($total_quarterly_income_paysystems*4)+($total_semiannual_income_paysystems*2)+$total_annual_income_paysystems;
$allcycles_paysystems=sprintf("%01.2f", $allcycles_paysystems);

if($total_annual_income_combined_paysystems>0)
	{
//lets try percentages
$permonth_paysystems=($total_monthly_income_paysystems/$total_annual_income_combined_paysystems);
$permonth_paysystems=sprintf("%01.2f", $permonth_paysystems);
$permonth_paysystems=($permonth_paysystems*100);

$quarterly_paysystems=($total_quarterly_income_paysystems/$total_annual_income_combined_paysystems);
$quarterly_paysystems=sprintf("%01.2f", $quarterly_paysystems);
$quarterly_paysystems=($quarterly_paysystems*100);

$semiannual_paysystems=($total_semiannual_income_paysystems/$total_annual_income_combined_paysystems);
$semiannual_paysystems=sprintf("%01.2f", $semiannual_paysystems);
$semiannual_paysystems=($semiannual_paysystems*100);

$annual_paysystems=($total_annual_income_paysystems/$total_annual_income_combined_paysystems);
$annual_paysystems=sprintf("%01.2f", $annual_paysystems);
$annual_paysystems=($annual_paysystems*100);


	echo("
	<TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
CELLPADDING='0'>
  <TR>
    <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
      CELLPADDING='0'>
        <TR>
          <TD WIDTH='100%'><B><FONT SIZE='-1' FACE='Tahoma'><center>PaySystems Breakdown</FONT></B></TD> 
        </TR>
        <TR>
          <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='1'
            CELLPADDING='1'>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Monthly</FONT></TD>
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='m1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='m2.gif' WIDTH='$permonth_paysystems' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$permonth_paysystems%'><IMG SRC='m3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD>
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_monthly_income_paysystems</FONT></TD>
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Quarterly</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='q1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='q2.gif' WIDTH='$quarterly_paysystems' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$quarterly_paysystems%'><IMG SRC='q3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_quarterly_income_paysystems</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Semi-Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='sa1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='sa2.gif' WIDTH='$semiannual_paysystems' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$semiannual_paysystems%'><IMG SRC='sa3.gif' WIDTH='2' HEIGHT='10'
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_semiannual_income_paysystems</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='a1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='a2.gif' WIDTH='$annual_paysystems' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$annual_paysystems%'><IMG SRC='a3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_annual_income_paysystems</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><B><FONT SIZE='-2'
                   FACE='Tahoma'>All Cycles:</FONT></B></TD> 
                <TD COLSPAN='2' BGCOLOR='#dbedf9'><B><FONT SIZE='-2' FACE='Tahoma'>$currency$allcycles_paysystems</FONT></B></TD> 
                 
              </TR>
              <TR>
                <TD COLSPAN='3' BGCOLOR='#dbedf9'><img src='".$http_images."/space.gif' width='1' height='6'></TD> 
                 
              </TR>
            </TABLE></TD>
        </TR>
      </TABLE></TD>
  </TR>
</TABLE>
		");
	}
// END PAYSYSTEMS

// START MAIL IN PAYMENT

$rs5=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='6' AND payment_term='monthly'"));
$total_monthly_income_mailinpayment=sprintf("%01.2f", $rs5[0]);

$rs6=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='6' AND payment_term='quarterly'"));
$total_quarterly_income_mailinpayment=sprintf("%01.2f", $rs6[0]);

$rs7=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='6' AND payment_term='semi-annual'"));
$total_semiannual_income_mailinpayment=sprintf("%01.2f", $rs7[0]);

$rs8=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='6' AND payment_term='annual'"));
$total_annual_income_mailinpayment=sprintf("%01.2f", $rs8[0]);

$rs9=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='6'"));
$total_annual_income_combined_mailinpayment=sprintf("%01.2f", $rs9[0]);

$allcycles_mailinpayment=($total_monthly_income_mailinpayment*12)+($total_quarterly_income_mailinpayment*4)+($total_semiannual_income_mailinpayment*2)+$total_annual_income_mailinpayment;
$allcycles_mailinpayment=sprintf("%01.2f", $allcycles_mailinpayment);

if($total_annual_income_combined_mailinpayment>0)
	{
//lets try percentages
$permonth_mailinpayment=($total_monthly_income_mailinpayment/$total_annual_income_combined_mailinpayment);
$permonth_mailinpayment=sprintf("%01.2f", $permonth_mailinpayment);
$permonth_mailinpayment=($permonth_mailinpayment*100);

$quarterly_mailinpayment=($total_quarterly_income_mailinpayment/$total_annual_income_combined_mailinpayment);
$quarterly_mailinpayment=sprintf("%01.2f", $quarterly_mailinpayment);
$quarterly_mailinpayment=($quarterly_mailinpayment*100);

$semiannual_mailinpayment=($total_semiannual_income_mailinpayment/$total_annual_income_combined_mailinpayment);
$semiannual_mailinpayment=sprintf("%01.2f", $semiannual_mailinpayment);
$semiannual_mailinpayment=($semiannual_mailinpayment*100);

$annual_mailinpayment=($total_annual_income_mailinpayment/$total_annual_income_combined_mailinpayment);
$annual_mailinpayment=sprintf("%01.2f", $annual_mailinpayment);
$annual_mailinpayment=($annual_mailinpayment*100);


	echo("
	<TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
CELLPADDING='0'>
  <TR>
    <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
      CELLPADDING='0'>
        <TR>
          <TD WIDTH='100%'><B><FONT SIZE='-1' FACE='Tahoma'><center>Mail in Payment Breakdown</FONT></B></TD> 
        </TR>
        <TR>
          <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='1'
            CELLPADDING='1'>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Monthly</FONT></TD>
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='m1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='m2.gif' WIDTH='$permonth_mailinpayment' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$permonth_mailinpayment%'><IMG SRC='m3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD>
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_monthly_income_mailinpayment</FONT></TD>
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Quarterly</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='q1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='q2.gif' WIDTH='$quarterly_mailinpayment' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$quarterly_mailinpayment%'><IMG SRC='q3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_quarterly_income_mailinpayment</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Semi-Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='sa1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='sa2.gif' WIDTH='$semiannual_mailinpayment' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$semiannual_mailinpayment%'><IMG SRC='sa3.gif' WIDTH='2' HEIGHT='10'
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_semiannual_income_mailinpayment</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='a1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='a2.gif' WIDTH='$annual_mailinpayment' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$annual_mailinpayment%'><IMG SRC='a3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_annual_income_mailinpayment</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><B><FONT SIZE='-2'
                   FACE='Tahoma'>All Cycles:</FONT></B></TD> 
                <TD COLSPAN='2' BGCOLOR='#dbedf9'><B><FONT SIZE='-2' FACE='Tahoma'>$currency$allcycles_mailinpayment</FONT></B></TD> 
                 
              </TR>
              <TR>
                <TD COLSPAN='3' BGCOLOR='#dbedf9'><img src='".$http_images."/space.gif' width='1' height='6'></TD> 
                 
              </TR>
            </TABLE></TD>
        </TR>
      </TABLE></TD>
  </TR>
</TABLE>
		");
	}
// end mail
// start 2co
$rs5=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='4' AND payment_term='monthly'"));
$total_monthly_income_2checkout=sprintf("%01.2f", $rs5[0]);

$rs6=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='4' AND payment_term='quarterly'"));
$total_quarterly_income_2checkout=sprintf("%01.2f", $rs6[0]);

$rs7=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='4' AND payment_term='semi-annual'"));
$total_semiannual_income_2checkout=sprintf("%01.2f", $rs7[0]);

$rs8=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='4' AND payment_term='annual'"));
$total_annual_income_2checkout=sprintf("%01.2f", $rs8[0]);

$rs9=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='4'"));
$total_annual_income_combined_2checkout=sprintf("%01.2f", $rs9[0]);

$allcycles_2checkout=($total_monthly_income_2checkout*12)+($total_quarterly_income_2checkout*4)+($total_semiannual_income_2checkout*2)+$total_annual_income_2checkout;
$allcycles_2checkout=sprintf("%01.2f", $allcycles_2checkout);

if($total_annual_income_combined_2checkout>0)
	{
//lets try percentages
$permonth_2checkout=($total_monthly_income_2checkout/$total_annual_income_combined_2checkout);
$permonth_2checkout=sprintf("%01.2f", $permonth_2checkout);
$permonth_2checkout=($permonth_2checkout*100);

$quarterly_2checkout=($total_quarterly_income_2checkout/$total_annual_income_combined_2checkout);
$quarterly_2checkout=sprintf("%01.2f", $quarterly_2checkout);
$quarterly_2checkout=($quarterly_2checkout*100);

$semiannual_2checkout=($total_semiannual_income_2checkout/$total_annual_income_combined_2checkout);
$semiannual_2checkout=sprintf("%01.2f", $semiannual_2checkout);
$semiannual_2checkout=($semiannual_2checkout*100);

$annual_2checkout=($total_annual_income_2checkout/$total_annual_income_combined_2checkout);
$annual_2checkout=sprintf("%01.2f", $annual_2checkout);
$annual_2checkout=($annual_2checkout*100);


	echo("
	<TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
CELLPADDING='0'>
  <TR>
    <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
      CELLPADDING='0'>
        <TR>
          <TD WIDTH='100%'><B><FONT SIZE='-1' FACE='Tahoma'><center>2Checkout Breakdown</FONT></B></TD> 
        </TR>
        <TR>
          <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='1'
            CELLPADDING='1'>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Monthly</FONT></TD>
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='m1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='m2.gif' WIDTH='$permonth_2checkout' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$permonth_2checkout%'><IMG SRC='m3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD>
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_monthly_income_2checkout</FONT></TD>
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Quarterly</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='q1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='q2.gif' WIDTH='$quarterly_2checkout' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$quarterly_2checkout%'><IMG SRC='q3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_quarterly_income_2checkout</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Semi-Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='sa1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='sa2.gif' WIDTH='$semiannual_2checkout' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$semiannual_2checkout%'><IMG SRC='sa3.gif' WIDTH='2' HEIGHT='10'
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_semiannual_income_2checkout</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='a1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='a2.gif' WIDTH='$annual_2checkout' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$annual_2checkout%'><IMG SRC='a3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_annual_income_2checkout</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><B><FONT SIZE='-2'
                   FACE='Tahoma'>All Cycles:</FONT></B></TD> 
                <TD COLSPAN='2' BGCOLOR='#dbedf9'><B><FONT SIZE='-2' FACE='Tahoma'>$currency$allcycles_2checkout</FONT></B></TD> 
                 
              </TR>
              <TR>
                <TD COLSPAN='3' BGCOLOR='#dbedf9'><img src='".$http_images."/space.gif' width='1' height='6'></TD> 
                 
              </TR>
            </TABLE></TD>
        </TR>
      </TABLE></TD>
  </TR>
</TABLE>
		");
	}
// end 2co
// start worldpay
$rs5=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='2' AND payment_term='monthly'"));
$total_monthly_income_worldpay=sprintf("%01.2f", $rs5[0]);

$rs6=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='2' AND payment_term='quarterly'"));
$total_quarterly_income_worldpay=sprintf("%01.2f", $rs6[0]);

$rs7=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='2' AND payment_term='semi-annual'"));
$total_semiannual_income_worldpay=sprintf("%01.2f", $rs7[0]);

$rs8=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='2' AND payment_term='annual'"));
$total_annual_income_worldpay=sprintf("%01.2f", $rs8[0]);

$rs9=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='2'"));
$total_annual_income_combined_worldpay=sprintf("%01.2f", $rs9[0]);

$allcycles_worldpay=($total_monthly_income_worldpay*12)+($total_quarterly_income_worldpay*4)+($total_semiannual_income_worldpay*2)+$total_annual_income_worldpay;
$allcycles_worldpay=sprintf("%01.2f", $allcycles_worldpay);

if($total_annual_income_combined_worldpay>0)
	{
//lets try percentages
$permonth_worldpay=($total_monthly_income_worldpay/$total_annual_income_combined_worldpay);
$permonth_worldpay=sprintf("%01.2f", $permonth_worldpay);
$permonth_worldpay=($permonth_worldpay*100);

$quarterly_worldpay=($total_quarterly_income_worldpay/$total_annual_income_combined_worldpay);
$quarterly_worldpay=sprintf("%01.2f", $quarterly_worldpay);
$quarterly_worldpay=($quarterly_worldpay*100);

$semiannual_worldpay=($total_semiannual_income_worldpay/$total_annual_income_combined_worldpay);
$semiannual_worldpay=sprintf("%01.2f", $semiannual_worldpay);
$semiannual_worldpay=($semiannual_worldpay*100);

$annual_worldpay=($total_annual_income_worldpay/$total_annual_income_combined_worldpay);
$annual_worldpay=sprintf("%01.2f", $annual_worldpay);
$annual_worldpay=($annual_worldpay*100);


	echo("
	<TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
CELLPADDING='0'>
  <TR>
    <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
      CELLPADDING='0'>
        <TR>
          <TD WIDTH='100%'><B><FONT SIZE='-1' FACE='Tahoma'><center>WorldPay Breakdown</FONT></B></TD> 
        </TR>
        <TR>
          <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='1'
            CELLPADDING='1'>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Monthly</FONT></TD>
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='m1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='m2.gif' WIDTH='$permonth_worldpay' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$permonth_worldpay%'><IMG SRC='m3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD>
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_monthly_income_worldpay</FONT></TD>
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Quarterly</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='q1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='q2.gif' WIDTH='$quarterly_worldpay' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$quarterly_worldpay%'><IMG SRC='q3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_quarterly_income_worldpay</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Semi-Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='sa1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='sa2.gif' WIDTH='$semiannual_worldpay' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$semiannual_worldpay%'><IMG SRC='sa3.gif' WIDTH='2' HEIGHT='10'
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_semiannual_income_worldpay</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='a1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='a2.gif' WIDTH='$annual_worldpay' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$annual_worldpay%'><IMG SRC='a3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_annual_income_worldpay</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><B><FONT SIZE='-2'
                   FACE='Tahoma'>All Cycles:</FONT></B></TD> 
                <TD COLSPAN='2' BGCOLOR='#dbedf9'><B><FONT SIZE='-2' FACE='Tahoma'>$currency$allcycles_worldpay</FONT></B></TD> 
                 
              </TR>
              <TR>
                <TD COLSPAN='3' BGCOLOR='#dbedf9'><img src='".$http_images."/space.gif' width='1' height='6'></TD> 
                 
              </TR>
            </TABLE></TD>
        </TR>
      </TABLE></TD>
  </TR>
</TABLE>
		");
	}
// end worldpay
// start authnet
$rs5=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='8' AND payment_term='monthly'"));
$total_monthly_income_authorizenet=sprintf("%01.2f", $rs5[0]);

$rs6=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='8' AND payment_term='quarterly'"));
$total_quarterly_income_authorizenet=sprintf("%01.2f", $rs6[0]);

$rs7=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='8' AND payment_term='semi-annual'"));
$total_semiannual_income_authorizenet=sprintf("%01.2f", $rs7[0]);

$rs8=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='8' AND payment_term='annual'"));
$total_annual_income_authorizenet=sprintf("%01.2f", $rs8[0]);

$rs9=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='8'"));
$total_annual_income_combined_authorizenet=sprintf("%01.2f", $rs9[0]);

$allcycles_authorizenet=($total_monthly_income_authorizenet*12)+($total_quarterly_income_authorizenet*4)+($total_semiannual_income_authorizenet*2)+$total_annual_income_authorizenet;
$allcycles_authorizenet=sprintf("%01.2f", $allcycles_authorizenet);

if($total_annual_income_combined_authorizenet>0)
	{
//lets try percentages
$permonth_authorizenet=($total_monthly_income_authorizenet/$total_annual_income_combined_authorizenet);
$permonth_authorizenet=sprintf("%01.2f", $permonth_authorizenet);
$permonth_authorizenet=($permonth_authorizenet*100);

$quarterly_authorizenet=($total_quarterly_income_authorizenet/$total_annual_income_combined_authorizenet);
$quarterly_authorizenet=sprintf("%01.2f", $quarterly_authorizenet);
$quarterly_authorizenet=($quarterly_authorizenet*100);

$semiannual_authorizenet=($total_semiannual_income_authorizenet/$total_annual_income_combined_authorizenet);
$semiannual_authorizenet=sprintf("%01.2f", $semiannual_authorizenet);
$semiannual_authorizenet=($semiannual_authorizenet*100);

$annual_authorizenet=($total_annual_income_authorizenet/$total_annual_income_combined_authorizenet);
$annual_authorizenet=sprintf("%01.2f", $annual_authorizenet);
$annual_authorizenet=($annual_authorizenet*100);


	echo("
	<TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
CELLPADDING='0'>
  <TR>
    <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
      CELLPADDING='0'>
        <TR>
          <TD WIDTH='100%'><B><FONT SIZE='-1' FACE='Tahoma'><center>Authorize.net Breakdown</FONT></B></TD> 
        </TR>
        <TR>
          <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='1'
            CELLPADDING='1'>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Monthly</FONT></TD>
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='m1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='m2.gif' WIDTH='$permonth_authorizenet' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$permonth_authorizenet%'><IMG SRC='m3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD>
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_monthly_income_authorizenet</FONT></TD>
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Quarterly</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='q1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='q2.gif' WIDTH='$quarterly_authorizenet' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$quarterly_authorizenet%'><IMG SRC='q3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_quarterly_income_authorizenet</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Semi-Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='sa1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='sa2.gif' WIDTH='$semiannual_authorizenet' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$semiannual_authorizenet%'><IMG SRC='sa3.gif' WIDTH='2' HEIGHT='10'
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_semiannual_income_authorizenet</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='a1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='a2.gif' WIDTH='$annual_authorizenet' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$annual_authorizenet%'><IMG SRC='a3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_annual_income_authorizenet</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><B><FONT SIZE='-2'
                   FACE='Tahoma'>All Cycles:</FONT></B></TD> 
                <TD COLSPAN='2' BGCOLOR='#dbedf9'><B><FONT SIZE='-2' FACE='Tahoma'>$currency$allcycles_authorizenet</FONT></B></TD> 
                 
              </TR>
              <TR>
                <TD COLSPAN='3' BGCOLOR='#dbedf9'><img src='".$http_images."/space.gif' width='1' height='6'></TD> 
                 
              </TR>
            </TABLE></TD>
        </TR>
      </TABLE></TD>
  </TR>
</TABLE>
		");
	}
// end authnet
// begin isecure
$rs5=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='9' AND payment_term='monthly'"));
$total_monthly_income_internetsecure=sprintf("%01.2f", $rs5[0]);

$rs6=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='9' AND payment_term='quarterly'"));
$total_quarterly_income_internetsecure=sprintf("%01.2f", $rs6[0]);

$rs7=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='9' AND payment_term='semi-annual'"));
$total_semiannual_income_internetsecure=sprintf("%01.2f", $rs7[0]);

$rs8=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='9' AND payment_term='annual'"));
$total_annual_income_internetsecure=sprintf("%01.2f", $rs8[0]);

$rs9=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='9'"));
$total_annual_income_combined_internetsecure=sprintf("%01.2f", $rs9[0]);

$allcycles_internetsecure=($total_monthly_income_internetsecure*12)+($total_quarterly_income_internetsecure*4)+($total_semiannual_income_internetsecure*2)+$total_annual_income_internetsecure;
$allcycles_internetsecure=sprintf("%01.2f", $allcycles_internetsecure);

if($total_annual_income_combined_internetsecure>0)
	{
//lets try percentages
$permonth_internetsecure=($total_monthly_income_internetsecure/$total_annual_income_combined_internetsecure);
$permonth_internetsecure=sprintf("%01.2f", $permonth_internetsecure);
$permonth_internetsecure=($permonth_internetsecure*100);

$quarterly_internetsecure=($total_quarterly_income_internetsecure/$total_annual_income_combined_internetsecure);
$quarterly_internetsecure=sprintf("%01.2f", $quarterly_internetsecure);
$quarterly_internetsecure=($quarterly_internetsecure*100);

$semiannual_internetsecure=($total_semiannual_income_internetsecure/$total_annual_income_combined_internetsecure);
$semiannual_internetsecure=sprintf("%01.2f", $semiannual_internetsecure);
$semiannual_internetsecure=($semiannual_internetsecure*100);

$annual_internetsecure=($total_annual_income_internetsecure/$total_annual_income_combined_internetsecure);
$annual_internetsecure=sprintf("%01.2f", $annual_internetsecure);
$annual_internetsecure=($annual_internetsecure*100);


	echo("
	<TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
CELLPADDING='0'>
  <TR>
    <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
      CELLPADDING='0'>
        <TR>
          <TD WIDTH='100%'><B><FONT SIZE='-1' FACE='Tahoma'><center>InternetSecure Breakdown</FONT></B></TD> 
        </TR>
        <TR>
          <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='1'
            CELLPADDING='1'>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Monthly</FONT></TD>
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='m1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='m2.gif' WIDTH='$permonth_internetsecure' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$permonth_internetsecure%'><IMG SRC='m3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD>
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_monthly_income_internetsecure</FONT></TD>
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Quarterly</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='q1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='q2.gif' WIDTH='$quarterly_internetsecure' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$quarterly_internetsecure%'><IMG SRC='q3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_quarterly_income_internetsecure</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Semi-Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='sa1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='sa2.gif' WIDTH='$semiannual_internetsecure' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$semiannual_internetsecure%'><IMG SRC='sa3.gif' WIDTH='2' HEIGHT='10'
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_semiannual_income_internetsecure</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='a1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='a2.gif' WIDTH='$annual_internetsecure' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$annual_internetsecure%'><IMG SRC='a3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_annual_income_internetsecure</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><B><FONT SIZE='-2'
                   FACE='Tahoma'>All Cycles:</FONT></B></TD> 
                <TD COLSPAN='2' BGCOLOR='#dbedf9'><B><FONT SIZE='-2' FACE='Tahoma'>$currency$allcycles_internetsecure</FONT></B></TD> 
                 
              </TR>
              <TR>
                <TD COLSPAN='3' BGCOLOR='#dbedf9'><img src='".$http_images."/space.gif' width='1' height='6'></TD> 
                 
              </TR>
            </TABLE></TD>
        </TR>
      </TABLE></TD>
  </TR>
</TABLE>
		");
	}
// end isecure
// begin linkpoint
$rs5=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='10' AND payment_term='monthly'"));
$total_monthly_income_linkpoint=sprintf("%01.2f", $rs5[0]);

$rs6=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='10' AND payment_term='quarterly'"));
$total_quarterly_income_linkpoint=sprintf("%01.2f", $rs6[0]);

$rs7=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='10' AND payment_term='semi-annual'"));
$total_semiannual_income_linkpoint=sprintf("%01.2f", $rs7[0]);

$rs8=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='10' AND payment_term='annual'"));
$total_annual_income_linkpoint=sprintf("%01.2f", $rs8[0]);

$rs9=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='10'"));
$total_annual_income_combined_linkpoint=sprintf("%01.2f", $rs9[0]);

$allcycles_linkpoint=($total_monthly_income_linkpoint*12)+($total_quarterly_income_linkpoint*4)+($total_semiannual_income_linkpoint*2)+$total_annual_income_linkpoint;
$allcycles_linkpoint=sprintf("%01.2f", $allcycles_linkpoint);

if($total_annual_income_combined_linkpoint>0)
	{
//lets try percentages
$permonth_linkpoint=($total_monthly_income_linkpoint/$total_annual_income_combined_linkpoint);
$permonth_linkpoint=sprintf("%01.2f", $permonth_linkpoint);
$permonth_linkpoint=($permonth_linkpoint*100);

$quarterly_linkpoint=($total_quarterly_income_linkpoint/$total_annual_income_combined_linkpoint);
$quarterly_linkpoint=sprintf("%01.2f", $quarterly_linkpoint);
$quarterly_linkpoint=($quarterly_linkpoint*100);

$semiannual_linkpoint=($total_semiannual_income_linkpoint/$total_annual_income_combined_linkpoint);
$semiannual_linkpoint=sprintf("%01.2f", $semiannual_linkpoint);
$semiannual_linkpoint=($semiannual_linkpoint*100);

$annual_linkpoint=($total_annual_income_linkpoint/$total_annual_income_combined_linkpoint);
$annual_linkpoint=sprintf("%01.2f", $annual_linkpoint);
$annual_linkpoint=($annual_linkpoint*100);


	echo("
	<TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
CELLPADDING='0'>
  <TR>
    <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
      CELLPADDING='0'>
        <TR>
          <TD WIDTH='100%'><B><FONT SIZE='-1' FACE='Tahoma'><center>LinkPoint Breakdown</FONT></B></TD> 
        </TR>
        <TR>
          <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='1'
            CELLPADDING='1'>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Monthly</FONT></TD>
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='m1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='m2.gif' WIDTH='$permonth_linkpoint' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$permonth_linkpoint%'><IMG SRC='m3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD>
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_monthly_income_linkpoint</FONT></TD>
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Quarterly</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='q1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='q2.gif' WIDTH='$quarterly_linkpoint' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$quarterly_linkpoint%'><IMG SRC='q3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_quarterly_income_linkpoint</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Semi-Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='sa1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='sa2.gif' WIDTH='$semiannual_linkpoint' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$semiannual_linkpoint%'><IMG SRC='sa3.gif' WIDTH='2' HEIGHT='10'
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_semiannual_income_linkpoint</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='a1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='a2.gif' WIDTH='$annual_linkpoint' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$annual_linkpoint%'><IMG SRC='a3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_annual_income_linkpoint</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><B><FONT SIZE='-2'
                   FACE='Tahoma'>All Cycles:</FONT></B></TD> 
                <TD COLSPAN='2' BGCOLOR='#dbedf9'><B><FONT SIZE='-2' FACE='Tahoma'>$currency$allcycles_linkpoint</FONT></B></TD> 
                 
              </TR>
              <TR>
                <TD COLSPAN='3' BGCOLOR='#dbedf9'><img src='".$http_images."/space.gif' width='1' height='6'></TD> 
                 
              </TR>
            </TABLE></TD>
        </TR>
      </TABLE></TD>
  </TR>
</TABLE>
		");
	}
// end linkpoint
// begin psigate
$rs5=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='11' AND payment_term='monthly'"));
$total_monthly_income_psigate=sprintf("%01.2f", $rs5[0]);

$rs6=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='11' AND payment_term='quarterly'"));
$total_quarterly_income_psigate=sprintf("%01.2f", $rs6[0]);

$rs7=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='11' AND payment_term='semi-annual'"));
$total_semiannual_income_psigate=sprintf("%01.2f", $rs7[0]);

$rs8=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='11' AND payment_term='annual'"));
$total_annual_income_psigate=sprintf("%01.2f", $rs8[0]);

$rs9=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='11'"));
$total_annual_income_combined_psigate=sprintf("%01.2f", $rs9[0]);

$allcycles_psigate=($total_monthly_income_psigate*12)+($total_quarterly_income_psigate*4)+($total_semiannual_income_psigate*2)+$total_annual_income_psigate;
$allcycles_psigate=sprintf("%01.2f", $allcycles_psigate);

if($total_annual_income_combined_psigate>0)
	{
//lets try percentages
$permonth_psigate=($total_monthly_income_psigate/$total_annual_income_combined_psigate);
$permonth_psigate=sprintf("%01.2f", $permonth_psigate);
$permonth_psigate=($permonth_psigate*100);

$quarterly_psigate=($total_quarterly_income_psigate/$total_annual_income_combined_psigate);
$quarterly_psigate=sprintf("%01.2f", $quarterly_psigate);
$quarterly_psigate=($quarterly_psigate*100);

$semiannual_psigate=($total_semiannual_income_psigate/$total_annual_income_combined_psigate);
$semiannual_psigate=sprintf("%01.2f", $semiannual_psigate);
$semiannual_psigate=($semiannual_psigate*100);

$annual_psigate=($total_annual_income_psigate/$total_annual_income_combined_psigate);
$annual_psigate=sprintf("%01.2f", $annual_psigate);
$annual_psigate=($annual_psigate*100);


	echo("
	<TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
CELLPADDING='0'>
  <TR>
    <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
      CELLPADDING='0'>
        <TR>
          <TD WIDTH='100%'><B><FONT SIZE='-1' FACE='Tahoma'><center>PSiGate Breakdown</FONT></B></TD> 
        </TR>
        <TR>
          <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='1'
            CELLPADDING='1'>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Monthly</FONT></TD>
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='m1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='m2.gif' WIDTH='$permonth_psigate' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$permonth_psigate%'><IMG SRC='m3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD>
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_monthly_income_psigate</FONT></TD>
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Quarterly</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='q1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='q2.gif' WIDTH='$quarterly_psigate' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$quarterly_psigate%'><IMG SRC='q3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_quarterly_income_psigate</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Semi-Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='sa1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='sa2.gif' WIDTH='$semiannual_psigate' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$semiannual_psigate%'><IMG SRC='sa3.gif' WIDTH='2' HEIGHT='10'
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_semiannual_income_psigate</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='a1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='a2.gif' WIDTH='$annual_psigate' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$annual_psigate%'><IMG SRC='a3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_annual_income_psigate</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><B><FONT SIZE='-2'
                   FACE='Tahoma'>All Cycles:</FONT></B></TD> 
                <TD COLSPAN='2' BGCOLOR='#dbedf9'><B><FONT SIZE='-2' FACE='Tahoma'>$currency$allcycles_psigate</FONT></B></TD> 
                 
              </TR>
              <TR>
                <TD COLSPAN='3' BGCOLOR='#dbedf9'><img src='".$http_images."/space.gif' width='1' height='6'></TD> 
                 
              </TR>
            </TABLE></TD>
        </TR>
      </TABLE></TD>
  </TR>
</TABLE>
		");
	}
// end psigate
// begin paypal2
$rs5=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='12' AND payment_term='monthly'"));
$total_monthly_income_paypalalt=sprintf("%01.2f", $rs5[0]);

$rs6=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='12' AND payment_term='quarterly'"));
$total_quarterly_income_paypalalt=sprintf("%01.2f", $rs6[0]);

$rs7=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='12' AND payment_term='semi-annual'"));
$total_semiannual_income_paypalalt=sprintf("%01.2f", $rs7[0]);

$rs8=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='12' AND payment_term='annual'"));
$total_annual_income_paypalalt=sprintf("%01.2f", $rs8[0]);

$rs9=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='12'"));
$total_annual_income_combined_paypalalt=sprintf("%01.2f", $rs9[0]);

$allcycles_paypalalt=($total_monthly_income_paypalalt*12)+($total_quarterly_income_paypalalt*4)+($total_semiannual_income_paypalalt*2)+$total_annual_income_paypalalt;
$allcycles_paypalalt=sprintf("%01.2f", $allcycles_paypalalt);

if($total_annual_income_combined_paypalalt>0)
	{
//lets try percentages
$permonth_paypalalt=($total_monthly_income_paypalalt/$total_annual_income_combined_paypalalt);
$permonth_paypalalt=sprintf("%01.2f", $permonth_paypalalt);
$permonth_paypalalt=($permonth_paypalalt*100);

$quarterly_paypalalt=($total_quarterly_income_paypalalt/$total_annual_income_combined_paypalalt);
$quarterly_paypalalt=sprintf("%01.2f", $quarterly_paypalalt);
$quarterly_paypalalt=($quarterly_paypalalt*100);

$semiannual_paypalalt=($total_semiannual_income_paypalalt/$total_annual_income_combined_paypalalt);
$semiannual_paypalalt=sprintf("%01.2f", $semiannual_paypalalt);
$semiannual_paypalalt=($semiannual_paypalalt*100);

$annual_paypalalt=($total_annual_income_paypalalt/$total_annual_income_combined_paypalalt);
$annual_paypalalt=sprintf("%01.2f", $annual_paypalalt);
$annual_paypalalt=($annual_paypalalt*100);


	echo("
	<TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
CELLPADDING='0'>
  <TR>
    <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
      CELLPADDING='0'>
        <TR>
          <TD WIDTH='100%'><B><FONT SIZE='-1' FACE='Tahoma'><center>PayPal ALT Breakdown</FONT></B></TD> 
        </TR>
        <TR>
          <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='1'
            CELLPADDING='1'>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Monthly</FONT></TD>
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='m1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='m2.gif' WIDTH='$permonth_paypalalt' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$permonth_paypalalt%'><IMG SRC='m3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD>
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_monthly_income_paypalalt</FONT></TD>
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Quarterly</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='q1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='q2.gif' WIDTH='$quarterly_paypalalt' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$quarterly_paypalalt%'><IMG SRC='q3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_quarterly_income_paypalalt</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Semi-Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='sa1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='sa2.gif' WIDTH='$semiannual_paypalalt' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$semiannual_paypalalt%'><IMG SRC='sa3.gif' WIDTH='2' HEIGHT='10'
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_semiannual_income_paypalalt</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='a1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='a2.gif' WIDTH='$annual_paypalalt' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$annual_paypalalt%'><IMG SRC='a3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_annual_income_paypalalt</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><B><FONT SIZE='-2'
                   FACE='Tahoma'>All Cycles:</FONT></B></TD> 
                <TD COLSPAN='2' BGCOLOR='#dbedf9'><B><FONT SIZE='-2' FACE='Tahoma'>$currency$allcycles_paypalalt</FONT></B></TD> 
                 
              </TR>
              <TR>
                <TD COLSPAN='3' BGCOLOR='#dbedf9'><img src='".$http_images."/space.gif' width='1' height='6'></TD> 
                 
              </TR>
            </TABLE></TD>
        </TR>
      </TABLE></TD>
  </TR>
</TABLE>
		");
	}
// end paypal2
// start worldpay2
$rs5=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='13' AND payment_term='monthly'"));
$total_monthly_income_worldpayalt=sprintf("%01.2f", $rs5[0]);

$rs6=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='13' AND payment_term='quarterly'"));
$total_quarterly_income_worldpayalt=sprintf("%01.2f", $rs6[0]);

$rs7=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='13' AND payment_term='semi-annual'"));
$total_semiannual_income_worldpayalt=sprintf("%01.2f", $rs7[0]);

$rs8=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='13' AND payment_term='annual'"));
$total_annual_income_worldpayalt=sprintf("%01.2f", $rs8[0]);

$rs9=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='13'"));
$total_annual_income_combined_worldpayalt=sprintf("%01.2f", $rs9[0]);

$allcycles_worldpayalt=($total_monthly_income_worldpayalt*12)+($total_quarterly_income_worldpayalt*4)+($total_semiannual_income_worldpayalt*2)+$total_annual_income_worldpayalt;
$allcycles_worldpayalt=sprintf("%01.2f", $allcycles_worldpayalt);

if($total_annual_income_combined_worldpayalt>0)
	{
//lets try percentages
$permonth_worldpayalt=($total_monthly_income_worldpayalt/$total_annual_income_combined_worldpayalt);
$permonth_worldpayalt=sprintf("%01.2f", $permonth_worldpayalt);
$permonth_worldpayalt=($permonth_worldpayalt*100);

$quarterly_worldpayalt=($total_quarterly_income_worldpayalt/$total_annual_income_combined_worldpayalt);
$quarterly_worldpayalt=sprintf("%01.2f", $quarterly_worldpayalt);
$quarterly_worldpayalt=($quarterly_worldpayalt*100);

$semiannual_worldpayalt=($total_semiannual_income_worldpayalt/$total_annual_income_combined_worldpayalt);
$semiannual_worldpayalt=sprintf("%01.2f", $semiannual_worldpayalt);
$semiannual_worldpayalt=($semiannual_worldpayalt*100);

$annual_worldpayalt=($total_annual_income_worldpayalt/$total_annual_income_combined_worldpayalt);
$annual_worldpayalt=sprintf("%01.2f", $annual_worldpayalt);
$annual_worldpayalt=($annual_worldpayalt*100);


	echo("
	<TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
CELLPADDING='0'>
  <TR>
    <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
      CELLPADDING='0'>
        <TR>
          <TD WIDTH='100%'><B><FONT SIZE='-1' FACE='Tahoma'><center>WorldPay ALT Breakdown</FONT></B></TD> 
        </TR>
        <TR>
          <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='1'
            CELLPADDING='1'>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Monthly</FONT></TD>
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='m1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='m2.gif' WIDTH='$permonth_worldpayalt' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$permonth_worldpayalt%'><IMG SRC='m3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD>
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_monthly_income_worldpayalt</FONT></TD>
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Quarterly</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='q1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='q2.gif' WIDTH='$quarterly_worldpayalt' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$quarterly_worldpayalt%'><IMG SRC='q3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_quarterly_income_worldpayalt</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Semi-Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='sa1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='sa2.gif' WIDTH='$semiannual_worldpayalt' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$semiannual_worldpayalt%'><IMG SRC='sa3.gif' WIDTH='2' HEIGHT='10'
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_semiannual_income_worldpayalt</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='a1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='a2.gif' WIDTH='$annual_worldpayalt' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$annual_worldpayalt%'><IMG SRC='a3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_annual_income_worldpayalt</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><B><FONT SIZE='-2'
                   FACE='Tahoma'>All Cycles:</FONT></B></TD> 
                <TD COLSPAN='2' BGCOLOR='#dbedf9'><B><FONT SIZE='-2' FACE='Tahoma'>$currency$allcycles_worldpayalt</FONT></B></TD> 
                 
              </TR>
              <TR>
                <TD COLSPAN='3' BGCOLOR='#dbedf9'><img src='".$http_images."/space.gif' width='1' height='6'></TD> 
                 
              </TR>
            </TABLE></TD>
        </TR>
      </TABLE></TD>
  </TR>
</TABLE>
		");
	}
// end worldpay2
// start cybersource
$rs5=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='14' AND payment_term='monthly'"));
$total_monthly_income_cybersource=sprintf("%01.2f", $rs5[0]);

$rs6=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='14' AND payment_term='quarterly'"));
$total_quarterly_income_cybersource=sprintf("%01.2f", $rs6[0]);

$rs7=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='14' AND payment_term='semi-annual'"));
$total_semiannual_income_cybersource=sprintf("%01.2f", $rs7[0]);

$rs8=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='14' AND payment_term='annual'"));
$total_annual_income_cybersource=sprintf("%01.2f", $rs8[0]);

$rs9=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='14'"));
$total_annual_income_combined_cybersource=sprintf("%01.2f", $rs9[0]);

$allcycles_cybersource=($total_monthly_income_cybersource*12)+($total_quarterly_income_cybersource*4)+($total_semiannual_income_cybersource*2)+$total_annual_income_cybersource;
$allcycles_cybersource=sprintf("%01.2f", $allcycles_cybersource);

if($total_annual_income_combined_cybersource>0)
	{
//lets try percentages
$permonth_cybersource=($total_monthly_income_cybersource/$total_annual_income_combined_cybersource);
$permonth_cybersource=sprintf("%01.2f", $permonth_cybersource);
$permonth_cybersource=($permonth_cybersource*100);

$quarterly_cybersource=($total_quarterly_income_cybersource/$total_annual_income_combined_cybersource);
$quarterly_cybersource=sprintf("%01.2f", $quarterly_cybersource);
$quarterly_cybersource=($quarterly_cybersource*100);

$semiannual_cybersource=($total_semiannual_income_cybersource/$total_annual_income_combined_cybersource);
$semiannual_cybersource=sprintf("%01.2f", $semiannual_cybersource);
$semiannual_cybersource=($semiannual_cybersource*100);

$annual_cybersource=($total_annual_income_cybersource/$total_annual_income_combined_cybersource);
$annual_cybersource=sprintf("%01.2f", $annual_cybersource);
$annual_cybersource=($annual_cybersource*100);


	echo("
	<TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
CELLPADDING='0'>
  <TR>
    <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
      CELLPADDING='0'>
        <TR>
          <TD WIDTH='100%'><B><FONT SIZE='-1' FACE='Tahoma'><center>CyberSource Breakdown</FONT></B></TD> 
        </TR>
        <TR>
          <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='1'
            CELLPADDING='1'>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Monthly</FONT></TD>
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='m1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='m2.gif' WIDTH='$permonth_cybersource' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$permonth_cybersource%'><IMG SRC='m3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD>
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_monthly_income_cybersource</FONT></TD>
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Quarterly</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='q1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='q2.gif' WIDTH='$quarterly_cybersource' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$quarterly_cybersource%'><IMG SRC='q3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_quarterly_income_cybersource</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Semi-Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='sa1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='sa2.gif' WIDTH='$semiannual_cybersource' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$semiannual_cybersource%'><IMG SRC='sa3.gif' WIDTH='2' HEIGHT='10'
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_semiannual_income_cybersource</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='a1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='a2.gif' WIDTH='$annual_cybersource' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$annual_cybersource%'><IMG SRC='a3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_annual_income_cybersource</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><B><FONT SIZE='-2'
                   FACE='Tahoma'>All Cycles:</FONT></B></TD> 
                <TD COLSPAN='2' BGCOLOR='#dbedf9'><B><FONT SIZE='-2' FACE='Tahoma'>$currency$allcycles_cybersource</FONT></B></TD> 
                 
              </TR>
              <TR>
                <TD COLSPAN='3' BGCOLOR='#dbedf9'><img src='".$http_images."/space.gif' width='1' height='6'></TD> 
                 
              </TR>
            </TABLE></TD>
        </TR>
      </TABLE></TD>
  </TR>
</TABLE>
		");
	}
// end cybersource
// start offline
$rs5=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='15' AND payment_term='monthly'"));
$total_monthly_income_offline=sprintf("%01.2f", $rs5[0]);

$rs6=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='15' AND payment_term='quarterly'"));
$total_quarterly_income_offline=sprintf("%01.2f", $rs6[0]);

$rs7=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='15' AND payment_term='semi-annual'"));
$total_semiannual_income_offline=sprintf("%01.2f", $rs7[0]);

$rs8=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='15' AND payment_term='annual'"));
$total_annual_income_offline=sprintf("%01.2f", $rs8[0]);

$rs9=mysql_fetch_row(mysql_query("select sum(total_due_reoccur) from hosting_order where status='1' AND payment_method='15'"));
$total_annual_income_combined_offline=sprintf("%01.2f", $rs9[0]);

$allcycles_offline=($total_monthly_income_offline*12)+($total_quarterly_income_offline*4)+($total_semiannual_income_offline*2)+$total_annual_income_offline;
$allcycles_offline=sprintf("%01.2f", $allcycles_offline);

if($total_annual_income_combined_offline>0)
	{
//lets try percentages
$permonth_offline=($total_monthly_income_offline/$total_annual_income_combined_offline);
$permonth_offline=sprintf("%01.2f", $permonth_offline);
$permonth_offline=($permonth_offline*100);

$quarterly_offline=($total_quarterly_income_offline/$total_annual_income_combined_offline);
$quarterly_offline=sprintf("%01.2f", $quarterly_offline);
$quarterly_offline=($quarterly_offline*100);

$semiannual_offline=($total_semiannual_income_offline/$total_annual_income_combined_offline);
$semiannual_offline=sprintf("%01.2f", $semiannual_offline);
$semiannual_offline=($semiannual_offline*100);

$annual_offline=($total_annual_income_offline/$total_annual_income_combined_offline);
$annual_offline=sprintf("%01.2f", $annual_offline);
$annual_offline=($annual_offline*100);


	echo("
	<TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
CELLPADDING='0'>
  <TR>
    <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='0'
      CELLPADDING='0'>
        <TR>
          <TD WIDTH='100%'><B><FONT SIZE='-1' FACE='Tahoma'><center>Offline CC Breakdown</FONT></B></TD> 
        </TR>
        <TR>
          <TD WIDTH='100%'><TABLE WIDTH='225' BORDER='0' CELLSPACING='1'
            CELLPADDING='1'>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Monthly</FONT></TD>
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='m1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='m2.gif' WIDTH='$permonth_offline' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$permonth_offline%'><IMG SRC='m3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD>
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_monthly_income_offline</FONT></TD>
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Quarterly</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='q1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='q2.gif' WIDTH='$quarterly_offline' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$quarterly_offline%'><IMG SRC='q3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_quarterly_income_offline</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Semi-Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='sa1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='sa2.gif' WIDTH='$semiannual_offline' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$semiannual_offline%'><IMG SRC='sa3.gif' WIDTH='2' HEIGHT='10'
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_semiannual_income_offline</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><FONT SIZE='-2'
                   FACE='Tahoma'>Annual</FONT></TD> 
                <TD WIDTH='110' BGCOLOR='#e8e8e8'><IMG SRC='a1.gif' WIDTH='2'
                  HEIGHT='10' ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'><IMG 
                  SRC='a2.gif' WIDTH='$annual_offline' HEIGHT='10' ALIGN='BOTTOM' BORDER='0'
                  NATURALSIZEFLAG='0' title='$annual_offline%'><IMG SRC='a3.gif' WIDTH='2' HEIGHT='10' 
                  ALIGN='BOTTOM' BORDER='0' NATURALSIZEFLAG='3'></TD> 
                <TD WIDTH='55' BGCOLOR='#dbedf9'><FONT SIZE='-2' FACE='Arial'>$currency$total_annual_income_offline</FONT></TD> 
              </TR>
              <TR>
                <TD WIDTH='65' ALIGN='RIGHT' BGCOLOR='#dbedf9'><B><FONT SIZE='-2'
                   FACE='Tahoma'>All Cycles:</FONT></B></TD> 
                <TD COLSPAN='2' BGCOLOR='#dbedf9'><B><FONT SIZE='-2' FACE='Tahoma'>$currency$allcycles_offline</FONT></B></TD> 
                 
              </TR>
              <TR>
                <TD COLSPAN='3' BGCOLOR='#dbedf9'><img src='".$http_images."/space.gif' width='1' height='6'></TD> 
                 
              </TR>
            </TABLE></TD>
        </TR>
      </TABLE></TD>
  </TR>
</TABLE>
		");
	}
echo("
</td> 
					</tr>
				</table>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
<table width='100%' cellpadding='0' cellspacing='0' border='0'>
	<tr>
		<td><img src='".$http_images."/space.gif' width='1' height='6'></td>
	</tr>
</table>
");
?>