<?PHP
echo("
<table width='530' border='0' cellspacing='0' cellpadding='0' bgcolor='40a3de' height='25' style='border-top: solid; border-left: solid; border-right: solid; border-color: 53afe5; border-width: 1pxl'>
	<tr>
		<td width='100%'><b><font COLOR='#FFFFFF' SIZE='-2' face='Verdana'>(".$open_trouble_tickets.")
		Active trouble Ticket</font></b></td>
	</tr>
</table>
<table width='530' border='0' cellspacing='1' cellpadding='2' style='border-left: solid; border-right: solid; border-bottom: solid; border-color: #53afe5; border-width: 1pxl'>
	");
echo $active_ticket_details;
echo("
</table>
<table width='530' border='0' cellspacing='0' cellpadding='2' style='border-bottom: solid; border-left: solid; border-right: solid; border-color: 53afe5; border-width: 1pxl'>
	<tr>
		<td width='50%' bGCOLOR='#a5daf9'><font SIZE='-2' face='Verdana'><a href='".$http_admin."/trouble_ticket_closed.php?sid=".trim($sid)."' style='color:000000;'>View All Resolved Tickets</A></font></td> 
		<td width='50%' bGCOLOR='#a5daf9'></td>
	</tr>
</table>
<table width='530' border='0' cellspacing='0' cellpadding='0'>
	<tr>
	  <td width='100%'><img src='".$http_images."/space.gif' width='1' height='10' ALIGN='bottom' border='0' naturalsizeflag='0'></td> 
	</tr>
</table>
	");
?>