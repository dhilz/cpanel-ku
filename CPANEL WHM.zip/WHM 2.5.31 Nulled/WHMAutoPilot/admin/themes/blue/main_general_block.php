<?PHP
$rs_a=mysql_fetch_row(mysql_query("select status from payment_process where pid='8'"));
$rs_aa=mysql_fetch_row(mysql_query("select status from payment_process where pid='10'"));
$rs_admail=mysql_fetch_row(mysql_query("select email_admin from config"));
$noadminmail=$rs_admail[0];
$rs_gateways=mysql_fetch_row(mysql_query("select count(*) from payment_process where status='1'"));
$nogateways=$rs_gateways[0];
if ($nogateways==0)
	{ echo("
		<table width='530' cellpadding='2' cellspacing='3' style='border-style: solid; border-color: 990000; border-width: 1pxl' align='left' bgcolor='ffcaca'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>No active payment gateways setup yet - orders will not process until gateways are setup, activated<BR><img src='".$http_images."/space.gif' width='25' height='9'>and also active <B>per package group</td> 
			</tr>
			
		</table><BR><BR><BR>
		");
	}
if ($noadminmail=="")
	{
	echo("
		<table width='530' cellpadding='2' cellspacing='3' style='border-style: solid; border-color: 990000; border-width: 1pxl' align='left' bgcolor='ffcaca'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>No Admin email is set yet.  Emails will fail without this setting updated.  Please <a href='".$http_admin."/config_editor.php?sid=".trim($sid)."'>click here</a> to update now.</td> 
			</tr>
			
		</table><BR><BR><BR>
		");
	}
echo("
<!--- END OG THEME BLOCK --->
<table width='530' border='0' cellspacing='0' cellpadding='0' bgcolor='40a3de' height='25' style='border-top: solid; border-left: solid; border-right: solid; border-color: 53afe5; border-width: 1pxl'>
	<tr>
	  <td width='100%'><b><FONT COLOR='#FFFFFF' SIZE='-2' face='Verdana'>      General Administration Links</FONT></b></td>
	</tr>
</table>
<table width='530' border='0' cellspacing='1' cellpadding='2' style='border-left: solid; border-right: solid; border-bottom: solid; border-color: #53afe5; border-width: 1pxl'>
	<tr>
	  <td width='50%' bgcolor='#dbedf9'><a href='".$http_admin."/dbbackup.php?sid=".trim($sid)."&which=1'>Manually Backup Database</a></td> 
	  <td width='50%' bgcolor='#dbedf9'><a href='".$http_admin."/edit_client_news.php?sid=".trim($sid)."'>Edit Client Area News</a></td>
	</tr>
	<tr>
	  <td width='50%' bgcolor='#dbedf9'><a href='".$http_admin."/edit_templates.php?sid=".trim($sid)."'>Edit Email Templates</a></td> 
	  <td width='50%' bgcolor='#dbedf9'><a href='".$http_admin."/manage_admin.php?sid=".trim($sid)."'>Manage Administrators</a></td>
	</tr>
	<tr>
	  <td width='50%' bgcolor='#dbedf9'><a href='".$http_admin."/edit_affiliate_paragraph.php?sid=".trim($sid)."'>Edit Affiliate Details Paragraph</a></td> 
	  <td width='50%' bgcolor='#dbedf9'><a href='".$http_admin."/client_email.php?sid=".trim($sid)."'>Email Users</a></td>
	</tr>
	");
$ic0=mysql_fetch_row(mysql_query("select count(*) from session_history where locked='1'"));
$ic1=mysql_fetch_row(mysql_query("select count(*) from domains where status='0'"));
$ic2=mysql_fetch_row(mysql_query("select count(*) from authnet_batch where batch_status='0'"));
$ic3=mysql_fetch_row(mysql_query("select count(*) from linkpoint_holding_queue where status='1'"));
echo("
	<tr>
	  <td width='50%' bgcolor='#dbedf9'><a href='".$http_admin."/manage_session_history.php?sid=".trim($sid)."'>Manage Incomplete Orders</a>&nbsp;&nbsp;[&nbsp;".(($ic0[0]>0)?"<a href='".$http_admin."/manage_session_history.php?sid=".trim($sid)."'>":"")."".$ic0[0]."".(($ic0[0]>0)?"</a>":"")."&nbsp;]</td> 
	  <td width='50%' bgcolor='#dbedf9'><a href='".$http_admin."/enom_incomplete.php?sid=".$sid."'>Manage Incomplete Enom Orders</a>&nbsp;&nbsp;[&nbsp;".(($ic1[0]>0)?"<a href='".$http_admin."/enom_incomplete.php?sid=".trim($sid)."'>":"")."".$ic1[0]."".(($ic1[0]>0)?"</a>":"")."&nbsp;]<!---<a href='".$http_admin."/addon_migration.php?sid=".trim($sid)."'>Migrate Pre-Version 2.1.0 Addons</a>---></td>
	</tr>
	<tr>
	  <td width='50%' bgcolor='#dbedf9'><a href='".$http_admin."/config_editor.php?sid=".trim($sid)."'><B><font color='red'>Edit WHM AutoPilot Configuration</b></font></a></td> 
	  <td width='50%' bgcolor='#dbedf9'>".(($rs_a[0]==1)?"<a href='".$http_admin."/manage_batch.php?sid=".trim($sid)."'>Manage Authorize.net  Batch</a>&nbsp;&nbsp;[&nbsp;".(($ic2[0]>0)?"<b><a href='".$http_admin."/view_batch.php?sid=".trim($sid)."&c=0'>":"")."".$ic2[0]."".(($ic2[0]>0)?"</a></b>":"")."&nbsp;Open]":"")."</td>
	</tr>
	<tr>
	  <td width='50%' bgcolor='#dbedf9'><a href='".$http_admin."/fraudcall.php?sid=".$sid."'>Varilogix Fraud Call Configuration</a> <font color='999999'> [BETA]</td> 
	  <td width='50%' bgcolor='#dbedf9'><a href='".$http_admin."/admin_access.php?sid=".$sid."'>Admin Area Access Configuration [IP Lock]</a></td>
	</tr>
	<tr>
	  <td width='50%' bgcolor='#dbedf9'><a href='".$http_admin."/fg_config.php?sid=".trim($sid)."' target='_blank'>FraudGate Configuration</a> <font color='999999'> [ testing ]</td> 
	  <td width='50%' bgcolor='#dbedf9'>".(($rs_aa[0]==1)?"<a href='".$http_admin."/linkpoint_holding.php?sid=".trim($sid)."'>Manage LinkPoint Periodic Billings</a>&nbsp;&nbsp;[&nbsp;".(($ic3[0]>0)?"<b><a href='".$http_admin."/linkpoint_holding.php?sid=".trim($sid)."&c=0'>":"")."".$ic3[0]."".(($ic3[0]>0)?"</a></b>":"")."&nbsp;Open]":"")."</td>
	</tr>
</table>

<table width='530' border='0' cellspacing='0' cellpadding='0'>
	<tr>
	  <td width='100%'><img src='".$http_images."/space.gif' width='1' height='10' ALIGN='bottom' border='0' naturalsizeflag='0'></td> 
	</tr>
</table>
<!--- END OG THEME BLOCK --->
	");
?>
