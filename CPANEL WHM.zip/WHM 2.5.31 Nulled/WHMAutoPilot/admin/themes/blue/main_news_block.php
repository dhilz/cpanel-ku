<?PHP
$keep.="Quick Links:";
$keep.="<br>---> <a href='".$http_admin."/redirect.php?pushed=http://www.whmautopilot.com/bugs' target='_blank'>Report A Bug</a>";
$keep.="<br>---> <a href='".$http_admin."/redirect.php?pushed=http://www.whmautopilot.com/support' target='_blank'>Contact AP Support</a>";
$keep.="<br>---> <a href='".$http_admin."/redirect.php?pushed=http://www.whmautopilot.com/forum' target='_blank'>Visit AP support forums</a>";
$keep.="<br>---> <a href='".$http_admin."/redirect.php?pushed=http://whmautopilot.com/forum/index.php?showforum=8' target='_blank'>Read All Script News & Updates</a>";
echo("
<!--- START SIDE BAR BLOCK --->
<table width='230' BORDER='0' CELLSPACING='0' CELLPADDING='0'>
	<tr>
		<td width='100%'><IMG SRC='".$http_images."/scriptnews.jpg'
		width='230' HEIGHT='34' ALIGN='BOTTOM' BORDER='0' NATURALsizeFLAG='3'></td> 
	</tr>
	<tr>
		<td width='100%'>
		<table width='230' BORDER='0' CELLSPACING='0' CELLPADDING='0' style='border-bottom: solid; border-left: solid; border-right: solid; border-color: #53afe5; border-width: 1pxl'>
			<tr>
				<td width='100%' BGCOLOR='#dbedf9'>
				<table width='100%' BORDER='0' CELLSPACING='2' CELLPADDING='2'>
					<tr>
						<td width='225'><font size='-2' FACE='Verdana'>".$keep."</font></td> 
					</tr>
				</table>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
<table width='100%' cellpadding='0' cellspacing='0' border='0'>
	<tr>
		<td><img src='".$http_images."/space.gif' width='1' height='6'></td>
	</tr>
</table>
<!--- END SIDE BAR BLOCK --->
	");
?>