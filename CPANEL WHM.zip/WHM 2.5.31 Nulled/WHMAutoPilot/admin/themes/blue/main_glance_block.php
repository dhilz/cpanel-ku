<?PHP
echo("
<!--- START SIDE BAR BLOCK --->
<table width='230' BORDER='0' CELLSPACING='0' CELLPADDING='0'>
	<tr>
		<td width='100%'><IMG SRC='".$http_images."/systemstats.jpg'
		width='230' HEIGHT='34' ALIGN='BOTTOM' BORDER='0' NATURALsizeFLAG='3'></td> 
	</tr>
	<tr>
		<td width='100%'>
		<table width='230' BORDER='0' CELLSPACING='0' CELLPADDING='0' style='border-bottom: solid; border-left: solid; border-right: solid; border-color: #53afe5; border-width: 1pxl'>
			<tr>
				<td width='100%' BGCOLOR='#dbedf9'>
				<table width='100%' BORDER='0' CELLSPACING='2' CELLPADDING='2'>
					<tr>
						<td width='225'><font size='-2' FACE='verdana'>Total Active Hosting Accounts: <B>".$total_active_accounts."</B></font></td> 
					</tr>
					<tr>
						<td width='225'><font size='-2' FACE='verdana'>Total Active Resellers: <B>".$total_active_resellers."</B></font></td> 
					</tr>
					<tr>
						<td width='225'><font size='-2' FACE='verdana'>Total Dedicated Servers: <B>".$dct[0]."</B></font></td> 
					</tr>
					<tr>
						<td width='225'><font size='-2' FACE='verdana'>Total Servers (WHM): <B>".$total_servers."</B></font></td> 
					</tr>
					<tr>
						<td width='225'><font size='-2' FACE='verdana'>Active Server (WHM):<br><B>".$current_server_name."</B></font></td> 
					</tr>
					<tr>
						<td width='225'><font size='-2' FACE='verdana'>Domains Unresolved: <B>".$total_unresolved."</B></font></td> 
					</tr>
				<!---	<tr>
						<td width='225'><font size='-2' FACE='verdana'>Est. Monthly Income: <B>".$currency."".$total_monthly_income."".$currency_type."</B></font></td> 
					</tr> --->
					<tr>
						<td width='225'><font size='-2' FACE='verdana'><B>Recurring Income Summary:</B><br>".$payment_type_amount."</font></td> 
					</tr>
				</table>
				</td>
			</tr>
		</table>
		</td>
	</tr>
</table>
<table width='100%' cellpadding='0' cellspacing='0' border='0'>
	<tr>
		<td><img src='".$http_images."/space.gif' width='1' height='6'></td>
	</tr>
</table>
<!--- END SIDE BAR BLOCK --->
	");
?>