<?
/*
LquiD's Magick Zend/ionCube UnFucker V. 0.8.2.5 R2
   LquiD's Magick Zend/ionCube UnFucker is a 
   Decoder for Zend Encoded/SafeGuarded files
####################################################
       Version Information, Debug Output
####################################################
PHP Version 4.4.2 [hacked] | DeCompile Wrapper Version V 0.5.7.3 R4
####################################################
Decompiled By: LquiD of VST | http://vsteam.uk.to
*/


  function call_home ($server_ip, $server_name, $license, $call_home_to, $install_dir)
  {
  $ret == 1;
    return $ret;
  }

  function parse_template ($template)
  {
    $fh = file ($template);
    foreach ($fh as $line_num => $line)
    {
      if ($line_num == 0)
      {
        $data = $line;
        continue;
      }
      else
      {
        $data .= $line;
        continue;
      }
    }

    return $data;
  }


?>
