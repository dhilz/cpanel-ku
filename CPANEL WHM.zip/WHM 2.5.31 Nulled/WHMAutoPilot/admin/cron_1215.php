<?PHP
include"../inc/var.php";
include "../inc/connect.php";

$http_admin=str_replace("https", "http", $http_admin);

# run the invoice cron
$read=@fopen($http_admin."/cron_invoice.php", "r");
$result=@fread($read, filesize($server_admin."/cron_invoice.php"));
@fclose($read);
# die($result);

/*
# run the authnet batch cron
$read=@fopen($http_admin."/cron_authnet.php", "r");
$result=@fread($read, filesize($server_admin."/cron_authnet.php"));
@fclose($read);
*/

# run the affiliate cron
$read=@fopen($http_admin."/cron_affiliate.php", "r");
$result=@fread($read, filesize($server_admin."/cron_affiliate.php"));
@fclose($read);

# run the database backup cron
$read=@fopen($http_admin."/cron_dbbackup.php", "r");
$result=@fread($read, filesize($server_admin."/cron_dbbackup.php"));
@fclose($read);
?>