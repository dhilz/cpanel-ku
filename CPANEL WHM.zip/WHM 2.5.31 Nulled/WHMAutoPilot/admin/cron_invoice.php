<?PHP
include"../inc/var.php";
include "../inc/connect.php";  
include "../inc/whm_functions.php";  
include "../inc/invoice_functions.php";  

/*
# Debbugging 6/18/2004
$query0="select ";
$query0.="count(hosting_order.oid) ";		// 0
$query0.="from ";
$query0.="hosting_order, user ";
$query0.="where ";
$query0.="hosting_order.uid=user.uid ";
$query0.="and ";
$query0.="hosting_order.status='1' ";
$query0.="order by oid asc ";

$rs=mysql_Fetch_row(mysql_query($query0));
echo $rs[0]; die;
*/

$query0="select ";
$query0.="hosting_order.next_due_date, ";		// 0
$query0.="hosting_order.domain_name, ";			// 1
$query0.="hosting_order.payment_method, ";		// 2
$query0.="hosting_order.payment_term, ";		// 3
$query0.="hosting_order.total_due_reoccur, ";	// 4
$query0.="user.first_name, ";					// 5
$query0.="user.email, ";						// 6
$query0.="hosting_order.oid, ";					// 7
$query0.="hosting_order.total_due_today, ";		// 8
$query0.="hosting_order.total_due_reoccur, ";	// 9
$query0.="hosting_order.addon_choices, ";		// 10
$query0.="hosting_order.pid, ";					// 11
$query0.="hosting_order.uid ";					// 12
$query0.="from ";
$query0.="hosting_order, user ";
$query0.="where ";
$query0.="hosting_order.uid=user.uid ";
$query0.="and ";
$query0.="hosting_order.status='1' ";
$query0.="order by oid asc ";

$row0=mysql_query($query0);
while ($rs0=mysql_fetch_row($row0))
	{
	# Query ---------------------------------------------------------------------
	$next_due_date=stripslashes(trim($rs0[0]));
	if (trim($next_due_date)=="") { $next_due_date=-1; }
	$domain_name=stripslashes(trim($rs0[1]));
	$payment_method=stripslashes(trim($rs0[2])); # <-- if == 8 == authnet == create batch
	$payment_term=stripslashes(trim(strtolower(str_replace("-", "_", $rs0[3]))));
	$total_due_reoccur=stripslashes(trim($rs0[4]));
	$first_name=stripslashes(trim($rs0[5]));
	$email=stripslashes(trim($rs0[6]));
	$oid=stripslashes(trim($rs0[7]));
	$total_due_today=stripslashes(trim($rs0[8]));
	$total_due_reoccur=stripslashes(trim($rs0[9]));
	$addon_choices=stripslashes(trim($rs0[10]));
	$processor_id=stripslashes(trim($rs0[11]));
	$uid=stripslashes(trim($rs0[12]));
	
	# debugging 6/18/2004
	# if ($oid==484) { die($domain_name); }
	# if ($oid==484) { die($total_due_today); }
	# if ($oid==484) { die($total_due_reoccur); }
	# -------------------------------------------------------------------------

	$query7="select ";
	$query7.="monthly_pid, ";			// 11
	$query7.="quarterly_pid, ";		// 12
	$query7.="semi_annual_pid, ";		// 13
	$query7.="annual_pid ";			// 14
	$query7.="from ";
	$query7.="plan_specs ";
	$query7.="where pid='".addslashes($processor_id)."'";
	
	$rs7=mysql_fetch_row(mysql_query($query7));

	$monthly_pid=stripslashes(trim($rs7[0]));
	$quarterly_pid=stripslashes(trim($rs7[1]));
	$semi_annual_pid=stripslashes(trim($rs7[2]));
	$annual_pid=stripslashes(trim($rs7[3]));

	# -------------------------------------------------------------------------

	if ($payment_term=="monthly") { $payment_term=1; $checkout_id=$monthly_pid; }
	else if ($payment_term=="quarterly") { $payment_term=3; $checkout_id=$quarterly_pid; }
	else if ($payment_term=="semi_annual") { $payment_term=6; $checkout_id=$semi_annual_pid; }
	else if ($payment_term=="annual") { $payment_term=12; $checkout_id=$annual_pid; }
	
	# -------------------------------------------------------------------------

	$query2="select ";
	$query2.="name ";
	$query2.="from ";
	$query2.="payment_process ";
	$query2.="where ";
	$query2.="pid='".addslashes(trim($payment_method))."'";

	$rs2=mysql_fetch_row(mysql_query($query2));

	$payment_processor_name=stripslashes(trim($rs2[0]));

	# -------------------------------------------------------------------------
	
	/*
	RETIRED 5/27/2004

	# shadow from previous invoice or create new master invoice?		
	$query2="select ";
	$query2.="iid ";
	$query2.="from ";
	$query2.="invoice ";
	$query2.="where ";
	$query2.="invoice_type='0' ";
	$query2.="and ";
	$query2.="oid='".addslashes(trim($oid))."' ";
	$query2.="and ";
	$query2.="master='1'";

	$rs2=mysql_fetch_row(mysql_query($query2));

	$iid=stripslashes(trim($rs2[0]));
	if (trim($iid)=="") { unset($iid); }
	*/

	$invoice_number=grab_invoice_number();

	# -------------------------------------------------------------------------
	
	# integrity check
	# if (date("m/d/Y", $next_due_date)=="12/31/1969")
	if (is_valid_date($next_due_date)===0)
		{ 
		$headers="From: ".$email_admin;
		$headers.="\nReply-To: ".$email_admin;
		$headers.="\nX-Mailer: PHP/".phpversion();
		
		$subject="Invalid Next Due Date: ".$domain_name;
				
		$message=("Greetings ".$first_name.",\nPlease log into your AutoPilot and correct this date.\n\nThanks,\nWeb Support Team\n\nThis email was generated on: ".date("m/d/Y h:i:s a"));

		mail($email_admin, $subject, $message, $headers);
		}
	else
		{
		# email notice
		$m=date("m", $next_due_date);
		$d=date("d", $next_due_date);
		$y=date("Y", $next_due_date);
		$notice_days=sprintf("%01.0f", $invoice_notice_period/84600);
		$modified_due_date=mktime(0, 0, 0, $m, ($d-$notice_days), $y);

		if (strcmp(date("mdY", $modified_due_date), date("mdY", time()))==0)
			{
			$headers="From: ".$email_admin;
			$headers.="\nReply-To: ".$email_admin;
			$headers.="\nX-Mailer: PHP/".phpversion();
			
			$days_until_due=sprintf("%01.0f", ($invoice_notice_period/(3600*24)));
			invoice_due_in_x_days($email_admin, $first_name, $domain_name, $total_due_reoccur, $payment_processor_name, $email, $notice_days, 0);
			}
		
		# ---------------------------------------------------------------------------
		# debugging 6/18/2004
		# if ($oid==484) { echo "here"; }

		if ($modified_due_date<=time())
			{
			# if ($oid==484) { echo "there"; } die;
			/*
			RETIRED 5/27/2004

			if (isset($iid))
				{
				# pull data from last invoice		
				$query4="select ";	
				$query4.="total_due_reoccur, ";	// 0
				$query4.="extras, ";			// 1
				$query4.="total_due_today ";	// 2
				$query4.="from ";
				$query4.="invoice ";
				$query4.="where ";
				$query4.="invoice_type='0' ";
				$query4.="and ";
				$query4.="oid='".addslashes(trim($oid))."'";
				$query4.="and ";
				$query4.="master='1'";
				
				$rs4=mysql_fetch_row(mysql_query($query4));

				$total_due_reoccur=stripslashes(trim($rs4[0]));
				$extras=stripslashes($rs4[1]);
				$total_due_today=stripslashes(trim($rs4[2]));

				$extra_buffer="";
				$xct=(substr_count($extras, "\n")-1);
				$xarr=explode("\n", $extras);
				for ($i=0; $i<=$xct; $i++)
					{
					if (ereg("one time", $xarr[$i])!=true&&trim($xarr[$i])!="") { $extra_buffer.=$xarr[$i]."\n"; }
					}
				
				# reset the master
				$query5="update ";
				$query5.="invoice ";
				$query5.="set ";
				$query5.="master='0' ";
				$query5.="where ";
				$query5.="invoice_type='0' ";
				$query5.="and ";
				$query5.="oid='".addslashes(trim($oid))."'";
				$query5.="and ";
				$query5.="master='1'";

				mysql_query($query5);

				# create a new master
				$query6="insert ";
				$query6.="into ";
				$query6.="invoice ";
				$query6.="set ";
				$query6.="oid='".addslashes(trim($oid))."', ";
				$query6.="due_date='".addslashes(trim($next_due_date))."', ";
				$query6.="created='".addslashes(trim($next_due_date))."', ";
				$query6.="invoice_number='".addslashes(trim($invoice_number))."', ";
				if (trim($extra_buffer)!="") { $query6.="extras='".addslashes($extra_buffer)."', "; }
				$query6.="payment_method='".addslashes(trim($payment_method))."', ";
				$query6.="total_due_reoccur='".addslashes(trim($total_due_reoccur))."', ";
				$query6.="invoice_type='0', ";
				$query6.="status='0', ";
				$query6.="master='1'";
				
				mysql_query($query6);
				}
			else
				{
			*/
			
			# added 6/14/2004
			$query5="select ";
			$query5.="count(*) ";
			$query5.="from ";
			$query5.="invoice ";
			$query5.="where ";
			$query5.="invoice_type='0' ";
			$query5.="and ";
			$query5.="oid='".addslashes(trim($oid))."' ";
			$query5.="and ";
			$query5.="master='1'";
			
			$rs5=mysql_fetch_row(mysql_query($query5));
			
			# debugging 6/18/2004
			# if ($oid==484) { echo $query5; die($rs5[0]); }

			if ($rs5[0]>=1)
				{
				# reset the master
				$query5="update ";
				$query5.="invoice ";
				$query5.="set ";
				$query5.="master='0' ";
				$query5.="where ";
				$query5.="invoice_type='0' ";
				$query5.="and ";
				$query5.="oid='".addslashes(trim($oid))."' ";
				$query5.="and ";
				$query5.="master='1'";

				mysql_query($query5);
				
				$v=1;
				}
			else { $v=0; }

			$query3="insert ";
			$query3.="into ";
			$query3.="invoice ";
			$query3.="set ";
			$query3.="oid='".addslashes(trim($oid))."', ";
			
			# $query3.="due_date='".addslashes(trim($next_due_date))."', ";
			$query3.="due_date='".addslashes(trim($next_due_date))."', "; # changed 10/13/2003

			# $query3.="created='".time()."', ";
			$query3.="created='".addslashes(trim($next_due_date))."', "; # changed 10/13/2003

			$query3.="invoice_number='".addslashes(trim($invoice_number))."', ";
			
			# added 6/14/2004
			if ($v<=0) { $query3.="total_due_today='".addslashes(trim($total_due_today))."', "; }
			else { $query3.="total_due_today='0', "; }

			$query3.="total_due_reoccur='".addslashes(trim($total_due_reoccur))."', ";
			$query3.="payment_method='".addslashes(trim($payment_method))."', ";
			
			$extras=build_hosting_extras($addon_choices);
			if (strcmp($extras, "0")!=0) { $query3.="extras='".addslashes(trim($extras))."', "; }

			$query3.="invoice_type='0', ";
			$query3.="status='0', ";
			$query3.="master='1'";
			
			mysql_query($query3);

			#	}
			

			# reset next due date
			# if ($next_due_date<time())
			if ($modified_due_date<=time())
				{
				$authnet_due_date=$next_due_date;
				$next_due_date=create_next_due($next_due_date, $payment_term);
				
				$query1="update ";
				$query1.="hosting_order ";
				$query1.="set ";
				$query1.="next_due_date='".addslashes(trim($next_due_date))."' ";
				$query1.="where ";
				$query1.="oid='".addslashes(trim($oid))."'";

				mysql_query($query1);
				
				if ($payment_method==8) { include $server_admin_tools."/authnet_batch.php"; }
				}
			
			unset($v);
			}
		}
	}

daily_invoice_summary($email_admin, 0);
daily_invoice_summary_service($email_admin, 0);

$query="select ";
$query.="invoice.iid, ";		// 0
$query.="hosting_order.uid ";	// 1
$query.="from ";
$query.="invoice, hosting_order ";
$query.="where ";
$query.="invoice.oid=hosting_order.oid ";
$query.="and ";
$query.="invoice.invoice_type='0' ";
$query.="order by ";
$query.="invoice.oid asc";

$row=mysql_query($query);
while ($rs=mysql_fetch_row($row))
	{
	$query="update ";
	$query.="invoice ";
	$query.="set ";
	$query.="uid='".$rs[1]."' ";
	$query.="where ";
	$query.="iid='".$rs[0]."'";
	
	if (!mysql_query($query)) { $x+=1; echo "IID: ".$rs[0]." Failed. The UID is: ".$rs[1]."<br />"; }

	$g+=1;
	}
?>