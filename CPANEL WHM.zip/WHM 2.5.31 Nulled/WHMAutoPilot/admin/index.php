<?
/*
*/


  if (!(file_exists ('../inc/var.php')))
  {
    header ('Location: ../inc/install.php');
    exit ();
  }

  include '../inc/var.php';
  include '../inc/connect.php';
  include '../inc/languages/english.php';
  include '../inc/client_functions.php';
  include '../inc/whm_functions.php';
  include '../inc/login_functions.php';
  $locate_access_logs = $below_public . '/access_logs';
  if (!(is_writable ($locate_access_logs)))
  {
    echo '<center><table width=\'500\' cellpadding=\'' . $error_table_padding . '\' cellspacing=\'' . $error_table_spacing . '\' ' . $error_table_border . ' align=\'' . $error_table_align . '\' bgcolor=\'' . $error_table_bgcolor . '\'>
			<tr>
				<td align=\'left\' valign=\'top\'><img src=\'' . $http_images . '/space.gif\' width=\'9\' height=\'9\'><div style=\'padding-left:10;padding-bottom:5\' class=\'tah10\'><center><B>Post Login Checks show an item not yet completed.<BR><B><font color=\'red\'>Please CHMOD ' . $locate_access_logs . ' to 777 Before Logging In</td> 
			</tr>
			
		</table></center>
			';
  }

  list ($a, $b, $c) = explode ('{{', $data);
  function parse_template ($template)
  {
    $buffer = '';
    $fh = file ($template);
    foreach ($fh as $line)
    {
      $buffer .= $line;
    }

    return $buffer;
  }

  if (isset ($define_admin))
  {
    include $server_admin_tools . '/define_admin_check.php';
  }

  if (isset_admin () == 0)
  {
    include '../inc/header.php';
    $not_show = true;
    include $server_admin_tools . '/define_admin.php';
    mysql_close ($dblink);
    include '../inc/footer.php';
    exit ();
  }

  if (isset ($submit))
  {
    add2log ($below_public, 'Attempted Login', $username);
    if (trim ($username) == '')
    {
      $err = true;
    }

    if (trim ($password) == '')
    {
      $err = true;
    }

    $lookup = admin_lookup_username ($username);
    if ($lookup == 0)
    {
      $err = true;
    }

    if (!($err))
    {
      if (admin_validate_password ($password, $lookup) == 0)
      {
        $sid = admin_update_session ($lookup);
        add2log ($below_public, 'Logged in Successfully', $username);
        header ('Location: ' . $http_admin . '/index2.php?sid=' . $sid);
        exit ();
      }

      $err = true;
    }

    if (isset ($err))
    {
      add2log ($below_public, 'Login Failed', $username);
      invalid_admin_login_attempt ($email_admin, $username, $password);
    }
  }

  if (isset ($submitx))
  {
    if (check_ct_admin_by_email ($email) <= '0')
    {
      if (strlen (trim ($email)) == 0)
      {
        $email = 'not entered';
      }

      $err1 = true;
    }
    else
    {
      $lookup = admin_isset ($email);
      if (1 <= $lookup)
      {
        admin_recreate_password ($email, $site_name, $email_admin, admin_update_with_random ($email));
        $done = true;
      }

      $done = true;
    }
  }

  echo '
		<html>
			<head>
				<title>::< WHM AutoPilot Admin Login >::</title>
				<style type=\'text/css\'>
  <!--
img {
	border: none;
}
.tah10 {
	font-family: Tahoma;
	font-size: 11px;
	text-decoration: none;
	color: #000000;
}
.tah8 {
	font-family: Tahoma;
	font-size: 9px;
	text-decoration: none;
	color: #999999;
}
-->
</style>
			</head>
		</body>
		<form action=\'' . $PHP_SELF . '\' method=\'POST\'>
		<CENTER><BR><BR><BR><TABLE WIDTH=\'264\' BORDER=\'0\' CELLSPACING=\'0\' CELLPADDING=\'0\'>
  <TR>
    <TD WIDTH=\'100%\'><IMG SRC=\'' . $http_images . '/admin_top.jpg\' WIDTH=\'264\'
      HEIGHT=\'41\' ALIGN=\'BOTTOM\' BORDER=\'0\' NATURALSIZEFLAG=\'3\'></TD> 
  </TR>
  <TR>
    <TD WIDTH=\'100%\' BACKGROUND=\'' . $http_images . '/admin_tb_back.jpg\'>
		<table width=\'100%\' cellpadding=\'2\' cellspacing=\'0\' border=\'0\'>
		<tr>
			<td colspan=\'2\'><img src=\'' . $http_images . '/space.gif\' width=\'1\' height=\'5\'></td>
		</tr>
		<tr>
			<td colspan=\'2\'><div style=\'padding-left:10;\' class=\'tah10\'><b>Login to Admin</b></div><div style=\'padding-left:10;padding-bottom:5\' class=\'tah8\'>Invalid access is logged & notification sent to site admin</td>
		<tr>
		<tr>
			<td colspan=\'2\'><img src=\'' . $http_images . '/space.gif\' width=\'1\' height=\'1\'></td>
		</tr>
		';
  if (isset ($err))
  {
    echo '
		<tr>
			<td colspan=\'2\'><img src=\'' . $http_images . '/space.gif\' width=\'15\' height=\'2\'><div style=\'padding-left:10;padding-bottom:5\' class=\'tah10\'><img src=\'' . $http_images . '/error_arrow.gif\'><font color=\'red\'><B>Authentication Failed.</font></b></div><div style=\'padding-left:10;padding-bottom:5\' class=\'tah8\'>A notification has been sent to the site admin with your attempt details including your IP address</td>
		</tr>
		<tr>
			<td colspan=\'2\'><img src=\'' . $http_images . '/space.gif\' width=\'1\' height=\'2\'></td>
		</tr>
		';
  }

  echo '
		<tr>
			<td align=\'right\' valign=\'middle\' width=\'35%\'><div style=\'padding-left:10;padding-bottom:5\' class=\'tah10\'><B>Username:</td>
			<td align=\'left\' valign=\'middle\' width=\'65%\'><input style=\'font-family:verdana, arial, helvetica; font-size: 7pt; border-style: solid; border-color: 808080; border-width: 1pxl; background-color: ffffff; font-weight: 800\' size=\'20\' maxlength=\'50\' type=\'text\' name=\'username\' value=\'' . (isset ($username) ? '' . $username . '' : '') . '\'></td>
		</tr>
		<tr>
			<td align=\'right\' valign=\'middle\' width=\'35%\'><font color=\'#000000\'><div style=\'padding-left:10;padding-bottom:5\' class=\'tah10\'><B>Password:</font></td>
			<td align=\'left\' valign=\'middle\' width=\'65%\'><input style=\'font-family:verdana, arial, helvetica; font-size: 7pt; border-style: solid; border-color: 808080; border-width: 1pxl; background-color: ffffff; font-weight: 800\' size=\'20\' maxlength=\'50\' type=\'password\' name=\'password\'></td>
		</tr>
		<tr>
			<td align=\'left\' valign=\'middle\' width=\'35%\'></td>
			<td align=\'left\' valign=\'middle\' width=\'65%\'><input style=\'font-family:verdana, arial, helvetica; font-size: 8pt; border-style: solid; border-color: 808080; border-width: 1pxl; background-color: ffffff; font-weight: 800\' type=\'submit\' name=\'submit\' value=\'Login Now\'></td>
		</tr>
	</table>
	</form>
	<form action=\'' . $PHP_SELF . '\' method=\'POST\'>
	<table width=\'100%\' cellpadding=\'2\' cellspacing=\'0\' border=\'0\'>
		<tr>
			<td colspan=\'2\'><img src=\'' . $http_images . '/space.gif\' width=\'1\' height=\'5\'></td>
		</tr>
		<tr>
			<td colspan=\'2\'><div style=\'padding-left:10;\' class=\'tah10\'><b>Resend your password</b></div><div style=\'padding-left:10;padding-bottom:5\' class=\'tah8\'>Enter your registered admin email below</td>
		<tr>
		<tr>
			<td colspan=\'2\'><img src=\'' . $http_images . '/space.gif\' width=\'1\' height=\'4\'></td>
		</tr>
		';
  if (isset ($done))
  {
    echo '
		<tr>
			<td colspan=\'2\'><img src=\'' . $http_images . '/space.gif\' width=\'15\' height=\'9\'><img src=\'' . $http_images . '/error_arrow.gif\'> Your account information was emailed successfully.</td>
		<tr>
		<tr>
			<td colspan=\'2\'><img src=\'' . $http_images . '/space.gif\' width=\'1\' height=\'4\'></td>
		</tr>
		';
  }

  if (isset ($err1))
  {
    echo '
		<tr>
			<td colspan=\'2\'><img src=\'' . $http_images . '/space.gif\' width=\'15\' height=\'2\'><div style=\'padding-left:10;padding-bottom:5\' class=\'tah10\'><img src=\'' . $http_images . '/error_arrow.gif\'><font color=\'red\'>No records found for: ' . $email . '</td>
		<tr>
		<tr>
			<td colspan=\'2\'><img src=\'' . $http_images . '/space.gif\' width=\'1\' height=\'2\'></td>
		</tr>
		';
  }

  echo '
		<tr>
			<td align=\'right\' valign=\'middle\' width=\'25%\'><div style=\'padding-left:10;padding-bottom:5\' class=\'tah10\'><B>Email:</td>
			<td align=\'left\' valign=\'middle\' width=\'75%\'><input style=\'font-family:verdana, arial, helvetica; font-size: 7pt; border-style: solid; border-color: 808080; border-width: 1pxl; background-color: ffffff\' size=\'25\' maxlength=\'255\' type=\'text\' name=\'email\' value=\'' . (isset ($email) ? '' . $email . '' : '') . '\'></td>
		</tr>
		<tr>
			<td align=\'left\' valign=\'middle\' width=\'25%\'></td>
			<td align=\'left\' valign=\'middle\' width=\'75%\'><input style=\'font-family:verdana, arial, helvetica; font-size: 8pt; border-style: solid; border-color: 808080; border-width: 1pxl; background-color: ffffff; font-weight: 800\' type=\'submit\' name=\'submitx\' value=\'Resend Now\'></td>
		</tr>
		
	</table>
	</form>
	</TD> 
  </TR>
  <TR>
    <TD WIDTH=\'100%\'><IMG SRC=\'' . $http_images . '/admin_bottom.jpg\' WIDTH=\'264\'
      HEIGHT=\'65\' ALIGN=\'BOTTOM\' BORDER=\'0\' NATURALSIZEFLAG=\'3\'></TD> 
  </TR>
</TABLE><div class=\'tah8\'>Running Version ' . $current_mib_version . '</CENTER>
	</body>
	</html>
	';
?>
