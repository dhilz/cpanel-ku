<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";

// No order id, can't show page - redirect
$oid=base64_decode($c);

include "inc/connect.php";
include "inc/client_functions.php";
include "inc/whm_functions.php";

// authenicate sid
if (auth_sid($sid)==1) { header("Location: ".$http_web."/clogin.php"); exit; }

if (isset($change_date))
	{
	$domain_parsed=$mm."/".$dd."/".$yyyy;
	mysql_query("update hosting_order set ogcreate='".addslashes(trim($ogcreate_mysql))."', domain_expire='".addslashes(trim($domain_parsed))."' where oid='".addslashes(trim($oid))."'");
	}

// build the query
$query="select ";
$query.="hosting_order.domain_name, ";		// 0
$query.="hosting_order.resolved, ";			// 1
$query.="hosting_order.ip, ";				// 2
$query.="hosting_order.resolved_time, ";	// 3
$query.="hosting_order.ur_date, ";			// 4
$query.="hosting_order.domain_expire, ";	// 5
$query.="hosting_order.whm_username, ";		// 6
$query.="hosting_order.whm_password, ";		// 7
$query.="user.sid, ";						// 8
$query.="hosting_order.ip, ";				// 9
$query.="hosting_order.ns1, ";				// 10
$query.="hosting_order.ns2, ";				// 11
$query.="hosting_order.ogcreate, ";			// 12
$query.="hosting_order.pid, ";				// 13
$query.="hosting_order.payment_term, ";		// 14
$query.="hosting_order.status, ";			// 15
$query.="hosting_order.whm_id, ";			// 16
$query.="hosting_order.payment_method, ";	// 17
$query.="user.uid, ";						// 18
$query.="hosting_order.addon_choices, ";	// 19
$query.="hosting_order.ogcreate, ";			// 20
$query.="hosting_order.client_notes, ";		// 21
$query.="plan_specs.dedicated, ";			// 22
$query.="hosting_order.pns1, ";				// 23
$query.="hosting_order.pns2, ";				// 24
$query.="hosting_order.server_hostname, ";	// 25
$query.="hosting_order.server_specs, ";		// 26
$query.="hosting_order.domain_registration, ";	// 27
$query.="hosting_order.tld_id ";	// 28
$query.="from user, hosting_order, plan_specs ";
$query.="where user.uid=hosting_order.uid ";
$query.="and hosting_order.oid='".addslashes(trim($oid))."' ";
$query.="and hosting_order.pid=plan_specs.pid ";
$query.="order by user.uid asc";

// execute the query
$rs=mysql_fetch_row(mysql_query($query));

// define variables
$domain_name=stripslashes($rs[0]);
$resolved=stripslashes($rs[1]);
$ip=stripslashes($rs[2]);
$resolved_date=stripslashes($rs[3]);
$ur_date=stripslashes($rs[4]);
$domain_expire=stripslashes($rs[5]);
$whm_username=stripslashes($rs[6]);
$whm_password=stripslashes($rs[7]);
$client_sid=stripslashes($rs[8]);
$ip=stripslashes($rs[9]);
$ns1=stripslashes($rs[10]);
$ns2=stripslashes($rs[11]);
$ogcreate_hosting=stripslashes($rs[12]);
$pid=stripslashes($rs[13]);
$payment_term=stripslashes($rs[14]);
$order_status=stripslashes($rs[15]);
$whm_id=stripslashes($rs[16]);
$payment_method=stripslashes($rs[17]);
$uid=stripslashes($rs[18]);
$addon_choices=stripslashes($rs[19]);
$ogcreate_mysql=stripslashes($rs[20]);
$client_notes=stripslashes($rs[21]);
$dedicated=stripslashes($rs[22]);
$pns1=stripslashes($rs[23]);
$pns2=stripslashes($rs[24]);
$server_hostname=stripslashes($rs[25]);
$server_specs=stripslashes($rs[26]);
$domain_reg=stripslashes($rs[27]);

// build the query
$xquery="select ";
$xquery.="package_name ";			// 0
$xquery.="from plan_specs ";
$xquery.="where pid='".addslashes(trim($pid))."'";

// execute the query
$rs0=mysql_fetch_row(mysql_query($xquery));

// define variables
$package_name=stripslashes(trim($rs0[0]));

include "inc/header.php";

// grab the payment type image
$pay_image=pay_image($payment_method, $http_images);

echo("
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td><img src='".$http_images."/menu_arrow_back.gif'><a href='".$http_web."/client_area.php?sid=".trim($sid)."&status=".trim($status)."'>".$text_goback."</a></td>
	</tr>
	<tr>
		<td><hr color='#F0EFED'></td>
	</tr>
</table>
	");

$query="select ";
$query.="password, ";
$query.="count(*), ";
$query.="expires ";
$query.="from ";
$query.="domains ";
$query.="where ";
$query.="uid='".addslashes(trim($uid))."' ";
$query.="and ";
$query.="oid='".addslashes(trim($oid))."' ";
$query.="and ";
$query.="status='1' ";
$query.="group by password";

$rs=mysql_fetch_row(mysql_query($query));

if ($domain_reg==1&&$use_enom==1)
	{
	if ($rs[1]>0) { $domain_expire=date("m/d/Y", $rs[2]); }
	}

include $server_tools."/client_view_account_info.php";

echo("
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td><img src='".$http_images."/space.gif' width='1' height='12'></td>
	</tr>
</table>
	");

if ($domain_reg==1&&$use_enom==1)
	{
	if ($rs[1]>0)
		{
		include $server_tools."/enom_info.php";
		}

	}

// End Main Process
mysql_close($dblink);
include "inc/footer.php";
?>