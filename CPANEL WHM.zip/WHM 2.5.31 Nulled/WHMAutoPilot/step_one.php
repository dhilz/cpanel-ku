<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/client_functions.php";
include $server_tools."/step_one_code[0].php";
include "inc/header.php";

echo("
<form action='".$PHP_SELF."' method='POST'>
<input type='hidden' name='sid' value='".$sid."'>
<input type='hidden' name='gid' value='".$gid."'>
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td><a href='".$http_web."/step_one.php?sid=".$sid."&gid=".$gid."'><font size='1' color='#990000'><b>".$navigate_selectpackage."</b></font></a><img src='".$http_images."/order_arrow.gif'><font size='1'>".$navigate_domainoptions."</font><img src='".$http_images."/order_arrow.gif'><font size='1'>".$navigate_addonoptions."</font><img src='".$http_images."/order_arrow.gif'><font size='1'>".$navigate_accountinfo."</font></td>
	</tr>
	<tr>
		<td><img border='0' src='".$http_images."/space.gif' width='1' height='6'></td>
	</tr>
	");

$alt0=("
	<tr>
		<td><a href='{{parse0}}'><img border='0' src='".$http_images."/order_arrow.gif'>".$stepone_viewhostingpackages1."</a></td>
	</tr>
	");

$alt1=("
	<tr>
		<td><a href='{{parse2}}'><img border='0' src='".$http_images."/order_arrow.gif'>".$stepone_viewhostingpackages2."</a></td>
	</tr>
	");

# include $server_tools."/step_one_code[1].php";

$condition0=$r[0];
$condition1=$r[1];
$condition2=$r[2];
echo parse_engine0($alt0, $alt1, $sid, $condition0, $condition1, $condition2);
$domain_registration=$domain_switch;

echo("
	<tr>
		<td><img src='".$http_images."/space.gif' width='1' height='10'></td>
	</tr>
	<tr>
		<td align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='8'></td>
	</tr>
	<tr>
		<td><img border='0' src='".$http_images."/order_arrow.gif'><b>Domain Name Options</b></td>
	</tr>
	<tr>
		<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='radio' name='domain_registration' value='0'".((isset($domain_registration))?"".(($domain_registration==0)?" checked":"")."":" checked")." id='domain_registration0'> <label for='domain_registration0'>$text_iamtransfering.</label></td>
	</tr>
");
# if ($gid!=999&&$gid!=998&&$gid!=997) extended to cover 3 groups
if ($do_registrations!=yes)
//	elseif ($gid!=2)
{
echo("
 <tr>
  <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type='radio' name='domain_registration' value='1' ".((isset($domain_registration))?"".(($domain_registration==1)?" checked":"")."":"")." id='domain_registration1'> <label for='domain_registration1'>I want ".$site_name." to register my domain, this is a new domain.</label></td>
 </tr>
 ");
}
echo("
	<tr>
		<td align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='16'></td>
	</tr>
<tr>
		<td>
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	");

if (isset($err)||isset($e0)||isset($e1)||isset($e2)) { echo "<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>"; }

if (isset($err))
	{
	echo("
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepone_errornopackage."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		");
	}

if (isset($e0))
	{
	echo("
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepone_errorpromoexpired."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		");
	}

if (isset($e1))
	{
	echo("
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepone_errorpromoinvalid."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		");
	}

if (isset($e2))
	{
	echo("
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='9' height='9'><img src='".$http_images."/error_arrow.gif'>".$stepone_errorpromoinvalid."</td> 
			</tr>
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='2'></td>
			</tr>
		");
	}

if (isset($err)||isset($e0)||isset($e1)||isset($e2))
	{
	echo("
			<tr>
				<td><img src='".$http_images."/space.gif' width='1' height='10'></td>
			</tr>
		</table>
		");
	}

echo "<table width='".$package_table_width."' cellpadding='".$package_table_padding."' cellspacing='".$package_table_spacing."' border='".$package_table_border."' align='".$package_table_align."' bgcolor='".$package_table_bgcolor."'>";
echo $buffer0;
echo("
</table></td></tr></table>
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
<tr>
		<td width='10%' align='left' valign='top'></td>
		<td width='90%' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='12'></td>
	</tr>
	<tr>
		<td colspan='2'><img border='0' src='".$http_images."/order_arrow.gif'>".$stepone_choosepayment."</td>
	</tr>
	");
echo $data[0];
echo $data[1];
echo $data[2];
echo $data[3];
echo $data[4];
echo $data[5];
echo $data[6];
echo $data[7];
echo $data[8];
echo $data[9];
echo $data[10];
echo $data[11];
echo $data[12];
echo("
</table>
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='8'></td>
	</tr>
	<tr>
		<td colspan='2'><img border='0' src='".$http_images."/order_arrow.gif'>".$stepone_promoreferralstitle."</td>
	</tr>
	<tr>
		<td width='40%' align='left' valign='top'><img src='".$http_images."/space.gif' width='32' height='1'>".$stepone_promoinput."</td>
		<td width='60%' align='left' valign='top'><input ".$orderinput_style." type='text' size='30' maxlength='255' name='promotion_code' value='".((isset($xpromotion_code))?"".$xpromotion_code."":"")."'> ".$text_optional."</td>
	</tr>
	<tr>
		<td width='40%' align='left' valign='top'><img src='".$http_images."/space.gif' width='32' height='1'>".$stepone_referralinput."</td>
		<td width='60%' align='left' valign='top'><input ".$orderinput_style." type='text' size='30' maxlength='255' name='referrer_id' value='".((isset($xreferrer_id))?"".$xreferrer_id."":"".((isset($referrer_id))?"".$referrer_id."":"")."")."'> ".$text_optional."</td>
	</tr>
	<tr>
		<td colspan='2'><img src='".$http_images."/space.gif' width='1' height='15'></td>
	</tr>
	<tr>
		<td width='40%' align='left' valign='top'></td>
		<td width='60%' align='left' valign='top'><input ".$orderbutton_style." type='submit' name='submit' value='".$stepone_submitbutton."'></td>
	</tr>
	");
if ($coisactive=="1")
			{
					echo("
					<tr>
						<td colspan='2'><BR><font size='-2'><CENTER>2Checkout.com, Inc. is an authorized retailer of goods and services provided by  <B>".$site_title."</b></CENTER></td>
					</tr>
					");
			}
echo("
</table>
</form>
	");
include "inc/footer.php";
mysql_close($dblink);
?>