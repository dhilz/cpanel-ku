<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/client_functions.php";
include $server_tools."/step_three_code[0].php";
include "inc/header.php";

echo("
<SCRIPT LANGUAGE=\"JavaScript\">
function change_tr_color(base, which, on_color) 
	{
	if (!base) { document.all(which).bgColor=on_color;}
	else { document.all(which).bgColor=''; }
	}
</SCRIPT>
<table width='".$standard_table_width."' cellpadding='2' cellspacing='0' border='0' align='center'>
	<tr>
		<td><a href='".$http_web."/step_one.php?sid=".trim($sid)."&gid=".trim($gid)."'><font size='1'>".$navigate_selectpackage."</font></a><img src='".$http_images."/order_arrow.gif'><a href='".$http_web."/step_two.php?sid=".trim($sid)."&gid=".trim($gid)."'><font size='1'>".$navigate_domainoptions."</font></a><img src='".$http_images."/order_arrow.gif'><a href='".$http_web."/step_three.php?sid=".trim($sid)."&gid=".trim($gid)."&addon_gid=".$addon_gid."'><font size='1' color='#990000'><b>".$navigate_addonoptions."</b></font></a><img src='".$http_images."/order_arrow.gif'><font size='1'>".$navigate_accountinfo."</font></td>
	</tr>
</table>
<form action='".$PHP_SELF."' method='POST' name='form'>
<input type='hidden' name='sid' value='".trim($sid)."'>
<input type='hidden' name='gid' value='".trim($gid)."'>
<table width='85%' cellpadding='2' cellspacing='0' border='0' align='center'>
	<tr>
		<td>
		<table width='".$standard_table_width."' cellpadding='2' cellspacing='0' border='0'>
			<tr>
				<td align='center' valign='middle'><font color='#990000'><b>".$text_buy."</b></font></td>
				<td align='left' valign='middle'>&nbsp;<font color='#990000'><b>".$text_addonname."</b></font></td>
				<td align='left' valign='middle'>&nbsp;<font color='#990000'><b>".$text_setupfee."</b></font></td>
				<td align='left' valign='middle'>&nbsp;<font color='#990000'><b>".$text_addoncost."</b></font></td>
			</tr>
	");

echo $display;

echo("
			<tr>
				<td colspan='4'><img src='".$http_images."/space.gif' width='1' height='16'></td>
			</tr>
			<tr>
				<td colspan='1' align='left' valign='top'></td>
				<td colspan='3' align='left' valign='top'><input ".$orderbutton_style." type='submit' name='submit' value='".$stepthree_submitbutton."'></td>
			</tr>
		</table>
		</td>
	</tr>
</table>
</form>
	");

include "inc/footer.php";
mysql_close($dblink);
?>