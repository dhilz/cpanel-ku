<?PHP
echo phpinfo();
?>