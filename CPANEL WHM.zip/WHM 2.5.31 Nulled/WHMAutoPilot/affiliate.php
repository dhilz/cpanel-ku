<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/client_functions.php";
include "inc/affiliate_functions.php";

// run this query
// ALTER TABLE `hosting_order` ADD `afuid` BIGINT( 22 ) NOT NULL ;

// authenicate sid
if (auth_sid($sid)==1) { header("Location: ".$http_web."/clogin.php"); exit; }

if (isset($request))
	{
	$rsx=mysql_fetch_row(mysql_query("select uid from user where sid='".addslashes(trim($sid))."'"));
	$uid=$rsx[0];

	mysql_query("insert into affiliate_user set uid='".addslashes(trim($uid))."', ogcreate='".time()."', status='2'");

	$done=true;
	}

include "inc/header.php";

$rs=mysql_fetch_row(mysql_query("select affiliate_user.afuid from affiliate_user, user where user.sid='".addslashes(trim($sid))."' and user.uid=affiliate_user.uid order by user.uid asc limit 0, 1"));

$afuid=$rs[0];

echo("
<table width='".$standard_table_width."' cellpadding='2' cellspacing='0' border='0'>
	<tr>
		<td><img src='".$http_images."/menu_arrow_back.gif'><a href='".$http_web."/client_area.php?sid=".trim($sid)."'>".$text_goback."</a></td>
	</tr>
	<tr>
		<td><hr color='#F0EFED'></td>
	</tr>
</table>
	");

// grab the user and email based on sid
$rs0=mysql_fetch_row(mysql_query("select email, uid from user where sid='".addslashes(trim($sid))."'"));
echo("
	<table width='".$standard_table_width."' cellpadding='2' cellspacing='0' border='0'>
		<tr>
			<td><img src='".$http_images."/menu_arrow.gif'><b>".$text_activeaffiliatemenu."</b></td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='15' height='9'>". $text_commisionratesasof .date("m/d/y h:i:s a").":</td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='1' height='1'></td>
		</tr>
	</table>
	<table width='".$standard_table_width."' cellpadding='2' cellspacing='0' border='0'>
		<tr>
			<td width='1%' align='left' valign='center'><img src='".$http_images."/the_space.gif' width='13' height='9'></td>
			<td width='99%' align='left' valign='center'>
			<table width='100%' cellpadding='2' cellspacing='1' border='0'>
				<tr>
					<td align='center' valign='center' bgcolor='#E5E7E9'><b>#</b></td>
					<td align='left' valign='center' bgcolor='#E5E7E9'>&nbsp;&nbsp;<b>".$text_packagename."</b></td>
					<td align='left' valign='center' bgcolor='#E5E7E9'>&nbsp;&nbsp;<b>".$text_commissiontype."</b></td>
					<td align='left' valign='center' bgcolor='#E5E7E9'>&nbsp;&nbsp;<b>".$text_commissionamount."</b></td>
				</tr>
		");
$i=1;
$y=1;
$row1=mysql_query("select package_name, com_type, com_rate_month, com_rate_onetime, monthly_cost, gid, pid from plan_specs where plan_status='1'");
while ($rs1=mysql_fetch_row($row1))
	{
	if ($rs1[1]!=0)
		{
		$monthly_cost=$rs1[4];
		$com_monthly=$rs1[2];
		$gid=$rs1[5];
		$pid=$rs1[6];
		if ($y==1) {$bgcolor="#F2F4F6"; $y=0;} else {$bgcolor="#ECEEF0"; $y=1;}
		echo("
			<tr>
				<td align='center' valign='center' bgcolor='".$bgcolor."'>".$i.").</td>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>&nbsp;&nbsp;".$rs1[0]."</td>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>&nbsp;&nbsp;".(($rs1[1]==0)?"No Plan Defined":"".(($rs1[1]==1)?"One Time":"Percent")."")."</td>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>".(($rs1[1]==1)?"&nbsp;&nbsp;".$currency."".$rs1[3]."".$currency_type."":"".(($rs1[1]!=0)?"&nbsp;&nbsp;".$rs1[2]."%&nbsp;&nbsp;&nbsp;[".affiliate_month_percentage($currency, $currency_type, $monthly_cost, $com_monthly)." / Month]":"N/A")."")."</td>
			</tr>
			<tr>
				<td colspan='1'></td>
				<td colspan='3' align='left' valign='center' bgcolor='".$bgcolor."'><img src='".$http_images."/drop_arrow.gif'>".$text_referrallink."<a href='".$http_web."/step_one.php?gid=".trim($gid)."&xpid=".trim($pid)."&referrer_id=".$afuid."'>".$http_web."/step_one.php?gid=".trim($gid)."&xpid=".trim($pid)."&referrer_id=".$afuid."</a></td>
			</tr>
			");
		$i++;
		}
	}
if ($i==1)
	{
	echo("
		<tr>
			<td colspan='4'><img src='".$http_images."/error_arrow.gif'> ".$text_noplansfound.".</td>
		</tr>
		");
	}
echo("
	</table>
<table width='".$standard_table_width."' cellpadding='2' cellspacing='0' border='0'>
	<tr>
		<td><img src='".$http_images."/the_space.gif' width='1' height='4'></td>
	</tr>
	<tr>
		<td><hr color='#F0EFED'></td>
	</tr>
	<tr>
		<td><img src='".$http_images."/the_space.gif' width='1' height='4'></td>
	</tr>
</table>
	<table width='".$standard_table_width."' cellpadding='2' cellspacing='0' border='0'>
		<tr>
			<td colspan='2'>".$text_yourcommissionearnings . date("m/d/y h:i:s a").":</td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='1' height='1'></td>
		</tr>
	</table>
	<table width='".$standard_table_width."' cellpadding='2' cellspacing='1' border='0'>
		<tr>
			<td colspan='4'>".$text_percbased."</td>
		</tr>
		<tr>
			<td align='center' valign='center' bgcolor='#E5E7E9'><b>#</b></td>
			<td align='left' valign='center' bgcolor='#E5E7E9'>&nbsp;&nbsp;<b>".$text_packagename."</b></td>
			<td align='left' valign='center' bgcolor='#E5E7E9'>&nbsp;&nbsp;<b>".$text_volume."</b></td>
			<td align='left' valign='center' bgcolor='#E5E7E9'>&nbsp;&nbsp;<b>% ".$text_commission."</b></td>
			<td align='left' valign='center' bgcolor='#E5E7E9'>&nbsp;&nbsp;<b>".$text_yield."</b></td>
		</tr>
		");
$g=1;
$y=1;
$row1=mysql_query("select package_name, com_rate_month, monthly_cost, pid from plan_specs where plan_status='1' and com_type='2'");
while ($rs1=mysql_fetch_row($row1))
	{
	$com_monthly=$rs1[1];

	$rs2=mysql_fetch_row(mysql_query("select SUM(total_due_to_client) from affiliate_details where pid='".addslashes(trim($rs1[3]))."' and afuid='".addslashes(trim($afuid))."' and status='1'"));
	
	$rs3=mysql_fetch_row(mysql_query("select total_amount_package, status from affiliate_details where pid='".addslashes(trim($rs1[3]))."' and afuid='".addslashes(trim($afuid))."' and status='1'"));
	$monthly_cost=$rs3[0];

	$ct0=mysql_fetch_row(mysql_query("select count(*) from affiliate_details where pid='".addslashes(trim($rs1[3]))."' and afuid='".addslashes(trim($afuid))."' and status='1'"));
	
	if ($rs3[1]==1)
		{
		if ($y==1) {$bgcolor="#F2F4F6"; $y=0;} else {$bgcolor="#ECEEF0"; $y=1;}
		echo("
			<tr>
				<td align='center' valign='center' bgcolor='".$bgcolor."'>".$g.").</td>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>
				<table width='".$standard_table_width."' cellpadding='2' cellspacing='0' border='0'>
					<tr>
						<td width='1%' align='left' valign='middle'>&nbsp;&nbsp;<a href='".$http_web."/affiliate_view.php?sid=".trim($sid)."&pid=".trim($rs1[3])."&afuid=".trim($afuid)."'><img border='0' src='".$http_images."/icon_view.gif'></a>&nbsp;&nbsp;</td>
						<td width='99%' align='left' valign='middle'>".$rs1[0]."</td>
					</tr>
				</table>
				</td>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>&nbsp;&nbsp;".$currency."".($monthly_cost*$ct0[0])."".$currency_type."</td>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>&nbsp;&nbsp;".$com_monthly."%</td>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>&nbsp;&nbsp;".$currency."".sprintf("%01.2f", $rs2[0])."".$currency_type."</td>
			</tr>
			");
		$g++;
		}
	}
if ($g==1)
	{
	echo("
		<tr>
			<td colspan='4'><img src='".$http_images."/error_arrow.gif'> ".$text_norecordsfound.".</td>
		</tr>
		");
	}
echo("
	</table>
	<table width='".$standard_table_width."' cellpadding='2' cellspacing='1' border='0'>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='1' height='12'></td>
		</tr>
		<tr>
			<td colspan='4'>".$text_onetimebased."</td>
		</tr>
		<tr>
			<td align='center' valign='center' bgcolor='#E5E7E9'><b>#</b></td>
			<td align='left' valign='center' bgcolor='#E5E7E9'>&nbsp;&nbsp;<b>".$text_packagename."</b></td>
			<td align='left' valign='center' bgcolor='#E5E7E9'>&nbsp;&nbsp;<b>".$text_volume."</b></td>
			<td align='left' valign='center' bgcolor='#E5E7E9'>&nbsp;&nbsp;<b>".$text_onetimepayout."</b></td>
			<td align='left' valign='center' bgcolor='#E5E7E9'>&nbsp;&nbsp;<b>".$text_yield."</b></td>
		</tr>
		");
$h=1;
$y=1;
$row1=mysql_query("select package_name, com_rate_onetime, monthly_cost, pid from plan_specs where plan_status='1' and com_type='1'");
while ($rs1=mysql_fetch_row($row1))
	{
	$com_onetime=$rs1[1];

	$rs2=mysql_fetch_row(mysql_query("select SUM(total_due_to_client) from affiliate_details where pid='".addslashes(trim($rs1[3]))."' and afuid='".addslashes(trim($afuid))."' and status='1'"));
	
	$rs3=mysql_fetch_row(mysql_query("select total_amount_package, status from affiliate_details where pid='".addslashes(trim($rs1[3]))."' and afuid='".addslashes(trim($afuid))."' and status='1'"));
	$monthly_cost=$rs3[0];

	$ct0=mysql_fetch_row(mysql_query("select count(*) from affiliate_details where pid='".addslashes(trim($rs1[3]))."' and afuid='".addslashes(trim($afuid))."' and status='1'"));

	if ($rs3[1]==1)
		{
		if ($y==1) {$bgcolor="#F2F4F6"; $y=0;} else {$bgcolor="#ECEEF0"; $y=1;}
		echo("
			<tr>
				<td align='center' valign='center' bgcolor='".$bgcolor."'>".$h.").</td>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>
				<table width='".$standard_table_width."' cellpadding='2' cellspacing='0' border='0'>
					<tr>
						<td width='1%' align='left' valign='middle'>&nbsp;&nbsp;<a href='".$http_web."/affiliate_view.php?sid=".trim($sid)."&pid=".trim($rs1[3])."&afuid=".trim($afuid)."'><img border='0' src='".$http_images."/icon_view.gif'></a>&nbsp;&nbsp;</td>
						<td width='99%' align='left' valign='middle'>".$rs1[0]."</td>
					</tr>
				</table>
				</td>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>&nbsp;&nbsp;".$currency."".($monthly_cost*$ct0[0])."".$currency_type."</td>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>&nbsp;&nbsp;".$currency."".$com_onetime."".$currency_type."</td>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>&nbsp;&nbsp;".$currency."".sprintf("%01.2f", $rs2[0])."".$currency_type."</td>
			</tr>
			");
		$h++;
		}
	}
if ($h==1)
	{
	echo("
		<tr>
			<td colspan='4'><img src='".$http_images."/error_arrow.gif'> ".$text_norecordfound.".</td>
		</tr>
		");
	}

echo "<table>";

# list($past_1, $past_2, $past_3)=split("[|]", past_3_months());
$x=0;
$last_three_months=past_3_months();
foreach ($last_three_months as $key => $month)
	{
	$query="select ";
	$query.="sum(owed_to_client) ";
	$query.="from ";
	$query.="affiliate_history ";
	$query.="where ";
	$query.="afuid='".addslashes(trim($afuid))."' ";
	$query.="and ";
	$query.="from_unixtime(period_of, '%Y%m')=".date("Ym", $month);

	$rs=mysql_fetch_row(mysql_query($query));

	$results[$x]['month']=date("F", $month);
	$results[$x]['total']=$rs[0];
	$x+=1;
	}

$balance_forward+=$results[0]['total'];
$balance_forward+=$results[1]['total'];
$balance_forward+=$results[2]['total'];

echo("
			<table width='".$standard_table_width."' cellpadding='2' cellspacing='1' border='0'>
				<tr>
					<td colspan='3'><img src='".$http_images."/the_space.gif' width='1' height='12'></td>
				</tr>
				<tr>
					<td align='left' valign='center' bgcolor='#E5E7E9'>&nbsp;&nbsp;<b>".$results[0]['month']." Total</b></td>
					<td align='left' valign='center' bgcolor='#E5E7E9'>&nbsp;&nbsp;<b>".$results[1]['month']." Total</b></td>
					<td align='left' valign='center' bgcolor='#E5E7E9'>&nbsp;&nbsp;<b>".$results[2]['month']." Total</b></td>
					<td align='left' valign='center' bgcolor='#E5E7E9'>&nbsp;&nbsp;<b>Balance Forward</b></td>
				</tr>
				<tr>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>&nbsp;&nbsp;".$currency."".sprintf("%01.2f", $results[0]['total'])."".$currency_type."</td>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>&nbsp;&nbsp;".$currency."".sprintf("%01.2f", $results[1]['total'])."".$currency_type."</td>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>&nbsp;&nbsp;".$currency."".sprintf("%01.2f", $results[2]['total'])."".$currency_type."</td>
				<td align='left' valign='center' bgcolor='".$bgcolor."'>&nbsp;&nbsp;".$currency."".sprintf("%01.2f", $balance_forward)."".$currency_type."</td>
				</tr>
			</table>
			</td>
		</tr>
	</table>
	</form>
	");
include "inc/footer.php";
?>