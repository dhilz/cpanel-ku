<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/client_functions.php";
include "inc/affiliate_functions.php";

// run this query
// ALTER TABLE `hosting_order` ADD `afuid` BIGINT( 22 ) NOT NULL ;

// authenicate sid
if (auth_sid($sid)==1) { header("Location: ".$http_web."/clogin.php"); exit; }

if (isset($request))
	{
	$rsx=mysql_fetch_row(mysql_query("select uid from user where sid='".addslashes(trim($sid))."'"));
	$uid=$rsx[0];

	mysql_query("insert into affiliate_user set uid='".addslashes(trim($uid))."', ogcreate='".time()."', status='2'");

	$done=true;
	}

include "inc/header.php";

$rs=mysql_fetch_row(mysql_query("select affiliate_user.afuid from affiliate_user, user where user.sid='".addslashes(trim($sid))."' and user.uid=affiliate_user.uid order by user.uid asc limit 0, 1"));

$afuid=$rs[0];

echo("
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td><img src='".$http_images."/menu_arrow_back.gif'><a href='".$http_web."/affiliate.php?sid=".trim($sid)."'><b>$text_goback</b></a></td>
	</tr>
	<tr>
		<td><hr color='#F0EFED'></td>
	</tr>
</table>
	");

// grab the user and email based on sid
$rs0=mysql_fetch_row(mysql_query("select email, uid from user where sid='".addslashes(trim($sid))."'"));
echo("
	<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
		<tr>
			<td><img src='".$http_images."/menu_arrow.gif'><b>$text_activeaffiliatedetails</b></td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='15' height='9'>$text_affiliatesthatyouhaverefered ".date("m/d/y h:i:s a").":</td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/the_space.gif' width='1' height='1'></td>
		</tr>
	</table>
	<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
		<tr>
			<td width='1%' align='left' valign='center'><img src='".$http_images."/the_space.gif' width='13' height='9'></td>
			<td width='99%' align='left' valign='center'>
			<table width='100%' cellpadding='2' cellspacing='1' border='0'>
				<tr>
					<td align='center' valign='center' bgcolor='#E5E7E9'><b>#</b></td>
					<td align='left' valign='center' bgcolor='#E5E7E9'>&nbsp;&nbsp;<b>$text_domain</b></td>
					<td align='left' valign='center' bgcolor='#E5E7E9'>&nbsp;&nbsp;<b>$text_client</b></td>
					<td align='left' valign='center' bgcolor='#E5E7E9'>&nbsp;&nbsp;<b>$text_monthlypayout </b></td>
					<td align='left' valign='center' bgcolor='#E5E7E9'>&nbsp;&nbsp;<b>$text_created</b></td>
				</tr>
		");
$i=1;
$y=1;
$row1=mysql_query("select refered_uid, oid, record_payout_type, package_name, total_amount_package, total_due_to_client, ogcreate, status from affiliate_details where pid='".addslashes(trim($pid))."' and afuid='".addslashes(trim($afuid))."' and status='1' order by ogcreate asc");
while ($rs1=mysql_fetch_row($row1))
	{
	$rs2=mysql_fetch_row(mysql_query("select user.first_name, user.last_name, user.email, hosting_order.domain_name from user, hosting_order where hosting_order.oid='".addslashes(trim($rs1[1]))."' and hosting_order.uid=user.uid order by hosting_order.oid asc limit 0, 1"));
	
	if ($y==1) {$bgcolor="#F2F4F6"; $y=0;} else {$bgcolor="#ECEEF0"; $y=1;}
	echo("
		<tr>
			<td align='center' valign='center' bgcolor='".$bgcolor."'>".$i.").</td>
			<td align='left' valign='center' bgcolor='".$bgcolor."'>&nbsp;&nbsp;<a href='http://".$rs2[3]."'>http://".$rs2[3]."</a></td>
			<td align='left' valign='center' bgcolor='".$bgcolor."'>&nbsp;&nbsp;<a href='mailto:".$rs2[2]."'>".$rs2[0]." ".$rs2[1]."</a></td>
			<td align='left' valign='center' bgcolor='".$bgcolor."'>&nbsp;&nbsp;".$currency."".$rs1[5]."".$currency_type."</td>
			<td align='left' valign='center' bgcolor='".$bgcolor."'>&nbsp;&nbsp;".date("m/d/Y h:i:s a", $rs1[6])."</td>
		</tr>
		");
	$i++;
	}
if ($i==1)
	{
	echo("
		<tr>
			<td colspan='4'><img src='".$http_images."/error_arrow.gif'>$text_norecords</td>
		</tr>
		");
	}
echo("
	</table>
		</td>
	</tr>
	</table>
	");
include "inc/footer.php";
?>