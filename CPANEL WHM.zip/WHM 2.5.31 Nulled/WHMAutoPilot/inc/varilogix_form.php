<?PHP
if (strcmp("cybersourcehop", strtolower($payment_type_name))==0)
	{
	include("inc/mod_HOP.php");
	
	# -------------------------------------------------------------------------

	$hop=hop_values();
	$getMerchantID=$hop['merchant_id'];
	$getPublicKey=$hop['public_key'];
	$getPrivateKey=$hop['private_key'];
	
	# -------------------------------------------------------------------------
	
	$parse_out0="<form action='https://orderpage.ic3.com/hop/orderform.jsp' method='post' target='_parent'>";
	$parse_out0.=InsertSignature($total_due_today);
	$parse_out0.="<input type='hidden' name='comments' value=':: Hosting For ::".$package_name." [".$domain_name."]'>";
	$parse_out0.="<input type='hidden' name='ordtrack' value='".trim($sid)."'>";
	$parse_out0.="<input type='hidden' name='invoicetype' value='neworder'>";
	}
else if (strcmp("authorize.net", strtolower($payment_type_name))==0)
	{
	$parse_out0.="<form action='".$http_web."/credit_card.php' target='_parent' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='sid' value='".trim($sid)."'>\n";
	$parse_out0.="<input type='hidden' name='gid' value='".trim($gid)."'>\n";
	}
else if (strcmp("linkpoint", strtolower($payment_type_name))==0)
	{
	$parse_out0.="<form action='".$http_web."/lcredit_card.php' target='_parent' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='sid' value='".trim($sid)."'>\n";
	$parse_out0.="<input type='hidden' name='gid' value='".trim($gid)."'>\n";
	}
else if (strcmp("psigate", strtolower($payment_type_name))==0)
	{
	$parse_out0.="<form action='".$http_web."/pcredit_card.php' target='_parent' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='sid' value='".trim($sid)."'>\n";
	$parse_out0.="<input type='hidden' name='gid' value='".trim($gid)."'>\n";
	}
else if (strcmp("mail in payment", strtolower($payment_type_name))==0)
	{
	$query="update ";
	$query.="session_history ";
	$query.="set ";
	$query.="locked='0' ";
	$query.="where ";
	$query.="sid='".addslashes(trim($sid))."'";

	mysql_query($query);

	$parse_out0.="<form action='".$http_web."/verify_order.php' target='_parent' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='pay_mod' value='mail_in_payment'>\n";
	$parse_out0.="<input type='hidden' name='sid' value='".trim($sid)."'>\n";
	$parse_out0.="<input type='hidden' name='gid' value='".trim($gid)."'>\n";
	$parse_out0.="<input type='hidden' name='total_due_today' value='".base64_encode(trim($total_due_today))."'>\n";
	$parse_out0.="<input type='hidden' name='total_due_reoccur' value='".base64_encode(trim($total_reoccur))."'>\n";
	}
else if (strcmp("paypal", strtolower($payment_type_name))==0)
	{
	$rsp=mysql_fetch_row(mysql_query("select paypal_address, paypal_image_url from payment_process where pid='".addslashes(trim($payment_method))."'"));

	$parse_out0.="<form action='https://www.paypal.com/cgi-bin/webscr' target='_parent' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='cmd' value='_xclick-subscriptions'>\n";
	$parse_out0.="<input type='hidden' name='business' value='".trim($rsp[0])."'>\n";
	$parse_out0.="<input type='hidden' name='item_name' value='".$package_name." [".$domain_name."]'>\n";
	$parse_out0.="<input type='hidden' name='custom' value='".$sid."'>\n";
	$parse_out0.="<input type='hidden' name='return' value='".$http_web."/paypal_success.php'>\n";
	$parse_out0.="<input type='hidden' name='cancel_return' value='".$http_web."/step_one.php'>\n";

	$parse_out0.="<input type='hidden' name='p3' value='".$term."'>\n";
	$parse_out0.="<input type='hidden' name='t3' value='M'>\n";
	$parse_out0.="<input type='hidden' name='src' value='1'>\n";
	$parse_out0.="<input type='hidden' name='sra' value='1'>\n";
	$parse_out0.="<input type='hidden' name='currency_code' value='".trim($currency_type)."'>\n";
	$parse_out0.="<input type='hidden' name='no_shipping' value='1'>\n";
	$parse_out0.="<input type='hidden' name='rm' value='2'>\n";
	$parse_out0.="<input type='hidden' name='no_note' value='1'>\n";
	if (trim($rsp[1])!="") { $parse_out0.="<input type='hidden' name='image_url' value='".$rsp[1]."'>\n"; }

	# investigate free trial!!!!!!!!!!!!!!!!!!
	if ($free_trial==1)
		{
		$parse_out0.="<input type='hidden' name='a1' value='".$cost_per_tld."'>\n";
		$parse_out0.="<input type='hidden' name='p1' value='".$free_trial_length."'>\n";
		$parse_out0.="<input type='hidden' name='t1' value='M'>\n";
		
		$parse_out0.="<input type='hidden' name='a2' value='".sprintf("%01.2f", $total_due_today)."'>\n";
		$parse_out0.="<input type='hidden' name='p2' value='".trim($term)."'>\n";
		$parse_out0.="<input type='hidden' name='t2' value='M'>\n";
		}
	else
		{
		$parse_out0.="<input type='hidden' name='a1' value='".sprintf("%01.2f", $total_due_today)."'>\n";
		$parse_out0.="<input type='hidden' name='p1' value='".trim($term)."'>\n";
		$parse_out0.="<input type='hidden' name='t1' value='M'>\n";
		}

	$parse_out0.="<input type='hidden' name='a3' value='".sprintf("%01.2f", $total_reoccur)."'>\n";
	}
else if (strcmp("12", strtolower($payment_method))==0)
	{
	$rsp=mysql_fetch_row(mysql_query("select paypal_address, paypal_image_url from payment_process where pid='".addslashes(trim($payment_method))."'"));

	$parse_out0.="<form action='https://www.paypal.com/cgi-bin/webscr' target='_parent' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='cmd' value='_xclick-subscriptions'>\n";
	$parse_out0.="<input type='hidden' name='business' value='".trim($rsp[0])."'>\n";
	$parse_out0.="<input type='hidden' name='item_name' value='".$package_name." [".$domain_name."]'>\n";
	$parse_out0.="<input type='hidden' name='custom' value='".$sid."'>\n";
	$parse_out0.="<input type='hidden' name='return' value='".$http_web."/paypal_success.php'>\n";
	$parse_out0.="<input type='hidden' name='cancel_return' value='".$http_web."/step_one.php'>\n";

	$parse_out0.="<input type='hidden' name='p3' value='".$term."'>\n";
	$parse_out0.="<input type='hidden' name='t3' value='M'>\n";
	$parse_out0.="<input type='hidden' name='src' value='1'>\n";
	$parse_out0.="<input type='hidden' name='sra' value='1'>\n";
	$parse_out0.="<input type='hidden' name='currency_code' value='".trim($currency_type)."'>\n";
	$parse_out0.="<input type='hidden' name='no_shipping' value='1'>\n";
	$parse_out0.="<input type='hidden' name='rm' value='2'>\n";
	$parse_out0.="<input type='hidden' name='no_note' value='1'>\n";
	if (trim($rsp[1])!="") { $parse_out0.="<input type='hidden' name='image_url' value='".$rsp[1]."'>\n"; }

	# investigate free trial!!!!!!!!!!!!!!!!!!
	if ($free_trial==1)
		{
		if ($cost_per_tld=="") { $cost_per_tld="0.00"; }
		$parse_out0.="<input type='hidden' name='a1' value='".$cost_per_tld."'>\n";
		$parse_out0.="<input type='hidden' name='p1' value='".$free_trial_length."'>\n";
		$parse_out0.="<input type='hidden' name='t1' value='M'>\n";
		$total_due_today=$total_due_today-$cost_per_tld;
		$parse_out0.="<input type='hidden' name='a2' value='".sprintf("%01.2f", $total_due_today)."'>\n";
		$parse_out0.="<input type='hidden' name='p2' value='".trim($term)."'>\n";
		$parse_out0.="<input type='hidden' name='t2' value='M'>\n";
		}
	else
		{
		$parse_out0.="<input type='hidden' name='a1' value='".sprintf("%01.2f", $total_due_today)."'>\n";
		$parse_out0.="<input type='hidden' name='p1' value='".trim($term)."'>\n";
		$parse_out0.="<input type='hidden' name='t1' value='M'>\n";
		}

	$parse_out0.="<input type='hidden' name='a3' value='".sprintf("%01.2f", $total_reoccur)."'>\n";
	}
else if (strcmp("paysystems tpp-pro", strtolower($payment_type_name))==0)
	{
	$rsp=mysql_fetch_row(mysql_query("select paysystems_companyid from payment_process where pid='".addslashes(trim($payment_method))."'"));

	$rspd=mysql_fetch_row(mysql_query("select tpp_pro_period from plan_specs where pid='".addslashes(trim($pid))."'"));

	// Get the days of payment cycle
	if ($term==1) {$xpterm=30;}
	else if ($term==3) {$xpterm=90;}
	else if ($term==6) {$xpterm=180;}
	else if ($term==12) {$xpterm=360;}

	$parse_out0.="<form action='https://secure.paysystems1.com/cgi-v310/payment/onlinesale-tpppro.asp' target='_parent' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='companyid' value='".trim($rsp[0])."'>\n";
	$parse_out0.="<input type='hidden' name='product1' value='".$package_name." [".$domain_name."]'>\n";
	$parse_out0.="<input type='hidden' name='formget' value='N'>\n";
	$parse_out0.="<input type='hidden' name='redirect' value='".$http_web."/tpp_pro_success.php'>\n";
	$parse_out0.="<input type='hidden' name='redirectfail' value='".$http_web."/index.php'>\n";
	$parse_out0.="<input type='hidden' name='option1' value='".base64_encode(e("576cb7f68040520768bf51c75f7f4c84", $sid))."'>\n";
	$parse_out0.="<input type='hidden' name='reoccur' value='Y'>\n";
	$parse_out0.="<input type='hidden' name='cycle' value='".$xpterm."'>\n";
	$parse_out0.="<input type='hidden' name='totalperiod' value='".$rspd[0]."'>\n";

	
	$parse_out0.="<input type='hidden' name='total' value='".sprintf("%01.2f",($total_due_today))."'>\n";
	$parse_out0.="<input type='hidden' name='repeatamount' value='".sprintf("%01.2f", $total_reoccur)."'>\n";
	}
///// Internet Secure change 16/08/2004
else if (strcmp("internet secure", strtolower($payment_type_name))==0)
	{
	$rsp=mysql_fetch_row(mysql_query("select internetsecure_merchant_id, internetsecure_language, internetsecure_return_cgi from payment_process where pid='".addslashes(trim($payment_method))."'"));

	$rspd=mysql_fetch_row(mysql_query("select internetsecure_period from plan_specs where pid='".addslashes(trim($pid))."'"));

	// Get the days of payment cycle
	if ($term==1) {$xpterm="monthly";
	$rm_start = "startmonth=+1";	}
	else if ($term==3) {$xpterm="quarterly"; $rm_start = "startmonth=+3";}
	else if ($term==6) {$xpterm="semiannually"; $rm_start = "startmonth=+6";}
	else if ($term==12) {$xpterm="annually"; $rm_start = "startyear=+1";}
	

	if (!$rspd[0]) $rspd[0] = 12;

	
	$parse_out0.="<form action='https://secure.internetsecure.com/process.cgi' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='MerchantNumber' value='".trim($rsp[0])."'>\n";
	$parse_out0.="<input type='hidden' name='language' value='".trim($rsp[1])."'>\n";
	$parse_out0.="<input type='hidden' name='ReturnCGI' value='".$http_web."/internet_secure_success.php"."'>\n";
	$parse_out0.="<input type=hidden name='Products' value='$total_due_today::1::$plan_group_name::".$package_name." [".$domain_name."]"."::{RB amount=$total_reoccur $rm_start frequency=$xpterm duration=$rspd[0] email=2}'>\n";
	$parse_out0.="<input type='hidden' name='xxxName' value='$first_name $last_name'>\n";
	$parse_out0.="<input type='hidden' name='xxxCompany' value='$organization_name'>\n";
	$parse_out0.="<input type='hidden' name='xxxAddress' value='$street_address_1'>\n";
	$parse_out0.="<input type='hidden' name='xxxCity' value='$city'>\n";
	$parse_out0.="<input type='hidden' name='xxxProvince' value='$state'>\n";
	$parse_out0.="<input type='hidden' name='xxxCountry' value='$country'>\n";
	$parse_out0.="<input type='hidden' name='xxxPostal' value='$zip_code'>\n"; 
	$parse_out0.="<input type='hidden' name='xxxEmail' value='$email'>\n"; 
	$parse_out0.="<input type='hidden' name='xxxPhone' value='$phone'>\n"; 
	$parse_out0.="<input type='hidden' name='xxxVar1' value='".base64_encode(e("576cb7f68040520768bf51c75f7f4c84", $sid))."'>\n";
	
	}


///// Internet Secure change 16/08/2004
else if (strcmp("2checkout", strtolower($payment_type_name))==0)
	{
	$rsp=mysql_fetch_row(mysql_query("select checkout_sid, demo, co_system from payment_process where pid='".addslashes(trim($payment_method))."'"));
	# $rsp=mysql_fetch_row(mysql_query("select checkout_sid, demo from payment_process where pid='".addslashes(trim($payment_method))."'"));

	$rspd=mysql_fetch_row(mysql_query("select monthly_pid, quarterly_pid, semi_annual_pid, annual_pid from plan_specs where pid='".addslashes(trim($pid))."'"));

	if ($term==1) { $mqsaa_pid=$rspd[0]; }
	else if ($term==3) { $mqsaa_pid=$rspd[1]; }
	else if ($term==6) { $mqsaa_pid=$rspd[2]; }
	else if ($term==12) { $mqsaa_pid=$rspd[3]; }
	
	if ($rsp[2]==0) 
		{ 
		$parse_out0.="<form action='https://www.2checkout.com/cgi-bin/crbuyers/recpurchase.2c' target='_parent' method='POST'>\n"; 
		$parse_out0.="<input type='hidden' name='merchant_order_id' value='".trim($sid."|0")."'>\n";
		}
	else 
		{ 
		$parse_out0.="<form action='https://www2.2checkout.com/2co/buyer/purchase' target='_parent' method='POST'>\n"; 
		$parse_out0.="<input type='hidden' name='quantity' value='1'>\n";
		$parse_out0.="<input type='hidden' name='merchant_product_id' value='".trim($sid."|0")."'>\n";
		}
	
	
	$parse_out0.="<input type='hidden' name='sid' value='".trim($rsp[0])."'>\n";
	$parse_out0.="<input type='hidden' name='product_id' value='".$mqsaa_pid."'>\n";

	if (trim($rsp[1])==1) { $parse_out0.="<input type='hidden' name='demo' value='Y'>\n"; }
	if ($domain_registration==1)
		{
		$getcoid=mysql_fetch_row(mysql_query("select coid from tld_chart where tld_id='".addslashes(trim($tld_id))."'"));
		$parse_out0.="<input type='hidden' name='quantity1' value='1'>\n";
		$parse_out0.="<input type='hidden' name='product_id1' value='".addslashes(trim($getcoid[0]))."'>\n";
		}

	}
else if (strcmp("worldpay future pay", strtolower($payment_type_name))==0)
	{	
	// get the paypal addr from the payment_process table
	$rsp=mysql_fetch_row(mysql_query("select worldpay_id, worldpay_cc, worldpay_demo from payment_process where pid='".addslashes(trim($payment_method))."'"));

	// Get the link id
	if ($term==1)  { $intrval=1; }
	else if ($term==3) { $intrval=3; }
	else if ($term==6) { $intrval=6; }
	else if ($term==12) { $intrval=12; }

	$parse_out0.="<form action='https://select.worldpay.com/wcc/purchase' target='_parent' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='desc' value='".$package_name." [".$domain_name."]'>\n";
	$parse_out0.="<input type='hidden' name='cartId' value='".trim($sid)."'>\n";
	$parse_out0.="<input type='hidden' name='instId' value='".trim($rsp[0])."'>\n";
	$parse_out0.="<input type='hidden' name='currency' value='".trim($rsp[1])."'>\n";
	$parse_out0.="<input type='hidden' name='futurePayType' value='regular'>\n";
	$parse_out0.="<input type='hidden' name='option' value='1'>\n";
	$parse_out0.="<input type='hidden' name='startDelayUnit' value='3'>\n";
	$parse_out0.="<input type='hidden' name='startDelayMult' value='".$intrval."'>\n";
	$parse_out0.="<input type='hidden' name='intervalUnit' value='3'>\n";
	$parse_out0.="<input type='hidden' name='intervalMult' value='".$intrval."'>\n";
	$xlink=str_replace("http://", "", strtolower($http_web));
	$xlink=str_replace("https://", "", $xlink);
	$parse_out0.="<input type='hidden' name='MC_callback' value='".trim($xlink)."/worldpay_success.php'>\n";
	$parse_out0.="<input type='hidden' name='testMode' value='".$rsp[2]."'>\n";
	
	$parse_out0.="<input type='hidden' name='amount' value='".sprintf("%01.2f",($total_due_today))."'>\n";
	$parse_out0.="<input type='hidden' name='normalAmount' value='".sprintf("%01.2f", $total_reoccur)."'>\n";
	}
else if (strcmp("13", strtolower($payment_method))==0)
	{	
	// get the paypal addr from the payment_process table
	$rsp=mysql_fetch_row(mysql_query("select worldpay_id, worldpay_cc, worldpay_demo from payment_process where pid='".addslashes(trim($payment_method))."'"));

	// Get the link id
	if ($term==1)  { $intrval=1; }
	else if ($term==3) { $intrval=3; }
	else if ($term==6) { $intrval=6; }
	else if ($term==12) { $intrval=12; }

	$parse_out0.="<form action='https://select.worldpay.com/wcc/purchase' target='_parent' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='desc' value='".$package_name." [".$domain_name."]'>\n";
	$parse_out0.="<input type='hidden' name='cartId' value='".trim($sid)."'>\n";
	$parse_out0.="<input type='hidden' name='instId' value='".trim($rsp[0])."'>\n";
	$parse_out0.="<input type='hidden' name='currency' value='".trim($rsp[1])."'>\n";
	$parse_out0.="<input type='hidden' name='futurePayType' value='regular'>\n";
	$parse_out0.="<input type='hidden' name='option' value='1'>\n";
	$parse_out0.="<input type='hidden' name='startDelayUnit' value='3'>\n";
	$parse_out0.="<input type='hidden' name='startDelayMult' value='".$intrval."'>\n";
	$parse_out0.="<input type='hidden' name='intervalUnit' value='3'>\n";
	$parse_out0.="<input type='hidden' name='intervalMult' value='".$intrval."'>\n";
	$xlink=str_replace("http://", "", strtolower($http_web));
	$xlink=str_replace("https://", "", $xlink);
	$parse_out0.="<input type='hidden' name='MC_callback' value='".trim($xlink)."/worldpay_success.php'>\n";
	$parse_out0.="<input type='hidden' name='testMode' value='".$rsp[2]."'>\n";
	
	$parse_out0.="<input type='hidden' name='amount' value='".sprintf("%01.2f",($total_due_today))."'>\n";
	$parse_out0.="<input type='hidden' name='normalAmount' value='".sprintf("%01.2f", $total_reoccur)."'>\n";
	}


echo $parse_out0;
echo "<center><input ".$button_style." type='submit' name='submit' value='Click to continue'></center>";
echo "</form>";
exit;
?>
