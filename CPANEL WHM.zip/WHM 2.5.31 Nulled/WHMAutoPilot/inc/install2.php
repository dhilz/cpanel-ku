<?PHP

include "var.php";
include "install_connect.php";

$WHERE[here] = "http://".$_SERVER['HTTP_HOST'];
		if (!strpos($_SERVER['HTTP_REFERER'], $_SERVER['HTTP_HOST'])) 
		{
		header("Location: $WHERE[here]");
		exit();
		}

$xinput_style="style=\"BORDER-STYLE: solid;BORDER-COLOR: #999999; BACKGROUND-COLOR: #ffffff; BORDER-WIDTH: 1px; FONT-FAMILY: Verdana; FONT-SIZE: 8pt\"";
$input0="Enter the default site title here.";
$input1="Enter the default name of your site here.";
# $input2="Enter the system notification email.";
$input3="Enter the IP address of a remote DNS server here.";

if(phpversion() <= "4.0.6") { $_POST=$HTTP_POST_VARS; }
if ($_POST['submit'])
	{
	if (trim($_POST['site_title'])==$input0||trim($_POST['site_title'])=="") { $e0=true; }
	if (trim($_POST['site_name'])==$input1||trim($_POST['site_name'])=="") { $e1=true; }
	if (trim($_POST['balance_required_for_payment'])=="") { $e3=true; }
	if (trim($_POST['currency'])=="") { $e4=true; }
	if (trim($_POST['currency_type'])=="") { $e5=true; }
	if (trim($_POST['domain_fee'])=="") { $e6=true; }
	if (trim($_POST['resolve_server'])==$input3||trim($_POST['resolve_server'])=="") { $e7=true; }
	if (trim($_POST['run_domain_expire'])=="") { $e8=true; }

	# if (trim($_POST['email_admin'])==$input2||trim($_POST['email_admin'])=="") { $e2=true; }
	# if (trim($_POST['username'])=="") { $e9=true; }
	# if (trim($_POST['password'])==""||strcmp($_POST['password'], $_POST['password1'])!=0) { $e10=true; }

	if (trim($_POST['http_web'])=="") { $e11=true; }
	if (trim($_POST['server_root'])=="") { $e12=true; }
	if (trim($_POST['below_public'])=="") { $e13=true; }
	
	if (!isset($e0)&&!isset($e1)&&!isset($e2)&&!isset($e3)&&!isset($e4)
		&&!isset($e5)&&!isset($e6)&&!isset($e7)&&!isset($e8)&&!isset($e9)
		&&!isset($e10)&&!isset($e11)&&!isset($e12)&&!isset($e13))
		{
		$query="update ";
		$query.="config ";
		$query.="set ";
		$query.="email_support='".addslashes(trim($_POST['email_admin']))."', ";
		$query.="get_mib_news='http://benchmarkdesigns.net/mib_news.nfo', ";
		$query.="copyright='<FONT COLOR=\"#ffffff\" SIZE=\"-2\" FACE=\"Verdana\">� 2002 Benchmark Designs, LLC.</FONT>', ";
		$query.="button_style='style=\"font-family:verdana, arial, helvetica; font-size: 8pt; border-style: solid; border-color: 000000; border-width: 1pxl; background-color: dbedf9; font-weight: 800\"', ";
		$query.="input_style='style=\"font-family:verdana, arial, helvetica; font-size: 8pt; border-style: solid; border-color: 000000; border-width: 1pxl; background-color: ffffff\"', ";
		$query.="phpbb_active='no', ";
		$query.="strong_security='no', ";
		$query.="theme='blue', ";
		$query.="site_title='".addslashes(trim($_POST['site_title']))."', ";
		$query.="site_name='".addslashes(trim($_POST['site_name']))."', ";
		$query.="balance_required_for_payment='".addslashes(trim(str_replace("$", "", $_POST['balance_required_for_payment'])))."', ";
		$query.="currency='".addslashes(trim($_POST['currency']))."', ";
		$query.="currency_type='".addslashes(trim($_POST['currency_type']))."', ";
		$query.="domain_fee='".addslashes(trim(str_replace("$", "", $_POST['domain_fee'])))."', ";
		$query.="resolve_server='".addslashes(trim($_POST['resolve_server']))."', ";
		$query.="run_domain_expire='".addslashes(trim($_POST['run_domain_expire']))."', ";
		$query.="http_web='".addslashes(trim($_POST['http_web']))."', ";
		$query.="server_root='".addslashes(trim($_POST['server_root']))."', ";
		$query.="below_public='".addslashes(trim($_POST['below_public']))."', ";
		$query.="default_reseller_cpanel_theme='".addslashes(trim(strtolower($_POST['default_reseller_cpanel_theme'])))."', ";
		$query.="http_web_tools='".addslashes(trim($_POST['http_web']."/tools"))."', ";
		$query.="http_admin='".addslashes(trim($_POST['http_web']."/admin"))."', ";
		$query.="http_admin_tools='".addslashes(trim($_POST['http_web']."/admin/tools"))."', ";
		$query.="http_images='".addslashes(trim($_POST['http_web']."/admin/themes/blue/images"))."', ";
		$query.="server_backup='".addslashes(trim($_POST['below_public']."/dbbackup"))."', ";
		$query.="resolver_log='".addslashes(trim($_POST['below_public']."/resolver_logs"))."', ";
		$query.="server_tools='".addslashes(trim($_POST['server_root']."/tools"))."', ";
		$query.="server_admin_inc='".addslashes(trim($_POST['server_root']."/admin/themes/blue"))."', ";
		$query.="server_inc='".addslashes(trim($_POST['server_root']."/inc"))."', ";
		$query.="server_admin='".addslashes(trim($_POST['server_root']."/admin"))."', ";
		$query.="server_admin_tools='".addslashes(trim($_POST['server_root']."/admin/tools"))."', ";
		$query.="local_lang='english'";

		mysql_query($query);

		$query1="delete ";
		$query1.="from ";
		$query1.="user ";
		$query1.="where ";
		$query1.="status='69'";
		mysql_query($query1);
	
		/*
		$query0="insert ";
		$query0.="into ";
		$query0.="user ";
		$query0.="set ";
		$query0.="email='".addslashes(trim($_POST['email_admin']))."', ";
		$query0.="username='".addslashes(trim($_POST['username']))."', ";
		$query0.="password='".md5(strtolower(trim($_POST['password'])))."', ";
		$query0.="sid='".md5(microtime())."', ";
		$query0.="status='69'";
		mysql_query($query0);
		*/
		
		header("Location: install3.php");
		exit;
		}
	}

$b=2;
include "install_header.php";

echo("
	<form action='".$PHP_SELF."' method='POST'>
	<input type='hidden' name='no' value='5'>
	<table width='100%' cellpadding='2' cellspacing='0' border='0'>
		<tr>
			<td colspan='2'><img src='install[1].gif'>&nbsp;<font color='#0F82B8'><b>Step 2:</b></font> <b>Paths and configurations</b></td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='middle'>&nbsp;</td>
		</tr>
	");
if (isset($e0))
	{
	echo("
		<tr>
			<td colspan='2'><img src='install[26].gif'><font color='#C60C08'>You must enter a Site Title to continue.</font></td>
		</tr>
		");
	}
if (isset($e1))
	{
	echo("
		<tr>
			<td colspan='2'><img src='install[26].gif'><font color='#C60C08'>You must enter a Site Name to continue.</font></td>
		</tr>
		");
	}
if (isset($e2))
	{
	echo("
		<tr>
			<td colspan='2'><img src='install[26].gif'><font color='#C60C08'>You must enter an System Email Address to continue.</font></td>
		</tr>
		");
	}
if (isset($e3))
	{
	echo("
		<tr>
			<td colspan='2'><img src='install[26].gif'><font color='#C60C08'>You must enter a Minimum Affiliate Payout to continue.</font></td>
		</tr>
		");
	}
if (isset($e4))
	{
	echo("
		<tr>
			<td colspan='2'><img src='install[26].gif'><font color='#C60C08'>Please enter the default Currency to continue.</font></td>
		</tr>
		");
	}
if (isset($e5))
	{
	echo("
		<tr>
			<td colspan='2'><img src='install[26].gif'><font color='#C60C08'>Please enter the default Currency Type to continue.</font></td>
		</tr>
		");
	}
if (isset($e6))
	{
	echo("
		<tr>
			<td colspan='2'><img src='install[26].gif'><font color='#C60C08'>You must enter a Domain Name Fee to continue.</font></td>
		</tr>
		");
	}
if (isset($e7))
	{
	echo("
		<tr>
			<td colspan='2'><img src='install[26].gif'><font color='#C60C08'>You must enter a Resolve Server to continue.</font></td>
		</tr>
		");
	}
if (isset($e8))
	{
	echo("
		<tr>
			<td colspan='2'><img src='install[26].gif'><font color='#C60C08'>Please enter yes or no for Enable Domain Expire Check.</font></td>
		</tr>
		");
	}
if (isset($e9))
	{
	echo("
		<tr>
			<td colspan='2'><img src='install[26].gif'><font color='#C60C08'>You must enter a username to continue.</font></td>
		</tr>
		");
	}
if (isset($e10))
	{
	echo("
		<tr>
			<td colspan='2'><img src='install[26].gif'><font color='#C60C08'>Please re-enter your passwords to continue.</font></td>
		</tr>
		");
	}
if (isset($e11))
	{
	echo("
		<tr>
			<td colspan='2'><img src='install[26].gif'><font color='#C60C08'>You must enter the HTTP Web Path to continue.</font></td>
		</tr>
		");
	}
if (isset($e12))
	{
	echo("
		<tr>
			<td colspan='2'><img src='install[26].gif'><font color='#C60C08'>You must enter the Base Server Path to continue.</font></td>
		</tr>
		");
	}
if (isset($e13))
	{
	echo("
		<tr>
			<td colspan='2'><img src='install[26].gif'><font color='#C60C08'>You must enter the AutoPilot Data Directory Path to continue.</font></td>
		</tr>
		");
	}
if (isset($e0)||isset($e1)||isset($e2)||isset($e3)||isset($e4)
||isset($e5)||isset($e6)||isset($e7)||isset($e8)||isset($e9)
||isset($e10)||isset($e11)||isset($e12)||isset($e13))
	{
	echo("
		<tr>
			<td colspan='2'><hr color='#F7F3F7'></td>
		</tr>
		");
	}
echo("
		<tr>
			<td colspan='2' align='left' valign='middle'><b>General Variables</b></td>
		</tr>
		<tr>
			<td width='40%' align='left' valign='middle'><img src='install[0].gif'>&nbsp;Default Site Title:</td>
			<td width='60%' align='left' valign='middle'><input size='50' maxlength='255' ".$xinput_style." type='text' name='site_title' value='".((isset($site_title))?"".$site_title."":"".$input0."")."' onFocus=\"if(this.value=='".$input0."') this.value='';\" onBlur=\"if(this.value=='') this.value='".$input0."';\"></td>
		</tr>
		<tr>
			<td width='40%' align='left' valign='middle'><img src='install[0].gif'>&nbsp;Default Site Name:</td>
			<td width='60%' align='left' valign='middle'><input size='50' maxlength='255' ".$xinput_style." type='text' name='site_name' value='".((isset($site_name))?"".$site_name."":"".$input1."")."' onFocus=\"if(this.value=='".$input1."') this.value='';\" onBlur=\"if(this.value=='') this.value='".$input1."';\"></td>
		</tr>
		<!---<tr>
			<td width='40%' align='left' valign='middle'><img src='install[0].gif'>&nbsp;System Email Address:</td>
			<td width='60%' align='left' valign='middle'><input size='50' maxlength='255' ".$xinput_style." type='text' name='email_admin' value='".((isset($email_admin))?"".$email_admin."":"".$input2."")."' onFocus=\"if(this.value=='".$input2."') this.value='';\" onBlur=\"if(this.value=='') this.value='".$input2."';\"></td>
		</tr>--->
		<tr>
			<td width='40%' align='left' valign='middle'><img src='install[0].gif'>&nbsp;Minimum Affiliate Payout:</td>
			<td width='60%' align='left' valign='middle'><input size='50' maxlength='255' ".$xinput_style." type='text' name='balance_required_for_payment' value='".((isset($balance_required_for_payment))?"".$balance_required_for_payment."":"$50")."'></td>
		</tr>
		<tr>
			<td width='40%' align='left' valign='middle'><img src='install[0].gif'>&nbsp;Currency:</td>
			<td width='60%' align='left' valign='middle'><input size='50' maxlength='255' ".$xinput_style." type='text' name='currency' value='".((isset($currency))?"".$currency."":"$")."'></td>
		</tr>
		<tr>
			<td width='40%' align='left' valign='middle'><img src='install[0].gif'>&nbsp;Currency Type:</td>
			<td width='60%' align='left' valign='middle'><input size='50' maxlength='255' ".$xinput_style." type='text' name='currency_type' value='".((isset($currency_type))?"".$currency_type."":"USD")."'></td>
		</tr>
		<tr>
			<td width='40%' align='left' valign='middle'><img src='install[0].gif'>&nbsp;Cost Per Domain Name:</td>
			<td width='60%' align='left' valign='middle'><input size='50' maxlength='255' ".$xinput_style." type='text' name='domain_fee' value='".((isset($domain_fee))?"".$domain_fee."":"$15")."'></td>
		</tr>
		<tr>
			<td width='40%' align='left' valign='middle'><img src='install[0].gif'>&nbsp;Resolve Server:</td>
			<td width='60%' align='left' valign='middle'><input size='50' maxlength='255' ".$xinput_style." type='text' name='resolve_server' value='".((isset($resolve_server))?"".$resolve_server."":"".$input3."")."' onFocus=\"if(this.value=='".$input3."') this.value='';\" onBlur=\"if(this.value=='') this.value='".$input3."';\"></td>
		</tr>
		<tr>
			<td width='40%' align='left' valign='middle'><img src='install[0].gif'>&nbsp;Enable Domain Expire Check:</td>
			<td width='60%' align='left' valign='middle'><select name='run_domain_expire' ".$xinput_style.">
				<option value='yes'".(($run_domain_expire=="yes")?" selected":"").">Yes</option>
				<option value='no'".(($run_domain_expire=="no")?" selected":"").">No</option>
			</select></td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='middle'>&nbsp;</td>
		</tr>
		<!--- <tr>
			<td colspan='2' align='left' valign='middle'><b>Create Default Admin Account</b></td>
		</tr>
		<tr>
			<td width='40%' align='left' valign='middle'><img src='install[0].gif'>&nbsp;System Email Address:</td>
			<td width='60%' align='left' valign='middle'><input size='50' maxlength='255' ".$xinput_style." type='text' name='email_admin' value='".((isset($email_admin))?"".$email_admin."":"")."'></td>
		</tr>
		<tr>
			<td width='40%' align='left' valign='middle'><img src='install[0].gif'>&nbsp;Admin Username:</td>
			<td width='60%' align='left' valign='middle'><input size='50' maxlength='255' ".$xinput_style." type='text' name='username' value='".((isset($username))?"".$username."":"")."'></td>
		</tr>
		<tr>
			<td width='40%' align='left' valign='middle'><img src='install[0].gif'>&nbsp;Admin Password:</td>
			<td width='60%' align='left' valign='middle'><input size='50' maxlength='255' ".$xinput_style." type='text' name='password' value='".((isset($password))?"".$password."":"")."'></td>
		</tr>
		<tr>
			<td width='40%' align='left' valign='middle'><img src='install[0].gif'>&nbsp;Verify Password:</td>
			<td width='60%' align='left' valign='middle'><input size='50' maxlength='255' ".$xinput_style." type='text' name='password1' value='".((isset($password1))?"".$password1."":"")."'></td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='middle'>&nbsp;</td>
		</tr> --->
		<tr>
			<td colspan='2' align='left' valign='middle'><b>Define File Paths</b></td>
		</tr>
	");

if (ereg("http://", $_SERVER['SERVER_NAME'])!=true) { $guess_http_web="http://".$_SERVER['SERVER_NAME']; }
else { $guess_http_web=$_SERVER['SERVER_NAME']; } 

$guess_http_web=str_replace("www.", "", $guess_http_web);
$guess_http_web.=str_replace("/inc/install2.php", "", $_SERVER['PHP_SELF']);
$guess_root_path=str_replace("/inc/install2.php", "", $HTTP_SERVER_VARS['PATH_TRANSLATED']);

$gg=0;
$tok=strtok($guess_root_path, "/");
while ($tok)
	{
	if ($gg==0||$gg==1) { $guess_absolute_path.="/".$tok; }
	else { $guess_absolute_path.="/mib_data"; break; }
	$gg+=1;
	$tok=strtok("/");
	}

$guess_absolute_path;

echo("
		<tr>
			<td width='40%' align='left' valign='middle'><img src='install[0].gif'>&nbsp;HTTP Web Path:</td>
			<td width='60%' align='left' valign='middle'><input size='50' maxlength='255' ".$xinput_style." type='text' name='http_web' value='".((isset($http_web))?"".$http_web."":"".$guess_http_web."")."'></td>
		</tr>
		<tr>
			<td width='40%' align='left' valign='middle'><img src='install[0].gif'>&nbsp;Base Server Path:</td>
			<td width='60%' align='left' valign='middle'><input size='50' maxlength='255' ".$xinput_style." type='text' name='server_root' value='".((isset($server_root))?"".$server_root."":"".$guess_root_path."")."'></td>
		</tr>
		<tr>
			<td width='40%' align='left' valign='middle'><img src='install[0].gif'>&nbsp;AutoPilot Data Directory:</td>
			<td width='60%' align='left' valign='middle'><input size='50' maxlength='255' ".$xinput_style." type='text' name='below_public' value='".((isset($below_public))?"".$below_public."":"".$guess_absolute_path."")."'></td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='middle'>&nbsp;</td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='middle'><b>Resellers Only</b></td>
		</tr>
		<tr>
			<td width='40%' align='left' valign='middle'><img src='install[0].gif'>&nbsp;Default cPanel Theme:</td>
			<td width='60%' align='left' valign='middle'><input size='50' maxlength='255' ".$xinput_style." type='text' name='default_reseller_cpanel_theme' value='".((isset($default_reseller_cpanel_theme))?"".$default_reseller_cpanel_theme."":"")."'></td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='middle'>&nbsp;</td>
		</tr>
		<tr>
			<td width='40%' align='left' valign='middle'></td>
			<td width='60%' align='left' valign='middle'><input type='hidden' name='submit' value='5'><input type='image' src='install[27].gif' onmouseover='this.src=\"install[28].gif\"' onmouseout='this.src=\"install[27].gif\"' alt='Click to Continue'></td>
		</tr>
	</table>
	</form>
	");

include "install_footer.php";
mysql_close($dblink);
?>