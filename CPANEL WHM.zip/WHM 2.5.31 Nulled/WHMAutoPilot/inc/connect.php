<?PHP
#session_start();
$dblink=MYSQL_CONNECT($dbhost, $dbuser, $dbpass) OR DIE("<font color='#990000'><b>Database Currently Unavailable.</b></font> <b>Please try again later.</b>");
@mysql_select_db($db) or die("<font color='#990000'><b>Unable to Select Database.</b></font> <b>Please try again later.</b>");

$var_query="select ";
$var_query.="email_support, ";					// 0
$var_query.="get_mib_news, ";					// 1
$var_query.="copyright, ";						// 2
$var_query.="button_style, ";					// 3
$var_query.="input_style, ";					// 4
$var_query.="phpbb_active, ";					// 5
$var_query.="strong_security, ";				// 6
$var_query.="theme, ";							// 7
$var_query.="site_title, ";						// 8
$var_query.="site_name, ";						// 9
$var_query.="balance_required_for_payment, ";	// 10
$var_query.="currency, ";						// 11
$var_query.="currency_type, ";					// 12
$var_query.="domain_fee, ";						// 13
$var_query.="resolve_server, ";					// 14
$var_query.="run_domain_expire, ";				// 15
$var_query.="http_web, ";						// 16
$var_query.="server_root, ";					// 17
$var_query.="below_public, ";					// 18
$var_query.="default_reseller_cpanel_theme, ";	// 19
$var_query.="http_web_tools, ";					// 20
$var_query.="http_admin, ";						// 21
$var_query.="http_admin_tools, ";				// 22
$var_query.="http_images, ";					// 23
$var_query.="server_backup, ";					// 24
$var_query.="resolver_log, ";					// 25
$var_query.="server_tools, ";					// 26
$var_query.="server_admin_inc, ";				// 27
$var_query.="server_inc, ";						// 28
$var_query.="server_admin, ";					// 29
$var_query.="server_admin_tools, ";				// 30
$var_query.="license, ";						// 31
$var_query.="http_images, ";					// 32
$var_query.="server_backup, ";					// 33
$var_query.="resolver_log, ";					// 34
$var_query.="server_tools, ";					// 35
$var_query.="server_admin_inc, ";				// 36
$var_query.="server_inc, ";						// 37
$var_query.="server_admin, ";					// 38
$var_query.="server_admin_tools, ";				// 39
$var_query.="local_lang, ";						// 40
$var_query.="invoice_notice_period, ";			// 41
$var_query.="tos_agreement, ";					// 42
$var_query.="session_expire, ";					// 43
$var_query.="use_enom, ";						// 44
$var_query.="send_reminders, ";					// 45
$var_query.="do_registrations, ";				// 46
$var_query.="email_admin, ";					// 47
$var_query.="activate_support, ";				// 48
$var_query.="enable_debugging, ";				// 49
$var_query.="charset, ";						// 50
$var_query.="ip_restrict, ";					// 51
$var_query.="allow_proxy, ";					// 52
$var_query.="activate_serverstats, ";			// 53
$var_query.="maintenance ";						// 54
$var_query.="from ";
$var_query.="config ";
$var_query.="limit 0, 1";

$var_row=@mysql_fetch_row(@mysql_query($var_query));

$email_support=stripslashes(trim($var_row[0]));
$get_mib_news=stripslashes(trim($var_row[1]));
$copyright=stripslashes(trim($var_row[2]));
$button_style=stripslashes(trim($var_row[3]));
$input_style=stripslashes(trim($var_row[4]));
$phpbb_active=stripslashes(trim($var_row[5]));
$strong_security=stripslashes(trim($var_row[6]));
$theme=stripslashes(trim($var_row[7]));
$site_title=stripslashes(trim($var_row[8]));
$site_name=stripslashes(trim($var_row[9]));
$balance_required_for_payment=stripslashes(trim($var_row[10]));
$currency=stripslashes(trim($var_row[11]));
$currency_type=stripslashes(trim($var_row[12]));
# echo $domain_fee=stripslashes(trim($var_row[13])); die;
$domain_fee=stripslashes(trim($var_row[13]));
$resolve_server=stripslashes(trim($var_row[14]));
$run_domain_expire=stripslashes(trim($var_row[15]));
$http_web=stripslashes(trim($var_row[16]));
$server_root=stripslashes(trim($var_row[17]));
$below_public=stripslashes(trim($var_row[18]));
$default_reseller_cpanel_theme=stripslashes(trim($var_row[19]));
$http_web_tools=stripslashes(trim($var_row[20]));
$http_admin=stripslashes(trim($var_row[21]));
$http_admin_tools=stripslashes(trim($var_row[22]));
$http_images=stripslashes(trim($var_row[23]));
$server_backup=stripslashes(trim($var_row[24]));
$resolver_log=stripslashes(trim($var_row[25]));
$server_tools=stripslashes(trim($var_row[26]));
$server_admin_inc=stripslashes(trim($var_row[27]));
$server_inc=stripslashes(trim($var_row[28]));
$server_admin=stripslashes(trim($var_row[29]));
$server_admin_tools=stripslashes(trim($var_row[30]));
$license=stripslashes(trim($var_row[31]));
$http_images=stripslashes(trim($var_row[32]));
$server_backup=stripslashes(trim($var_row[33]));
$resolver_log=stripslashes(trim($var_row[34]));
$server_tools=stripslashes(trim($var_row[35]));
$server_admin_inc=stripslashes(trim($var_row[36]));
$server_inc=stripslashes(trim($var_row[37]));
$server_admin=stripslashes(trim($var_row[38]));
$server_admin_tools=stripslashes(trim($var_row[39]));
$local_lang=stripslashes(trim($var_row[40]));
$invoice_notice_period=stripslashes(trim($var_row[41]));
$tos_agreement=stripslashes(trim($var_row[42]));
if (trim($tos_agreement)=="") { $tos_agreement=$http_web."/tos.php"; }
$email_admin=stripslashes(trim($var_row[47]));
if (trim($email_admin)=="") { $email_admin=$email_support; }
$session_expire=stripslashes(trim($var_row[43]));
$use_enom=stripslashes(trim($var_row[44]));
$send_reminders=stripslashes(trim($var_row[45]));
$do_registrations=stripslashes(trim($var_row[46]));
$activate_support=stripslashes(trim($var_row[48]));
$enable_debugging=stripslashes(trim($var_row[49]));
$charset=stripslashes(trim($var_row[50]));
$ip_restrict=stripslashes(trim($var_row[51]));
$allow_proxy=stripslashes(trim($var_row[52]));
$activate_serverstats=stripslashes(trim($var_row[53]));
$maintenance=stripslashes(trim($var_row[54]));
$current_mib_version="2.5.31[tw] - [ Zend ]";
// Checking Language

#if (isset($_REQUEST["Language"])) {$_SESSION["Language"] = $_REQUEST["Language"];} //if language is posted, get it.
#if (isset($_SESSION["Language"])){$local_lang = $_SESSION["Language"];}    //if session, set local_lang = Session

?>