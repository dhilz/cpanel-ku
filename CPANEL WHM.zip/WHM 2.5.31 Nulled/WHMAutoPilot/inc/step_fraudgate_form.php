<?
$query="select ";
$query.="first_name, ";			// 0
$query.="last_name, ";			// 1
$query.="organization_name, ";	// 2
$query.="street_address_1, ";	// 3
$query.="street_address_2, ";	// 4
$query.="city, ";				// 5
$query.="state, ";				// 6
$query.="zip_code, ";			// 7
$query.="country, ";			// 8
$query.="phone, ";				// 9
$query.="fax, ";				// 10
$query.="email, ";				// 11
$query.="username, ";			// 12
$query.="password, ";			// 13
$query.="advert, ";				// 14
$query.="advert_other, ";		// 15
$query.="tos, ";				// 16
$query.="pid, ";				// 17
$query.="payment_term, ";		// 18
$query.="domain_name, ";		// 19
$query.="domain_registration, ";// 20
$query.="domain_expire, ";		// 21
$query.="payment_method, ";		// 22
$query.="whm_username, ";		// 23
$query.="whm_password, ";		// 24
$query.="promotion_code, ";		// 25
$query.="referrer_id, ";		// 26
$query.="uid, ";				// 27
$query.="client_ip, ";			// 28
$query.="addon_choices, ";		// 29
$query.="client_notes, ";		// 30
$query.="whm_id, ";				// 31
$query.="pns1, ";				// 32
$query.="pns2, ";				// 33
$query.="server_hostname, ";	// 34
$query.="root_pw, ";			// 35
$query.="tld ";					// 35
$query.="from session_history ";
$query.="where sid='".addslashes(trim($sid))."'";

$rs=mysql_fetch_row(mysql_query($query));

$first_name=stripslashes(trim($rs[0]));
$last_name=stripslashes(trim($rs[1]));
$organization_name=stripslashes(trim($rs[2]));
$street_address_1=stripslashes(trim($rs[3]));
$street_address_2=stripslashes(trim($rs[4]));
$city=stripslashes(trim($rs[5]));
$state=stripslashes(trim($rs[6]));
$zip_code=stripslashes(trim($rs[7]));
$country=stripslashes(trim($rs[8]));
$phone=stripslashes(trim($rs[9]));
$fax=stripslashes(trim($rs[10]));
$email=stripslashes(trim($rs[11]));
$username=stripslashes(trim($rs[12]));
$password=stripslashes(trim($rs[13]));
$advert=stripslashes(trim($rs[14]));
$advert_other=stripslashes(trim($rs[15]));
$tos=stripslashes(trim($rs[16]));
$pid=stripslashes(trim($rs[17]));
$payment_term=stripslashes(trim($rs[18]));
$payment_term=strtolower($payment_term);
$domain_expire=stripslashes(trim($rs[21]));
$payment_method=stripslashes(trim($rs[22]));
$whm_username=stripslashes(trim($rs[23]));
$whm_password=stripslashes(trim($rs[24]));
$coupon_code=stripslashes(trim($rs[25]));
$referrer_id=stripslashes(trim($rs[26]));
$uid=stripslashes(trim($rs[27]));
$client_ip=stripslashes(trim($rs[28]));
$addon_choices=stripslashes(trim($rs[29]));
$client_notes=stripslashes(trim($rs[30]));
$whm_id=stripslashes(trim($rs[31]));
$pns1=stripslashes(trim($rs[32]));
$pns2=stripslashes(trim($rs[33]));
$server_hostname=stripslashes(trim($rs[34]));
$root_pw=stripslashes(trim($rs[35]));
$domain_name=stripslashes(trim($rs[19]));
$domain_registration=stripslashes(trim($rs[20]));
$tld_id=stripslashes(trim($rs[36]));

if ($domain_registration==1)
	{
	$query_tld="select ";
	$query_tld.="tld, ";
	$query_tld.="cost, ";
	$query_tld.="reg_period ";
	$query_tld.="from ";
	$query_tld.="tld_chart ";
	$query_tld.="where ";
	$query_tld.="tld_id='".addslashes(trim($tld_id))."'";

	$rs_tld=mysql_fetch_row(mysql_query($query_tld));

	$domain_name=$domain_name.".".stripslashes(trim($rs_tld[0]));
	$cost_per_tld=stripslashes(trim($rs_tld[1]));
	$reg_period=stripslashes(trim($rs_tld[2]));
	$text_peryear=$currency.sprintf("%01.2f", $cost_per_tld)." ".$currency_type;
	$text_peryear.=" per ";
	if ($reg_period==1) { $text_peryear.="1 year"; }
	else if ($reg_period==2) { $text_peryear.="2 years"; }
	else if ($reg_period==3) { $text_peryear.="5 years"; }
	else if ($reg_period==4) { $text_peryear.="10 years"; }
	}
 
$query0="select ";
$query0.="package_name, ";		// 0
$query0.="monthly_cost, ";		// 1
$query0.="quarterly_cost, ";	// 2
$query0.="semi_annual_cost, ";	// 3
$query0.="annual_cost, ";		// 4
$query0.="setup_cost, ";		// 5
$query0.="web_space, ";			// 6
$query0.="bandwidth, ";			// 7
$query0.="email, ";				// 8
$query0.="gid, ";				// 9
$query0.="addon_gid, ";			// 10
$query0.="free_trial, ";		// 11
$query0.="free_trial_length, ";	// 12
$query0.="dedicated ";			// 13
$query0.="from plan_specs ";
$query0.="where pid='".addslashes(trim($pid))."'";

$rs0=mysql_fetch_row(mysql_query($query0));

$package_name=stripslashes(trim($rs0[0]));
$monthly_cost=stripslashes(trim($rs0[1]));
$quarterly_cost=stripslashes(trim($rs0[2]));
$semi_annual_cost=stripslashes(trim($rs0[3]));
$annual_cost=stripslashes(trim($rs0[4]));
$setup_cost=stripslashes(trim($rs0[5]));
$web_space=stripslashes(trim($rs0[6]));
$bandwidth=stripslashes(trim($rs0[7]));
$email_wp=stripslashes(trim($rs0[8]));
$gid=stripslashes(trim($rs0[9]));
$addon_gid=stripslashes(trim($rs0[10]));
$free_trial=stripslashes(trim($rs0[11]));
$free_trial_length=stripslashes(trim($rs0[12]));
$dedicated=stripslashes(trim($rs0[13]));

$rs1=mysql_fetch_row(mysql_query("select name from plan_groups where gid='".addslashes(trim($gid))."'"));
$plan_group_name=stripslashes(trim($rs1[0]));

$rs2=mysql_fetch_row(mysql_query("select name from payment_process where pid='".addslashes(trim($payment_method))."'"));
$payment_type_name=stripslashes(trim($rs2[0]));

if (strcmp("monthly", $payment_term)==0)
	{
	$payment_term="Monthly";
	$formatted_cost=$currency.sprintf("%01.2f", $monthly_cost)." ".$currency_type;
	$term=1;
	}
else if (strcmp("quarterly", $payment_term)==0)
	{
	$payment_term="Quarterly";
	$formatted_cost=$currency.sprintf("%01.2f", $quarterly_cost)." ".$currency_type;
	$term=3;
	}
else if (strcmp("semi_annual", $payment_term)==0)
	{
	$payment_term="Semi-Annual";
	$formatted_cost=$currency.sprintf("%01.2f", $semi_annual_cost)." ".$currency_type;
	$term=6;
	}
else if (strcmp("annual", $payment_term)==0)
	{
	$payment_term="Annual";
	$formatted_cost=$currency.sprintf("%01.2f", $annual_cost)." ".$currency_type;
	$term=12;
	}

// --- FORMS --- //

if (strcmp("authorize.net", strtolower($payment_type_name))==0)
	{
	$parse_out0.="<form action='".$http_web."/credit_card.php' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='sid' value='".trim($sid)."'>\n";
	$parse_out0.="<input type='hidden' name='gid' value='".trim($gid)."'>\n";
	}
else if (strcmp("mail in payment", strtolower($payment_type_name))==0)
	{
	$parse_out0.="<form action='".$http_web."/verify_order.php' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='pay_mod' value='mail_in_payment'>\n";
	$parse_out0.="<input type='hidden' name='sid' value='".trim($sid)."'>\n";
	$parse_out0.="<input type='hidden' name='gid' value='".trim($gid)."'>\n";
	$parse_out0.="<input type='hidden' name='total_due_today' value='".base64_encode(trim($total_due_today))."'>\n";
	$parse_out0.="<input type='hidden' name='total_due_reoccur' value='".base64_encode(trim($total_reoccur))."'>\n";
	}
else if (strcmp("paypal", strtolower($payment_type_name))==0)
	{
	$rsp=mysql_fetch_row(mysql_query("select paypal_address, paypal_image_url from payment_process where pid='".addslashes(trim($payment_method))."'"));

	$parse_out0.="<form action='https://www.paypal.com/cgi-bin/webscr' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='cmd' value='_xclick-subscriptions'>\n";
	$parse_out0.="<input type='hidden' name='business' value='".trim($rsp[0])."'>\n";
	$parse_out0.="<input type='hidden' name='item_name' value='".$package_name." [".$domain_name."]'>\n";
	$parse_out0.="<input type='hidden' name='custom' value='".$sid."'>\n";
	$parse_out0.="<input type='hidden' name='return' value='".$http_web."/paypal_success.php'>\n";
	$parse_out0.="<input type='hidden' name='cancel_return' value='".$http_web."/step_one.php'>\n";

	$parse_out0.="<input type='hidden' name='p3' value='".$term."'>\n";
	$parse_out0.="<input type='hidden' name='t3' value='M'>\n";
	$parse_out0.="<input type='hidden' name='src' value='1'>\n";
	$parse_out0.="<input type='hidden' name='sra' value='1'>\n";
	$parse_out0.="<input type='hidden' name='currency_code' value='".trim($currency_type)."'>\n";
	$parse_out0.="<input type='hidden' name='no_shipping' value='1'>\n";
	$parse_out0.="<input type='hidden' name='rm' value='2'>\n";
	$parse_out0.="<input type='hidden' name='no_note' value='1'>\n";
	if (trim($rsp[1])!="") { $parse_out0.="<input type='hidden' name='image_url' value='".$rsp[1]."'>\n"; }

	if ($free_trial==1)
		{
		$parse_out0.="<input type='hidden' name='a1' value='".$cost_per_tld."'>\n";
		$parse_out0.="<input type='hidden' name='p1' value='".$free_trial_length."'>\n";
		$parse_out0.="<input type='hidden' name='t1' value='M'>\n";

		$parse_out0.="<input type='hidden' name='a2' value='".sprintf("%01.2f", $total_due_today)."'>\n";
		$parse_out0.="<input type='hidden' name='p2' value='".trim($term)."'>\n";
		$parse_out0.="<input type='hidden' name='t2' value='M'>\n";
		}
	else
		{
		$parse_out0.="<input type='hidden' name='a1' value='".sprintf("%01.2f", $total_due_today)."'>\n";
		$parse_out0.="<input type='hidden' name='p1' value='".trim($term)."'>\n";
		$parse_out0.="<input type='hidden' name='t1' value='M'>\n";
		}

	$parse_out0.="<input type='hidden' name='a3' value='".sprintf("%01.2f", $total_reoccur)."'>\n";
	}
else if (strcmp("paysystems tpp-pro", strtolower($payment_type_name))==0)
	{
	$rsp=mysql_fetch_row(mysql_query("select paysystems_companyid from payment_process where pid='".addslashes(trim($payment_method))."'"));

	$rspd=mysql_fetch_row(mysql_query("select tpp_pro_period from plan_specs where pid='".addslashes(trim($pid))."'"));

	// Get the days of payment cycle
	if ($term==1) {$xpterm=30;}
	else if ($term==3) {$xpterm=90;}
	else if ($term==6) {$xpterm=180;}
	else if ($term==12) {$xpterm=360;}

	$parse_out0.="<form action='https://secure.paysystems1.com/cgi-v310/payment/onlinesale-tpppro.asp' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='companyid' value='".trim($rsp[0])."'>\n";
	$parse_out0.="<input type='hidden' name='product1' value='".$package_name." [".$domain_name."]'>\n";
	$parse_out0.="<input type='hidden' name='formget' value='N'>\n";
	$parse_out0.="<input type='hidden' name='redirect' value='".$http_web."/tpp_pro_success.php'>\n";
	$parse_out0.="<input type='hidden' name='redirectfail' value='".$http_web."/index.php'>\n";
	$parse_out0.="<input type='hidden' name='option1' value='".base64_encode(e("576cb7f68040520768bf51c75f7f4c84", $sid))."'>\n";
	$parse_out0.="<input type='hidden' name='reoccur' value='Y'>\n";
	$parse_out0.="<input type='hidden' name='cycle' value='".$xpterm."'>\n";
	$parse_out0.="<input type='hidden' name='totalperiod' value='".$rspd[0]."'>\n";

	$parse_out0.="<input type='hidden' name='total' value='".sprintf("%01.2f",($total_due_today))."'>\n";
	$parse_out0.="<input type='hidden' name='repeatamount' value='".sprintf("%01.2f", $total_reoccur)."'>\n";
	}
else if (strcmp("2checkout", strtolower($payment_type_name))==0)
	{
	$rsp=mysql_fetch_row(mysql_query("select checkout_sid, demo, co_system from payment_process where pid='".addslashes(trim($payment_method))."'"));
	# $rsp=mysql_fetch_row(mysql_query("select checkout_sid, demo from payment_process where pid='".addslashes(trim($payment_method))."'"));

	$rspd=mysql_fetch_row(mysql_query("select monthly_pid, quarterly_pid, semi_annual_pid, annual_pid from plan_specs where pid='".addslashes(trim($pid))."'"));

	if ($term==1) { $mqsaa_pid=$rspd[0]; }
	else if ($term==3) { $mqsaa_pid=$rspd[1]; }
	else if ($term==6) { $mqsaa_pid=$rspd[2]; }
	else if ($term==12) { $mqsaa_pid=$rspd[3]; }

	if ($rsp[2]==0)
		{
		$parse_out0.="<form action='https://www.2checkout.com/cgi-bin/crbuyers/recpurchase.2c' method='POST'>\n";
		$parse_out0.="<input type='hidden' name='merchant_order_id' value='".trim($sid."|0")."'>\n";
		}
	else
		{
		$parse_out0.="<form action='https://www2.2checkout.com/2co/buyer/purchase' method='POST'>\n";
		$parse_out0.="<input type='hidden' name='quantity' value='1'>\n";
		$parse_out0.="<input type='hidden' name='merchant_product_id' value='".trim($sid."|0")."'>\n";
		}


	$parse_out0.="<input type='hidden' name='sid' value='".trim($rsp[0])."'>\n";
	$parse_out0.="<input type='hidden' name='product_id' value='".$mqsaa_pid."'>\n";

	if (trim($rsp[1])==1) { $parse_out0.="<input type='hidden' name='demo' value='Y'>\n"; }
	}
else if (strcmp("worldpay future pay", strtolower($payment_type_name))==0)
	{
	// get the paypal addr from the payment_process table
	$rsp=mysql_fetch_row(mysql_query("select worldpay_id, worldpay_cc, worldpay_demo from payment_process where pid='".addslashes(trim($payment_method))."'"));

	// Get the link id
	if ($term==1)  { $intrval=1; }
	else if ($term==3) { $intrval=3; }
	else if ($term==6) { $intrval=6; }
	else if ($term==12) { $intrval=12; }

	$parse_out0.="<form action='https://select.worldpay.com/wcc/purchase' method='POST'>\n";
	$parse_out0.="<input type='hidden' name='desc' value='".$package_name." [".$domain_name."]'>\n";
	$parse_out0.="<input type='hidden' name='cartId' value='".trim($sid)."'>\n";
	$parse_out0.="<input type='hidden' name='instId' value='".trim($rsp[0])."'>\n";
	$parse_out0.="<input type='hidden' name='currency' value='".trim($rsp[1])."'>\n";
	$parse_out0.="<input type='hidden' name='futurePayType' value='regular'>\n";
	$parse_out0.="<input type='hidden' name='option' value='1'>\n";
	$parse_out0.="<input type='hidden' name='startDelayUnit' value='3'>\n";
	$parse_out0.="<input type='hidden' name='startDelayMult' value='".$intrval."'>\n";
	$parse_out0.="<input type='hidden' name='intervalUnit' value='3'>\n";
	$parse_out0.="<input type='hidden' name='intervalMult' value='".$intrval."'>\n";
	$xlink=str_replace("http://", "", strtolower($http_web));
	$xlink=str_replace("https://", "", $xlink);
	$parse_out0.="<input type='hidden' name='MC_callback' value='".trim($xlink)."/worldpay_success.php'>\n";
	$parse_out0.="<input type='hidden' name='testMode' value='".$rsp[2]."'>\n";
	}

echo $parse_out0;
echo "<center><input ".$button_style." type='submit' name='submit' value='Click to continue'></center>";
echo "</form>";
?>
