<?PHP

include "var.php";
include "connect.php";

$WHERE[here] = "http://".$_SERVER['HTTP_HOST'];
		if (!strpos($_SERVER['HTTP_REFERER'], $_SERVER['HTTP_HOST'])) 
		{
		header("Location: $WHERE[here]");
		exit();
		}

if (isset($del))
	{
	@unlink($server_inc."/install.php");
	@unlink($server_inc."/install1.php");
	@unlink($server_inc."/install2.php");
	@unlink($server_inc."/install3.php");
	@unlink($server_inc."/install4.php");
	@unlink($server_inc."/install_var.php");
	@unlink($server_inc."/Master_DB.sql");
	@unlink($server_inc."/install_connect.php");
	@unlink($server_inc."/install_header.php");
	@unlink($server_inc."/install_footer.php");

	for ($i=0; $i<=30; $i++) { @unlink($server_inc."/install[".$i."].gif"); }

	$query="select ";
	$query.="sid ";
	$query.="from ";
	$query.="user ";
	$query.="where ";
	$query.="status='69' ";
	$query.="limit 0, 1";
	$rs=mysql_fetch_row(mysql_query($query));

	function start($expire)
		{
		GLOBAL $REMOTE_ADDR;

		mysql_query("delete from session");
		mysql_query("insert into session set sid='".md5($REMOTE_ADDR)."', created='".time()."'");

		return 1;
		}
	start($expire);

	header("Location: ".$http_admin."/index2.php?sid=".$rs[0]);
	exit;
	}

$b=4;
include "install_header.php";

echo("
	<table width='100%' cellpadding='4' cellspacing='0' border='0'>
		<tr>
			<td><img src='install[1].gif'>&nbsp;<font color='#0F82B8'><b>WHM AutoPilot was installed successfully!</b></font></td>
		</tr>
		<tr>
			<td>Thank You for choosing WHM AutoPilot Client Management System Nullified by VST.</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><b>Please create the following Cron Jobs:</b></td>
		</tr>
		<tr>
			<td><hr color='#F7F3F7'></td>
		</tr>
		<tr>
			<td><img src='install[0].gif'>&nbsp;Will run daily at 12:15 AM:</td>
		</tr>
		<tr>
			<td><font color='#C60C08' size='1'>15 0 * * * GET ".$http_admin."/cron_1215.php > /dev/null</font></td>
		</tr>
		<tr>
			<td><hr color='#F7F3F7'></td>
		</tr>
		<tr>
			<td><img src='install[0].gif'>&nbsp;Will run daily, every 8 hours:</td>
		</tr>
		<tr>
			<td><font color='#C60C08' size='1'>0 */8 * * * GET ".$http_admin."/cron_resolver.php > /dev/null</font></td>
		</tr>
		<tr>
			<td><hr color='#F7F3F7'></td>
		</tr>
		<tr>
			<td><img src='install[0].gif'>&nbsp;Will run weekly on Fridays:</td>
		</tr>
		<tr>
			<td><font color='#C60C08' size='1'>5 0 * * 6 GET ".$http_admin."/cron_weekly_sales.php > /dev/null</font></td>
		</tr>
		<tr>
			<td><hr color='#F7F3F7'></td>
		</tr>
		<tr>
			<td><img src='install[0].gif'>&nbsp;Will run on the first of the month:</td>
		</tr>
		<tr>
			<td><font color='#C60C08' size='1'>0 0 1 * * GET ".$http_admin."/cron_reports_new_monthly_signups.php > /dev/null</font></td>
		</tr>
		<tr>
			<td><font color='#C60C08' size='1'>0 0 1 * * GET ".$http_admin."/cron_reports_monthly_revenue.php> /dev/null</font></td>
		</tr>
		<tr>
			<td><hr color='#F7F3F7'></td>
		</tr>
		<tr>
			<td><a href='".$PHP_SELF."?del=5'><b>Click here</b></a> to continue to admin.</td>
		</tr>
	</table>
	");

include "install_footer.php";
mysql_close($dblink);
?>