<?PHP
// Displays a list of the 50 x_states
function display_states($state, $input_style)
	{
	GLOBAL $sorp;

	return ("
<select name='state' ".$input_style."".((isset($sorp))?"".(($sorp==0)?"":" disabled")."":"").">
	<option value='AL'".(($state=="AL")?" selected":"").">Alabama</option>
	<option value='AK'".(($state=="AK")?" selected":"").">Alaska</option>
	<option value='AS'".(($state=="AS")?" selected":"").">American Samoa</option>
	<option value='AZ'".(($state=="AZ")?" selected":"").">Arizona</option>
	<option value='AR'".(($state=="AR")?" selected":"").">Arkansas</option>
	<option value='CA'".(($state=="CA")?" selected":"").">California</option>
	<option value='CO'".(($state=="CO")?" selected":"").">Colorado</option>
	<option value='CT'".(($state=="CT")?" selected":"").">Connecticut</option>
	<option value='DE'".(($state=="DE")?" selected":"").">Delaware</option>
	<option value='DC'".(($state=="DC")?" selected":"").">District of Columbia</option>
	<option value='FM'".(($state=="FM")?" selected":"").">States of Micronesia</option>
	<option value='FL'".(($state=="FL")?" selected":"").">Florida</option>
	<option value='GA'".(($state=="GA")?" selected":"").">Georgia</option>
	<option value='GU'".(($state=="GU")?" selected":"").">Guam</option>
	<option value='HI'".(($state=="HI")?" selected":"").">Hawaii</option>
	<option value='ID'".(($state=="ID")?" selected":"").">Idaho</option>
	<option value='IL'".(($state=="IL")?" selected":"").">Illinois</option>
	<option value='IN'".(($state=="IN")?" selected":"").">Indiana</option>
	<option value='IA'".(($state=="IA")?" selected":"").">Iowa</option>
	<option value='KS'".(($state=="KS")?" selected":"").">Kansas</option>
	<option value='KY'".(($state=="KY")?" selected":"").">Kentucky</option>
	<option value='LA'".(($state=="LA")?" selected":"").">Louisiana</option>
	<option value='ME'".(($state=="ME")?" selected":"").">Maine</option>
	<option value='MH'".(($state=="MH")?" selected":"").">Marshall Islands</option>
	<option value='MD'".(($state=="MD")?" selected":"").">Maryland</option>
	<option value='MA'".(($state=="MA")?" selected":"").">Massachusetts</option>
	<option value='MI'".(($state=="MI")?" selected":"").">Michigan</option>
	<option value='MN'".(($state=="MN")?" selected":"").">Minnesota</option>
	<option value='MS'".(($state=="MS")?" selected":"").">Mississippi</option>
	<option value='MO'".(($state=="MO")?" selected":"").">Missouri</option>
	<option value='MT'".(($state=="MT")?" selected":"").">Montana</option>
	<option value='NE'".(($state=="NE")?" selected":"").">Nebraska</option>
	<option value='NV'".(($state=="NV")?" selected":"").">Nevada</option>
	<option value='NH'".(($state=="NH")?" selected":"").">New Hampshire</option>
	<option value='NJ'".(($state=="NJ")?" selected":"").">New Jersey</option>
	<option value='NM'".(($state=="NM")?" selected":"").">New Mexico</option>
	<option value='NY'".(($state=="NY")?" selected":"").">New York</option>
	<option value='NC'".(($state=="NC")?" selected":"").">North Carolina</option>
	<option value='ND'".(($state=="ND")?" selected":"").">North Dakota</option>
	<option value='MP'".(($state=="MP")?" selected":"").">Northern Mariana Is.</option>
	<option value='OH'".(($state=="OH")?" selected":"").">Ohio</option>
	<option value='OK'".(($state=="OK")?" selected":"").">Oklahoma</option>
	<option value='OR'".(($state=="OR")?" selected":"").">Oregon</option>
	<option value='PW'".(($state=="PW")?" selected":"").">Palau</option>
	<option value='PA'".(($state=="PA")?" selected":"").">Pennsylvania</option>
	<option value='PR'".(($state=="PR")?" selected":"").">Puerto Rico</option>
	<option value='RI'".(($state=="RI")?" selected":"").">Rhode Island</option>
	<option value='SC'".(($state=="SC")?" selected":"").">South Carolina</option>
	<option value='SD'".(($state=="SD")?" selected":"").">South Dakota</option>
	<option value='TN'".(($state=="TN")?" selected":"").">Tennessee</option>
	<option value='TX'".(($state=="TX")?" selected":"").">Texas</option>
	<option value='UT'".(($state=="UT")?" selected":"").">Utah</option>
	<option value='VT'".(($state=="VT")?" selected":"").">Vermont</option>
	<option value='VA'".(($state=="VA")?" selected":"").">Virginia</option>
	<option value='VI'".(($state=="VI")?" selected":"").">Virgin Islands</option>
	<option value='WA'".(($state=="WA")?" selected":"").">Washington</option>
	<option value='WV'".(($state=="WV")?" selected":"").">West Virginia</option>
	<option value='WI'".(($state=="WI")?" selected":"").">Wisconsin</option>
	<option value='WY'".(($state=="WY")?" selected":"").">Wyoming</option>
	<option value='AA'".(($state=="AA")?" selected":"").">Armed Forces Americas</option>
	<option value='AE'".(($state=="AE")?" selected":"").">Armed Forces Europe</option>
	<option value='AP'".(($state=="AP")?" selected":"").">Armed Forces Pacific</option>
	</select> 
		");
	}

// valid 2 digit country codes for auth.net
function display_country($xCountry, $input_style)
	{
	return ("
	<select name='x_Country' ".$input_style.">
		<option value='US'".(($x_Country=="US")?" selected":"").">UNITED STATES</option>
		<option value='AF'".(($x_Country=="AF")?" selected":"").">AFGHANISTAN</option>
		<option value='AL'".(($x_Country=="AL")?" selected":"").">ALBANIA</option>
		<option value='DZ'".(($x_Country=="DZ")?" selected":"").">ALGERIA</option>
		<option value='AS'".(($x_Country=="AS")?" selected":"").">AMERICAN SAMOA</option>
		<option value='AD'".(($x_Country=="AD")?" selected":"").">ANDORRA</option>
		<option value='AO'".(($x_Country=="AO")?" selected":"").">ANGOLA</option>
		<option value='AI'".(($x_Country=="AI")?" selected":"").">ANGUILLA</option>
		<option value='AQ'".(($x_Country=="AQ")?" selected":"").">ANTARCTICA</option>
		<option value='AG'".(($x_Country=="AG")?" selected":"").">ANTIGUA / BARBUDA</option>
		<option value='AR'".(($x_Country=="AR")?" selected":"").">ARGENTINA</option>
		<option value='AM'".(($x_Country=="AM")?" selected":"").">ARMENIA</option>
		<option value='AW'".(($x_Country=="AW")?" selected":"").">ARUBA</option>
		<option value='AU'".(($x_Country=="AU")?" selected":"").">AUSTRALIA</option>
		<option value='AT'".(($x_Country=="AT")?" selected":"").">AUSTRIA</option>
		<option value='AZ'".(($x_Country=="AZ")?" selected":"").">AZERBAIJAN</option>
		<option value='BS'".(($x_Country=="BS")?" selected":"").">BAHAMAS</option>
		<option value='BH'".(($x_Country=="BH")?" selected":"").">BAHRAIN</option>
		<option value='BD'".(($x_Country=="BD")?" selected":"").">BANGLADESH</option>
		<option value='BB'".(($x_Country=="BB")?" selected":"").">BARBADOS</option>
		<option value='BY'".(($x_Country=="BY")?" selected":"").">BELARUS</option>
		<option value='BE'".(($x_Country=="BE")?" selected":"").">BELGIUM</option>
		<option value='BZ'".(($x_Country=="BZ")?" selected":"").">BELIZE</option>
		<option value='BJ'".(($x_Country=="BJ")?" selected":"").">BENIN</option>
		<option value='BM'".(($x_Country=="BM")?" selected":"").">BERMUDA</option>
		<option value='BT'".(($x_Country=="BT")?" selected":"").">BHUTAN</option>
		<option value='BO'".(($x_Country=="BO")?" selected":"").">BOLIVIA</option>
		<option value='BA'".(($x_Country=="BA")?" selected":"").">BOSNIA / HERZEGOVINA</option>
		<option value='BW'".(($x_Country=="BW")?" selected":"").">BOTSWANA</option>
		<option value='BV'".(($x_Country=="BV")?" selected":"").">BOUVET ISLAND</option>
		<option value='BR'".(($x_Country=="BR")?" selected":"").">BRAZIL</option>
		<option value='IO'".(($x_Country=="IO")?" selected":"").">BRITISH INDIAN OCEAN TERRITORY</option>
		<option value='BN'".(($x_Country=="BN")?" selected":"").">BRUNEI DARUSSALAM</option>
		<option value='BG'".(($x_Country=="BG")?" selected":"").">BULGARIA</option>
		<option value='BF'".(($x_Country=="BF")?" selected":"").">BURKINA FASO</option>
		<option value='BI'".(($x_Country=="BI")?" selected":"").">BURUNDI</option>
		<option value='KH'".(($x_Country=="KH")?" selected":"").">CAMBODIA</option>
		<option value='CM'".(($x_Country=="CM")?" selected":"").">CAMEROON</option>
		<option value='CA'".(($x_Country=="CA")?" selected":"").">CANADA</option>
		<option value='CV'".(($x_Country=="CV")?" selected":"").">CAPE VERDE</option>
		<option value='KY'".(($x_Country=="KY")?" selected":"").">CAYMAN ISLANDS</option>
		<option value='CF'".(($x_Country=="CF")?" selected":"").">CENTRAL AFRICAN REPUBLIC</option>
		<option value='TD'".(($x_Country=="TD")?" selected":"").">CHAD</option>
		<option value='CL'".(($x_Country=="CL")?" selected":"").">CHILE</option>
		<option value='CN'".(($x_Country=="CN")?" selected":"").">CHINA</option>
		<option value='CX'".(($x_Country=="CX")?" selected":"").">CHRISTMAS ISLAND</option>
		<option value='CC'".(($x_Country=="CC")?" selected":"").">COCOS (KEELING) ISLANDS</option>
		<option value='CO'".(($x_Country=="CO")?" selected":"").">COLOMBIA</option>
		<option value='KM'".(($x_Country=="KM")?" selected":"").">COMOROS</option>
		<option value='CG'".(($x_Country=="CG")?" selected":"").">CONGO</option>
		<option value='CD'".(($x_Country=="CD")?" selected":"").">CONGO, DEMOCRATIC REPUBLIC</option>
		<option value='CK'".(($x_Country=="CK")?" selected":"").">COOK ISLANDS</option>
		<option value='CR'".(($x_Country=="CR")?" selected":"").">COSTA RICA</option>
		<option value='CI'".(($x_Country=="CI")?" selected":"").">C�TE D'IVOIRE</option>
		<option value='HR'".(($x_Country=="HR")?" selected":"").">CROATIA</option>
		<option value='CU'".(($x_Country=="CU")?" selected":"").">CUBA</option>
		<option value='CY'".(($x_Country=="CY")?" selected":"").">CYPRUS</option>
		<option value='CZ'".(($x_Country=="CZ")?" selected":"").">CZECH REPUBLIC</option>
		<option value='DK'".(($x_Country=="DK")?" selected":"").">DENMARK</option>
		<option value='DJ'".(($x_Country=="DJ")?" selected":"").">DJIBOUTI</option>
		<option value='DM'".(($x_Country=="DM")?" selected":"").">DOMINICA</option>
		<option value='DO'".(($x_Country=="DO")?" selected":"").">DOMINICAN REPUBLIC</option>
		<option value='EC'".(($x_Country=="EC")?" selected":"").">ECUADOR</option>
		<option value='EG'".(($x_Country=="EG")?" selected":"").">EGYPT</option>
		<option value='SV'".(($x_Country=="SV")?" selected":"").">EL SALVADOR</option>
		<option value='GQ'".(($x_Country=="GQ")?" selected":"").">EQUATORIAL GUINEA</option>
		<option value='ER'".(($x_Country=="ER")?" selected":"").">ERITREA</option>
		<option value='EE'".(($x_Country=="EE")?" selected":"").">ESTONIA</option>
		<option value='ET'".(($x_Country=="ET")?" selected":"").">ETHIOPIA</option>
		<option value='FK'".(($x_Country=="FK")?" selected":"").">FALKLAND ISLANDS (MALVINAS)</option>
		<option value='FO'".(($x_Country=="FO")?" selected":"").">FAROE ISLANDS</option>
		<option value='FJ'".(($x_Country=="FJ")?" selected":"").">FIJI</option>
		<option value='FI'".(($x_Country=="FI")?" selected":"").">FINLAND</option>
		<option value='FR'".(($x_Country=="FR")?" selected":"").">FRANCE</option>
		<option value='GF'".(($x_Country=="GF")?" selected":"").">FRENCH GUIANA</option>
		<option value='PF'".(($x_Country=="PF")?" selected":"").">FRENCH POLYNESIA</option>
		<option value='TF'".(($x_Country=="TF")?" selected":"").">FRENCH SOUTHERN TERRITORIES</option>
		<option value='GA'".(($x_Country=="GA")?" selected":"").">GABON</option>
		<option value='GM'".(($x_Country=="GM")?" selected":"").">GAMBIA</option>
		<option value='GE'".(($x_Country=="GE")?" selected":"").">GEORGIA</option>
		<option value='DE'".(($x_Country=="DE")?" selected":"").">GERMANY</option>
		<option value='GH'".(($x_Country=="GH")?" selected":"").">GHANA</option>
		<option value='GI'".(($x_Country=="GI")?" selected":"").">GIBRALTAR</option>
		<option value='GR'".(($x_Country=="GR")?" selected":"").">GREECE</option>
		<option value='GL'".(($x_Country=="GL")?" selected":"").">GREENLAND</option>
		<option value='GD'".(($x_Country=="GD")?" selected":"").">GRENADA</option>
		<option value='GP'".(($x_Country=="GP")?" selected":"").">GUADELOUPE</option>
		<option value='GU'".(($x_Country=="GU")?" selected":"").">GUAM</option>
		<option value='GT'".(($x_Country=="GT")?" selected":"").">GUATEMALA</option>
		<option value='GN'".(($x_Country=="GN")?" selected":"").">GUINEA</option>
		<option value='GW'".(($x_Country=="GW")?" selected":"").">GUINEA-BISSAU</option>
		<option value='GY'".(($x_Country=="GY")?" selected":"").">GUYANA</option>
		<option value='HT'".(($x_Country=="HT")?" selected":"").">HAITI</option>
		<option value='HM'".(($x_Country=="HM")?" selected":"").">HEARD ISLAND</option>
		<option value='HM'".(($x_Country=="HM")?" selected":"").">MCDONALD ISLANDS</option>
		<option value='VA'".(($x_Country=="VA")?" selected":"").">VATICAN CITY STATE</option>
		<option value='HN'".(($x_Country=="HN")?" selected":"").">HONDURAS</option>
		<option value='HK'".(($x_Country=="HK")?" selected":"").">HONG KONG</option>
		<option value='HU'".(($x_Country=="HU")?" selected":"").">HUNGARY</option>
		<option value='IS'".(($x_Country=="IS")?" selected":"").">ICELAND</option>
		<option value='IN'".(($x_Country=="IN")?" selected":"").">INDIA</option>
		<option value='ID'".(($x_Country=="ID")?" selected":"").">INDONESIA</option>
		<option value='IR'".(($x_Country=="IR")?" selected":"").">IRAN</option>
		<option value='IQ'".(($x_Country=="IQ")?" selected":"").">IRAQ</option>
		<option value='IE'".(($x_Country=="IE")?" selected":"").">IRELAND</option>
		<option value='IL'".(($x_Country=="IL")?" selected":"").">ISRAEL</option>
		<option value='IT'".(($x_Country=="IT")?" selected":"").">ITALY</option>
		<option value='JM'".(($x_Country=="JM")?" selected":"").">JAMAICA</option>
		<option value='JP'".(($x_Country=="JP")?" selected":"").">JAPAN</option>
		<option value='JO'".(($x_Country=="JO")?" selected":"").">JORDAN</option>
		<option value='KZ'".(($x_Country=="KZ")?" selected":"").">KAZAKHSTAN</option>
		<option value='KE'".(($x_Country=="KE")?" selected":"").">KENYA</option>
		<option value='KI'".(($x_Country=="KI")?" selected":"").">KIRIBATI</option>
		<option value='KP'".(($x_Country=="KP")?" selected":"").">KOREA</option>
		<option value='KR'".(($x_Country=="KR")?" selected":"").">KOREA, REPUBLIC OF</option>
		<option value='KW'".(($x_Country=="KW")?" selected":"").">KUWAIT</option>
		<option value='KG'".(($x_Country=="KG")?" selected":"").">KYRGYZSTAN</option>
		<option value='LA'".(($x_Country=="LA")?" selected":"").">LAO PEOPLE'S DEMOCRATIC REPUBLIC</option>
		<option value='LV'".(($x_Country=="LV")?" selected":"").">LATVIA</option>
		<option value='LB'".(($x_Country=="LB")?" selected":"").">LEBANON</option>
		<option value='LS'".(($x_Country=="LS")?" selected":"").">LESOTHO</option>
		<option value='LR'".(($x_Country=="LR")?" selected":"").">LIBERIA</option>
		<option value='LY'".(($x_Country=="LY")?" selected":"").">LIBYAN ARAB JAMAHIRIYA</option>
		<option value='LI'".(($x_Country=="LI")?" selected":"").">LIECHTENSTEIN</option>
		<option value='LT'".(($x_Country=="LT")?" selected":"").">LITHUANIA</option>
		<option value='LU'".(($x_Country=="LU")?" selected":"").">LUXEMBOURG</option>
		<option value='MO'".(($x_Country=="MO")?" selected":"").">MACAO</option>
		<option value='MK'".(($x_Country=="MK")?" selected":"").">MACEDONIA</option>
		<option value='MG'".(($x_Country=="MG")?" selected":"").">MADAGASCAR</option>
		<option value='MW'".(($x_Country=="MW")?" selected":"").">MALAWI</option>
		<option value='MY'".(($x_Country=="MY")?" selected":"").">MALAYSIA</option>
		<option value='MV'".(($x_Country=="MV")?" selected":"").">MALDIVES</option>
		<option value='ML'".(($x_Country=="ML")?" selected":"").">MALI</option>
		<option value='MT'".(($x_Country=="MT")?" selected":"").">MALTA</option>
		<option value='MH'".(($x_Country=="MH")?" selected":"").">MARSHALL ISLANDS</option>
		<option value='MQ'".(($x_Country=="MQ")?" selected":"").">MARTINIQUE</option>
		<option value='MR'".(($x_Country=="MR")?" selected":"").">MAURITANIA</option>
		<option value='MU'".(($x_Country=="MU")?" selected":"").">MAURITIUS</option>
		<option value='YT'".(($x_Country=="YT")?" selected":"").">MAYOTTE</option>
		<option value='MX'".(($x_Country=="MX")?" selected":"").">MEXICO</option>
		<option value='FM'".(($x_Country=="FM")?" selected":"").">MICRONESIA</option>
		<option value='MD'".(($x_Country=="MD")?" selected":"").">MOLDOVA</option>
		<option value='MC'".(($x_Country=="MC")?" selected":"").">MONACO</option>
		<option value='MN'".(($x_Country=="MN")?" selected":"").">MONGOLIA</option>
		<option value='MS'".(($x_Country=="MS")?" selected":"").">MONTSERRAT</option>
		<option value='MA'".(($x_Country=="MA")?" selected":"").">MOROCCO</option>
		<option value='MZ'".(($x_Country=="MZ")?" selected":"").">MOZAMBIQUE</option>
		<option value='MM'".(($x_Country=="MM")?" selected":"").">MYANMAR</option>
		<option value='NA'".(($x_Country=="NA")?" selected":"").">NAMIBIA</option>
		<option value='NR'".(($x_Country=="NR")?" selected":"").">NAURU</option>
		<option value='NP'".(($x_Country=="NP")?" selected":"").">NEPAL</option>
		<option value='NL'".(($x_Country=="NL")?" selected":"").">NETHERLANDS</option>
		<option value='AN'".(($x_Country=="AN")?" selected":"").">NETHERLANDS ANTILLES</option>
		<option value='NC'".(($x_Country=="NC")?" selected":"").">NEW CALEDONIA</option>
		<option value='NZ'".(($x_Country=="NZ")?" selected":"").">NEW ZEALAND</option>
		<option value='NI'".(($x_Country=="NI")?" selected":"").">NICARAGUA</option>
		<option value='NE'".(($x_Country=="NE")?" selected":"").">NIGER</option>
		<option value='NG'".(($x_Country=="NG")?" selected":"").">NIGERIA</option>
		<option value='NU'".(($x_Country=="NU")?" selected":"").">NIUE</option>
		<option value='NF'".(($x_Country=="NF")?" selected":"").">NORFOLK ISLAND</option>
		<option value='MP'".(($x_Country=="MP")?" selected":"").">NORTHERN MARIANA ISLANDS</option>
		<option value='NO'".(($x_Country=="NO")?" selected":"").">NORWAY</option>
		<option value='OM'".(($x_Country=="OM")?" selected":"").">OMAN</option>
		<option value='PK'".(($x_Country=="PK")?" selected":"").">PAKISTAN</option>
		<option value='PW'".(($x_Country=="PW")?" selected":"").">PALAU</option>
		<option value='PS'".(($x_Country=="PS")?" selected":"").">PALESTINIAN TERRITORY</option>
		<option value='PA'".(($x_Country=="PA")?" selected":"").">PANAMA</option>
		<option value='PG'".(($x_Country=="PG")?" selected":"").">PAPUA NEW GUINEA</option>
		<option value='PY'".(($x_Country=="PY")?" selected":"").">PARAGUAY</option>
		<option value='PE'".(($x_Country=="PE")?" selected":"").">PERU</option>
		<option value='PH'".(($x_Country=="PH")?" selected":"").">PHILIPPINES</option>
		<option value='PN'".(($x_Country=="PN")?" selected":"").">PITCAIRN</option>
		<option value='PL'".(($x_Country=="PL")?" selected":"").">POLAND</option>
		<option value='PT'".(($x_Country=="PT")?" selected":"").">PORTUGAL</option>
		<option value='PR'".(($x_Country=="PR")?" selected":"").">PUERTO RICO</option>
		<option value='QA'".(($x_Country=="QA")?" selected":"").">QATAR</option>
		<option value='RE'".(($x_Country=="RE")?" selected":"").">R�UNION</option>
		<option value='RO'".(($x_Country=="RO")?" selected":"").">ROMANIA</option>
		<option value='RU'".(($x_Country=="RU")?" selected":"").">RUSSIAN FEDERATION</option>
		<option value='RW'".(($x_Country=="RW")?" selected":"").">RWANDA</option>
		<option value='SH'".(($x_Country=="SH")?" selected":"").">SAINT HELENA</option>
		<option value='KN'".(($x_Country=="KN")?" selected":"").">SAINT KITTS AND NEVIS</option>
		<option value='LC'".(($x_Country=="LC")?" selected":"").">SAINT LUCIA</option>
		<option value='PM'".(($x_Country=="PM")?" selected":"").">SAINT PIERRE AND MIQUELON</option>
		<option value='VC'".(($x_Country=="VC")?" selected":"").">SAINT VINCENT AND THE GRENADINES</option>
		<option value='WS'".(($x_Country=="WS")?" selected":"").">SAMOA</option>
		<option value='SM'".(($x_Country=="SM")?" selected":"").">SAN MARINO</option>
		<option value='ST'".(($x_Country=="ST")?" selected":"").">SAO TOME AND PRINCIPE</option>
		<option value='SA'".(($x_Country=="SA")?" selected":"").">SAUDI ARABIA</option>
		<option value='SN'".(($x_Country=="SN")?" selected":"").">SENEGAL</option>
		<option value='SC'".(($x_Country=="SC")?" selected":"").">SEYCHELLES</option>
		<option value='SL'".(($x_Country=="SL")?" selected":"").">SIERRA LEONE</option>
		<option value='SG'".(($x_Country=="SG")?" selected":"").">SINGAPORE</option>
		<option value='SK'".(($x_Country=="SK")?" selected":"").">SLOVAKIA</option>
		<option value='SI'".(($x_Country=="SI")?" selected":"").">SLOVENIA</option>
		<option value='SB'".(($x_Country=="SB")?" selected":"").">SOLOMON ISLANDS</option>
		<option value='SO'".(($x_Country=="SO")?" selected":"").">SOMALIA</option>
		<option value='ZA'".(($x_Country=="ZA")?" selected":"").">SOUTH AFRICA</option>
		<option value='GS'".(($x_Country=="GS")?" selected":"").">SOUTH GEORGIA</option>
		<option value='GS'".(($x_Country=="GS")?" selected":"").">THE SOUTH SANDWICH ISLANDS</option>
		<option value='ES'".(($x_Country=="ES")?" selected":"").">SPAIN</option>
		<option value='LK'".(($x_Country=="LK")?" selected":"").">SRI LANKA</option>
		<option value='SD'".(($x_Country=="SD")?" selected":"").">SUDAN</option>
		<option value='SR'".(($x_Country=="SR")?" selected":"").">SURINAME</option>
		<option value='SJ'".(($x_Country=="SJ")?" selected":"").">SVALBARD AND JAN MAYEN</option>
		<option value='SZ'".(($x_Country=="SZ")?" selected":"").">SWAZILAND</option>
		<option value='SE'".(($x_Country=="SE")?" selected":"").">SWEDEN</option>
		<option value='CH'".(($x_Country=="CH")?" selected":"").">SWITZERLAND</option>
		<option value='SY'".(($x_Country=="SY")?" selected":"").">SYRIAN ARAB REPUBLIC</option>
		<option value='TW'".(($x_Country=="TW")?" selected":"").">TAIWAN</option>
		<option value='TJ'".(($x_Country=="TJ")?" selected":"").">TAJIKISTAN</option>
		<option value='TZ'".(($x_Country=="TZ")?" selected":"").">TANZANIA</option>
		<option value='TH'".(($x_Country=="TH")?" selected":"").">THAILAND</option>
		<option value='TL'".(($x_Country=="TL")?" selected":"").">TIMOR-LESTE</option>
		<option value='TG'".(($x_Country=="TG")?" selected":"").">TOGO</option>
		<option value='TK'".(($x_Country=="TK")?" selected":"").">TOKELAU</option>
		<option value='TO'".(($x_Country=="TO")?" selected":"").">TONGA</option>
		<option value='TT'".(($x_Country=="TT")?" selected":"").">TRINIDAD AND TOBAGO</option>
		<option value='TN'".(($x_Country=="TN")?" selected":"").">TUNISIA</option>
		<option value='TR'".(($x_Country=="TR")?" selected":"").">TURKEY</option>
		<option value='TM'".(($x_Country=="TM")?" selected":"").">TURKMENISTAN</option>
		<option value='TC'".(($x_Country=="TC")?" selected":"").">TURKS AND CAICOS ISLANDS</option>
		<option value='TV'".(($x_Country=="TV")?" selected":"").">TUVALU</option>
		<option value='UG'".(($x_Country=="UG")?" selected":"").">UGANDA</option>
		<option value='UA'".(($x_Country=="UA")?" selected":"").">UKRAINE</option>
		<option value='AE'".(($x_Country=="AE")?" selected":"").">UNITED ARAB EMIRATES</option>
		<option value='GB'".(($x_Country=="GB")?" selected":"").">UNITED KINGDOM</option>
		<option value='UM'".(($x_Country=="UM")?" selected":"").">US MINOR OUTLYING ISLANDS</option>
		<option value='UY'".(($x_Country=="UY")?" selected":"").">URUGUAY</option>
		<option value='UZ'".(($x_Country=="UZ")?" selected":"").">UZBEKISTAN</option>
		<option value='VU'".(($x_Country=="VU")?" selected":"").">VANUATU</option>
		<option value='VE'".(($x_Country=="VE")?" selected":"").">VENEZUELA</option>
		<option value='VN'".(($x_Country=="VN")?" selected":"").">VIET NAM</option>
		<option value='VG'".(($x_Country=="VG")?" selected":"").">VIRGIN ISLANDS, BRITISH</option>
		<option value='VI'".(($x_Country=="VI")?" selected":"").">VIRGIN ISLANDS, U.S.</option>
		<option value='WF'".(($x_Country=="WF")?" selected":"").">WALLIS AND FUTUNA</option>
		<option value='EH'".(($x_Country=="EH")?" selected":"").">WESTERN SAHARA</option>
		<option value='YE'".(($x_Country=="YE")?" selected":"").">YEMEN</option>
		<option value='YU'".(($x_Country=="YU")?" selected":"").">YUGOSLAVIA</option>
		<option value='ZM'".(($x_Country=="ZM")?" selected":"").">ZAMBIA</option>
		<option value='ZW'".(($x_Country=="ZW")?" selected":"").">ZIMBABWE</option>
	</select>
		");
	}

function country($country,$input_style)
	{
	echo("
		<SELECT NAME='country' ".$input_style.">
					<OPTION VALUE='US'".((isset($country))?"".(($country=="US")?" selected":"")."":" selected").">United States</option>
					<OPTION VALUE='AF'".(($country=="AF")?" selected":"").">Afghanistan</option>
					<OPTION VALUE='AL'".(($country=="AL")?" selected":"").">Albania</option>
					<OPTION VALUE='DZ'".(($country=="DZ")?" selected":"").">Algeria</option>
					<OPTION VALUE='AS'".(($country=="AS")?" selected":"").">American Samoa</option>
					<OPTION VALUE='AD'".(($country=="AD")?" selected":"").">Andorra</option>
					<OPTION VALUE='AO'".(($country=="AO")?" selected":"").">Angola</option>
					<OPTION VALUE='AI'".(($country=="AI")?" selected":"").">Anguilla</option>
					<OPTION VALUE='AQ'".(($country=="AQ")?" selected":"").">Antarctica</option>
					<OPTION VALUE='AG'".(($country=="AG")?" selected":"").">Antigua And Barbuda</option>
					<OPTION VALUE='AR'".(($country=="AR")?" selected":"").">Argentina</option>
					<OPTION VALUE='AM'".(($country=="AM")?" selected":"").">Armenia</option>
					<OPTION VALUE='AW'".(($country=="AW")?" selected":"").">Aruba</option>
					<OPTION VALUE='AU'".(($country=="AU")?" selected":"").">Australia</option>
					<OPTION VALUE='AT'".(($country=="AT")?" selected":"").">Austria</option>
					<OPTION VALUE='AZ'".(($country=="AZ")?" selected":"").">Azerbaijan</option>
					<OPTION VALUE='BS'".(($country=="BS")?" selected":"").">Bahamas</option>
					<OPTION VALUE='BH'".(($country=="BH")?" selected":"").">Bahrain</option>
					<OPTION VALUE='BD'".(($country=="BD")?" selected":"").">Bangladesh</option>
					<OPTION VALUE='BB'".(($country=="BB")?" selected":"").">Barbados</option>
					<OPTION VALUE='BY'".(($country=="BY")?" selected":"").">Belarus</option>
					<OPTION VALUE='BE'".(($country=="BE")?" selected":"").">Belgium</option>
					<OPTION VALUE='BZ'".(($country=="BZ")?" selected":"").">Belize</option>
					<OPTION VALUE='BJ'".(($country=="BJ")?" selected":"").">Benin</option>
					<OPTION VALUE='BM'".(($country=="BM")?" selected":"").">Bermuda</option>
					<OPTION VALUE='BT'".(($country=="BT")?" selected":"").">Bhutan</option>
					<OPTION VALUE='BO'".(($country=="BO")?" selected":"").">Bolivia</option>
					<OPTION VALUE='BA'".(($country=="BA")?" selected":"").">Bosnia Hercegovina</option>
					<OPTION VALUE='BW'".(($country=="BW")?" selected":"").">Botswana</option>
					<OPTION VALUE='BV'".(($country=="BV")?" selected":"").">Bouvet Island</option>
					<OPTION VALUE='BR'".(($country=="BR")?" selected":"").">Brazil</option>
					<OPTION VALUE='BN'".(($country=="BN")?" selected":"").">Brunei Darussalam</option>
					<OPTION VALUE='BG'".(($country=="BG")?" selected":"").">Bulgaria</option>
					<OPTION VALUE='BF'".(($country=="BF")?" selected":"").">Burkina Faso</option>
					<OPTION VALUE='BI'".(($country=="BI")?" selected":"").">Burundi</option>
					<OPTION VALUE='KH'".(($country=="KH")?" selected":"").">Cambodia</option>
					<OPTION VALUE='CM'".(($country=="CM")?" selected":"").">Cameroon</option>
					<OPTION VALUE='CA'".(($country=="CA")?" selected":"").">Canada</option>
					<OPTION VALUE='CV'".(($country=="CV")?" selected":"").">Cape Verde</option>
					<OPTION VALUE='KY'".(($country=="KY")?" selected":"").">Cayman Islands</option>
					<OPTION VALUE='CF'".(($country=="CF")?" selected":"").">Central African Republic</option>
					<OPTION VALUE='TD'".(($country=="TD")?" selected":"").">Chad</option>
					<OPTION VALUE='CL'".(($country=="CL")?" selected":"").">Chile</option>
					<OPTION VALUE='CN'".(($country=="CN")?" selected":"").">China</option>
					<OPTION VALUE='CX'".(($country=="CX")?" selected":"").">Christmas Island</option>
					<OPTION VALUE='CC'".(($country=="CC")?" selected":"").">Cocos (Keeling) Islands</option>
					<OPTION VALUE='CO'".(($country=="CO")?" selected":"").">Colombia</option>
					<OPTION VALUE='KM'".(($country=="KM")?" selected":"").">Comoros</option>
					<OPTION VALUE='CG'".(($country=="CG")?" selected":"").">Congo</option>
					<OPTION VALUE='CK'".(($country=="CK")?" selected":"").">Cook Islands</option>
					<OPTION VALUE='CR'".(($country=="CR")?" selected":"").">Costa Rica</option>
					<OPTION VALUE='CI'".(($country=="CI")?" selected":"").">Cote D'Ivoire</option>
					<OPTION VALUE='HR'".(($country=="HR")?" selected":"").">Croatia</option>
					<OPTION VALUE='CU'".(($country=="CU")?" selected":"").">Cuba</option>
					<OPTION VALUE='CY'".(($country=="CY")?" selected":"").">Cyprus</option>
					<OPTION VALUE='CZ'".(($country=="CZ")?" selected":"").">Czech Republic</option>
					<OPTION VALUE='CS'".(($country=="CS")?" selected":"").">Czechoslovakia</option>
					<OPTION VALUE='DK'".(($country=="DK")?" selected":"").">Denmark</option>
					<OPTION VALUE='DJ'".(($country=="DJ")?" selected":"").">Djibouti</option>
					<OPTION VALUE='DM'".(($country=="DM")?" selected":"").">Dominica</option>
					<OPTION VALUE='DO'".(($country=="DO")?" selected":"").">Dominican Republic</option>
					<OPTION VALUE='TP'".(($country=="TP")?" selected":"").">East Timor</option>
					<OPTION VALUE='EC'".(($country=="EC")?" selected":"").">Ecuador</option>
					<OPTION VALUE='EG'".(($country=="EG")?" selected":"").">Egypt</option>
					<OPTION VALUE='SV'".(($country=="SV")?" selected":"").">El Salvador</option>
					<OPTION VALUE='GB'".(($country=="GB")?" selected":"").">England</option>
					<OPTION VALUE='GQ'".(($country=="GQ")?" selected":"").">Equatorial Guinea</option>
					<OPTION VALUE='ER'".(($country=="ER")?" selected":"").">Eritrea</option>
					<OPTION VALUE='EE'".(($country=="EE")?" selected":"").">Estonia</option>
					<OPTION VALUE='ET'".(($country=="ET")?" selected":"").">Ethiopia</option>
					<OPTION VALUE='FK'".(($country=="FK")?" selected":"").">Falkland Islands (Malvinas)</option>
					<OPTION VALUE='FO'".(($country=="FO")?" selected":"").">Faroe Islands</option>
					<OPTION VALUE='FJ'".(($country=="FJ")?" selected":"").">Fiji</option>
					<OPTION VALUE='FI'".(($country=="FI")?" selected":"").">Finland</option>
					<OPTION VALUE='FR'".(($country=="FR")?" selected":"").">France</option>
					<OPTION VALUE='FX'".(($country=="FX")?" selected":"").">France, Metropolitan</option>
					<OPTION VALUE='GF'".(($country=="GF")?" selected":"").">French Guiana</option>
					<OPTION VALUE='PF'".(($country=="PF")?" selected":"").">French Polynesia</option>
					<OPTION VALUE='TF'".(($country=="TF")?" selected":"").">French Southern Territories</option>
					<OPTION VALUE='GA'".(($country=="GA")?" selected":"").">Gabon</option>
					<OPTION VALUE='GM'".(($country=="GM")?" selected":"").">Gambia</option>
					<OPTION VALUE='GE'".(($country=="GE")?" selected":"").">Georgia</option>
					<OPTION VALUE='DE'".(($country=="DE")?" selected":"").">Germany</option>
					<OPTION VALUE='GH'".(($country=="GH")?" selected":"").">Ghana</option>
					<OPTION VALUE='GI'".(($country=="GI")?" selected":"").">Gibraltar</option>
					<OPTION VALUE='GB'".(($country=="GB")?" selected":"").">Great Britain</option>
					<OPTION VALUE='GR'".(($country=="GR")?" selected":"").">Greece</option>
					<OPTION VALUE='GL'".(($country=="GL")?" selected":"").">Greenland</option>
					<OPTION VALUE='GD'".(($country=="GD")?" selected":"").">Grenada</option>
					<OPTION VALUE='GP'".(($country=="GP")?" selected":"").">Guadeloupe</option>
					<OPTION VALUE='GU'".(($country=="GU")?" selected":"").">Guam</option>
					<OPTION VALUE='GT'".(($country=="GT")?" selected":"").">Guatemela</option>
					<OPTION VALUE='GG'".(($country=="GG")?" selected":"").">Guernsey</option>
					<OPTION VALUE='GN'".(($country=="GN")?" selected":"").">Guinea</option>
					<OPTION VALUE='GW'".(($country=="GW")?" selected":"").">Guinea-Bissau</option>
					<OPTION VALUE='GY'".(($country=="GY")?" selected":"").">Guyana</option>
					<OPTION VALUE='HT'".(($country=="HT")?" selected":"").">Haiti</option>
					<OPTION VALUE='HM'".(($country=="HM")?" selected":"").">Heard and McDonald Islands</option>
					<OPTION VALUE='HN'".(($country=="HD")?" selected":"").">Holland</option>
					<OPTION VALUE='HN'".(($country=="HN")?" selected":"").">Honduras</option>
					<OPTION VALUE='HK'".(($country=="HK")?" selected":"").">Hong Kong</option>
					<OPTION VALUE='HU'".(($country=="HU")?" selected":"").">Hungary</option>
					<OPTION VALUE='IS'".(($country=="IS")?" selected":"").">Iceland</option>
					<OPTION VALUE='IN'".(($country=="IN")?" selected":"").">India</option>
					<OPTION VALUE='ID'".(($country=="ID")?" selected":"").">Indonesia</option>
					<OPTION VALUE='IR'".(($country=="IR")?" selected":"").">Iran</option>
					<OPTION VALUE='IQ'".(($country=="IQ")?" selected":"").">Iraq</option>
					<OPTION VALUE='IE'".(($country=="IE")?" selected":"").">Ireland</option>
					<OPTION VALUE='IM'".(($country=="IM")?" selected":"").">Isle Of Man</option>
					<OPTION VALUE='IL'".(($country=="IL")?" selected":"").">Israel</option>
					<OPTION VALUE='IT'".(($country=="IT")?" selected":"").">Italy</option>
					<OPTION VALUE='JM'".(($country=="JM")?" selected":"").">Jamaica</option>
					<OPTION VALUE='JP'".(($country=="JP")?" selected":"").">Japan</option>
					<OPTION VALUE='JE'".(($country=="JE")?" selected":"").">Jersey</option>
					<OPTION VALUE='JO'".(($country=="JO")?" selected":"").">Jordan</option>
					<OPTION VALUE='KZ'".(($country=="KZ")?" selected":"").">Kazakhstan</option>
					<OPTION VALUE='KE'".(($country=="KE")?" selected":"").">Kenya</option>
					<OPTION VALUE='KI'".(($country=="KI")?" selected":"").">Kiribati</option>
					<OPTION VALUE='KR'".(($country=="KR")?" selected":"").">Korea, Republic Of</option>
					<OPTION VALUE='KW'".(($country=="KW")?" selected":"").">Kuwait</option>
					<OPTION VALUE='KG'".(($country=="KG")?" selected":"").">Kyrgyzstan</option>
					<OPTION VALUE='LV'".(($country=="LV")?" selected":"").">Latvia</option>
					<OPTION VALUE='LB'".(($country=="LB")?" selected":"").">Lebanon</option>
					<OPTION VALUE='LS'".(($country=="LS")?" selected":"").">Lesotho</option>
					<OPTION VALUE='LR'".(($country=="LR")?" selected":"").">Liberia</option>
					<OPTION VALUE='LY'".(($country=="LY")?" selected":"").">Libyan Arab Jamahiriya</option>
					<OPTION VALUE='LI'".(($country=="LI")?" selected":"").">Liechtenstein</option>
					<OPTION VALUE='LT'".(($country=="LT")?" selected":"").">Lithuania</option>
					<OPTION VALUE='LU'".(($country=="LU")?" selected":"").">Luxembourg</option>
					<OPTION VALUE='MO'".(($country=="MO")?" selected":"").">Macau</option>
					<OPTION VALUE='MK'".(($country=="MK")?" selected":"").">Macedonia</option>
					<OPTION VALUE='MG'".(($country=="MG")?" selected":"").">Madagascar</option>
					<OPTION VALUE='MW'".(($country=="MW")?" selected":"").">Malawi</option>
					<OPTION VALUE='MY'".(($country=="MY")?" selected":"").">Malaysia</option>
					<OPTION VALUE='MV'".(($country=="MV")?" selected":"").">Maldives</option>
					<OPTION VALUE='ML'".(($country=="ML")?" selected":"").">Mali</option>
					<OPTION VALUE='MT'".(($country=="MT")?" selected":"").">Malta</option>
					<OPTION VALUE='MH'".(($country=="MH")?" selected":"").">Marshall Islands</option>
					<OPTION VALUE='MQ'".(($country=="MQ")?" selected":"").">Martinique</option>
					<OPTION VALUE='MR'".(($country=="MR")?" selected":"").">Mauritania</option>
					<OPTION VALUE='MU'".(($country=="MU")?" selected":"").">Mauritius</option>
					<OPTION VALUE='YT'".(($country=="YT")?" selected":"").">Mayotte</option>
					<OPTION VALUE='MX'".(($country=="MX")?" selected":"").">Mexico</option>
					<OPTION VALUE='MD'".(($country=="MD")?" selected":"").">Moldova</option>
					<OPTION VALUE='MC'".(($country=="MC")?" selected":"").">Monaco</option>
					<OPTION VALUE='MN'".(($country=="MN")?" selected":"").">Mongolia</option>
					<OPTION VALUE='MS'".(($country=="MS")?" selected":"").">Montserrat</option>
					<OPTION VALUE='MA'".(($country=="MA")?" selected":"").">Morocco</option>
					<OPTION VALUE='MZ'".(($country=="MZ")?" selected":"").">Mozambique</option>
					<OPTION VALUE='MM'".(($country=="MM")?" selected":"").">Myanmar</option>
					<OPTION VALUE='NA'".(($country=="NA")?" selected":"").">Namibia</option>
					<OPTION VALUE='NR'".(($country=="NR")?" selected":"").">Nauru</option>
					<OPTION VALUE='NP'".(($country=="NP")?" selected":"").">Nepal</option>
					<OPTION VALUE='NL'".(($country=="NL")?" selected":"").">Netherlands</option>
					<OPTION VALUE='AN'".(($country=="AN")?" selected":"").">Netherlands Antilles</option>
					<OPTION VALUE='NT'".(($country=="NT")?" selected":"").">Neutral Zone</option>
					<OPTION VALUE='NC'".(($country=="NC")?" selected":"").">New Caledonia</option>
					<OPTION VALUE='NZ'".(($country=="NZ")?" selected":"").">New Zealand</option>
					<OPTION VALUE='NI'".(($country=="NI")?" selected":"").">Nicaragua</option>
					<OPTION VALUE='NE'".(($country=="NE")?" selected":"").">Niger</option>
					<OPTION VALUE='NG'".(($country=="NG")?" selected":"").">Nigeria</option>
					<OPTION VALUE='NU'".(($country=="NU")?" selected":"").">Niue</option>
					<OPTION VALUE='NF'".(($country=="NF")?" selected":"").">Norfolk Island</option>
					<OPTION VALUE='MP'".(($country=="MP")?" selected":"").">Northern Mariana Islands</option>
					<OPTION VALUE='NO'".(($country=="NO")?" selected":"").">Norway</option>
					<OPTION VALUE='OM'".(($country=="OM")?" selected":"").">Oman</option>
					<OPTION VALUE='PK'".(($country=="PK")?" selected":"").">Pakistan</option>
					<OPTION VALUE='PW'".(($country=="PW")?" selected":"").">Palau</option>
					<OPTION VALUE='PS'".(($country=="PS")?" selected":"").">Palestine</option>
					<OPTION VALUE='PA'".(($country=="PA")?" selected":"").">Panama</option>
					<OPTION VALUE='PG'".(($country=="PG")?" selected":"").">Papua New Guinea</option>
					<OPTION VALUE='PY'".(($country=="PY")?" selected":"").">Paraguay</option>
					<OPTION VALUE='PE'".(($country=="PE")?" selected":"").">Peru</option>
					<OPTION VALUE='PH'".(($country=="PH")?" selected":"").">Philippines</option>
					<OPTION VALUE='PN'".(($country=="PN")?" selected":"").">Pitcairn</option>
					<OPTION VALUE='PL'".(($country=="PL")?" selected":"").">Poland</option>
					<OPTION VALUE='PT'".(($country=="PT")?" selected":"").">Portugal</option>
					<OPTION VALUE='PR'".(($country=="PR")?" selected":"").">Puerto Rico</option>
					<OPTION VALUE='QA'".(($country=="QA")?" selected":"").">Qatar</option>
					<OPTION VALUE='RE'".(($country=="RE")?" selected":"").">Reunion</option>
					<OPTION VALUE='RO'".(($country=="RO")?" selected":"").">Romania</option>
					<OPTION VALUE='RU'".(($country=="RU")?" selected":"").">Russian Federation</option>
					<OPTION VALUE='RW'".(($country=="RW")?" selected":"").">Rwanda</option>
					<OPTION VALUE='SH'".(($country=="SH")?" selected":"").">Saint Helena</option>
					<OPTION VALUE='KN'".(($country=="KN")?" selected":"").">Saint Kitts And Nevis</option>
					<OPTION VALUE='LC'".(($country=="LC")?" selected":"").">Saint Lucia</option>
					<OPTION VALUE='PM'".(($country=="PM")?" selected":"").">Saint Pierre</option>
					<OPTION VALUE='WS'".(($country=="WS")?" selected":"").">Samoa</option>
					<OPTION VALUE='SM'".(($country=="SM")?" selected":"").">San Marino</option>
					<OPTION VALUE='ST'".(($country=="ST")?" selected":"").">Sao Tome and Principe</option>
					<OPTION VALUE='SA'".(($country=="SA")?" selected":"").">Saudi Arabia</option>
					<OPTION VALUE='SN'".(($country=="SN")?" selected":"").">Senegal</option>
					<OPTION VALUE='SC'".(($country=="SC")?" selected":"").">Seychelles</option>
					<OPTION VALUE='SL'".(($country=="SL")?" selected":"").">Sierra Leone</option>
					<OPTION VALUE='SG'".(($country=="SG")?" selected":"").">Singapore</option>
					<OPTION VALUE='SK'".(($country=="SK")?" selected":"").">Slovakia</option>
					<OPTION VALUE='SI'".(($country=="SI")?" selected":"").">Slovenia</option>
					<OPTION VALUE='SB'".(($country=="SB")?" selected":"").">Solomon Islands</option>
					<OPTION VALUE='SO'".(($country=="SO")?" selected":"").">Somalia</option>
					<OPTION VALUE='ZA'".(($country=="ZA")?" selected":"").">South Africa</option>
					<OPTION VALUE='ES'".(($country=="ES")?" selected":"").">Spain</option>
					<OPTION VALUE='LK'".(($country=="LK")?" selected":"").">Sri Lanka</option>
					<OPTION VALUE='SD'".(($country=="SD")?" selected":"").">Sudan</option>
					<OPTION VALUE='SR'".(($country=="SR")?" selected":"").">Suriname</option>
					<OPTION VALUE='SJ'".(($country=="SJ")?" selected":"").">Svalbard</option>
					<OPTION VALUE='SZ'".(($country=="SZ")?" selected":"").">Swaziland</option>
					<OPTION VALUE='SE'".(($country=="SE")?" selected":"").">Sweden</option>
					<OPTION VALUE='CH'".(($country=="CH")?" selected":"").">Switzerland</option>
					<OPTION VALUE='SY'".(($country=="SY")?" selected":"").">Syrian Arab Republic</option>
					<OPTION VALUE='TW'".(($country=="TW")?" selected":"").">Taiwan</option>
					<OPTION VALUE='TJ'".(($country=="TJ")?" selected":"").">Tajikista</option>
					<OPTION VALUE='TZ'".(($country=="TZ")?" selected":"").">Tanzania</option>
					<OPTION VALUE='TH'".(($country=="TH")?" selected":"").">Thailand</option>
					<OPTION VALUE='TG'".(($country=="TG")?" selected":"").">Togo</option>
					<OPTION VALUE='TK'".(($country=="TK")?" selected":"").">Tokelau</option>
					<OPTION VALUE='TO'".(($country=="TO")?" selected":"").">Tonga</option>
					<OPTION VALUE='TT'".(($country=="TT")?" selected":"").">Trinidad and Tobago</option>
					<OPTION VALUE='TN'".(($country=="TN")?" selected":"").">Tunisia</option>
					<OPTION VALUE='TR'".(($country=="TR")?" selected":"").">Turkey</option>
					<OPTION VALUE='TM'".(($country=="TM")?" selected":"").">Turkmenistan</option>
					<OPTION VALUE='TC'".(($country=="TC")?" selected":"").">Turks and Caicos Islands</option>
					<OPTION VALUE='TV'".(($country=="TV")?" selected":"").">Tuvalu</option>
					<OPTION VALUE='UG'".(($country=="UG")?" selected":"").">Uganda</option>
					<OPTION VALUE='UA'".(($country=="UA")?" selected":"").">Ukraine</option>
					<OPTION VALUE='AE'".(($country=="AE")?" selected":"").">United Arab Emirates</option>
					<OPTION VALUE='UK'".(($country=="UK")?" selected":"").">United Kingdom</option>
					<OPTION VALUE='UY'".(($country=="UY")?" selected":"").">Uruguay</option>
					<OPTION VALUE='UZ'".(($country=="UZ")?" selected":"").">Uzbekistan</option>
					<OPTION VALUE='VU'".(($country=="VU")?" selected":"").">Vanuatu</option>
					<OPTION VALUE='VA'".(($country=="VA")?" selected":"").">Vatican City State</option>
					<OPTION VALUE='VE'".(($country=="VE")?" selected":"").">Venezuela</option>
					<OPTION VALUE='VN'".(($country=="VN")?" selected":"").">Vietnam</option>
					<OPTION VALUE='VG'".(($country=="VG")?" selected":"").">Virgin Islands (British)</option>
					<OPTION VALUE='VI'".(($country=="VI")?" selected":"").">Virgin Islands (U.S.)</option>
					<OPTION VALUE='WF'".(($country=="WF")?" selected":"").">Wallis and Futuna</option>
					<OPTION VALUE='WG'".(($country=="WG")?" selected":"").">West Bank and Gaza</option>
					<OPTION VALUE='EH'".(($country=="EH")?" selected":"").">Western Sahara</option>
					<OPTION VALUE='YE'".(($country=="YE")?" selected":"").">Yemen, Republic of</option>
					<OPTION VALUE='YU'".(($country=="YU")?" selected":"").">Yugoslavia</option>
					<OPTION VALUE='ZR'".(($country=="ZR")?" selected":"").">Zaire</option>
					<OPTION VALUE='ZM'".(($country=="ZM")?" selected":"").">Zambia</option>
					<OPTION VALUE='ZW'".(($country=="ZW")?" selected":"").">Zimbabwe</option>
			 </SELECT>
			");
	}
function advert($advert,$input_style)
	{
	echo("
		<SELECT NAME='advert' ".$input_style.">
			<OPTION VALUE='x'".((isset($advert))?"".(($advert=="x")?" selected":"")."":" selected").">-----------Select One----------</option>
			<OPTION VALUE='GoTo'".(($advert=="GoTo")?" selected":"").">-GoTo.com</option>
			<OPTION VALUE='Yahoo'".(($advert=="Yahoo")?" selected":"").">-Yahoo.com</option>
			<OPTION VALUE='WebHostIndex'".(($advert=="WebHostIndex")?" selected":"").">-Webhostindex.com</option>
			<OPTION VALUE='MCN'".(($advert=="MCN")?" selected":"").">-MyComputer.com</option>
			<OPTION VALUE='BraveNet'".(($advert=="BraveNet")?" selected":"").">-BraveNet.com</option>
			<OPTION VALUE='HostIndex'".(($advert=="HostIndex")?" selected":"").">-HostIndex.com</option>
			<OPTION VALUE='Everyone'".(($advert=="Everyone")?" selected":"").">-Everyone.net</option>
			<OPTION VALUE='Tophosts'".(($advert=="Tophosts")?" selected":"").">-Tophosts.com</option>
			<OPTION VALUE='Onvia.com'".(($advert=="Onvia.com")?" selected":"").">-Oniva.com</option>
			<OPTION VALUE='Other Web Site'".(($advert=="Other Web Site")?" selected":"").">-Other Web Site</option>
			<OPTION VALUE='Other Search Engine'".(($advert=="Other Search Engine")?" selected":"").">-Other Search Engine</option>
			<OPTION VALUE='Friend/Family'".(($advert=="Friend/Family")?" selected":"").">Friend/Family Member</option>
			<OPTION VALUE='Radio'".(($advert=="Radio")?" selected":"").">Radio Advertisement</option>
			<OPTION VALUE='TV'".(($advert=="TV")?" selected":"").">TV Advertisement</option>
			<OPTION VALUE='OTHER'".(($advert=="OTHER")?" selected":"").">OTHER</option>
		</SELECT>
			");
	}
?>