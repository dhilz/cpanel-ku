<?PHP
ini_set("max_execution_time", "84600");

function varilogix_enc_shared($data, $encrypt_key)
	{
	$encrypt_key=md5($encrypt_key);
	$ctr=0;
	$buffer="";

	for ($c=0; $c<strlen($data); $c++)
		{
		if ($ctr == strlen($encrypt_key)) { $ctr=0; }
		$buffer.=substr($data, $c, 1) ^ substr($encrypt_key, $ctr, 1);
		$ctr++;
		}

	return $buffer;
	}

function varilogix_d($enc_data) 
	{	
	# my decryption
	$enc_data=varilogix_enc_shared($enc_data, "cf731392369524b9979eecc6467509ba");
	$buffer='';

	for ($c=0; $c<strlen($enc_data); $c++)
		{
		$md5=substr($enc_data, $c, 1);
		$c++;
		$buffer.=(substr($enc_data, $c, 1) ^ $md5);
		}

	return $buffer;
	}

function varilogix_e($data) 
	{	
	# my encryption
	$random_key=md5(time().rand(1000, 9999));

	srand((double) microtime()*1000000);
	$encrypt_key=md5($random_key);
	$ctr=0;
	$buffer='';

	for ($c=0; $c<strlen($data); $c++)
		{
		if ($ctr==strlen($encrypt_key)) { $ctr=0; }
		$buffer.=substr($encrypt_key, $ctr, 1).(substr($data, $c, 1) ^ substr($encrypt_key, $ctr, 1));
		$ctr++;
		}
	
	return varilogix_enc_shared($buffer, "cf731392369524b9979eecc6467509ba");
	}

function generate_id()
	{
	srand;   
	settype($random, "Integer");
	$random=rand(0, 100000);    
	$epoch=time();    
	$id=$epoch^$random;

	return $id;
	}

function clean_number($phone_number)
	{
	return ereg_replace("[^0-9]", "", $phone_number);
	}

function format_phone_us($phone_number)
	{
	return clean_number($phone_number);
	
	/*
	if (strlen($phone_number)==10)
		{
		$area_code=substr($phone_number, 0, 3);
		$prefix=substr($phone_number, 3, 3);
		$suffix=substr($phone_number, -4);

		return $area_code."-".$prefix."-".$suffix;
		}
	
	return "invalid";
	*/
	}

function format_phone_everything_else($cc, $phone_number)
	{
	return "001 ".$cc."-".clean_number($phone_number);
	}

function us_or_not($cc, $phone_number)
	{
	if (strcmp($cc, "US")==0||strcmp($cc, "CA")==0)
		{
		return format_phone_us($phone_number);		
		}
	
	return format_phone_everything_else($phone_number);

	}

function dial_out($post_to, $query_string)
	{
	$link=curl_init();
	curl_setopt($link, CURLOPT_URL, $post_to);
	curl_setopt($link, CURLOPT_VERBOSE, 0);
	curl_setopt($link, CURLOPT_POST, 1);
	curl_setopt($link, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($link, CURLOPT_POSTFIELDS, $query_string);
	curl_setopt($link, CURLOPT_RETURNTRANSFER, 1);   
	curl_setopt($link, CURLOPT_TIMEOUT, 360); 
	$res=curl_exec($link);
	curl_close($link);

	return $res;
	}

function response($seed)
	{
	return substr($seed, 0, 5);
	}

function fraud_score($response, $result)
	{
	$buffer=str_replace($response.",", "", $result);

	if (strcmp($buffer, "")==0) { return "no_data"; }

	return $buffer;
	}

function process_initial_call($seed)
	{
	if (strcmp(response($seed), "1.1.0")==0) { return "passed|1.1.0|Dialed successfully"; }
	
	# -------------------------------------------------------------------------------

	if (strcmp(response($seed), "1.2.1")==0) 
		{ 
		$res="1.2.1|Dialed UNsuccessfully: Toll Free Numbers cannot be dialed";
		return "failed|".$res; 
		}

	if (strcmp(response($seed), "1.2.2")==0) 
		{ 
		$res="1.2.2|Dialed UNsuccessfully: phone number was in an undialable format";
		return "failed|".$res;
		}

	if (strcmp(response($seed), "1.2.3")==0) 
		{ 
		$res="1.2.3|Dialed UNsuccessfully: Undialable country, refer to accepted country list";
		return "failed|".$res;
		}

	if (strcmp(response($seed), "1.2.4")==0) 
		{ 
		$res="1.2.4|Dialed UNsuccessfully: Call cannot be dialed, please record time/date, id number ";
		$res.="and phone number called so we can investigate";
		return "failed|".$res;
		}

	if (strcmp(response($seed), "1.2.5")==0) 
		{ 
		$res="1.2.5|Dialed UNsuccessfully: Invalid phone number, Phone number cannot begin with \"1\"";
		return "failed|".$res;
		}

	if (strcmp(response($seed), "1.2.6")==0) 
		{ 
		$res="1.2.6|Dialed UNsuccessfully: Invalid phone number, Area Code and ";
		$res.="Country Code combination does not match proper format.";
		return "failed|".$res;
		}
	
	# -------------------------------------------------------------------------------
	
	if (strcmp(response($seed), "1.3.0")==0) 
		{ 
		$res="1.3.0|Cannot call Cell Phone as per user's preferences";
		return "failed|".$res;
		}

	if (strcmp(response($seed), "1.3.1")==0) 
		{ 
		$res="1.3.1|User does not have sufficient call credits for this call to be placed";
		return "failed|".$res; 
		}
	
	# -------------------------------------------------------------------------------
	
	if (strcmp(response($seed), "1.4.0")==0) 
		{ 
		$res="1.4.0|PVS_USERNAME and PVS_PASSWORD is incorrect";
		return "failed|".$res; 
		}
	
	# -------------------------------------------------------------------------------
	
	if (strcmp(response($seed), "1.5.0")==0) 
		{ 
		$res="1.5.0|API Post incomplete";
		return "failed|".$res; 
		}
	
	# -------------------------------------------------------------------------------
	
	return "failed";
	}


function process_call($seed, $post_to, $query_string, $max_tries, $sleep)
	{
	GLOBAL $http_images;

	while (strcmp($seed, "2.1.0")==0)
		{
		sleep($sleep);

		$g+=1;
		$result=dial_out($post_to, $query_string);
		$seed=response($result);
		
		echo "<img src='".$http_images."/callback[2].gif' alt='Please follow the operators instructions.'>";

		echo str_pad(" ", 250);
		flush();

		if ($g>=$max_tries) { return "failed|Maximum tries reached."; }
		}

	return $result;
	}

function process($post_to, $query_string, $phone)
	{
	GLOBAL $http_images;

	list($status, $returned_message)=explode("|", process_initial_call(dial_out($post_to, $query_string)));
	if (strcmp($status, "passed")==0)
		{	
		echo "&nbsp;<img src='".$http_images."/callback[0].gif' alt='1. We are calling you now. Please answer your phone to continue.'><img src='".$http_images."/callback[-1].gif' width='33'>";
		
		echo str_pad(" ", 256);
		flush();
		ob_flush();
		$result=process_call("2.1.0", $post_to, $query_string, 20, 5);

		$query="select ";
		$query.="fraudcall_value ";
		$query.="from ";
		$query.="autopilot_fraudcall ";
		$query.="where ";
		$query.="fraudcall_key='install_".clean_number($result)."' ";
		$query.="limit 0, 1";

		$rs=mysql_fetch_row(mysql_query($query));

		if (strcmp(response($result), "3.1.0")==0
			||strcmp($rs[0], "stop")!=0)
			{
			echo "<img src='".$http_images."/callback[-1].gif' width='33'><img src='".$http_images."/callback[6].gif' alt='Your order passed our screening!'>";
			}
		else { echo "<img src='".$http_images."/callback[-1].gif' width='33'><img src='".$http_images."/callback[4].gif' alt='Your order did not pass our screening!'>"; }
		
		return response($result)."|".fraud_score(response($result), $result);
		}

	return $returned_message."|".$status;
	}
?>