<?PHP
if(phpversion() <= "4.0.6") { $_POST=$HTTP_POST_VARS; }
if ($_POST['submit']) { header("Location: install1.php"); exit; }

$b=0;
include "install_header.php";

echo("
	<form action='".$PHP_SELF."' method='POST'>
	<table width='100%' cellpadding='2' cellspacing='0' border='0'>
		<tr>
			<td colspan='2'><img src='install[1].gif'>&nbsp;<font color='#0F82B8'><b>End User License Agreement</b></font></td>
		</tr>
		<tr>
			<td colspan='2'><textarea name='eula' rows='16' cols='80' style=\"BORDER-STYLE: solid;BORDER-COLOR: #999999; BACKGROUND-COLOR: #ffffff; BORDER-WIDTH: 1px; FONT-FAMILY: Verdana; FONT-SIZE: 8pt\" tabindex='1'>
WHM AutoPilot END USER LICENSE AGREEMENT
-------------------------------------------------------
For One (1) Domain/IP Installation and use

Script to be provided, updated, and installed on one domain per license agreement. For multiple domains, each installation must be issued a new license & key and abide the the terms below. All licenses and keys are managed and registered. Any license shown running on more than one (1) registered IP address will be terminated and lose access to use the script without refund.

Notice to User:

This End User License Agreement (EULA) is a CONTRACT between you (either an individual or a single entity) and Benchmark Designs, LLC (\"Benchmark Designs\"), which covers your use of the Benchmark Designs software product that accompanies this EULA and related software components, which may include associated media, printed materials, and \"online\" or electronic documentation. All such software and materials are referred to herein as the \"Software Product.\" A software license, issued to a designated user only by Benchmark Designs or its authorized agents, is required for each user of the Software Product. If you do not agree to the terms of this EULA, then do not install or use the Software Product or the Software Product License. By explicitly accepting this EULA, however, or by installing, copying, downloading, accessing, or otherwise using the Software Product and/or Software Product License, you are acknowledging and agreeing to be bound by the following terms:

1. GRANT OF NON-EXCLUSIVE LICENSE.

(a) Software Product License. The Software Product License, which is issued to a designated user, enables such designated user to use the Software Product on a single domain. Each user on a multi-user server system who uses the Software Product requires an additional Software Product License. You may not modify or create derivative copies of the Software Product License.

(b) Grant of License. Subject to a validly issued Software Product License, Benchmark Designs grants to you the non-exclusive, non-transferable right for you to use the Software Product on a single domain running a validly licensed copy of the operating system for which the Software Product was designed. You may not modify or create derivative copies of the Software Product. All rights not expressly granted to you are retained by Benchmark Designs.

(c) Backup Copy: Software Product. You may make copies of Software Product as reasonably necessary for the use authorized above, including as needed for backup and/or archival purposes. No other copies may be made. Each copy must reproduce all copyright and other proprietary rights notices on or in the Software Product.

2. INTELLECTUAL PROPERTY RIGHTS RESERVED BY BENCHMARK DESIGNS.

The Software Product is protected by U.S. and international copyright laws and treaties, as well as other intellectual property laws and treaties. You must not remove or alter any copyright notices on any copies of the Software Product. This Software Product copy is licensed, not sold. Furthermore, this EULA does not grant you any rights in connection with any trademarks or service marks of Benchmark Designs. Benchmark Designs reserves all intellectual property rights, including copyrights,
and trademark rights.

3. NO RIGHT TO TRANSFER.

You may not rent, lease, lend, or in any way distribute or transfer any rights in this EULA or the Software Product to third parties without Benchmark Designs's written approval and subject to written agreement by the recipient of the terms of this EULA.

4. PROHIBITION ON REVERSE ENGINEERING, DECOMPILATION, AND DISASSEMBLY.

You may not reverse engineer, decompile, defeat license encryption mechanisms, or disassemble the Software Product or Software Product License except and only to the extent that such activity is expressly permitted by applicable law notwithstanding this limitation.

5. SUPPORT SERVICES.

Benchmark Designs may provide you with support services related to the Software Product. Use of any such support services is governed by the Benchmark Designs polices and programs described in \"online\" documentation and/or other Benchmark Designs-provided materials. Any supplemental software code or related materials that Benchmark Designs provides to you as part of the support services is to be considered part of the Software Product and is subject to the terms and conditions of this EULA. With respect to any technical information you provide to Benchmark Designs as part of the support services, Benchmark Designs may use such information for its business purposes without restriction, including for product support and development. Benchmark Designs will not use such technical information in a form that personally identifies you.

6. TERMINATION WITHOUT PREJUDICE TO ANY OTHER RIGHTS.

Benchmark Designs may terminate this EULA if you fail to comply with any term or condition of this EULA. In such event, Licensee agrees to return to Licensor or to destroy all copies of the Software upon termination of the License.

7. NO WARRANTIES.

YOU ACCEPT THE SOFTWARE PRODUCT AND SOFTWARE PRODUCT LICENSE \"AS IS,\" AND BENCHMARK DESIGNS (AND ITS THIRD PARTY SUPPLIERS AND LICENSORS) MAKE NO WARRANTY AS TO ITS USE, PERFORMANCE, OR OTHERWISE. TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, BENCHMARK DESIGNS (AND ITS THIRD PARTY SUPPLIERS AND LICENSORS) DISCLAIM ALL OTHER REPRESENTATIONS, WARRANTIES, AND CONDITIONS, EXPRESS, IMPLIED, STATUTORY, OR OTHERWISE, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A PARTICULAR PURPOSE, TITLE, AND NON-INFRINGEMENT. THE ENTIRE RISK ARISING OUT OF USE OR PERFORMANCE OF THE SOFTWARE PRODUCT REMAINS WITH YOU.

8. LIMITATION OF LIABILITY.

THIS LIMITATION OF LIABILITY IS TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW. IN NO EVENT SHALL BENCHMARK DESIGNS (OR ITS THIRD PARTY SUPPLIERS AND LICENSORS) BE LIABLE FOR ANY COSTS OF SUBSTITUTE PRODUCTS OR SERVICES, OR FOR ANY SPECIAL, INCIDENTAL, INDIRECT, OR CONSEQUENTIAL DAMAGES WHATSOEVER (INCLUDING, WITHOUT LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION, OR LOSS OF BUSINESS INFORMATION) ARISING OUT OF THIS EULA OR THE USE OF OR INABILITY TO USE THE SOFTWARE PRODUCT OR THE FAILURE TO PROVIDE SUPPORT SERVICES, EVEN IF BENCHMARK DESIGNS HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. IN ANY CASE, BENCHMARK DESIGNS'S (AND ITS THIRD PARTY SUPPLIERS' AND LICENSORS') ENTIRE LIABILITY ARISING OUT OF THIS EULA SHALL BE LIMITED TO THE GREATER OF THE AMOUNT ACTUALLY PAID BY YOU FOR THE SOFTWARE PRODUCT OR U.S. $5.00; PROVIDED, HOWEVER, THAT IF YOU HAVE ENTERED INTO A BENCHMARK DESIGNS SUPPORT SERVICES AGREEMENT, BENCHMARK DESIGNS'S ENTIRE LIABILITY REGARDING SUPPORT SERVICES SHALL BE GOVERNED BY THE TERMS OF THAT AGREEMENT.

9. GOVERNING LAW; ENTIRE AGREEMENT.

This EULA is governed by the laws of the Commonwealth of Maryland, U.S.A., excluding the application of its conflict of law rules. The United Nations Convention for the International Sale of Goods shall not apply. This EULA is the entire agreement between us and supersedes any other communications or advertising with respect to the Software Product; this EULA may be modified only by written agreement signed by authorized representatives of you and Benchmark Designs.

10. CONTACT INFORMATION

If you have any questions about this EULA, or if you want to contact Benchmark Designs
for any reason, please direct all correspondence to:

Benchmark Designs, LLC
6901 Rabbit Run Road
Hurlock, Maryland 21643
1-800-276-9433

or email: info@benchmarkdesigns.com.

Benchmark Designs, Benchmark Manager in a Box and WHM AutoPilot are trademarks of Benchmark Designs, LLC.
			</textarea></td>
		</tr>
		<tr>
			<td colspan='2'><img src='install[6].gif' width='1' height='10'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='middle'></td>
			<td width='75%' align='left' valign='middle'><a href='Javascript: window.close();'><img border='0' src='install[2].gif' onmouseover='this.src=\"install[3].gif\"' onmouseout='this.src=\"install[2].gif\"' alt='I decline the End User License Agreement.'></a>&nbsp;<input type='hidden' name='submit' value='5'><input type='image' src='install[4].gif' onmouseover='this.src=\"install[5].gif\"' onmouseout='this.src=\"install[4].gif\"' alt='I accept and will follow the End User License Agreement.'></td>
		</tr>
	</table>
	</form>
	");

include "install_footer.php";
?>