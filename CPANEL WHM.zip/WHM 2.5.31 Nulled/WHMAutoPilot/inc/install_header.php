<?PHP 
if ($b==0) { $eula=9; } else { $eula=8; } 
if ($b==1) { $one=11; } else { $one=10; } 
if ($b==2) { $two=13; } else { $two=12; } 
if ($b==3) { $three=15; } else { $three=14; } 
if ($b==4) { $four=17; } else { $four=16; } 
?>
<!doctype html public \"-//W3C//DTD HTML 4.0 Transitional//EN\">
<html>
<head>
<title> WHM AutoPilot Installation Wizard </title>
<style>
	body, td, center, p {font-family:verdana, arial, helvetica; font-size: 13px; color: #45484A}
	div {font-family:verdana, arial, helvetica; font-size: 11px}
	A:link { 
	text-decoration: underline: none; none; color:#45484A;
	}
	A:visited { 
	text-decoration: underline: none; none; color:#45484A;
	}
	A:hover { 
	text-decoration: underline; font-weight: none;color:#45484A;
	}
	.linkTable
	{
	 PADDING-LEFT: 5px
	}
</style>
</head>

<body background='install[23].gif'>
<table width='746' cellpadding='0' cellspacing='0' border='0' align='center'>
	<tr>
		<td colspan='3'><img src='install[7].gif'><img src='install[<?PHP echo $eula; ?>].gif'><img src='install[<?PHP echo $one; ?>].gif'><img src='install[<?PHP echo $two; ?>].gif'><img src='install[<?PHP echo $three; ?>].gif'><img src='install[<?PHP echo $four; ?>].gif'></td>
	</tr>
	<tr>
		<td background='install[18].gif'><img src='install[6].gif' width='20' height='250'></td>
		<td bgcolor='#FFFFFF'>