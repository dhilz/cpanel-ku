<?PHP
$dblink=MYSQL_CONNECT($dbhost, $dbuser, $dbpass) OR DIE("<font color='#990000'><b>Database Currently Unavailable.</b></font> <b>Please try again later.</b>");
@mysql_select_db($db) or die("<font color='#990000'><b>Unable to Select Database.</b></font> <b>Please try again later.</b>");
?>