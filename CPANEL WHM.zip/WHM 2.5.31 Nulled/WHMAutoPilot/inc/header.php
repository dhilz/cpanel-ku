<?PHP
if($maintenance=="yes") 
	{ 
	header("Location: ".$http_web."/maintenance.php"); 
	exit; 
	}
echo("
<HTML>
<HEAD>
<TITLE> ".$site_title." </TITLE>
	<style>
		body, td, center, p {font-family: tahoma; font-size: 11px; color: #000000}
		A:link { 
		text-decoration: underline: none; none; color:#000000;
		}
		A:visited { 
		text-decoration: underline: none; none; color:#000000;
		}
		A:hover { 
		text-decoration: underline; font-weight: none;color:#990000;
		}
		.linkTable
		{
		 PADDING-LEFT: 5px
		}
	</style>
	");
if (ereg("step_one.php", $PHP_SELF)==true)
	{
	include "inc/step_one_tables.php";
	}
else if (ereg("step_two.php", $PHP_SELF)==true)
	{
	include "inc/step_two_tables.php";
	}
echo("
</HEAD>
<BODY 
	");
if (ereg("step_one.php", $PHP_SELF)==true)
	{
	echo"onLoad='select_row(\"plan\", ".$tick.");'";
	}
else if (ereg("step_two.php", $PHP_SELF)==true)
	{
	echo"onLoad='select_row(\"plan\", ".$tick.");'";
	}
	
echo">";
?>