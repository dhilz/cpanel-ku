<?PHP
@ob_start("ob_gzhandler");

if ($GLOBALS) { extract( $GLOBALS, EXTR_OVERWRITE); }
if ($_POST) { extract( $_POST, EXTR_OVERWRITE); }
if ($_SERVER) { extract( $_SERVER, EXTR_OVERWRITE); }
if ($_GET) { extract( $_GET, EXTR_OVERWRITE); }
if ($_COOKIE) { extract( $_COOKIE, EXTR_OVERWRITE); }
if ($_FILES) { extract( $_FILES, EXTR_OVERWRITE); }
if ($_ENV) { extract( $_ENV, EXTR_OVERWRITE); }
if ($_REQUEST) { unset($_REQUEST); }

$dbhost="{{dbhost}}";
$dbuser="{{dbuser}}";
$dbpass="{{dbpass}}";
$db="{{db}}";
?>