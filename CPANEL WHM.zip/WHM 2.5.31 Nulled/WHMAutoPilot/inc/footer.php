<?PHP
echo("
</BODY>
</HTML>
	");
?>