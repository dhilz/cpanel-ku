<?PHP
if ($GLOBALS) { extract( $GLOBALS, EXTR_OVERWRITE); }
if ($_POST) { extract( $_POST, EXTR_OVERWRITE); }
if ($_SERVER) { extract( $_SERVER, EXTR_OVERWRITE); }
if ($_GET) { extract( $_GET, EXTR_OVERWRITE); }
if ($_COOKIE) { extract( $_COOKIE, EXTR_OVERWRITE); }
if ($_FILES) { extract( $_FILES, EXTR_OVERWRITE); }
if ($_ENV) { extract( $_ENV, EXTR_OVERWRITE); }
if ($_REQUEST) { unset($_REQUEST); }

$WHERE[here] = "http://".$_SERVER['HTTP_HOST'];
		if (!strpos($_SERVER['HTTP_REFERER'], $_SERVER['HTTP_HOST'])) 
		{
		header("Location: $WHERE[here]");
		exit();
		}

$xinput_style="style=\"BORDER-STYLE: solid;BORDER-COLOR: #999999; BACKGROUND-COLOR: #ffffff; BORDER-WIDTH: 1px; FONT-FAMILY: Verdana; FONT-SIZE: 8pt\"";

if(phpversion() <= "4.0.6") { $_POST=$HTTP_POST_VARS; }
if ($_POST['submit'])
	{
	if (trim($_POST['db'])=="") { $e0=true; }
	if (trim($_POST['dbhost'])=="") { $e1=true; }
	if (trim($_POST['dbuser'])=="") { $e2=true; }
	if (trim($_POST['dbpass'])=="") { $e3=true; }
	if (!is_writable(str_replace("/install1.php", "", $HTTP_SERVER_VARS['PATH_TRANSLATED']))) { $e4=true; }
	
	if (!isset($e0)&&!isset($e1)&&!isset($e2)&&!isset($e3))
		{
		# --------------------------------------------------------
		$dblink=@mysql_connect($dbhost, $dbuser, $dbpass);
		$dbsel=@mysql_select_db($db);

		$read_dump=@fopen("Master_DB.sql", "r");
		$result_dump=@fread($read_dump, filesize("Master_DB.sql"));
		@fclose($read_dump);

		$result_dump=str_replace("`", "", $result_dump);

		$count=substr_count($result_dump, "\n");
		$explode=explode("\n", $result_dump);
		$buffer="";
		for ($i=0; $i<=($count-1); $i++)
			{
			# Create db structure
			if (substr($explode[$i], 0, 1)!="#")
				{
				if (substr(trim($explode[$i]), -1)==";") 
					{ 
					$temp=str_replace(";", "", $explode[$i]);
					$buffer.=str_replace("\n", " ", $temp);
					mysql_query($buffer);
					$buffer=""; 
					}
				else { $buffer.=str_replace("\n", " ", $explode[$i]); }
				}
			}
		
		if (isset($upgrade))
			{
			mysql_query("INSERT INTO `email_templates` VALUES ('38', 'Invoice Ready Notification to Client ', 'Your Invoice is Ready', 'Greetings {{first_name}}, Please visit the URL to view and pay this invoice. {{pay_link}} Thanks, Web Support Team This email was generated on: {{generate_date}}', '{{first_name}}|{{pay_link}}|{{generate_date}}|', '')");
			mysql_query("INSERT INTO `email_templates` VALUES ('37', 'Invoice Paid Successfully', 'Invoice #{{invoice_number}} was paid successfully!', 'Greetings, On {{date_paid}}, {{first_name}} {{last_name}} paid invoice #{{invoice_number}} in the amount of {{total_invoice_amount}}. Please visit your AutoPilot for the invoice details. Thanks Your AutoPilot This email was generated on: {{generate_date}}', '{{invoice_number}}|{{date_paid}}|{{first_name}}|{{last_name}}|{{total_invoice_amount}}|', '')");
			mysql_query("INSERT INTO `email_templates` VALUES ('39', 'Invoice Due in X Days Notice', 'Your account is due in {{days_until_due}}', 'Greetings {{first_name}}, Your account, {{domain_name}}, is due in {{days_until_due}} and will be billed for {{total_recuur}} via {{payment_processor}}. No action is required on your part, this is just a reminder. Thanks, Web Support Team This email was generated on: {{generate_date}}', '{{days_until_due}}|{{first_name}}|{{domain_name}}|{{total_recuur}}|{{payment_processor}}|{{generate_date}}|', '')");
			mysql_query("INSERT INTO `email_templates` VALUES ('40', 'Incomplete Order Notification', 'You have incomplete orders', 'Hello, You currently have {{incomplete_orders}} order(s) in the incomplete orders area of your AutoPilot. Please login to your admin area to view/process these orders. Thank you. Your AutoPilot This message was generated on: {{generate_date}}', '{{incomplete_orders}}|{{generate_date}}|', '')");
			mysql_query("INSERT INTO `email_templates` VALUES ('41', 'Daily Invoice Summary Report', 'Daily Invoice Summary Report', 'Hello,\r\n\r\nBelow is a list of hosting order invoices in the system that are either past due or unpaid past due.\r\n\r\nPlease login to your admin area and go to the invoice management area to update the status of these invoices.\r\n\r\nSome of these may have just rotated into a new billing cycle and have been billed by the proper gateway.  If this has\r\nhappened, verify payment was made at the gateway and update the invoice as paid in your system.  Marking them as paid\r\nwill reset the next due date accordingly for the hosting order.\r\n\r\n*** Past Due Invoices as of {{generate_date}} Seperated by Payment Gateway ***\r\n\r\n{{mail_in_summary}}{{paypal_summary}}{{paysystems_summary}}{{authorize.net_summary}}{{2checkout}}{{worldpay_summary}}', '{{generate_date}}|{{mail_in_summary}}|{{paypal_summary}}|{{paysystems_summary}}|{{authorize.net_summary}}|{{2checkout}}|{{worldpay_summary}}|', '')");
			mysql_query("ALTER TABLE `user` ADD `rsid` VARCHAR( 32 ) NOT NULL AFTER `sid`");
			mysql_query("DROP TABLE `session`");
			mysql_query("ALTER TABLE `session_history` ADD `tld` VARCHAR( 23 ) NOT NULL AFTER `domain_name`");
			mysql_query("ALTER TABLE `hosting_order` CHANGE `domain_lock` `domain_lock` INT( 4 ) DEFAULT '0' NOT NULL");
			mysql_query("ALTER TABLE `hosting_order` ADD `tld_id` BIGINT( 22 ) NOT NULL AFTER `domain_registration`");
			mysql_query("INSERT INTO `email_templates` ( `emid` , `name` , `subject` , `message` , `attr_avail` , `default_email` ) VALUES ('43', 'Domain Registration Notice', 'Domain Registration Requested for {{domain_name}}', 'Hello Admin, On, {{generate_date}}, {{first_name}} {{last_name}} ordered hosting that included the registration of a domain name. Domain: {{domain_name}} Cost Agreed: {{domain_reg_price}} Registrant Information: {{first_name}} {{last_name}} {{company_name}} {{address_1}} {{address_2}} {{city}} {{state}}, {{zip}} {{phone}} {{fax}} Please register this domain for the client immediately and make sure the nameservers placed in at the time of order are: {{primary_ns}} {{primary_ns_ip}} {{secondary_ns}} {{secondary_ns_ip}} This client has NOT been charged for this domain registration. Please login to your admin area after successful registration and invoice the client from your non-hosting products area for this registration. Thank you. Your AutoPilot Message Generated on: {{generate_date}}', '{{domain_name}}|{{generate_date}}|{{first_name}}|{{last_name}}|{{domain_reg_price}}|{{company_name}}|{{address_1}}|{{address_2}}|{{city}}|{{state}}|{{zip}}|{{phone}}|{{fax}}|{{primary_ns}}|{{primary_ns_ip}}|{{secondary_ns}}|{{secondary_ns_ip}}|', '')");
			mysql_query("ALTER TABLE `hosting_order` ADD `client_host` VARCHAR( 255 ) NOT NULL AFTER `client_ip`");
			mysql_query("UPDATE `email_templates` SET `attr_avail` = '{{ip}}|{{whm_username}}|{{whm_password}}|{{domain_name}}|{{primary_ns}}|{{primary_ns_ip}}|{{secondary_ns}}|{{secondary_ns_ip}}|{{generate_date}}|{{clientarea_username}}|{{clientarea_password}}|{{clientarea_loginlink}}' WHERE `emid` = '10' LIMIT 1");
			mysql_query("ALTER TABLE `authnet_batch` ADD `txn_id` VARCHAR( 255 ) NOT NULL AFTER `bid`");
			mysql_query("ALTER TABLE `hosting_order` ADD `txn_id` VARCHAR( 255 ) NOT NULL AFTER `uid`");
			mysql_query("ALTER TABLE `hosting_order` CHANGE `domain_lock` `domain_lock` INT( 4 ) DEFAULT '0' NOT NULL;");
			mysql_query("UPDATE `email_templates` SET `attr_avail` = '{{ip}}|{{whm_username}}|{{whm_password}}|{{domain_name}}|{{primary_ns}}|{{primary_ns_ip}}|{{secondary_ns}}|{{secondary_ns_ip}}|{{generate_date}}|{{clientarea_username}}|{{clientarea_password}}|{{clientarea_loginlink}}' WHERE `emid` = '10' LIMIT 1");
			mysql_query("UPDATE `email_templates` SET `subject` = 'Recurring Revenue per Server Report', `message` = '================================================= RECURRING REVENUE PER SERVER FOR {{site_name}} ================================================= {{server_details}} This message was generated on: {{generate_date}}' WHERE `emid` = '30' LIMIT 1");
			mysql_query("ALTER TABLE `config` CHANGE `domain_fee` `domain_fee` INT( 1 ) DEFAULT '0' NOT NULL");
			mysql_query("ALTER TABLE `authnet_batch` ADD `ccid` BIGINT( 22 ) NOT NULL AFTER `uid`");
			mysql_query("INSERT INTO `email_templates` ( `emid` , `name` , `subject` , `message` , `attr_avail` , `default_email` ) VALUES ('44', 'Support Ticket Opened by Client', '{{first_name}} {{last_name}} has opened a new support ticket [ Ticket # {{ticket_number}} ]', 'Hello, A new support request has been logged by a user. Here are the details: Ticket #{{ticket_number}} --------------------------- {{ticket_details}} --------------------------- Please login to your admin area to respond to this ticket. Thank you. Your AutoPilot Generated on {{generate_date}}', '{{first_name}}|{{last_name}}|{{ticket_number}}|{{ticket_details}}|{{generate_date}}|', '')");
			mysql_query("INSERT INTO `email_templates` ( `emid` , `name` , `subject` , `message` , `attr_avail` , `default_email` ) VALUES ('45', 'Client Reply to Support Ticket', '{{first_name}} {{last_name}} has replied to ticket [ Ticket # {{ticket_number}} ]', 'Hello, A response from the client has been made on the following ticket, details below: Here are the details: Ticket #{{ticket_number}} --------------------------- {{ticket_details}} --------------------------- Please login to your admin area to respond to this ticket. Thank you. Your AutoPilot Generated on {{generate_date}}', '{{first_name}}|{{last_name}}|{{ticket_number}}|{{ticket_details}}|{{generate_date}}|', '')");
			mysql_query("INSERT INTO `email_templates` ( `emid` , `name` , `subject` , `message` , `attr_avail` , `default_email` ) VALUES ('46', 'Admin Reply to Support Ticket', '[ Ticket # {{ticket_number}} ] Reply to support ticket', 'Hello, Below is the tech reply to your support request Ticket #{{ticket_number}} --------------- {{admin_reply_details}} --------------- Please do not reply directly to this email but login to your client area and update your request from your ticket management area in that location. If you feel this reply resolved your situation, please be sure to close your ticket from your client area. Thank You. Support Team Generated on {{generate_date}}', '{{last admin_reply_details}}|{{ticket_number}}|{{ticket_details}}|{{generate_date}}|', '')");
			mysql_query("ALTER TABLE `config` ADD `enom_user` VARCHAR( 255 ) NOT NULL , ADD `enom_pass` VARCHAR( 255 ) NOT NULL");
			mysql_query("ALTER TABLE `config` ADD `use_enom` INT( 1 ) DEFAULT '0' NOT NULL AFTER `resolve_works`");
			mysql_query("ALTER TABLE `session_history` ADD `sorp` INT( 1 ) DEFAULT '0' NOT NULL");
			mysql_query("ALTER TABLE `hosting_order` ADD `sorp` INT( 1 ) DEFAULT '0' NOT NULL");
			mysql_query("INSERT INTO `email_templates` ( `emid` , `name` , `subject` , `message` , `attr_avail` , `default_email` ) VALUES (47, 'Admin Domain Registration E-mail', 'eNom Domain Registration - {{domain_name}}', 'Hello, Below are the results of an automated registration through your eNom account. Order ID: {{enom_order_id}} Response: {{enom_response_code}} Domain Name: {{domain_name}} Domain Expiration: {{expiration_date}} * approximate date Registrant Information: {{first_name}} {{last_name}} {{address_1}} {{address_2}} {{city}} {{state}} {{zip}} {{country}} {{phone}} {{fax}} If this registration was successful, there are no actions needed on your part. If there was an error given in the response above, manual registration may need to be completed for this domain. Thank You Your AutoPilot Message Generated on: {{generate_date}}', '{{domain_name}}|{{enom_order_id}}|{{enom_response_code}}|{{expiration_date}}|{{first_name}}|{{last_name}}|{{address_1}}|{{address_2}}|{{city}}|{{state}}|{{country}}|{{zip}}|{{phone}}|{{fax}}|{{generate_date}}|', '')");
			mysql_query("UPDATE `email_templates` SET `attr_avail` = '{{domain_name}}|{{generate_date}}|{{first_name}}|{{last_name}}|{{domain_reg_price}}|{{company_name}}|{{address_1}}|{{address_2}}|{{city}}|{{state}}|{{zip}}|{{phone}}|{{fax}}|{{primary_ns}}|{{primary_ns_ip}}|{{secondary_ns}}|{{secondary_ns_ip}}|{{email_address}}|' WHERE `emid` = '43' LIMIT 1");
			}

		@mysql_close($dblink);
		
		# --------------------------------------------------------

		# include "connect.inc";
		
		if (!$dblink||!$dbsel) { $e5=true; }
		else 
			{ 
			if (file_exists("var.php")) { @unlink("inc/var.php"); }

			$read=@fopen("install_var.php", "r");
			$result=@fread($read, 1024);
			@fclose($read);

			$result=str_replace("{{dbhost}}", $dbhost, $result);
			$result=str_replace("{{dbuser}}", $dbuser, $result);
			$result=str_replace("{{dbpass}}", $dbpass, $result);
			$result=str_replace("{{db}}", $db, $result);

			$read=fopen("var.php", "w");
			fwrite($read, $result);
			fclose($read);


			header("Location: install2.php");
			exit;
			}
		}
	}

$b=1;
include "install_header.php";

echo("
	<form action='".$PHP_SELF."' method='POST'>
	<table width='100%' cellpadding='2' cellspacing='0' border='0'>
		<tr>
			<td colspan='2'><img src='install[1].gif'>&nbsp;<font color='#0F82B8'><b>Thank you for choosing WHMAutoPilot, nulled by VST!</b></font></td>
		</tr>
		<tr>
			<td colspan='2'>Please review the following checklist before continuing:</td>
		</tr>
		<tr>
			<td colspan='2'>&nbsp;<img src='install[0].gif'> I have created the MySQL database.</td>
		</tr>
		<tr>
			<td colspan='2'>&nbsp;<img src='install[0].gif'> I have temporarily chmod'ed the /inc directory to 0777.</td>
		</tr>
		<tr>
			<td colspan='2'><img src='install[6].gif' width='1' height='2'></td>
		</tr>
		<tr>
			<td colspan='2'><font color='#0F82B8'>Setup will now guide you through the installation process.</font></td>
		</tr>
		<tr>
			<td colspan='2'><hr color='#F7F3F7'></td>
		</tr>
	");
if (isset($e1))
	{
	echo("
		<tr>
			<td colspan='2'><img src='install[26].gif'><font color='#1394D0'>You must enter a MySQL DB Host to continue.</font></td>
		</tr>
		");
	}
if (isset($e0))
	{
	echo("
		<tr>
			<td colspan='2'><img src='install[26].gif'><font color='#1394D0'>You must enter a MySQL DB Name to continue.</font></td>
		</tr>
		");
	}
if (isset($e2))
	{
	echo("
		<tr>
			<td colspan='2'><img src='install[26].gif'><font color='#1394D0'>You must enter a MySQL DB User to continue.</font></td>
		</tr>
		");
	}
if (isset($e3))
	{
	echo("
		<tr>
			<td colspan='2'><img src='install[26].gif'><font color='#1394D0'>You must enter a MySQL DB Pass to continue.</font></td>
		</tr>
		");
	}
if (isset($e5))
	{
	echo("
		<tr>
			<td colspan='2'><img src='install[26].gif'><font color='#1394D0'>PHPAudit cannot access the database with the logins below.</font></td>
		</tr>
		");
	}
if (isset($e0)||isset($e1)||isset($e2)||isset($e3)||isset($e5))
	{
	echo("
		<tr>
			<td colspan='2'><hr color='#F7F3F7'></td>
		</tr>
		");
	}
$guess_dbhost="localhost";
echo("
		<tr>
			<td colspan='2'><img src='install[6].gif' width='1' height='6'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='middle'>MySQL DB Host:</td>
			<td width='75%' align='left' valign='middle'><input tabindex='1' size='40' maxlength='255' ".$xinput_style." type='text' name='dbhost' value='".((isset($dbhost))?"".$dbhost."":"".$guess_dbhost."")."'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='middle'>MySQL DB Name:</td>
			<td width='75%' align='left' valign='middle'><input tabindex='2' size='40' maxlength='255' ".$xinput_style." type='text' name='db' value='".((isset($db))?"".$db."":"")."'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='middle'>MySQL DB User:</td>
			<td width='75%' align='left' valign='middle'><input tabindex='3' size='40' maxlength='255' ".$xinput_style." type='text' name='dbuser' value='".((isset($dbuser))?"".$dbuser."":"")."'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='middle'>MySQL DB Pass:</td>
			<td width='75%' align='left' valign='middle'><input tabindex='4' size='40' maxlength='255' ".$xinput_style." type='text' name='dbpass' value='".((isset($dbpass))?"".$dbpass."":"")."'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='middle'>Upgrading?</td>
			<td width='75%' align='left' valign='middle'><input tabindex='5' type='checkbox' name='upgrade' value='1'> Check if this is an upgrade from 2.2.2 or 2.2.3 Beta</td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_image."/space.gif' width='1' height='10'></td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='middle'></td>
			<td width='75%' align='left' valign='middle'><input type='hidden' name='submit' value='6'><input type='image' src='install[24].gif' onmouseover='this.src=\"install[25].gif\"' onmouseout='this.src=\"install[24].gif\"' alt='Click to Continue'></td>
		</tr>
	</table>
	</form>
	");

include "install_footer.php";
?>
