<?PHP
/*
####################################################
       Version Information, Debug Output
####################################################
PHP Version 4.4.2 |
####################################################
*/
  function exec_email ($to_email, $to_name, $from_email, $from_name, $subject, $message, $email_type, $message_priority)
  {
    global $charset;
    $from_name = str_replace (',', '', $from_name);
    $from_name = str_replace ('.', '', $from_name);
    $to_name = str_replace (',', '', $to_name);
    $to_name = str_replace ('.', '', $to_name);
    ini_set (sendmail_from, $from_email);
    $generate_date = date ('r');
    $fp = fsockopen (ini_get ('SMTP'), ini_get ('smtp_port'), $errno, $errstr, 30);
    if (!($fp))
    {
      return false;
    }

    $stream = fgets ($fp, 1024);
    fputs ($fp, 'HELO {' . $_SERVER['SERVER_NAME'] . '}
');
    $stream = fgets ($fp, 1024);
    fputs ($fp, 'MAIL FROM:' . $from_email . '
');
    $stream = fgets ($fp, 1024);
    fputs ($fp, 'RCPT TO:' . $to_email . '
');
    $stream = fgets ($fp, 1024);
    fputs ($fp, 'DATA
');
    $stream = fgets ($fp, 1024);
    fputs ($fp, 'Subject: ' . $subject . '
');
    fputs ($fp, 'From: ' . $from_name . ' <' . $from_email . '>
');
    fputs ($fp, 'To: ' . $to_name . '  <' . $to_email . '>
');
    fputs ($fp, 'X-Sender: <' . $from_email . '>
');
    fputs ($fp, 'Return-Path: <' . $from_email . '>
');
    fputs ($fp, 'Errors-To: <' . $from_email . '>
');
    fputs ($fp, 'X-Mailer: PHP/' . phpversion () . '
');
    fputs ($fp, 'X-mimeole: Produced By Microsoft MimeOLE V5.00.2615.200
');
    fputs ($fp, 'X-Priority: ' . $message_priority . '
');
    fputs ($fp, 'Date: ' . $generate_date . '
');
    fputs ($fp, 'X-MSMail-Priority: ' . ($message_priority == 1 ? 'High' : 'Normal') . '
');
    fputs ($fp, 'Content-Type: text/' . ($email_type == 0 ? 'plain' : 'html') . '
');
    fputs ($fp, 'Charset: ' . $charset . '
');
    fputs ($fp, '
');
    fputs ($fp, stripslashes ($message) . '
');
    fputs ($fp, '.
');
    $stream = fgets ($fp, 1024);
    fputs ($fp, 'RSET
');
    $stream = fgets ($fp, 1024);
    fputs ($fp, 'QUIT
');
    $stream = fgets ($fp, 1024);
    fclose ($fp);
    ini_restore (sendmail_from);
    return true;
  }

  function invalid_admin_login_attempt ($email_admin, $username, $password_attempt)
  {
    global $_SERVER;
    global $site_name;
    $query = 'select ';
    $query .= 'subject, ';
    $query .= 'message, ';
    $query .= 'default_email ';
    $query .= 'from ';
    $query .= 'email_templates ';
    $query .= 'where ';
    $query .= 'emid=\'49\' ';
    $query .= 'limit 0, 1';
    $rs = mysql_fetch_row (mysql_query ($query));
    $subject = s ($rs[0]);
    $message = s ($rs[1]);
    $default_email = s ($rs[2]);
    $users_ip = $_SERVER['REMOTE_ADDR'];
    $generate_date = date ('m/d/Y h:i:s a');
    $admin_name = $site_name;
    if (strcmp ($username, '') == 0)
    {
      $username = 'submitted blank';
    }

    if (strcmp ($password_attempt, '') == 0)
    {
      $password_attempt = 'submitted blank';
    }

    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $subject = str_replace ('{{users_ip}}', $users_ip, $subject);
    $subject = str_replace ('{{username}}', $username, $subject);
    $subject = str_replace ('{{password_attempt}}', $password_attempt, $subject);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    $message = str_replace ('{{users_ip}}', $users_ip, $message);
    $message = str_replace ('{{username}}', $username, $message);
    $message = str_replace ('{{password_attempt}}', $password_attempt, $message);
    if (strcmp ($default_email, '') == 0)
    {
      $default_email = $email_admin;
    }

    exec_email ($email_admin, $admin_name, $default_email, $admin_name, $subject, $message, 0, 1);
  }

  function raw_post_details ($email_admin, $post_data, $domain_name, $payment_gateway)
  {
    global $_SERVER;
    global $site_name;
    global $enable_debugging;
    global $below_public;
    global $enable_debugging;
    $query = 'select ';
    $query .= 'subject, ';
    $query .= 'message, ';
    $query .= 'default_email ';
    $query .= 'from ';
    $query .= 'email_templates ';
    $query .= 'where ';
    $query .= 'emid=\'48\' ';
    $query .= 'limit 0, 1';
    $rs = mysql_fetch_row (mysql_query ($query));
    $subject = s ($rs[0]);
    $message = s ($rs[1]);
    $default_email = s ($rs[2]);
    $generate_date = date ('m/d/Y h:i:s a');
    $admin_name = $site_name;
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $subject = str_replace ('{{posted_data}}', $post_data, $subject);
    $subject = str_replace ('{{domain_name}}', $domain_name, $subject);
    $subject = str_replace ('{{payment_gateway}}', $payment_gateway, $subject);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    $message = str_replace ('{{post_data}}', $post_data, $message);
    $message = str_replace ('{{domain_name}}', $domain_name, $message);
    $message = str_replace ('{{payment_gateway}}', $payment_gateway, $message);
    if (!(@file_exists ($below_public . '/gateway_logs')))
    {
      $old_umask = @umask (0);
      @mkdir ($below_public . '/gateway_logs', 511);
      @umask ($old_umask);
    }

    $save_path = $below_public . '/gateway_logs/';
    $save_path .= date ('m-d-Y') . '_';
    $save_path .= md5 (microtime ()) . '_';
    $save_path .= str_replace (' ', '_', strtolower ($payment_gateway));
    $save_path .= '.txt';
    $fp = fopen ($save_path, 'w');
    fwrite ($fp, $message);
    fclose ($fp);
    if (strcmp ($default_email, '') == 0)
    {
      $default_email = $email_admin;
    }

    if (strcmp ($enable_debugging, '1') == 0)
    {
      exec_email ($email_admin, $admin_name, $default_email, $admin_name, $subject, $message, 0, 1);
    }

  }

  function exec_cron ($http_admin, $request, $qstring)
  {
    $link = curl_init ();
    curl_setopt ($link, CURLOPT_URL, $http_admin . $request);
    curl_setopt ($link, CURLOPT_HEADER, 0);
    curl_setopt ($link, CURLOPT_RETURNTRANSFER, 1);
    if ($qstring !== 0)
    {
      curl_setopt ($link, CURLOPT_POSTFIELDS, $qstring);
    }

    $data = curl_exec ($link);
    $data = split ('\\,', $data);
    curl_close ($link);
    return 0;
  }

  function exec_whm ($server_ip, $request, $qstring, $auth)
  {
    $link = curl_init ();
    curl_setopt ($link, CURLOPT_TIMEOUT, 8);
    curl_setopt ($link, CURLOPT_URL, 'http://' . $server_ip . ':2086' . $request);
    curl_setopt ($link, CURLOPT_HEADER, 0);
    curl_setopt ($link, CURLOPT_RETURNTRANSFER, 1);
    $curlheaders[0] = 'Authorization: WHM ' . $auth;
    curl_setopt ($link, CURLOPT_HTTPHEADER, $curlheaders);
    if ($qstring !== 0)
    {
      curl_setopt ($link, CURLOPT_POSTFIELDS, $qstring);
    }

    $data = curl_exec ($link);
    $data = split ('\\,', $data);
    curl_close ($link);
    return $data;
  }

  function check_ip_reserve ($server_ip, $whm_username, $whm_password)
  {
    $auth = $whm_username . ':' . preg_replace ('\'(
|
)\'', '', $whm_password);
    $request = '/scripts/reservedip';
    $qstring = '';
    $data = exec_whm ($server_ip, $request, $qstring, $auth);
    $buffer = '';
    foreach ($data as $line)
    {
      $buffer .= $line;
    }

    $buffer2 = explode ('
', $buffer);
    foreach ($buffer2 as $line2)
    {
      $buffer3 = explode (' ', $line2);
      foreach ($buffer3 as $line3)
      {
        if (substr ($line3, 0, 4) == 'name')
        {
          list ($bad, $good) = explode ('>', strip_tags ($line3));
          $good = trim ($good);
          $ip = trim ($good);
          $buffer4 = explode (' ', $line2);
          foreach ($buffer4 as $line4)
          {
            if (strcmp (strtolower (trim ($line4)), 'checked') == 0)
            {
              $taken = true;
              continue;
            }
          }

          if (!(isset ($taken)))
          {
            if ($ip != '')
            {
              $list .= $ip . '|';
              continue;
            }

            continue;
          }
          else
          {
            unset ($taken);
            continue;
          }

          continue;
        }
      }
    }

    if (!(isset ($list)))
    {
      return 0;
    }

    return $list;
  }

  function change_cpanel_password ($server_ip, $whm_username, $whm_password, $user, $new_password)
  {
    $auth = $whm_username . ':' . preg_replace ('\'(
|
)\'', '', $whm_password);
    $request = '/scripts/passwd';
    $qstring = 'password=' . $new_password;
    $qstring .= '&domain=' . $user;
    $qstring .= '&user=' . $user;
    $qstring .= '&submit-domain=Change%0D%0A++++Password';
    $data = exec_whm ($server_ip, $request, $qstring, $auth);
    foreach ($data as $line)
    {
      $base = strip_tags ($line);
      $base = explode (' ', $base);
      foreach ($base as $data)
      {
        if (ereg ('changed', trim ($data)) == true)
        {
          return 1;
        }
      }
    }

    return 0;
  }

  function list_accounts ($server_ip, $whm_username, $whm_password, $which)
  {
    $auth = $whm_username . ':' . preg_replace ('\'(
|
)\'', '', $whm_password);
    $request = '/scripts2/listaccts';
    $qstring = 'viewall=1';
    $qstring .= '&nohtml=1';
    $data = exec_whm ($server_ip, $request, $qstring, $auth);
    $buffer = '';
    foreach ($data as $line)
    {
      $line = str_replace ('=', '�', $line);
      $line = str_replace ('
', '{{', $line);
      $buffer .= $line . '�';
    }

    unset ($line);
    $buffer2 = explode ('{{', $buffer);
    $buffer3 = '';
    foreach ($buffer2 as $line_num => $line)
    {
      list ($user, $domain, $package, $owner) = explode ('�', $line);
      if (trim ($user) != '')
      {
        if (trim ($package) != '')
        {
          if (trim ($owner) != '')
          {
            $buffer3 .= $user . '|' . $package . '|' . $owner . '
';
            if (strcmp ('All ]', trim (strip_tags ($buffer3))) != 0)
            {
              $total += 1;
              continue;
            }

            continue;
          }

          continue;
        }

        continue;
      }
    }

    if ($which == 0)
    {
      return $buffer3;
    }

    if ($which == 1)
    {
      if (!($total))
      {
        return 0;
      }

      return $total;
    }

  }

  function show_server_status ($server_ip, $xwhm_username, $xwhm_password)
  {
    $auth = $xwhm_username . ':' . preg_replace ('\'(
|
)\'', '', $xwhm_password);
    $request = '/scripts/servup';
    $buffer = '';
    $data = exec_whm ($server_ip, $request, 0, $auth);
    foreach ($data as $line_num => $line)
    {
      $buffer .= strip_tags (trim ($line));
    }

    $arr = explode ('
', strtolower (str_replace (' ', '
', $buffer)));
    $apache_key = $arr[array_search ('httpd', $arr) + 1] . $arr[array_search ('httpd', $arr) + 2];
    $apache_status = explode ('))', $apache_key);
    $apache_status = $apache_status[1];
    if (strcmp (strtolower ($apache_status), 'up') == 0)
    {
      $alert = 0;
    }
    else
    {
      $alert = 1;
    }

    $apache_version = explode ('))', $apache_key);
    $apache_version = $apache_version[0] . '))';
    $main_buffer = 'Apache ' . $apache_version . '�' . $alert . '|';
    $bind_key = $arr[array_search ('named', $arr) + 1];
    $bind_array = explode (')', $bind_key);
    $bind_status = $bind_array[1];
    $bind_version = 'Bind ' . $bind_array[0] . ')';
    if (strcmp (strtolower ($bind_status), 'up') == 0)
    {
      $alert = 0;
    }
    else
    {
      $alert = 1;
    }

    $main_buffer .= $bind_version . '�' . $alert . '|';
    $rarr = array_reverse ($arr);
    $key = array_search ('cpu)', $rarr);
    $key += 2;
    if ($key == 2)
    {
      $key = array_search ('cpus)', $rarr);
      $key += 2;
    }

    $load = str_replace ('load', '', strtolower ($rarr[$key]));
    if (5 < $load)
    {
      $alert = 1;
    }
    else
    {
      $alert = 0;
    }

    $main_buffer .= $load . '�' . $alert . '|';
    return $main_buffer;
  }

  function show_cpanel_version ($server_ip, $xwhm_username, $xwhm_password)
  {
    $auth = $xwhm_username . ':' . preg_replace ('\'(
|
)\'', '', $xwhm_password);
    $request = '/scripts/command';
    $data = exec_whm ($server_ip, $request, 0, $auth);
    foreach ($data as $line_num => $line)
    {
      if (ereg ('>WHM', $line) == true)
      {
        $buffer = strip_tags (trim ($line));
        list ($junk, $good) = explode ('}', $buffer);
        $ct = substr_count ($good, '
');
        $explode = explode ('
', $good);
        $data = '';
        for ($i = 0; $i <= $ct; ++$i)
        {
          if (trim ($explode[$i]) != '')
          {
            $data .= trim ($explode[$i]) . '|';
            continue;
          }
        }

        list ($wv, $cv) = explode ('|', $data);
        return $wv . '|' . $cv . '|';
      }
    }

  }

  function get_free_ips ($server_ip, $xwhm_username, $xwhm_password)
  {
    $auth = $xwhm_username . ':' . preg_replace ('\'(
|
)\'', '', $xwhm_password);
    $request = '/scripts/ipusage';
    $data = exec_whm ($server_ip, $request, 0, $auth);
    $buffer = '';
    foreach ($data as $line_num => $line)
    {
      $buffer .= $line;
    }

    $reserved = check_ip_reserve ($server_ip, $xwhm_username, $xwhm_password);
    $reserved_list = explode ('|', $reserved);
    $buffer2 = explode ('
', $buffer);
    foreach ($buffer2 as $line2)
    {
      list ($ip, $junk) = explode ('</td>', $line2);
      $ip = strip_tags ($ip);
      $ip = trim ($ip);
      $valid_ip = $junk = strip_tags ($junk);
      $junk = trim ($junk);
      if ($junk == '')
      {
        if (is_numeric (str_replace ('.', '', $ip)) == true)
        {
          if (in_array ($ip, $reserved_list))
          {
            return $ip;
          }

          continue;
        }

        continue;
      }
    }

    return 0;
  }

  function default_install_ip ($server_ip, $xwhm_username, $xwhm_password)
  {
    $auth = $xwhm_username . ':' . preg_replace ('\'(
|
)\'', '', $xwhm_password);
    $request = '/scripts/editsets';
    $data = exec_whm ($server_ip, $request, 0, $auth);
    foreach ($data as $line_num => $line)
    {
      if (ereg ('name="ADDR"', $line) == true)
      {
        list ($junk, $good) = explode ('value="', strtolower ($line));
        list ($ip, $junk0) = explode ('"', $good);
        return $ip;
      }
    }

  }

  function show_bandwidth_usage ($server_ip, $xwhm_username, $xwhm_password)
  {
    $auth = $xwhm_username . ':' . preg_replace ('\'(
|
)\'', '', $xwhm_password);
    $request = '/scripts/showbw';
    $data = exec_whm ($server_ip, $request, 0, $auth);
    foreach ($data as $line_num => $line)
    {
      if (ereg ('Total', $line) == true)
      {
        list ($junk, $good, $bad, $ugly) = explode (']', $line);
        $buffer = strip_tags ($ugly);
        list ($band, $width) = explode ('.', $buffer);
        return $band . '.' . substr ($width, 0, 6);
      }
    }

  }

  function list_cpanel_themes ($server_ip, $whm_username, $whm_password)
  {
    $auth = $whm_username . ':' . preg_replace ('\'(
|
)\'', '', $whm_password);
    $request = '/scripts/listthemes';
    $data = exec_whm ($server_ip, $request, 0, $auth);
    $buffer = '';
    foreach ($data as $line_num => $line)
    {
      $buffer .= $line;
    }

    $array = explode ('<pre>', $buffer);
    $array = trim ($array[1]);
    $array = explode ('
', $array);
    $buffer = '';
    foreach ($array as $line_num => $line)
    {
      if (0 < $line_num)
      {
        $buffer .= '|';
      }

      $buffer .= $line;
    }

    return $buffer;
  }

  function check_whm_username ($server_ip, $xwhm_username, $xwhm_password, $whm_username)
  {
    global $domain_name;
    $auth = $xwhm_username . ':' . preg_replace ('\'(
|
)\'', '', $xwhm_password);
    $request = '/scripts2/listaccts';
    $qstring = 'viewall=1';
    $data = exec_whm ($server_ip, $request, $qstring, $auth);
    $buffer = '';
    $whm_username = strtolower ($whm_username);
    foreach ($data as $line_num => $line)
    {
      $buffer .= $line;
    }

    list ($junk, $good) = explode ('reseller</b>', strtolower ($buffer));
    $ct = substr_count ($good, '
') - 1;
    $explode = explode ('
', $good);
    for ($i = 0; $i <= $ct; ++$i)
    {
      if (trim ($explode[$i]) != '')
      {
        list ($y0, $y1, $y2, $y3, $y4, $y5, $y6, $y7, $y8, $y9, $y10) = explode ('</td>', $explode[$i]);
        $current = strip_tags (strtolower ($y2));
        $current_domain = strip_tags (strtolower ($y0));
        if (strcmp ($current_domain, $domain_name) == 0)
        {
          if (trim ($current_domain) != '')
          {
            return 1;
          }
        }

        if (strcmp ($current, $whm_username) == 0)
        {
          if (trim ($current) != '')
          {
            return 2;
          }

          continue;
        }

        continue;
      }
    }

  }

  function change_ownership ($server_ip, $xwhm_username, $xwhm_password, $username, $new_owner)
  {
    $auth = $xwhm_username . ':' . preg_replace ('\'(
|
)\'', '', $xwhm_password);
    $request = '/scripts/dochangeowner';
    $qstring = 'user=' . $username . '&owner=' . $new_owner;
    $data = exec_whm ($server_ip, $request, $qstring, $auth);
    $buffer = '';
    foreach ($data as $line_num => $line)
    {
      $buffer .= $line;
    }

    $query = 'select ';
    $query .= 'uid ';
    $query .= 'from ';
    $query .= 'user ';
    $query .= 'where ';
    $query .= 'username=\'' . addslashes (trim ($username)) . '\' ';
    $query .= 'limit 0, 1';
    $rs = mysql_fetch_row (mysql_query ($query));
    $old_uid = $rs[0];
    $query = 'select ';
    $query .= 'uid ';
    $query .= 'from ';
    $query .= 'user ';
    $query .= 'where ';
    $query .= 'username=\'' . addslashes (trim ($new_owner)) . '\' ';
    $query .= 'limit 0, 1';
    $rs = mysql_fetch_row (mysql_query ($query));
    $new_uid = $rs[0];
    $query = 'update ';
    $query .= 'invoice ';
    $query .= 'set ';
    $query .= 'uid=\'' . $new_uid . '\' ';
    $query .= 'where ';
    $query .= 'uid=\'' . $old_uid . '\'';
    mysql_query ($query);
    $query = 'update ';
    $query .= 'authnet_batch ';
    $query .= 'set ';
    $query .= 'uid=\'' . $new_uid . '\' ';
    $query .= 'where ';
    $query .= 'uid=\'' . $old_uid . '\'';
    mysql_query ($query);
    $query = 'update ';
    $query .= 'authnet_master_cc ';
    $query .= 'set ';
    $query .= 'uid=\'' . $new_uid . '\' ';
    $query .= 'where ';
    $query .= 'uid=\'' . $old_uid . '\'';
    mysql_query ($query);
    return 1;
  }

  function write_csv ($server_ip, $xwhm_username, $xwhm_password, $below_public, $which, $display_time, $whm_id)
  {
    $auth = $xwhm_username . ':' . preg_replace ('\'(
|
)\'', '', $xwhm_password);
    $request = '/scripts/fetchcsv';
    $qstring = '';
    $data = exec_whm ($server_ip, $request, $qstring, $auth);
    $buffer = '';
    foreach ($data as $line_num => $line)
    {
      if (ereg (',', $line) == false)
      {
        $line .= ',';
      }

      $buffer .= $line;
    }

    $line_array = explode ('
', $buffer);
    $buffer2 = '';
    for ($i = 0; $i <= count ($line_array); ++$i)
    {
      list ($j0, $domain, $ip, $username, $j1, $j2, $j3, $j4, $j5, $j6, $j7, $j8, $owner, $dns, $cp, $j9, $mb, $j10, $j11, $j12, $package, $j13, $j14, $j15, $j16, $j17, $j18, $created) = explode (',', $line_array[$i]);
      $display_time = display_time (trim ($created), 1);
      if (substr ($display_time, -4) != '0000')
      {
        $buffer2 .= trim ($i) . '|';
        $buffer2 .= trim ($domain) . '|';
        $buffer2 .= trim ($ip) . '|';
        $buffer2 .= trim ($username) . '|';
        $buffer2 .= trim ($owner) . '|';
        $buffer2 .= trim ($dns) . '|';
        $buffer2 .= trim ($cp) . '|';
        $buffer2 .= trim ($mb) . '|';
        $buffer2 .= trim ($package) . '|';
        $buffer2 .= $display_time . '|
';
        $buffer2 = str_replace ('|||||||-1|
', '', $buffer2);
        $buffer2 = str_replace (':443', '', $buffer2);
        continue;
      }
    }

    if ($which == 0)
    {
      return trim ($buffer2);
    }

    if ($which == 1)
    {
      $read = fopen ($below_public . '/whm_csv_' . $whm_id . '.log', 'w');
      $result = fwrite ($read, trim ($buffer2));
      fclose ($read);
      chmod ($below_public . '/whm_csv_' . $whm_id . '.log', 511);
      return 1;
    }

  }

  function create_account ($server_ip, $xwhm_username, $xwhm_password, $domain_name, $whm_username, $whm_password, $ip, $cgi, $quota, $frontpage, $cpmod, $maxftp, $maxsql, $maxpop, $maxlst, $maxsub, $bwlimit, $hasshell, $maxpark, $maxaddon, $whm_package_name, $default_ip)
  {
    $auth = $xwhm_username . ':' . preg_replace ('\'(
|
)\'', '', $xwhm_password);
    $request = '/scripts/wwwacct';
    $filename = 'domain=' . $domain_name;
    $filename .= '&username=' . $whm_username;
    $filename .= '&password=' . $whm_password;
    $filename .= '&quota=' . $quota;
    $filename .= '&cpmod=' . $cpmod;
    if ($ip == 1)
    {
      $filename .= '&ip=' . $ip;
    }

    if ($cgi == 1)
    {
      $filename .= '&cgi=1';
    }
    else
    {
      $filename .= '&cgi=n';
    }

    if ($frontpage == 1)
    {
      $filename .= '&frontpage=y';
    }
    else
    {
      $filename .= '&frontpage=n';
    }

    $filename .= '&maxftp=' . (trim ($maxftp) == '-1' ? 'unlimited' : '' . $maxftp . '');
    $filename .= '&maxsql=' . (trim ($maxsql) == '-1' ? 'unlimited' : '' . $maxsql . '');
    $filename .= '&maxpop=' . (trim ($maxpop) == '-1' ? 'unlimited' : '' . $maxpop . '');
    $filename .= '&maxlst=' . (trim ($maxlst) == '-1' ? 'unlimited' : '' . $maxlst . '');
    $filename .= '&maxsub=' . (trim ($maxsub) == '-1' ? 'unlimited' : '' . $maxsub . '');
    $filename .= '&bwlimit=' . $bwlimit;
    if ($hasshell == 1)
    {
      $filename .= '&hasshell=y';
    }
    else
    {
      $filename .= '&hasshell=n';
    }

    $filename .= '&maxpark=' . $maxpark;
    $filename .= '&maxaddon=' . (trim ($maxaddon) == '-1' ? 'unlimited' : '' . $maxaddon . '');
    if ($ip == 1)
    {
      $filename .= '&customip=' . trim ($default_ip);
    }
    else
    {
      $filename .= '&customip=--Auto+Assign--';
    }

    $filename .= '&nohtml=1';
    $msel = '';
    if ($ip == 1)
    {
      $msel .= 'y,';
    }
    else
    {
      $msel .= 'n,';
    }

    if ($cgi == 1)
    {
      $msel .= 'y,';
    }
    else
    {
      $msel .= 'n,';
    }

    $msel .= $quota . ',';
    if ($frontpage == 1)
    {
      $msel .= 'y,';
    }
    else
    {
      $msel .= 'n,';
    }

    $msel .= $cpmod . ',';
    $msel .= (trim ($maxftp) == '-1' ? 'unlimited' : '' . $maxftp . '') . ',';
    $msel .= (trim ($maxsql) == '-1' ? 'unlimited' : '' . $maxsql . '') . ',';
    $msel .= (trim ($maxpop) == '-1' ? 'unlimited' : '' . $maxpop . '') . ',';
    $msel .= (trim ($maxlst) == '-1' ? 'unlimited' : '' . $maxlst . '') . ',';
    $msel .= (trim ($maxsub) == '-1' ? 'unlimited' : '' . $maxsub . '') . ',';
    $msel .= (trim ($maxpark) == '-1' ? 'unlimited' : '' . $maxpark . '') . ',';
    $msel .= $bwlimit . ',';
    if ($hasshell == 1)
    {
      $msel .= 'y,';
    }
    else
    {
      $msel .= 'n,';
    }

    $msel .= $whm_package_name;
    $filename .= '&msel=' . $msel;
    $qstring = $filename;
    $data = exec_whm ($server_ip, $request, $qstring, $auth);
    $result = '';
    foreach ($data as $line_num => $line)
    {
      $result .= $line . '|';
    }

    $result = strip_tags ($result);
    if (ereg ('/etc/wwwacct.conf not found', $result) == true)
    {
      return 1;
    }

    if (ereg ('Missing NS Config Line in /etc/wwwacct.conf', $result) == true)
    {
      return 2;
    }

    if (ereg ('Missing NS2 Config Line in /etc/wwwacct.conf', $result) == true)
    {
      return 3;
    }

    if (ereg ('Missing HOMEDIR Config Line in /etc/wwwacct.conf', $result) == true)
    {
      return 4;
    }

    if (ereg ('Missing HOMEMATCH Config Line in /etc/wwwacct.conf', $result) == true)
    {
      return 5;
    }

    if (ereg ('Missing DEFMOD Config Line in /etc/wwwacct.conf', $result) == true)
    {
      return 6;
    }

    if (ereg ('Missing HOST Config Line in /etc/wwwacct.conf', $result) == true)
    {
      return 7;
    }

    if (ereg ('Missing LOGSTYLE Config Line in /etc/wwwacct.conf', $result) == true)
    {
      return 8;
    }

    if (ereg ('Missing BINDVER Config Line in /etc/wwwacct.conf', $result) == true)
    {
      return 9;
    }

    if (ereg ('Missing FTPTYPE Config Line in /etc/wwwacct.conf', $result) == true)
    {
      return 10;
    }

    if (ereg ('Missing SCRIPTALIAS Config Line in /etc/wwwacct.conf', $result) == true)
    {
      return 11;
    }

    if (ereg ('httpd.conf is corrupt.', $result) == true)
    {
      return 12;
    }

    if (ereg ('proftpd.conf', $result) == true)
    {
      return 13;
    }

    if (ereg ('Unable to determine main ip', $result) == true)
    {
      return 14;
    }

    if (ereg ('Ouch, sorry that username is taken', $result) == true)
    {
      return 15;
    }

    if (ereg ('Sorry that username is too long.', $result) == true)
    {
      return 16;
    }

    if (ereg ('Sorry usernames cannot begin with a number.', $result) == true)
    {
      return 17;
    }

    if (ereg ('Sorry usernames cannot begin with a dash.', $result) == true)
    {
      return 18;
    }

    if (ereg ('Requested IP address', $result) == true)
    {
      return 19;
    }

    if (ereg ('Unable to find an ip address', $result) == true)
    {
      return 20;
    }

    if (ereg ('You cannot setup a domain that is the same as the servers hostname', $result) == true)
    {
      return 21;
    }

    if (ereg ('Sorry, thats an invalid domain', $result) == true)
    {
      return 22;
    }

    if (ereg ('Sorry, thats an invalid username', $result) == true)
    {
      return 23;
    }

    if (ereg ('No domain name given', $result) == true)
    {
      return 24;
    }

    if (ereg ('Sorry, that domain is already setup', $result) == true)
    {
      return 25;
    }

    if (ereg ('Ok Guess NOT', $result) == true)
    {
      return 26;
    }

    if (ereg ('Sorry thats not a valid domain', $result) == true)
    {
      return 27;
    }

    if (ereg ('is not a valid domain name', $result) == true)
    {
      return 28;
    }

    if (ereg ('is not a valid domain name', $result) == true)
    {
      return 29;
    }

    if (ereg ('Sorry you are at your limit for creating', $result) == true)
    {
      return 30;
    }

    if (ereg ('Sorry, you must choose a plan', $result) == true)
    {
      return 31;
    }

    if (ereg ('Sorry, you cannot create an account with an unlimited bandwidth limit.', $result) == true)
    {
      return 33;
    }

    return 99;
  }

  function parse_whm_error ($create_account)
  {
    if (trim ($create_account) == '1')
    {
      return '/etc/wwwacct.conf not found';
    }

    if (trim ($create_account == '2'))
    {
      return 'Missing NS Config Line in /etc/wwwacct.conf';
    }

    if (trim ($create_account == '3'))
    {
      return 'Missing NS2 Config Line in /etc/wwwacct.conf';
    }

    if (trim ($create_account == '4'))
    {
      return 'Missing HOMEDIR Config Line in /etc/wwwacct.conf';
    }

    if (trim ($create_account == '5'))
    {
      return 'Missing HOMEMATCH Config Line in /etc/wwwacct.conf';
    }

    if (trim ($create_account == '6'))
    {
      return 'Missing DEFMOD Config Line in /etc/wwwacct.conf';
    }

    if (trim ($create_account == '7'))
    {
      return 'Missing HOST Config Line in /etc/wwwacct.conf';
    }

    if (trim ($create_account == '8'))
    {
      return 'Missing LOGSTYLE Config Line in /etc/wwwacct.conf';
    }

    if (trim ($create_account == '9'))
    {
      return 'Missing BINDVER Config Line in /etc/wwwacct.conf';
    }

    if (trim ($create_account == '10'))
    {
      return 'Missing FTPTYPE Config Line in /etc/wwwacct.conf';
    }

    if (trim ($create_account == '11'))
    {
      return 'Missing SCRIPTALIAS Config Line in /etc/wwwacct.conf';
    }

    if (trim ($create_account == '12'))
    {
      return 'httpd.conf is corrupt.';
    }

    if (trim ($create_account == '13'))
    {
      return 'proftpd.conf issues';
    }

    if (trim ($create_account == '14'))
    {
      return 'Unable to determine main ip';
    }

    if (trim ($create_account == '15'))
    {
      return 'Ouch, sorry that username is taken';
    }

    if (trim ($create_account == '16'))
    {
      return 'Username is too long.';
    }

    if (trim ($create_account == '17'))
    {
      return 'Usernames cannot begin with a number.';
    }

    if (trim ($create_account == '18'))
    {
      return 'Usernames cannot begin with a dash.';
    }

    if (trim ($create_account == '19'))
    {
      return 'Requested IP address issue';
    }

    if (trim ($create_account == '20'))
    {
      return 'Unable to find an ip address';
    }

    if (trim ($create_account == '21'))
    {
      return 'You cannot setup a domain that is the same as the servers hostname';
    }

    if (trim ($create_account == '22'))
    {
      return 'Invalid domain';
    }

    if (trim ($create_account == '23'))
    {
      return 'Invalid username';
    }

    if (trim ($create_account == '24'))
    {
      return 'No domain name given';
    }

    if (trim ($create_account == '25'))
    {
      return 'Domain is already installed on this server.';
    }

    if (trim ($create_account == '26'))
    {
      return 'Unknown Error, returned: [Ok Guess NOT]';
    }

    if (trim ($create_account == '27'))
    {
      return '1. Not a valid domain';
    }

    if (trim ($create_account == '28'))
    {
      return '2. Not a valid domain name';
    }

    if (trim ($create_account == '29'))
    {
      return '3. Not a valid domain name';
    }

    if (trim ($create_account == '1001'))
    {
      return 'Unique IP Request must be installed manually using WHM.';
    }

    if (trim ($create_account == '1002'))
    {
      return 'The account is now suspended.';
    }

    if (trim ($create_account == '1003'))
    {
      return 'The account is now active.';
    }

    if (trim ($create_account == '1004'))
    {
      return 'The account is cancelled.';
    }

    if (trim ($create_account == '30'))
    {
      return 'One of the following applies:<br>- You are at your limit in creating accounts for this plan.<br>- You have not defined the plan attributes correctly in AutoPilot.<br>- The chosen install server is in reseller mode by mistake.<br><br>';
    }

    if (trim ($create_account == '31'))
    {
      return 'No reseller plan defined.';
    }

    if (trim ($create_account == '32'))
    {
      return 'Unknown Error.';
    }

    if (trim ($create_account == '33'))
    {
      return 'Sorry, you cannot create an account with an unlimited bandwidth limit.';
    }

  }

  function suspend_account ($server_ip, $xwhm_username, $xwhm_password, $whm_username)
  {
    $auth = $xwhm_username . ':' . preg_replace ('\'(
|
)\'', '', $xwhm_password);
    $request = '/scripts2/suspendacct';
    $qstring = 'domain=' . $whm_username;
    $qstring .= '&user=' . $whm_username;
    $qstring .= '&suspend-domain=Suspend';
    $qstring .= '&reason=Processed_via_AutoPilot';
    $data = exec_whm ($server_ip, $request, $qstring, $auth);
    $buffer = '';
    foreach ($data as $line_num => $line)
    {
      $buffer .= $line;
    }

    return 0;
  }

  function unsuspend_account ($server_ip, $xwhm_username, $xwhm_password, $whm_username)
  {
    $auth = $xwhm_username . ':' . preg_replace ('\'(
|
)\'', '', $xwhm_password);
    $request = '/scripts2/suspendacct';
    $qstring = 'domain=' . $whm_username;
    $qstring .= '&user=' . $whm_username;
    $qstring .= '&unsuspend-domain=UnSuspend';
    $qstring .= '&reason=Processed_via_AutoPilot';
    $data = exec_whm ($server_ip, $request, $qstring, $auth);
    $buffer = '';
    foreach ($data as $line_num => $line)
    {
      $buffer .= $line;
    }

    return 0;
  }

  function terminate_account ($server_ip, $xwhm_username, $xwhm_password, $whm_username)
  {
    $auth = $xwhm_username . ':' . preg_replace ('\'(
|
)\'', '', $xwhm_password);
    $request = '/scripts/killacct';
    $qstring = 'domain=' . $whm_username;
    $qstring .= '&user=' . $whm_username;
    $qstring .= '&submit-domain=Terminate';
    $data = exec_whm ($server_ip, $request, $qstring, $auth);
    $buffer = '';
    foreach ($data as $line_num => $line)
    {
      $buffer .= $line;
    }

    return 0;
  }

  function change_sites_quota ($server_ip, $xwhm_username, $xwhm_password, $whm_username, $quota)
  {
    $auth = $xwhm_username . ':' . preg_replace ('\'(
|
)\'', '', $xwhm_password);
    $request = '/scripts/editquota';
    $qstring = 'user=' . $whm_username;
    $qstring .= '&quota=' . $quota;
    $data = exec_whm ($server_ip, $request, $qstring, $auth);
    $buffer = '';
    foreach ($data as $line_num => $line)
    {
      $buffer .= $line;
    }

    return 0;
  }

  function change_sites_ip ($server_ip, $xwhm_username, $xwhm_password, $whm_username, $old_ip, $new_ip)
  {
    $auth = $xwhm_username . ':' . preg_replace ('\'(
|
)\'', '', $xwhm_password);
    $request = '/scripts2/dochangeip';
    $qstring = 'user=' . $whm_username;
    $qstring .= '&oldip=' . $old_ip;
    $qstring .= '&customip=' . $new_ip;
    $data = exec_whm ($server_ip, $request, $qstring, $auth);
    $buffer = '';
    foreach ($data as $line_num => $line)
    {
      $buffer .= $line;
    }

    return 0;
  }

  function list_available_packages ($server_ip, $xwhm_username, $xwhm_password, $whm_username)
  {
    $auth = $xwhm_username . ':' . preg_replace ('\'(
|
)\'', '', $xwhm_password);
    $request = '/scripts2/editres';
    $qstring = 'res=' . $whm_username;
    $data = exec_whm ($server_ip, $request, $qstring, $auth);
    $buffer = '';
    foreach ($data as $line_num => $line)
    {
      $buffer .= $line;
    }

    $ct = substr_count ($buffer, '
');
    $ex = explode ('
', $buffer);
    for ($i = 0; $i <= $ct; ++$i)
    {
      if (!((!ereg ('Number Allowed', $ex[$i]) AND !isset ($bit))))
      {
        if (!(ereg ('</table>', strtolower ($ex[$i]))))
        {
          $bit .= $ex[$i] . '{|}';
          continue;
        }

        continue;
      }
    }

    unset ($ct);
    unset ($ex);
    unset ($i);
    $bit = strtolower ($bit);
    $bit = str_replace ('<tr>', '', $bit);
    $bit = str_replace ('</tr>', '', $bit);
    $bit = str_replace ('<td>', '', $bit);
    $ct = substr_count ($bit, '{|}');
    $ex = explode ('{|}', $bit);
    for ($i = 0; $i <= $ct; ++$i)
    {
      if (1 <= $i)
      {
        if ($i < $ct - 1)
        {
          list ($a, $b, $c) = explode ('</td>', $ex[$i]);
          list ($junk, $c) = explode ('value="', $c);
          $c = str_replace ('">', '', $c);
          $res .= $a . '|' . $b . '|' . $c . '|acctlim-|
';
          continue;
        }

        continue;
      }
    }

    return strip_tags ($res);
  }

  function grant_reseller ($server_ip, $xwhm_username, $xwhm_password, $whm_username)
  {
    $auth = $xwhm_username . ':' . preg_replace ('\'(
|
)\'', '', $xwhm_password);
    $request = '/scripts/addres';
    $qstring = 'res=' . $whm_username;
    $qstring .= '&submit=ok';
    $data = exec_whm ($server_ip, $request, $qstring, $auth);
    $buffer = '';
    foreach ($data as $line_num => $line)
    {
      $buffer .= $line;
    }

    return 0;
  }

  function create_reseller ($server_ip, $xwhm_username, $xwhm_password, $whm_username, $rid)
  {
    grant_reseller ($server_ip, $xwhm_username, $xwhm_password, $whm_username);
    $rqw3 = 'select ';
    $rqw3 .= 'limit_type, ';
    $rqw3 .= 'acl_list, ';
    $rqw3 .= 'resnumlimitamt, ';
    $rqw3 .= 'rslimit_disk, ';
    $rqw3 .= 'rsolimit_disk, ';
    $rqw3 .= 'rslimit_bw, ';
    $rqw3 .= 'rsolimit_bw ';
    $rqw3 .= 'from ';
    $rqw3 .= 'reseller_profile ';
    $rqw3 .= 'where ';
    $rqw3 .= 'rid=\'' . addslashes (trim ($rid)) . '\'';
    $rq3 = mysql_fetch_row (mysql_query ($rqw3));
    $limit_type = $rq3[0];
    $acl_list = base64_decode ($rq3[1]);
    $resnumlimitamt = stripslashes (trim ($rq3[2]));
    $rslimit_disk = stripslashes (trim ($rq3[3]));
    $rsolimit_disk = stripslashes (trim ($rq3[4]));
    $rslimit_bw = stripslashes (trim ($rq3[5]));
    $rsolimit_bw = stripslashes (trim ($rq3[6]));
    $buffer = 'res=' . $whm_username;
    $buffer .= '&submit=Save';
    $acl_ct = substr_count ($acl_list, '|');
    $ex = explode ('|', $acl_list);
    for ($i = 0; $i <= $acl_ct; ++$i)
    {
      $buffer .= '&' . str_replace ('_', '-', $ex[$i]) . '=1';
    }

    if ($limit_type == 0)
    {
      $buffer .= '&reslimit=1';
    }
    else
    {
      if ($limit_type == 1)
      {
        $buffer .= '&resnumlimit=1';
        $buffer .= '&resnumlimitamt=' . $resnumlimitamt;
      }
      else
      {
        if ($limit_type == 2)
        {
          $buffer .= '&resreslimit=1';
          $buffer .= '&rslimit-disk=' . $rslimit_disk;
          $buffer .= '&rsolimit-disk=' . $rsolimit_disk;
          $buffer .= '&rslimit-bw=' . $rslimit_bw;
          $buffer .= '&rsolimit-bw=' . $rsolimit_bw;
        }
      }
    }

    $auth = $xwhm_username . ':' . preg_replace ('\'(
|
)\'', '', $xwhm_password);
    $request = '/scripts2/editressv';
    $qstring = $buffer;
    $data = exec_whm ($server_ip, $request, $qstring, $auth);
    return 1;
  }

  function send_reseller_welcome_email ($emid, $oid)
  {
    $query0 = 'select ';
    $query0 .= 'subject, ';
    $query0 .= 'message, ';
    $query0 .= 'default_email ';
    $query0 .= 'from ';
    $query0 .= 'email_templates ';
    $query0 .= 'where ';
    $query0 .= 'emid=\'' . addslashes (trim ($emid)) . '\' ';
    $query0 .= 'limit 0, 1';
    $rs0 = mysql_fetch_row (mysql_query ($query0));
    $default_email = stripslashes (trim ($rs0[2]));
    $query1 = 'select ';
    $query1 .= 'user.first_name, ';
    $query1 .= 'hosting_order.domain_name, ';
    $query1 .= 'hosting_order.ip, ';
    $query1 .= 'hosting_order.whm_username, ';
    $query1 .= 'hosting_order.whm_password, ';
    $query1 .= 'plan_specs.package_name, ';
    $query1 .= 'plan_specs.web_space, ';
    $query1 .= 'plan_specs.bandwidth, ';
    $query1 .= 'reseller_profile.limit_type, ';
    $query1 .= 'reseller_profile.resnumlimitamt, ';
    $query1 .= 'server_config.server_name, ';
    $query1 .= 'user.email, ';
    $query1 .= 'server_config.primary_ns, ';
    $query1 .= 'server_config.primary_ns_ip, ';
    $query1 .= 'server_config.secondary_ns, ';
    $query1 .= 'server_config.secondary_ns_ip, ';
    $query1 .= 'hosting_order.pns1, ';
    $query1 .= 'hosting_order.pns2, ';
    $query1 .= 'user.last_name ';
    $query1 .= 'from ';
    $query1 .= 'hosting_order, ';
    $query1 .= 'plan_specs, ';
    $query1 .= 'reseller_profile, ';
    $query1 .= 'server_config, ';
    $query1 .= 'user ';
    $query1 .= 'where ';
    $query1 .= 'hosting_order.oid=\'' . addslashes (trim ($oid)) . '\' ';
    $query1 .= 'and ';
    $query1 .= 'hosting_order.whm_id=server_config.whm_id ';
    $query1 .= 'and ';
    $query1 .= 'hosting_order.pid=plan_specs.pid ';
    $query1 .= 'and ';
    $query1 .= 'plan_specs.rid=reseller_profile.rid ';
    $query1 .= 'and ';
    $query1 .= 'hosting_order.uid=user.uid ';
    $query1 .= 'order by hosting_order.oid ';
    $query1 .= 'asc ';
    $query1 .= 'limit 0, 1';
    $rs1 = mysql_fetch_row (mysql_query ($query1));
    $subject = stripslashes (trim ($rs0[0]));
    $message = stripslashes (trim ($rs0[1]));
    $first_name = stripslashes (trim ($rs1[0]));
    $last_name = stripslashes (trim ($rs1[18]));
    $domain = stripslashes (trim ($rs1[1]));
    $ip = stripslashes (trim ($rs1[2]));
    $username = stripslashes (trim ($rs1[3]));
    $password = stripslashes (trim ($rs1[4]));
    $package = stripslashes (trim ($rs1[5]));
    $space = stripslashes (trim ($rs1[6]));
    $bandwidth = stripslashes (trim ($rs1[7]));
    $limit_type = stripslashes (trim ($rs1[8]));
    if ($limit_type == 1)
    {
      $accounts = stripslashes (trim ($rs1[9]));
    }
    else
    {
      $accounts = 'Not limited by number of resold accounts.';
    }

    $server_name = stripslashes (trim ($rs1[10]));
    $generate_date = date ('m/d/Y h:i:s a');
    $email_client = stripslashes (trim ($rs1[11]));
    $primary_nameserver = stripslashes (trim ($rs1[12]));
    $primary_nameserver_ip = stripslashes (trim ($rs1[13]));
    $secondary_nameserver = stripslashes (trim ($rs1[14]));
    $secondary_nameserver_ip = stripslashes (trim ($rs1[15]));
    $primary_nameserver_reseller = stripslashes (trim ($rs1[16])) . '.' . $domain;
    $secondary_nameserver_reseller = stripslashes (trim ($rs1[17])) . '.' . $domain;
    $primary_nameserver_ip_reseller = $primary_nameserver_ip;
    $secondary_nameserver_ip_reseller = $secondary_nameserver_ip;
    $subject = str_replace ('{{first_name}}', $first_name, $subject);
    $subject = str_replace ('{{package}}', $package, $subject);
    $subject = str_replace ('{{space}}', $space, $subject);
    $subject = str_replace ('{{bandwidth}}', $bandwidth, $subject);
    $subject = str_replace ('{{accounts}}', $accounts, $subject);
    $subject = str_replace ('{{server_name}}', $server_name, $subject);
    $subject = str_replace ('{{domain}}', $domain, $subject);
    $subject = str_replace ('{{ip}}', $ip, $subject);
    $subject = str_replace ('{{username}}', $username, $subject);
    $subject = str_replace ('{{password}}', $password, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $subject = str_replace ('{{primary_nameserver}}', $primary_nameserver, $subject);
    $subject = str_replace ('{{primary_nameserver_ip}}', $primary_nameserver_ip, $subject);
    $subject = str_replace ('{{secondary_nameserver}}', $secondary_nameserver, $subject);
    $subject = str_replace ('{{secondary_nameserver_ip}}', $secondary_nameserver_ip, $subject);
    $subject = str_replace ('{{primary_nameserver_reseller}}', $primary_nameserver_reseller, $subject);
    $subject = str_replace ('{{primary_nameserver_ip_reseller}}', $primary_nameserver_ip_reseller, $subject);
    $subject = str_replace ('{{secondary_nameserver_reseller}}', $secondary_nameserver_reseller, $subject);
    $subject = str_replace ('{{secondary_nameserver_ip_reseller}}', $secondary_nameserver_ip_reseller, $subject);
    $message = str_replace ('{{first_name}}', $first_name, $message);
    $message = str_replace ('{{package}}', $package, $message);
    $message = str_replace ('{{space}}', $space, $message);
    $message = str_replace ('{{bandwidth}}', $bandwidth, $message);
    $message = str_replace ('{{accounts}}', $accounts, $message);
    $message = str_replace ('{{server_name}}', $server_name, $message);
    $message = str_replace ('{{domain}}', $domain, $message);
    $message = str_replace ('{{ip}}', $ip, $message);
    $message = str_replace ('{{username}}', $username, $message);
    $message = str_replace ('{{password}}', $password, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    $message = str_replace ('{{primary_nameserver}}', $primary_nameserver, $message);
    $message = str_replace ('{{primary_nameserver_ip}}', $primary_nameserver_ip, $message);
    $message = str_replace ('{{secondary_nameserver}}', $secondary_nameserver, $message);
    $message = str_replace ('{{secondary_nameserver_ip}}', $secondary_nameserver_ip, $message);
    $message = str_replace ('{{primary_nameserver_reseller}}', $primary_nameserver_reseller, $message);
    $message = str_replace ('{{primary_nameserver_ip_reseller}}', $primary_nameserver_ip_reseller, $message);
    $message = str_replace ('{{secondary_nameserver_reseller}}', $secondary_nameserver_reseller, $message);
    $message = str_replace ('{{secondary_nameserver_ip_reseller}}', $secondary_nameserver_ip_reseller, $message);
    global $email_admin;
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    $client_name = $first_name . ' ' . $last_name;
    exec_email ($email_client, $client_name, $email_admin, $admin_name, $subject, $message, 0, 3);
    $subject .= ' - Admin Copy';
    $message .= '

-------------------------------------------------------------';
    $message .= '

This is a copy of the message that was sent to the client.
';
    exec_email ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function send_dedicated_activation ($emid, $oid, $which)
  {
    $query0 = 'select ';
    $query0 .= 'subject, ';
    $query0 .= 'message, ';
    $query0 .= 'default_email ';
    $query0 .= 'from ';
    $query0 .= 'email_templates ';
    $query0 .= 'where ';
    $query0 .= 'emid=\'' . addslashes (trim ($emid)) . '\' ';
    $query0 .= 'limit 0, 1';
    $rs0 = mysql_fetch_row (mysql_query ($query0));
    $subject = stripslashes (trim ($rs0[0]));
    $message = stripslashes (trim ($rs0[1]));
    $default_email = stripslashes (trim ($rs0[2]));
    $query1 = 'select ';
    $query1 .= 'user.first_name, ';
    $query1 .= 'hosting_order.server_hostname, ';
    $query1 .= 'hosting_order.domain_name, ';
    $query1 .= 'plan_specs.os, ';
    $query1 .= 'hosting_order.ip, ';
    $query1 .= 'hosting_order.root_pw, ';
    $query1 .= 'user.email, ';
    $query1 .= 'hosting_order.server_specs, ';
    $query1 .= 'hosting_order.ipblock, ';
    $query1 .= 'hosting_order.rack, ';
    $query1 .= 'user.last_name ';
    $query1 .= 'from ';
    $query1 .= 'user, hosting_order, plan_specs ';
    $query1 .= 'where ';
    $query1 .= 'hosting_order.oid=\'' . addslashes (trim ($oid)) . '\' ';
    $query1 .= 'and ';
    $query1 .= 'hosting_order.uid=user.uid ';
    $query1 .= 'and ';
    $query1 .= 'hosting_order.pid=plan_specs.pid ';
    $query1 .= 'order by hosting_order.oid asc ';
    $query1 .= 'limit 0, 1';
    $rs1 = mysql_fetch_row (mysql_query ($query1));
    $first_name = stripslashes (trim ($rs1[0]));
    $last_name = stripslashes (trim ($rs1[10]));
    $server_hostname = stripslashes (trim ($rs1[1]));
    $domain_name = stripslashes (trim ($rs1[2]));
    $dedicated_server_name = $server_hostname . '.' . $domain_name;
    $dedicated_operating_system = stripslashes (trim ($rs1[3]));
    $dedicated_main_ip = stripslashes (trim ($rs1[4]));
    $dedicated_root_password = stripslashes (trim ($rs1[5]));
    $email_client = stripslashes (trim ($rs1[6]));
    $dedicated_server_specs = stripslashes (trim ($rs1[7]));
    $dedicated_ipblock_range = stripslashes (trim ($rs1[8]));
    $dedicated_rack_location = stripslashes (trim ($rs1[9]));
    $subject = str_replace ('{{first_name}}', $first_name, $subject);
    $subject = str_replace ('{{dedicated_root_password}}', $dedicated_root_password, $subject);
    $subject = str_replace ('{{dedicated_main_ip}}', $dedicated_main_ip, $subject);
    $subject = str_replace ('{{dedicated_operating_system}}', $dedicated_operating_system, $subject);
    $subject = str_replace ('{{dedicated_server_name}}', $dedicated_server_name, $subject);
    $subject = str_replace ('{{dedicated_server_specs}}', $dedicated_server_specs, $subject);
    $subject = str_replace ('{{dedicated_ipblock_range}}', $dedicated_ipblock_range, $subject);
    $subject = str_replace ('{{dedicated_rack_location}}', $dedicated_rack_location, $subject);
    $message = str_replace ('{{first_name}}', $first_name, $message);
    $message = str_replace ('{{dedicated_root_password}}', $dedicated_root_password, $message);
    $message = str_replace ('{{dedicated_main_ip}}', $dedicated_main_ip, $message);
    $message = str_replace ('{{dedicated_operating_system}}', $dedicated_operating_system, $message);
    $message = str_replace ('{{dedicated_server_name}}', $dedicated_server_name, $message);
    $message = str_replace ('{{dedicated_server_specs}}', $dedicated_server_specs, $message);
    $message = str_replace ('{{dedicated_ipblock_range}}', $dedicated_ipblock_range, $message);
    $message = str_replace ('{{dedicated_rack_location}}', $dedicated_rack_location, $message);
    global $email_admin;
    global $site_name;
    if (strcmp ($default_email, '') == 0)
    {
      $default_email = $email_admin;
    }

    $admin_name = $site_name;
    $client_name = $first_name . ' ' . $last_name;
    exec_email ($email_client, $client_name, $default_email, $admin_name, $subject, $message, 0, 3);
    if ($which == 1)
    {
      $subject .= ' - Admin Copy';
      $message .= '

-------------------------------------------------------------';
      $message .= '

This is a copy of the message that was sent to the client.
';
      exec_email ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
    }

    return 1;
  }

  function clear_cache ()
  {
    header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
    header ('Last-Modified: ' . gmdate ('D, d M Y H:i:s') . ' GMT');
    header ('Cache-Control: no-store, no-cache, must-revalidate');
    header ('Cache-Control: post-check=0, pre-check=0', false);
    header ('Pragma: no-cache');
  }

  function create_next_due ($og, $payment_term)
  {
    $hour = date ('h', $og);
    $min = date ('i', $og);
    $sec = date ('s', $og);
    $month = date ('m', $og);
    $day = date ('d', $og);
    $year = date ('Y', $og);
    $data = mktime ($hour, $min, $sec, $month + $payment_term, $day, $year);
    return $data;
  }

  function find_next_due ($payment_term, $oid, $which)
  {
    $payment_term = strtolower (stripslashes (trim ($payment_term)));
    $payment_term = str_replace ('-', '_', $payment_term);
    if ($payment_term == 'monthly')
    {
      $payment_term = '1';
    }
    else
    {
      if ($payment_term == 'quarterly')
      {
        $payment_term = '3';
      }
      else
      {
        if ($payment_term == 'semi_annual')
        {
          $payment_term = '6';
        }
        else
        {
          if ($payment_term == 'annual')
          {
            $payment_term = '12';
          }
        }
      }
    }

    if ($which == 0)
    {
      return '1|' . mktime (date ('h'), date ('i'), date ('s'), date ('m') + $payment_term, date ('d'), date ('Y')) . '|';
    }

    if ($which == 1)
    {
      $query = 'select ';
      $query .= 'next_due_date, ';
      $query .= 'ogcreate, ';
      $query .= 'domain_name ';
      $query .= 'from ';
      $query .= 'hosting_order ';
      $query .= 'where ';
      $query .= 'oid=\'' . addslashes (trim ($oid)) . '\'';
      $rs = mysql_fetch_row (mysql_query ($query));
      $next_due_date = stripslashes (trim ($rs[0]));
      $og = stripslashes (trim ($rs[1]));
      $domain_name = stripslashes (trim ($rs[2]));
      if (!((!($next_due_date == '') AND !($next_due_date == '---'))))
      {
        $i = 0;
        $x = 0;
        while ($i == 0)
        {
          if ($x == 24)
          {
            return '0|' . $domain_name . '|';
          }

          if ($x == 0)
          {
            $next_due_date = create_next_due ($og, $payment_term);
            if (time () < $next_due_date)
            {
              return '1|' . $next_due_date . '|';
            }

            $x = 1;
            continue;
          }
          else
          {
            $next_due_date = create_next_due ($next_due_date, $payment_term);
            if (time () < $next_due_date)
            {
              return '1|' . $next_due_date . '|';
            }

            $x += 1;
            continue;
          }
        }
      }
      else
      {
        $hour = date ('h', $next_due_date);
        $min = date ('i', $next_due_date);
        $sec = date ('s', $next_due_date);
        $month = date ('m', $next_due_date);
        $day = date ('d', $next_due_date);
        $year = date ('Y', $next_due_date);
        return '1|' . mktime ($hour, $min, $sec, $month + $payment_term, $day, $year) . '|';
      }
    }

  }

  function unique_ip_ordered ($addon_choices)
  {
    $count = substr_count ($addon_choices, '|');
    $explode = explode ('|', $addon_choices);
    for ($i = 0; $i <= $count; ++$i)
    {
      $rs1 = mysql_fetch_row (mysql_query ('select unique_ip from addon_specs where aid=\'' . addslashes (trim ($explode[$i])) . '\''));
      $unique_ip = stripslashes (trim ($rs1[0]));
      if ($unique_ip == 1)
      {
        return 1;
      }

      if ($unique_ip == 0)
      {
        return 0;
      }
    }

  }

  function display_addons_ordered_email ($addon_choices)
  {
    $count = substr_count ($addon_choices, '|');
    $explode = explode ('|', $addon_choices);
    for ($i = 0; $i <= $count; ++$i)
    {
      $rs1 = mysql_fetch_row (mysql_query ('select addon_name, extra_webspace, unique_ip from addon_specs where aid=\'' . addslashes (trim ($explode[$i])) . '\''));
      $unique_ip = stripslashes (trim ($rs1[2]));
      if ($unique_ip == 1)
      {
        $bit = true;
        continue;
      }
      else
      {
        if ($rs1[1] != 0)
        {
          $extra_webspace += stripslashes (trim ($rs1[1]));
          continue;
        }
        else
        {
          if (trim ($rs1[0]) != '')
          {
            $addons .= @stripslashes (@trim ($rs1[0])) . '
';
            continue;
          }

          continue;
        }

        continue;
      }
    }

    if (isset ($bit))
    {
      $addons .= 'Unique IP
';
    }

    if ($rs1[1] != 0)
    {
      $addons .= $extra_webspace . 'MB of extra webspace
';
    }

    return $addons;
  }

  function extra_webspace_ordered ($addon_choices)
  {
    $count = substr_count ($addon_choices, '|');
    $explode = explode ('|', $addon_choices);
    for ($i = 0; $i <= $count; ++$i)
    {
      $rs1 = mysql_fetch_row (mysql_query ('select extra_webspace from addon_specs where aid=\'' . addslashes (trim ($explode[$i])) . '\''));
      $extra_webspace += stripslashes (trim ($rs1[0]));
    }

    if ($extra_webspace == 0)
    {
      return 0;
    }

    if ($extra_webspace != 0)
    {
      return $extra_webspace;
    }

  }

  function grab_mib_news ($below_public, $sid, $http_admin)
  {
    $news = file ($below_public . '/mib_news_cache.nfo');
    foreach ($news as $line_num => $line)
    {
      if ($line_num == 0)
      {
        $mib_news = $line . '<br>';
        continue;
      }
      else
      {
        $mib_news .= $line . '<br>';
        continue;
      }
    }

    $mib_news = @trim ($mib_news);
    list ($keep, $not) = @split ('{{stop_here}}', $mib_news);
    $keep .= '<br>Quick Links:';
    $keep .= '<br>---> <a href=\'http://www.whmautopilot.com/bugs\' target=\'_blank\'>Report A Bug</a>';
    $keep .= '<br>---> <a href=\'http://www.whmautopilot.com/support\' target=\'_blank\'>Contact AP Support</a>';
    $keep .= '<br>---> <a href=\'http://www.whmautopilot.com/forum\' target=\'_blank\'>Visit AP support forums</a>';
    $keep .= '<br>---> <a href=\'' . $http_admin . '/mib_all_news.php?sid=' . trim ($sid) . '\'>Read All Script News & Updates</a>';
    return $keep;
  }

  function current_server_root ($current_server)
  {
    $rs = mysql_fetch_row (mysql_query ('select reseller from server_config where whm_id=\'' . addslashes (trim ($current_server)) . '\''));
    return $rs[0];
  }

  function list_reseller_plans ($server_ip, $whm_username, $whm_password)
  {
    $filename = 'http://' . $whm_username . ':' . $whm_password . '@' . $server_ip . ':2086/scripts2/wwwacctform';
    $lines = file ($filename);
    foreach ($lines as $line_num => $line)
    {
      if ($x == 1)
      {
        $x = 2;
      }

      if (ereg ('<tr background="/themes/blue/bg.gif"  class=cellheader><td>Account Type</td><td>Current</td><td>Max Allowed</td><td>Remaining</td></tr>', $line) == true)
      {
        $x = 1;
      }

      if ($x == 2)
      {
        $buffer = strpos ($line, '</td>');
        $current = substr ($line, 0, $buffer);
        if (strlen (trim ($current)) != 0)
        {
          $output .= str_replace ('<tr><td>', '', $current) . '|';
          continue;
        }

        continue;
      }
    }

    return $output;
  }

  function create_clean_domain_name ($domain_name)
  {
    global $tmp;
    global $domain_registration;
    $domain_name = strtolower ($domain_name);
    $domain_name = str_replace ('http://', '', $domain_name);
    $domain_name = str_replace ('www.', '', $domain_name);
    $domain_name = str_replace (' ', '', $domain_name);
    $domain_name = str_replace ('/', '', $domain_name);
    $domain_name = str_replace ('\'', '', $domain_name);
    if ($domain_registration == 1)
    {
      $temp = $domain_name . '.' . $tmp;
    }
    else
    {
      $temp = $domain_name;
    }

    if (ereg ('^[a-zA-Z0-9\\.-]+\\.[a-zA-Z]{2,4}$', $temp) == false)
    {
      return -4;
    }

    if (0 < substr_count ($domain_name, '.'))
    {
      $ext = strstr ($domain_name, '.');
      $domain = substr ($domain_name, 0, strlen ($domain_name) - strlen ($ext));
      if (ereg ('-', substr ($domain_name, 0, 1)) == true)
      {
        return -1;
      }

      if (ereg ('-', substr ($domain_name, -1)) == true)
      {
        return -2;
      }

      if (ereg ('_', $domain_name) == true)
      {
        return -3;
      }

      return $domain . '|' . $ext . '|';
    }

    if (ereg ('-', substr ($domain_name, 0, 1)) == true)
    {
      return -1;
    }

    if (ereg ('-', substr ($domain_name, -1)) == true)
    {
      return -2;
    }

    if (ereg ('_', $domain_name) == true)
    {
      return -3;
    }

    return $domain_name . '||';
  }

  function create_whm_username ($domain)
  {
    $domain = substr (preg_replace ('/[^A-Za-z0-9]/', chr (rand (97, 122)), $domain), 0, 7);
    if (ereg ('[0-9]', substr ($domain, 0, 1)) == true)
    {
      return str_replace (substr ($domain, 0, 1), 'x', $domain);
    }

    return $domain;
  }

  function e ($key, $data)
  {
    $data = trim ($data);
    $data .= 'abcd';
    $iv = substr (md5 ($key), 0, mcrypt_get_iv_size (MCRYPT_CAST_256, MCRYPT_MODE_CFB));
    $enc_data = mcrypt_encrypt (MCRYPT_CAST_256, $key, $data, 'cfb', $iv);
    return trim (chop (base64_encode ($enc_data)));
  }

  function d ($key, $enc_data)
  {
    $enc_data = trim (chop (base64_decode ($enc_data)));
    $iv = substr (md5 ($key), 0, mcrypt_get_iv_size (MCRYPT_CAST_256, MCRYPT_MODE_CFB));
    $dec_data = mcrypt_decrypt (MCRYPT_CAST_256, $key, $enc_data, 'cfb', $iv);
    if (strcmp (substr ($dec_data, -4), 'abcd') == 0)
    {
      $dec_data = substr ($dec_data, 0, strlen ($dec_data) - 4);
    }
    else
    {
      if (strcmp (substr ($dec_data, -3), 'abc') == 0)
      {
        $dec_data = substr ($dec_data, 0, strlen ($dec_data) - 3);
      }
    }

    return trim (chop ($dec_data));
  }

  function define_servers ($whm_id, $whm_username, $whm_password, $below_public)
  {
    $rs = mysql_fetch_row (mysql_query ('select active_server from server_config where whm_id=\'' . addslashes (trim ($whm_id)) . '\''));
    if ($rs[0] == 1)
    {
      $server_role = 1;
    }
    else
    {
      $server_role = 0;
    }

    $data = $whm_id . '|' . $server_role . '|' . $whm_username . '|' . preg_replace ('\'(
|
)\'', '', $whm_password);
    $data = e ('AutoPilotV2_rulez', $data);
    $read = fopen ($below_public . '/' . trim ($whm_id) . '.log', 'w');
    $result = fwrite ($read, $data);
    fclose ($read);
    chmod ($below_public . '/' . trim ($whm_id) . '.log', 511);
  }

  function read_log ($whm_id, $below_public)
  {
    $read = @fopen ($below_public . '/' . @trim ($whm_id) . '.log', 'r');
    $result = @fread ($read, @filesize ($below_public . '/' . @trim ($whm_id) . '.log'));
    @fclose ($read);
    $data = d ('AutoPilotV2_rulez', $result);
    $read = fopen ($below_public . '/' . trim ($whm_id) . '_tmp.log', 'w');
    $result = fwrite ($read, $data);
    fclose ($read);
    $read_old_log = file ($below_public . '/' . trim ($whm_id) . '_tmp.log');
    foreach ($read_old_log as $line_num => $line)
    {
      list ($xwhm_id, $server_role, $whm_username, $whm_password) = split ('[|]', trim ($line));
      if ($xwhm_id == $whm_id)
      {
        unlink ($below_public . '/' . trim ($whm_id) . '_tmp.log');
        return $whm_username . '|' . chunk_split ($whm_password, 32, '
');
      }
    }

  }

  function delete_server ($whm_id, $below_public)
  {
    unlink ($below_public . '/' . $whm_id . '.log');
  }

  function current_ns ()
  {
    $ct = mysql_fetch_row (mysql_query ('select count(*) from server_config where active_server=\'1\''));
    if ($ct[0] <= 0)
    {
      $ct0 == mysql_fetch_row (mysql_query ('select count(*) from server_config where manual_install_active=\'1\''));
      if ($ct0[0] <= 0)
      {
        return 99;
      }

      $rs = mysql_fetch_row (mysql_query ('select primary_ns, primary_ns_ip, secondary_ns, secondary_ns_ip from server_config where manual_install_active=\'1\''));
      return $rs[0] . '|' . $rs[1] . '|' . $rs[2] . '|' . $rs[3];
    }

    $rs = mysql_fetch_row (mysql_query ('select primary_ns, primary_ns_ip, secondary_ns, secondary_ns_ip from server_config where active_server=\'1\''));
    return $rs[0] . '|' . $rs[1] . '|' . $rs[2] . '|' . $rs[3];
  }

  function current_server ($identifier, $which)
  {
    if ($which == 0)
    {
      $r = mysql_fetch_row (mysql_query ('select whm_id from plan_specs where pid=\'' . addslashes (trim ($identifier)) . '\''));
    }
    else
    {
      if ($which == 1)
      {
        $r = mysql_fetch_row (mysql_query ('select plan_specs.whm_id from session_history, plan_specs where session_history.sid=\'' . addslashes (trim ($identifier)) . '\' and session_history.pid=plan_specs.pid'));
      }
    }

    if ($r[0] == -1)
    {
      return 99;
    }

    if ($r[0] == 0)
    {
      return current_server_internal ();
    }

    return $r[0];
  }

  function current_server_internal ()
  {
    $ct = mysql_fetch_row (mysql_query ('select count(*) from server_config where active_server=\'1\''));
    if ($ct[0] <= 0)
    {
      return 99;
    }

    $rs = mysql_fetch_row (mysql_query ('select whm_id from server_config where active_server=\'1\''));
    return $rs[0];
  }

  function auto_switch_server ($below_public, $email_admin)
  {
    $ct = mysql_fetch_row (mysql_query ('select count(*) from server_config where install_order=\'1\''));
    if ($ct[0] <= 0)
    {
      return 0;
    }

    if ($ct[0] == 1)
    {
      $current_server = current_server_internal ();
      if ($current_server == 0)
      {
        return 0;
      }

      $rs = mysql_fetch_row (mysql_query ('select server_ip, max_accounts from server_config where whm_id=\'' . addslashes (trim ($current_server)) . '\''));
      $server_ip = $rs[0];
      $max_accounts = $rs[1];
      $temp = @read_log ($current_server, $below_public);
      list ($whm_username, $whm_password) = split ('[|]', $temp);
      $total_accounts_on_server = list_accounts ($server_ip, $whm_username, $whm_password, 1);
      if ($max_accounts <= $total_accounts_on_server)
      {
        $rs0 = mysql_fetch_row (mysql_query ('select whm_id, ogcreate, active_server, manual_install_active, server_name from server_config where whm_id=\'' . addslashes (trim ($current_server)) . '\''));
        $rs1 = mysql_fetch_row (mysql_query ('select whm_id, server_name from server_config where install_order=\'1\''));
        $rowx = mysql_query ('select whm_id, install_order from server_config');
        while ($rx = mysql_fetch_row ($rowx))
        {
          if ($rx[1] != 2)
          {
            mysql_query ('update server_config set active_server=\'0\', manual_install_active=\'0\', install_server=\'0\' where whm_id=\'' . addslashes (trim ($rx[0])) . '\'');
            continue;
          }
        }

        mysql_query ('update server_config set active_server=\'' . addslashes (trim ($rs0[2])) . '\', manual_install_active=\'' . addslashes (trim ($rs0[3])) . '\', ogcreate=\'' . addslashes (trim ($rs0[1])) . '\', install_order=\'0\' where whm_id=\'' . addslashes (trim ($rs1[0])) . '\'');
        mysql_query ('update server_config set active_server=\'0\', manual_install_active=\'0\', ogcreate=\'' . $rs0[1] . '\', install_order=\'2\' where whm_id=\'' . addslashes (trim ($current_server)) . '\'');
        if ($rs0[2] == 1)
        {
          $server_role = 'Active Install';
        }
        else
        {
          if ($rs0[3] == 1)
          {
            $server_role = 'Manual Install';
          }
        }

        mysql_query ('update plan_specs set whm_id=\'' . addslashes (trim ($rs1[0])) . '\' where whm_id=\'' . addslashes (trim ($rs0[0])) . '\'');
        send_successful_server_switch ($email_admin, $max_accounts, $rs0[4], $rs1[1], $server_role);
      }

      return $rs1[0];
    }

    $current_server = current_server_internal ();
    if ($current_server == 0)
    {
      return 0;
    }

    $rs = mysql_fetch_row (mysql_query ('select server_ip, max_accounts, server_name from server_config where whm_id=\'' . addslashes (trim ($current_server)) . '\''));
    $server_ip = $rs[0];
    $max_accounts = $rs[1];
    $server_name = $rs[2];
    $temp = @read_log ($current_server, $below_public);
    $total_accounts_on_server = list_accounts ($server_ip, $whm_username, $whm_password, 1);
    if ($max_accounts <= $total_accounts_on_server)
    {
      send_max_accounts_reached ($email_admin, $max_accounts, $server_name);
    }

    return 0;
  }

  function domain_expire_30_days ($oid, $email_admin)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'20\''));
    $default_email = stripslashes (trim ($rs[2]));
    $rs1 = mysql_fetch_row (mysql_query ('select hosting_order.domain_name, hosting_order.domain_expire, user.email, user.first_name, user.last_name from hosting_order, user where hosting_order.oid=\'' . addslashes (trim ($oid)) . '\' and hosting_order.uid=user.uid order by hosting_order.oid asc limit 0, 1'));
    $domain_name = 'http://' . $rs1[0];
    $expire_date = $rs1[1];
    $generate_date = date ('m/d/Y h:i:s a');
    $client_email = $rs1[2];
    $user = $rs1[3] . ' ' . $rs1[4];
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{domain_name}}', $domain_name, $subject);
    $subject = str_replace ('{{expire_date}}', $expire_date, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{domain_name}}', $domain_name, $message);
    $message = str_replace ('{{expire_date}}', $expire_date, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    global $site_name;
    $admin_name = $site_name;
    exec_email ($client_email, $user, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function domain_expire_5_days ($oid, $email_admin)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'21\''));
    $default_email = stripslashes (trim ($rs[2]));
    $rs1 = mysql_fetch_row (mysql_query ('select hosting_order.domain_name, hosting_order.domain_expire, user.email, user.first_name, user.last_name from hosting_order, user where hosting_order.oid=\'' . addslashes (trim ($oid)) . '\' and hosting_order.uid=user.uid order by hosting_order.oid asc limit 0, 1'));
    $domain_name = 'http://' . $rs1[0];
    $expire_date = $rs1[1];
    $generate_date = date ('m/d/Y h:i:s a');
    $client_email = $rs1[2];
    $user = $rs1[3] . ' ' . $rs1[4];
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{domain_name}}', $domain_name, $subject);
    $subject = str_replace ('{{expire_date}}', $expire_date, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{domain_name}}', $domain_name, $message);
    $message = str_replace ('{{expire_date}}', $expire_date, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    exec_email ($client_email, $user, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function domain_expired ($oid, $email_admin)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'22\''));
    $default_email = stripslashes (trim ($rs[2]));
    $rs1 = mysql_fetch_row (mysql_query ('select hosting_order.domain_name, hosting_order.domain_expire, user.email, user.first_name, user.last_name from hosting_order, user where hosting_order.oid=\'' . addslashes (trim ($oid)) . '\' and hosting_order.uid=user.uid order by hosting_order.oid asc limit 0, 1'));
    $domain_name = 'http://' . $rs1[0];
    $expire_date = $rs1[1];
    $generate_date = date ('m/d/Y h:i:s a');
    $client_email = $rs1[2];
    $user = $rs1[3] . ' ' . $rs1[4];
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{domain_name}}', $domain_name, $subject);
    $subject = str_replace ('{{expire_date}}', $expire_date, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{domain_name}}', $domain_name, $message);
    $message = str_replace ('{{expire_date}}', $expire_date, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    exec_email ($client_email, $user, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function domain_expire_date_error ($oid, $email_admin)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'23\''));
    $default_email = stripslashes (trim ($rs[2]));
    $rs1 = mysql_fetch_row (mysql_query ('select hosting_order.domain_name, hosting_order.domain_expire, user.email from hosting_order, user where hosting_order.oid=\'' . addslashes (trim ($oid)) . '\' and hosting_order.uid=user.uid order by hosting_order.oid asc limit 0, 1'));
    $domain_name = 'http://' . $rs1[0];
    $expire_date = $rs1[1];
    $generate_date = date ('m/d/Y h:i:s a');
    $client_email = $rs1[2];
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{domain_name}}', $domain_name, $subject);
    $subject = str_replace ('{{expire_date}}', $expire_date, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{domain_name}}', $domain_name, $message);
    $message = str_replace ('{{expire_date}}', $expire_date, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    global $email_admin;
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    exec_email ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function resolve_config_settings ()
  {
    $query = 'select ';
    $query .= 'resolve_works ';
    $query .= 'from ';
    $query .= 'config ';
    $query .= 'limit 0, 1';
    $rs = mysql_fetch_row (mysql_query ($query));
    $resolve_works = stripslashes (trim ($rs[0]));
    return $resolve_works;
  }

  function resolve_monitor ()
  {
    $query = 'select ';
    $query .= 'cont_resolve ';
    $query .= 'from ';
    $query .= 'config ';
    $query .= 'limit 0, 1';
    $rs = mysql_fetch_row (mysql_query ($query));
    $cont_resolve = stripslashes (trim ($rs[0]));
    return $cont_resolve;
  }

  function resolve_server ()
  {
    $query = 'select ';
    $query .= 'resolve_server ';
    $query .= 'from ';
    $query .= 'config ';
    $query .= 'limit 0, 1';
    $rs = mysql_fetch_row (mysql_query ($query));
    $resolve_server = stripslashes (trim ($rs[0]));
    return $resolve_server;
  }

  function domain_expire_check ()
  {
    $query = 'select ';
    $query .= 'run_domain_expire ';
    $query .= 'from ';
    $query .= 'config ';
    $query .= 'limit 0, 1';
    $rs = mysql_fetch_row (mysql_query ($query));
    $run_domain_expire = stripslashes (trim ($rs[0]));
    return $run_domain_expire;
  }

  function resolver_nslookup2ip ($domain_name, $resolve_server)
  {
    global $resolver_log;
    @exec ('nslookup -type=A ' . $domain_name . ' ' . $resolve_server, $output);
    $buffer = '';
    foreach ($output as $line)
    {
      $buffer .= $line;
    }

    unset ($output);
    $returned_ = $buffer;
    write_resolver_log ($domain_name, $resolver_log, $buffer);
    $buffer = substr ($buffer, -21);
    $buffer = trim ($buffer);
    list ($junk, $ip) = split ('[ ]', $buffer);
    if (preg_match ('/[A-za-z]/', $ip))
    {
      return '0|' . $returned_;
    }

    return $ip;
  }

  function resolver_gethostbyname2ip ($domain_name)
  {
    $results = gethostbyname ($domain_name);
    if ($domain_name == $results)
    {
      return 0;
    }

    return $results;
  }

  function write_resolver_log ($domain_name, $resolver_log, $buffer)
  {
    $data = '[';
    $data .= date ('m/d/Y h:i:s a');
    $data .= '][';
    $data .= $domain_name;
    $data .= '][';
    $data .= str_replace ('	', '', $buffer);
    $data .= ']
';
    $filename = date ('m-d-y') . '.txt';
    $read = @fopen ($resolver_log . '/' . $filename, 'a+');
    @fwrite ($read, $data);
    @fclose ($read);
    @chmod ($resolver_log . '/' . $filename, 511);
  }

  function mark_as_resolved ($oid)
  {
    $query = 'update ';
    $query .= 'hosting_order ';
    $query .= 'set ';
    $query .= 'resolved=\'1\', ';
    $query .= 'resolved_time=\'' . time () . '\', ';
    $query .= 'ur_date=\'\', ';
    $query .= 'ur_lock=\'0\' ';
    $query .= 'where ';
    $query .= 'oid=\'' . addslashes (trim ($oid)) . '\'';
    mysql_query ($query);
  }

  function set_unresolved_lock ($oid)
  {
    $query = 'update ';
    $query .= 'hosting_order ';
    $query .= 'set ';
    $query .= 'ur_lock=\'1\', ';
    $query .= 'ur_date=\'' . time () . '\' ';
    $query .= 'where ';
    $query .= 'oid=\'' . addslashes (trim ($oid)) . '\'';
    mysql_query ($query);
  }

  function get_expired_lock ($oid)
  {
    $query = 'select  ';
    $query .= 'domain_lock ';
    $query .= 'from ';
    $query .= 'hosting_order ';
    $query .= 'where ';
    $query .= 'oid=\'' . addslashes (trim ($oid)) . '\'';
    $rs = mysql_fetch_row (mysql_query ($query));
    return $rs[0];
  }

  function set_domain_lock ($oid, $int)
  {
    $query = 'update ';
    $query .= 'hosting_order ';
    $query .= 'set ';
    $query .= 'domain_lock=\'' . addslashes (trim ($int)) . '\' ';
    $query .= 'where ';
    $query .= 'oid=\'' . addslashes (trim ($oid)) . '\'';
    mysql_query ($query);
  }

  function update_domain_due_date ($oid, $domain_expire)
  {
    $m = date ('m', $domain_expire);
    $d = date ('d', $domain_expire);
    $y = date ('y', $domain_expire);
    $new_expire = mktime (0, 0, 0, $m, $d, $y + 1);
    $new_expire = date ('m/d/Y', $new_expire);
    $query = 'update ';
    $query .= 'hosting_order ';
    $query .= 'set ';
    $query .= 'domain_expire=\'' . $new_expire . '\' ';
    $query .= 'where ';
    $query .= 'oid=\'' . addslashes (trim ($oid)) . '\'';
    mysql_query ($query);
  }

  function resolver ($email_admin)
  {
    $resolve_config_settings = resolve_config_settings ();
    $resolve_server = resolve_server ();
    $resolve_monitor = resolve_monitor ();
    $reports_resolved = '';
    $reports_monitor = '';
    $reports_unresolved = '';
    $report = '';
    $domain_expire_30 = '';
    $domain_expire_5 = '';
    $domain_expired = '';
    $query0 = 'select ';
    $query0 .= 'hosting_order.domain_name, ';
    $query0 .= 'user.first_name, ';
    $query0 .= 'user.last_name, ';
    $query0 .= 'user.email, ';
    $query0 .= 'hosting_order.domain_expire, ';
    $query0 .= 'hosting_order.resolved, ';
    $query0 .= 'hosting_order.ip, ';
    $query0 .= 'hosting_order.ur_lock, ';
    $query0 .= 'hosting_order.ur_date, ';
    $query0 .= 'hosting_order.oid, ';
    $query0 .= 'hosting_order.pid, ';
    $query0 .= 'hosting_order.ogcreate ';
    $query0 .= 'from ';
    $query0 .= 'hosting_order, user ';
    $query0 .= 'where ';
    $query0 .= 'hosting_order.status=\'1\'';
    $query0 .= 'and ';
    $query0 .= 'hosting_order.uid=user.uid ';
    $query0 .= 'order by hosting_order.domain_name asc';
    $row0 = mysql_query ($query0);
    while ($rs0 = mysql_fetch_row ($row0))
    {
      $domain_name = stripslashes (trim ($rs0[0]));
      $first_name = stripslashes (trim ($rs0[1]));
      $last_name = stripslashes (trim ($rs0[2]));
      $email = stripslashes (trim ($rs0[3]));
      $domain_expire = stripslashes (trim ($rs0[4]));
      list ($m, $d, $y) = split ('/', $domain_expire);
      $domain_expire = mktime (0, 0, 0, $m, $d, $y);
      $resolved = stripslashes (trim ($rs0[5]));
      $account_ip = stripslashes (trim ($rs0[6]));
      $ur_lock = stripslashes (trim ($rs0[7]));
      $ur_date = stripslashes (trim ($rs0[8]));
      $oid = stripslashes (trim ($rs0[9]));
      $domain_lock = get_expired_lock ($oid);
      $pid = stripslashes (trim ($rs0[10]));
      $query3 = 'select ';
      $query3 .= 'dedicated ';
      $query3 .= 'from ';
      $query3 .= 'plan_specs ';
      $query3 .= 'where ';
      $query3 .= 'pid=\'' . addslashes (trim ($pid)) . '\'';
      $rs3 = mysql_fetch_row (mysql_query ($query3));
      if ($rs3[0] == 0)
      {
        if ($resolve_config_settings == 0)
        {
          if ($resolved == 0)
          {
            mark_as_resolved ($oid);
            $resolved_inital = true;
          }
        }
        else
        {
          if ($resolved == 0)
          {
            if ($resolve_config_settings == 1)
            {
              $xlookup_ip = resolver_nslookup2ip ($domain_name, $resolve_server);
              list ($lookup_ip, $nslookup_results) = explode ('|', $xlookup_ip);
            }
            else
            {
              $lookup_ip = resolver_gethostbyname2ip ($domain_name);
            }

            if ($lookup_ip == 0)
            {
              $unresolved = true;
            }
            else
            {
              if ($account_ip == $lookup_ip)
              {
                mark_as_resolved ($oid);
                $logically_resolved = true;
              }
              else
              {
                $unresolved = true;
              }
            }
          }
          else
          {
            if ($resolve_monitor == 1)
            {
              if ($resolve_config_settings == 1)
              {
                $xlookup_ip = resolver_nslookup2ip ($domain_name, $resolve_server);
                list ($lookup_ip, $nslookup_results) = explode ('|', $xlookup_ip);
              }
              else
              {
                $lookup_ip = resolver_gethostbyname2ip ($domain_name);
              }

              if ($lookup_ip == 0)
              {
                $unresolved_monitor = true;
              }
              else
              {
                if ($account_ip == $lookup_ip)
                {
                  mark_as_resolved ($oid);
                }
                else
                {
                  $unresolved_monitor = true;
                }
              }
            }
          }
        }

        $seed = $domain_name . ' - Owner: ' . $first_name . ' ' . $last_name . ', ' . $email . ' - Installed on: ' . date ('m/d/Y', $rs0[11]) . '
';
        if (isset ($nslookup_results))
        {
          if (trim ($nslookup_results) != '')
          {
            $seed .= '[Lookup Results ] [' . $nslookup_results . ']

';
          }
          else
          {
            $seed .= '[No Lookup Results]

';
          }
        }
        else
        {
          $seed .= '
';
        }

        if (isset ($resolved_inital))
        {
          send_successfully_resolved_email ($oid, $email_admin);
          unset ($resolved_inital);
          $reports_resolved .= $seed . '|';
          $reports_resolved_ct += 1;
        }
        else
        {
          if (isset ($logically_resolved))
          {
            send_successfully_resolved_email ($oid, $email_admin);
            unset ($logically_resolved);
            $reports_resolved .= $seed . '|';
            $reports_resolved_ct += 1;
          }
          else
          {
            if (isset ($unresolved_monitor))
            {
              if ($ur_lock == 0)
              {
                set_unresolved_lock ($oid);
                $send_ = true;
              }

              if (isset ($send_))
              {
                send_admin_notice_domain_stopped_responding ($oid, $email_admin);
                unset ($send_);
              }

              unset ($unresolved_monitor);
              $reports_monitor .= $seed . '|';
              $reports_monitor_ct += 1;
            }
            else
            {
              if (isset ($unresolved))
              {
                if ($ur_lock == 0)
                {
                  set_unresolved_lock ($oid);
                  $send_ = true;
                }
                else
                {
                  if ($ur_date + 172800 < time ())
                  {
                    $send_ = true;
                  }
                }

                if (isset ($send_))
                {
                  send_unresolved_email ($oid, $email_admin);
                  unset ($send_);
                }

                unset ($unresolved);
                $reports_unresolved .= $seed . '|';
                $reports_unresolved_ct += 1;
              }
            }
          }
        }

        if (domain_expire_check () == 'yes')
        {
          if (checkdate (date ('m', $domain_expire), date ('d', $domain_expire), date ('Y', $domain_expire)) == true)
          {
            if ($domain_expire <= time ())
            {
              if ($domain_lock == 5)
              {
                domain_expired ($oid, $email_admin);
                set_domain_lock ($oid, 0);
                update_domain_due_date ($oid, $domain_expire);
                $domain_expired = $seed . '|';
                $domain_expired_ct += 1;
              }
            }

            if ($domain_expire - 432000 < time ())
            {
              if (time () < $domain_expire)
              {
                if ($domain_lock == 30)
                {
                  domain_expire_5_days ($oid, $email_admin);
                  set_domain_lock ($oid, 5);
                  $domain_expire_5 = $seed . '|';
                  $domain_expire_5_ct += 1;
                }
              }
            }

            if ($domain_expire - 2592000 < time ())
            {
              if (time () < $domain_expire)
              {
                if ($domain_lock == 0)
                {
                  domain_expire_30_days ($oid, $email_admin);
                  set_domain_lock ($oid, 30);
                  $domain_expire_30 = $seed . '|';
                  $domain_expire_30_ct += 1;
                }
              }
            }
          }
          else
          {
            domain_expire_date_error ($oid, $email_admin);
          }
        }

        unset ($seed);
        if (isset ($skip))
        {
          unset ($skip);
          continue;
        }

        continue;
      }
    }

    if (trim ($reports_resolved) == '')
    {
      $report .= 'None for this run.|0{';
    }
    else
    {
      $report .= $reports_resolved;
      $report .= $reports_resolved_ct . '{';
    }

    if (trim ($reports_unresolved) == '')
    {
      $report .= 'None for this run.|0{';
    }
    else
    {
      $report .= $reports_unresolved;
      $report .= $reports_unresolved_ct . '{';
    }

    if (trim ($reports_monitor) == '')
    {
      $report .= 'None for this run.|0{';
    }
    else
    {
      $report .= $reports_monitor;
      $report .= $reports_monitor_ct . '{';
    }

    if (trim ($domain_expire_30) == '')
    {
      $report .= 'None for this run.|0{';
    }
    else
    {
      $report .= $domain_expire_30;
      $report .= $domain_expire_30_ct . '{';
    }

    if (trim ($domain_expire_5) == '')
    {
      $report .= 'None for this run.|0{';
    }
    else
    {
      $report .= $domain_expire_5;
      $report .= $domain_expire_5_ct . '{';
    }

    if (trim ($domain_expired) == '')
    {
      $report .= 'None for this run.|0{';
      return $report;
    }

    $report .= $domain_expired;
    $report .= $domain_expired_ct . '{';
    return $report;
  }

  function resolver_individual ($email_admin, $individual)
  {
    $resolve_config_settings = resolve_config_settings ();
    $resolve_server = resolve_server ();
    $resolve_monitor = resolve_monitor ();
    $reports_resolved = '';
    $reports_monitor = '';
    $reports_unresolved = '';
    $report = '';
    $domain_expire_30 = '';
    $domain_expire_5 = '';
    $domain_expired = '';
    $query0 = 'select ';
    $query0 .= 'hosting_order.domain_name, ';
    $query0 .= 'user.first_name, ';
    $query0 .= 'user.last_name, ';
    $query0 .= 'user.email, ';
    $query0 .= 'hosting_order.domain_expire, ';
    $query0 .= 'hosting_order.resolved, ';
    $query0 .= 'hosting_order.ip, ';
    $query0 .= 'hosting_order.ur_lock, ';
    $query0 .= 'hosting_order.ur_date, ';
    $query0 .= 'hosting_order.oid ';
    $query0 .= 'from ';
    $query0 .= 'hosting_order, user ';
    $query0 .= 'where ';
    $query0 .= 'hosting_order.oid=\'' . addslashes (trim ($individual)) . '\'';
    $query0 .= 'and ';
    $query0 .= 'hosting_order.uid=user.uid ';
    $query0 .= 'order by hosting_order.domain_name asc';
    $rs0 = mysql_fetch_row (mysql_query ($query0));
    $domain_name = stripslashes (trim ($rs0[0]));
    $first_name = stripslashes (trim ($rs0[1]));
    $last_name = stripslashes (trim ($rs0[2]));
    $email = stripslashes (trim ($rs0[3]));
    $domain_expire = stripslashes (trim ($rs0[4]));
    list ($m, $d, $y) = split ('/', $domain_expire);
    $domain_expire = mktime (0, 0, 0, $m, $d, $y);
    $resolved = stripslashes (trim ($rs0[5]));
    $account_ip = stripslashes (trim ($rs0[6]));
    $ur_lock = stripslashes (trim ($rs0[7]));
    $ur_date = stripslashes (trim ($rs0[8]));
    $oid = stripslashes (trim ($rs0[9]));
    $domain_lock = get_expired_lock ($oid);
    if ($resolve_config_settings == 0)
    {
      if ($resolved == 0)
      {
        mark_as_resolved ($oid);
        $resolved_inital = true;
      }
    }
    else
    {
      if ($resolved == 0)
      {
        if ($resolve_config_settings == 1)
        {
          $lookup_ip = resolver_nslookup2ip ($domain_name, $resolve_server);
        }
        else
        {
          $lookup_ip = resolver_gethostbyname2ip ($domain_name);
        }

        if ($lookup_ip == 0)
        {
          $unresolved = true;
        }
        else
        {
          if ($account_ip == $lookup_ip)
          {
            mark_as_resolved ($oid);
            $logically_resolved = true;
          }
          else
          {
            $unresolved = true;
          }
        }
      }
      else
      {
        if ($resolve_monitor == 1)
        {
          if ($resolve_config_settings == 1)
          {
            $lookup_ip = resolver_nslookup2ip ($domain_name, $resolve_server);
          }
          else
          {
            $lookup_ip = resolver_gethostbyname2ip ($domain_name);
          }

          if ($lookup_ip == 0)
          {
            $unresolved_monitor = true;
          }
          else
          {
            if ($account_ip == $lookup_ip)
            {
              mark_as_resolved ($oid);
            }
            else
            {
              $unresolved_monitor = true;
            }
          }
        }
      }
    }

    $seed = $domain_name . ' - Owner: ' . $first_name . ' ' . $last_name . ', ' . $email . ' - Expires on: ' . date ('m/d/Y', $domain_expire) . '
';
    if (isset ($resolved_inital))
    {
      send_successfully_resolved_email ($oid, $email_admin);
      unset ($resolved_inital);
      $reports_resolved .= $seed . '|';
      $reports_resolved_ct += 1;
    }
    else
    {
      if (isset ($logically_resolved))
      {
        send_successfully_resolved_email ($oid, $email_admin);
        unset ($logically_resolved);
        $reports_resolved .= $seed . '|';
        $reports_resolved_ct += 1;
      }
      else
      {
        if (isset ($unresolved_monitor))
        {
          if ($ur_lock == 0)
          {
            set_unresolved_lock ($oid);
            $send_ = true;
          }

          if (isset ($send_))
          {
            send_admin_notice_domain_stopped_responding ($oid, $email_admin);
            unset ($send_);
          }

          unset ($unresolved_monitor);
          $reports_monitor .= $seed . '|';
          $reports_monitor_ct += 1;
        }
        else
        {
          if (isset ($unresolved))
          {
            if ($ur_lock == 0)
            {
              set_unresolved_lock ($oid);
              $send_ = true;
            }
            else
            {
              if ($ur_date + 172800 < time ())
              {
                $send_ = true;
              }
            }

            if (isset ($send_))
            {
              send_unresolved_email ($oid, $email_admin);
              unset ($send_);
            }

            unset ($unresolved);
            $reports_unresolved .= $seed . '|';
            $reports_unresolved_ct += 1;
          }
        }
      }
    }

    if (domain_expire_check () == 'yes')
    {
      if (checkdate (date ('m', $domain_expire), date ('d', $domain_expire), date ('Y', $domain_expire)) == true)
      {
        if ($domain_expire <= time ())
        {
          if ($domain_lock == 5)
          {
            domain_expired ($oid, $email_admin);
            set_domain_lock ($oid, 0);
            update_domain_due_date ($oid, $domain_expire);
            $domain_expired = $seed . '|';
            $domain_expired_ct += 1;
          }
        }

        if ($domain_expire - 432000 < time ())
        {
          if (time () < $domain_expire)
          {
            if ($domain_lock == 30)
            {
              domain_expire_5_days ($oid, $email_admin);
              set_domain_lock ($oid, 5);
              $domain_expire_5 = $seed . '|';
              $domain_expire_5_ct += 1;
            }
          }
        }

        if ($domain_expire - 2592000 < time ())
        {
          if (time () < $domain_expire)
          {
            if ($domain_lock == 0)
            {
              domain_expire_30_days ($oid, $email_admin);
              set_domain_lock ($oid, 30);
              $domain_expire_30 = $seed . '|';
              $domain_expire_30_ct += 1;
            }
          }
        }
      }
      else
      {
        domain_expire_date_error ($oid, $email_admin);
      }
    }

    unset ($seed);
    if (trim ($reports_resolved) == '')
    {
      $report .= 'None for this run.|0{';
    }
    else
    {
      $report .= $reports_resolved;
      $report .= $reports_resolved_ct . '{';
    }

    if (trim ($reports_unresolved) == '')
    {
      $report .= 'None for this run.|0{';
    }
    else
    {
      $report .= $reports_unresolved;
      $report .= $reports_unresolved_ct . '{';
    }

    if (trim ($reports_monitor) == '')
    {
      $report .= 'None for this run.|0{';
    }
    else
    {
      $report .= $reports_monitor;
      $report .= $reports_monitor_ct . '{';
    }

    if (trim ($domain_expire_30) == '')
    {
      $report .= 'None for this run.|0{';
    }
    else
    {
      $report .= $domain_expire_30;
      $report .= $domain_expire_30_ct . '{';
    }

    if (trim ($domain_expire_5) == '')
    {
      $report .= 'None for this run.|0{';
    }
    else
    {
      $report .= $domain_expire_5;
      $report .= $domain_expire_5_ct . '{';
    }

    if (trim ($domain_expired) == '')
    {
      $report .= 'None for this run.|0{';
      return $report;
    }

    $report .= $domain_expired;
    $report .= $domain_expired_ct . '{';
    return $report;
  }

  function send_newly_added_server_notification ($email_admin, $server_name, $server_ip, $primary_ns, $primary_ns_ip, $secondary_ns, $secondary_ns_ip, $max_accounts)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'5\''));
    $default_email = stripslashes (trim ($rs[2]));
    $generate_date = date ('m/d/Y h:i:s a');
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{server_name}}', $server_name, $subject);
    $subject = str_replace ('{{server_ip}}', $server_ip, $subject);
    $subject = str_replace ('{{primary_ns}}', $primary_ns, $subject);
    $subject = str_replace ('{{primary_ns_ip}}', $primary_ns_ip, $subject);
    $subject = str_replace ('{{secondary_ns}}', $secondary_ns, $subject);
    $subject = str_replace ('{{secondary_ns_ip}}', $secondary_ns_ip, $subject);
    $subject = str_replace ('{{max_accounts}}', $max_accounts, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{server_name}}', $server_name, $message);
    $message = str_replace ('{{server_ip}}', $server_ip, $message);
    $message = str_replace ('{{primary_ns}}', $primary_ns, $message);
    $message = str_replace ('{{primary_ns_ip}}', $primary_ns_ip, $message);
    $message = str_replace ('{{secondary_ns}}', $secondary_ns, $message);
    $message = str_replace ('{{secondary_ns_ip}}', $secondary_ns_ip, $message);
    $message = str_replace ('{{max_accounts}}', $max_accounts, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    global $email_admin;
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    exec_email ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function send_admin_max_accounts_reached ($max_clients, $active_server_name, $email_admin)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'6\''));
    $default_email = stripslashes (trim ($rs[2]));
    $generate_date = date ('m/d/Y h:i:s a');
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{max_clients}}', $max_clients, $subject);
    $subject = str_replace ('{{active_server_name}}', $active_server_name, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{max_clients}}', $max_clients, $message);
    $message = str_replace ('{{active_server_name}}', $active_server_name, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    global $email_admin;
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    exec_email ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function check_max_account_status ($email_admin, $below_public)
  {
    $current_server = current_server_internal ();
    if ($current_server != 99)
    {
      $rs = mysql_fetch_row (mysql_query ('select max_accounts, server_name, server_ip from server_config where whm_id=\'' . addslashes ($current_server) . '\''));
      $temp = @read_log ($current_server, $below_public);
      list ($xwhm_username, $xwhm_password) = split ('[|]', $temp);
      $server_ip = $rs[2];
      $installed_accounts = list_accounts ($server_ip, $xwhm_username, $xwhm_password, 1);
      $max_clients = $rs[0];
      $active_server_name = $rs[1];
      if ($max_clients <= $installed_accounts)
      {
        send_admin_max_accounts_reached ($max_clients, $active_server_name, $email_admin);
        return 1;
      }

      return 0;
    }

    return 0;
  }

  function new_account_installed ($email_admin, $oid, $currency, $currency_type, $addon_choices)
  {
    $query = 'select ';
    $query .= 'user.first_name, ';
    $query .= 'user.last_name, ';
    $query .= 'hosting_order.domain_name, ';
    $query .= 'hosting_order.ogcreate, ';
    $query .= 'hosting_order.pid, ';
    $query .= 'hosting_order.addon_choices, ';
    $query .= 'hosting_order.payment_method, ';
    $query .= 'hosting_order.payment_term, ';
    $query .= 'hosting_order.total_due_today, ';
    $query .= 'hosting_order.total_due_reoccur, ';
    $query .= 'hosting_order.whm_id, ';
    $query .= 'hosting_order.domain_registration,  ';
    $query .= 'user.advert, ';
    $query .= 'user.advert_other, ';
    $query .= 'hosting_order.promotion_code,  ';
    $query .= 'user.email,  ';
    $query .= 'hosting_order.pns1,  ';
    $query .= 'hosting_order.pns2,  ';
    $query .= 'hosting_order.client_notes  ';
    $query .= 'from user, hosting_order ';
    $query .= 'where user.uid=hosting_order.uid ';
    $query .= 'and hosting_order.oid=\'' . addslashes (trim ($oid)) . '\' ';
    $query .= 'order by user.uid asc';
    $rs1 = mysql_fetch_row (mysql_query ($query));
    $pns1 = 'Private Nameserver Prefix 1:' . stripslashes (trim ($rs1[16]));
    $pns2 = 'Private Nameserver Prefix 2:' . stripslashes (trim ($rs1[17]));
    $client_notes = 'Client Notes:
' . stripslashes (trim ($rs1[18]));
    $advert = stripslashes (trim ($rs1[12]));
    $advert_other = stripslashes (trim ($rs1[13]));
    $how_found = $advert . '' . (trim ($advert_other) != '' ? ': ' . $advert_other . '' : '') . '';
    $promotion_code = stripslashes (trim ($rs1[14]));
    if (trim ($promotion_code) != '')
    {
      $coupon = 'Used Promotion Code / Coupon: ' . $promotion_code;
    }
    else
    {
      $coupon = '';
    }

    $email_address = stripslashes (trim ($rs1[15]));
    $first_name = stripslashes (trim ($rs1[0]));
    $last_name = stripslashes (trim ($rs1[1]));
    $domain_name = stripslashes (trim ($rs1[2]));
    $ogcreate = stripslashes (trim ($rs1[3]));
    $pid = stripslashes (trim ($rs1[4]));
    $addon_choices = stripslashes (trim ($rs1[5]));
    $payment_method = stripslashes (trim ($rs1[6]));
    $payment_term = stripslashes (trim ($rs1[7]));
    if (trim (strtolower ($payment_term)) == 'monthly')
    {
      $payment_term = 'per Month';
    }
    else
    {
      if (trim (strtolower ($payment_term)) == 'quarterly')
      {
        $payment_term = 'per Quarter';
      }
      else
      {
        if (trim (strtolower ($payment_term)) == 'semi-annual')
        {
          $payment_term = 'Semi-Annually';
        }
        else
        {
          if (trim (strtolower ($payment_term)) == 'annually')
          {
            $payment_term = 'Annually';
          }
        }
      }
    }

    $total_due_today = stripslashes (trim ($rs1[8]));
    $total_due_reoccur = stripslashes (trim ($rs1[9]));
    $whm_id = stripslashes (trim ($rs1[10]));
    $domain_registration = stripslashes (trim ($rs1[11]));
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'7\''));
    $subject = stripslashes (trim ($rs[0]));
    $message = stripslashes (trim ($rs[1]));
    $default_email = stripslashes (trim ($rs[2]));
    $addons = 'Addons Ordered:
';
    $addons .= display_addons_ordered_email ($addon_choices);
    if ($domain_registration != 0)
    {
      $addons .= 'Domain Registration';
    }
    else
    {
      if (str_replace ('Addons Ordered:
', '', $addons) == '')
      {
        $addons .= ' - No account addons ordered';
      }
    }

    $rs3 = mysql_fetch_row (mysql_query ('select name from payment_process where pid=\'' . addslashes (trim ($payment_method)) . '\''));
    if ($whm_id != 0)
    {
      $rs4 = mysql_fetch_row (mysql_query ('select server_name from server_config where whm_id=\'' . addslashes (trim ($whm_id)) . '\''));
      $active_server_name = 'was installed onto ' . stripslashes (trim ($rs4[0]));
    }
    else
    {
      $active_server_name = 'was created as a pending account.';
    }

    $queryx = 'select ';
    $queryx .= 'package_name ';
    $queryx .= 'from plan_specs ';
    $queryx .= 'where pid=\'' . addslashes (trim ($pid)) . '\'';
    $rs2 = mysql_fetch_row (mysql_query ($queryx));
    $order_date = date ('m/d/Y', $ogcreate);
    $hosting_package = stripslashes (trim ($rs2[0]));
    $payment_gateway = stripslashes (trim ($rs3[0]));
    $generate_date = date ('m/d/Y h:i:s a');
    $subject = str_replace ('{{how_found}}', $how_found, $subject);
    $subject = str_replace ('{{email_address}}', $email_address, $subject);
    $subject = str_replace ('{{pns1}}', $pns1, $subject);
    $subject = str_replace ('{{pns2}}', $pns2, $subject);
    $subject = str_replace ('{{client_notes}}', $client_notes, $subject);
    $subject = str_replace ('{{coupon}}', $coupon, $subject);
    $subject = str_replace ('{{order_date}}', $order_date, $subject);
    $subject = str_replace ('{{active_server_name}}', $active_server_name, $subject);
    $subject = str_replace ('{{first_name}}', $first_name, $subject);
    $subject = str_replace ('{{last_name}}', $last_name, $subject);
    $subject = str_replace ('{{domain_name}}', $domain_name, $subject);
    $subject = str_replace ('{{hosting_package}}', $hosting_package, $subject);
    $subject = str_replace ('{{addons}}', $addons, $subject);
    $subject = str_replace ('{{payment_gateway}}', $payment_gateway, $subject);
    $subject = str_replace ('{{total_due_today}}', $total_due_today, $subject);
    $subject = str_replace ('{{total_reoccur}}', $total_due_reoccur, $subject);
    $subject = str_replace ('{{payment_term}}', $payment_term, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $message = str_replace ('{{how_found}}', $how_found, $message);
    $message = str_replace ('{{email_address}}', $email_address, $message);
    $message = str_replace ('{{pns1}}', $pns1, $message);
    $message = str_replace ('{{pns2}}', $pns2, $message);
    $message = str_replace ('{{client_notes}}', $client_notes, $message);
    $message = str_replace ('{{coupon}}', $coupon, $message);
    $message = str_replace ('{{order_date}}', $order_date, $message);
    $message = str_replace ('{{active_server_name}}', $active_server_name, $message);
    $message = str_replace ('{{first_name}}', $first_name, $message);
    $message = str_replace ('{{last_name}}', $last_name, $message);
    $message = str_replace ('{{domain_name}}', $domain_name, $message);
    $message = str_replace ('{{hosting_package}}', $hosting_package, $message);
    $message = str_replace ('{{addons}}', $addons, $message);
    $message = str_replace ('{{payment_gateway}}', $payment_gateway, $message);
    $message = str_replace ('{{total_due_today}}', $total_due_today, $message);
    $message = str_replace ('{{total_reoccur}}', $total_due_reoccur, $message);
    $message = str_replace ('{{payment_term}}', $payment_term, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    global $site_name;
    if (strcmp ($default_email, '') == 0)
    {
      $default_email = $email_admin;
    }

    $admin_name = $site_name;
    exec_email ($email_admin, $admin_name, $default_email, $admin_name, $subject, $message, 0, 3);
  }

  function new_order_received ($email_admin, $sid, $currency, $currency_type, $addon_choices)
  {
    $query = 'select ';
    $query .= 'first_name, ';
    $query .= 'last_name, ';
    $query .= 'domain_name, ';
    $query .= 'pid, ';
    $query .= 'addon_choices, ';
    $query .= 'payment_method, ';
    $query .= 'payment_term, ';
    $query .= 'total_due_today, ';
    $query .= 'total_due_reoccur, ';
    $query .= 'email, ';
    $query .= 'advert, ';
    $query .= 'advert_other, ';
    $query .= 'promotion_code, ';
    $query .= 'pns1, ';
    $query .= 'pns2, ';
    $query .= 'client_notes ';
    $query .= 'from session_history ';
    $query .= 'where sid=\'' . trim ($sid) . '\'';
    $rs1 = mysql_fetch_row (mysql_query ($query));
    $pns1 = stripslashes (trim ($rs1[13]));
    $pns2 = stripslashes (trim ($rs1[14]));
    $client_notes = stripslashes (trim ($rs1[15]));
    $first_name = stripslashes (trim ($rs1[0]));
    $last_name = stripslashes (trim ($rs1[1]));
    $domain_name = stripslashes (trim ($rs1[2]));
    $pid = stripslashes (trim ($rs1[3]));
    $addon_choices = stripslashes (trim ($rs1[4]));
    $payment_method = stripslashes (trim ($rs1[5]));
    $payment_term = stripslashes (trim ($rs1[6]));
    $total_due_today = stripslashes (trim ($rs1[7]));
    $total_due_reoccur = stripslashes (trim ($rs1[8]));
    $email_client = stripslashes (trim ($rs1[9]));
    $how_found = stripslashes (trim ($rs1[10]));
    $advert_other = stripslashes (trim ($rs1[11]));
    $promotion_code = stripslashes (trim ($rs1[12]));
    if (trim ($promotion_code) != '')
    {
      $coupon = 'Used Promotion Code / Coupon: ' . $promotion_code;
    }
    else
    {
      $coupon = '';
    }

    if (trim ($advert_other) != '')
    {
      $how_found .= '
 -- ' . $advert_other;
    }

    $rs0x = mysql_fetch_row (mysql_query ('select default_email from payment_process where pid=\'' . addslashes (trim ($payment_method)) . '\''));
    if (trim ($rs0x[0]) != '')
    {
      list ($sub, $body) = split ('{{break}}', $rs0x[0]);
      $subject = base64_decode ($sub);
      $message = base64_decode ($body);
    }
    else
    {
      $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'8\''));
      $subject = stripslashes (trim ($rs[0]));
      $message = stripslashes (trim ($rs[1]));
      $default_email = stripslashes (trim ($rs[2]));
    }

    $queryx = 'select ';
    $queryx .= 'package_name ';
    $queryx .= 'from plan_specs ';
    $queryx .= 'where pid=\'' . addslashes (trim ($pid)) . '\'';
    $rs2 = mysql_fetch_row (mysql_query ($queryx));
    $addons = 'Addons Ordered:
';
    $addons .= display_addons_ordered_email ($addon_choices);
    if ($domain_registration != 0)
    {
      $addons .= 'Domain Registration
';
    }
    else
    {
      if (str_replace ('Addons Ordered:
', '', $addons) == '')
      {
        $addons .= ' - No account addons ordered
';
      }
    }

    $rs3 = mysql_fetch_row (mysql_query ('select name from payment_process where pid=\'' . addslashes (trim ($payment_method)) . '\''));
    $hosting_package = stripslashes (trim ($rs2[0]));
    $payment_gateway = stripslashes (trim ($rs3[0]));
    $generate_date = date ('m/d/Y h:i:s a');
    $subject = str_replace ('{{coupon}}', $coupon, $subject);
    $subject = str_replace ('{{pns1}}', $pns1, $subject);
    $subject = str_replace ('{{pns2}}', $pns2, $subject);
    $subject = str_replace ('{{client_notes}}', $client_notes, $subject);
    $subject = str_replace ('{{first_name}}', $first_name, $subject);
    $subject = str_replace ('{{email_address}}', $email_client, $subject);
    $subject = str_replace ('{{how_found}}', $how_found, $subject);
    $subject = str_replace ('{{last_name}}', $last_name, $subject);
    $subject = str_replace ('{{domain_name}}', $domain_name, $subject);
    $subject = str_replace ('{{hosting_package}}', $hosting_package, $subject);
    $subject = str_replace ('{{addons}}', $addons, $subject);
    $subject = str_replace ('{{payment_gateway}}', $payment_gateway, $subject);
    $subject = str_replace ('{{total_due_today}}', $total_due_today, $subject);
    $subject = str_replace ('{{total_reoccur}}', $total_due_reoccur, $subject);
    $subject = str_replace ('{{payment_term}}', $payment_term, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $message = str_replace ('{{coupon}}', $coupon, $message);
    $message = str_replace ('{{pns1}}', $pns1, $message);
    $message = str_replace ('{{pns2}}', $pns2, $message);
    $message = str_replace ('{{client_notes}}', $client_notes, $message);
    $message = str_replace ('{{first_name}}', $first_name, $message);
    $message = str_replace ('{{email_address}}', $email_client, $message);
    $message = str_replace ('{{how_found}}', $how_found, $message);
    $message = str_replace ('{{last_name}}', $last_name, $message);
    $message = str_replace ('{{domain_name}}', $domain_name, $message);
    $message = str_replace ('{{hosting_package}}', $hosting_package, $message);
    $message = str_replace ('{{addons}}', $addons, $message);
    $message = str_replace ('{{payment_gateway}}', $payment_gateway, $message);
    $message = str_replace ('{{total_due_today}}', $total_due_today, $message);
    $message = str_replace ('{{total_reoccur}}', $total_due_reoccur, $message);
    $message = str_replace ('{{payment_term}}', $payment_term, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    global $email_admin;
    global $site_name;
    if (strcmp ($default_email, '') == 0)
    {
      $default_email = $email_admin;
    }

    $admin_name = $site_name;
    $client_name = $first_name . ' ' . $last_name;
    exec_email ($email_client, $client_name, $default_email, $admin_name, $subject, $message, 0, 3);
    $subject .= ' - Admin Copy';
    $message .= '

-------------------------------------------------------------';
    $message .= '

This is a copy of the message that was sent to the client.
';
    exec_email ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function send_dns_config ($email_admin, $oid)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'9\''));
    $default_email = stripslashes (trim ($rs[2]));
    $query = 'select ';
    $query .= 'hosting_order.domain_name, ';
    $query .= 'hosting_order.whm_id, ';
    $query .= 'user.email, ';
    $query .= 'user.first_name, ';
    $query .= 'user.last_name ';
    $query .= 'from user, hosting_order ';
    $query .= 'where user.uid=hosting_order.uid ';
    $query .= 'and hosting_order.oid=\'' . trim ($oid) . '\' ';
    $query .= 'order by user.uid asc';
    $rs1 = mysql_fetch_row (mysql_query ($query));
    $query1 = 'select ';
    $query1 .= 'primary_ns, ';
    $query1 .= 'primary_ns_ip, ';
    $query1 .= 'secondary_ns, ';
    $query1 .= 'secondary_ns_ip ';
    $query1 .= 'from server_config ';
    $query1 .= 'where whm_id=\'' . addslashes (trim ($rs1[1])) . '\'';
    $rs2 = mysql_fetch_row (mysql_query ($query1));
    $first_name = stripslashes (trim ($rs1[3]));
    $last_name = stripslashes (trim ($rs1[4]));
    $domain_name = stripslashes (trim ($rs1[0]));
    $primary_ns = stripslashes (trim ($rs2[0]));
    $primary_ns_ip = stripslashes (trim ($rs2[1]));
    $secondary_ns = stripslashes (trim ($rs2[2]));
    $secondary_ns_ip = stripslashes (trim ($rs2[3]));
    $email_client = stripslashes (trim ($rs1[2]));
    $generate_date = date ('m/d/Y h:i:s a');
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{domain_name}}', $domain_name, $subject);
    $subject = str_replace ('{{primary_ns}}', $primary_ns, $subject);
    $subject = str_replace ('{{primary_ns_ip}}', $primary_ns_ip, $subject);
    $subject = str_replace ('{{secondary_ns}}', $secondary_ns, $subject);
    $subject = str_replace ('{{secondary_ns_ip}}', $secondary_ns_ip, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{domain_name}}', $domain_name, $message);
    $message = str_replace ('{{primary_ns}}', $primary_ns, $message);
    $message = str_replace ('{{primary_ns_ip}}', $primary_ns_ip, $message);
    $message = str_replace ('{{secondary_ns}}', $secondary_ns, $message);
    $message = str_replace ('{{secondary_ns_ip}}', $secondary_ns_ip, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    $client_name = $first_name . ' ' . $last_name;
    exec_email ($email_client, $client_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function send_welcome_email_ip ($email_admin, $oid, $unique_ip_ordered)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'10\''));
    $default_email = stripslashes (trim ($rs[2]));
    $query = 'select ';
    $query .= 'hosting_order.domain_name, ';
    $query .= 'hosting_order.ip, ';
    $query .= 'hosting_order.whm_username, ';
    $query .= 'hosting_order.whm_password, ';
    $query .= 'user.email, ';
    $query .= 'hosting_order.whm_id, ';
    $query .= 'user.username, ';
    $query .= 'user.password, ';
    $query .= 'config.http_web, ';
    $query .= 'user.first_name, ';
    $query .= 'user.last_name ';
    $query .= 'from user, hosting_order, config ';
    $query .= 'where user.uid=hosting_order.uid ';
    $query .= 'and hosting_order.oid=\'' . addslashes (trim ($oid)) . '\' ';
    $query .= 'order by user.uid asc';
    $rs1 = mysql_fetch_row (mysql_query ($query));
    $email_client = stripslashes (trim ($rs1[4]));
    $whm_id = stripslashes (trim ($rs1[5]));
    $dns = mysql_fetch_row (mysql_query ('select primary_ns, primary_ns_ip, secondary_ns, secondary_ns_ip, server_name, server_noclocal from server_config where whm_id=\'' . addslashes (trim ($whm_id)) . '\''));
    $primary_ns = $dns[0];
    $primary_ns_ip = $dns[1];
    $secondary_ns = $dns[2];
    $secondary_ns_ip = $dns[3];
    $server_name = $dns[4];
    $server_location = $dns[5];
    $first_name = stripslashes (trim ($rs1[9]));
    $last_name = stripslashes (trim ($rs1[10]));
    $ip = stripslashes (trim ($rs1[1]));
    $whm_username = stripslashes (trim ($rs1[2]));
    $whm_password = stripslashes (trim ($rs1[3]));
    $domain_name = stripslashes (trim ($rs1[0]));
    $user_username = stripslashes (trim ($rs1[6]));
    $user_temppass = clogin_d (base64_decode ($rs1[7]));
    $client_login_temp = stripslashes (trim ($rs1[8]));
    $client_login = $client_login_temp . '/clogin.php';
    $generate_date = date ('m/d/Y h:i:s a');
    if ($unique_ip_ordered == 1)
    {
      $temporary_path = 'http://' . $ip;
    }
    else
    {
      $temporary_path = $ip . '/~' . $whm_username . '/';
    }

    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{ip}}', $ip, $subject);
    $subject = str_replace ('{{whm_username}}', $whm_username, $subject);
    $subject = str_replace ('{{whm_password}}', $whm_password, $subject);
    $subject = str_replace ('{{domain_name}}', $domain_name, $subject);
    $subject = str_replace ('{{primary_ns}}', $primary_ns, $subject);
    $subject = str_replace ('{{primary_ns_ip}}', $primary_ns_ip, $subject);
    $subject = str_replace ('{{secondary_ns}}', $secondary_ns, $subject);
    $subject = str_replace ('{{secondary_ns_ip}}', $secondary_ns_ip, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $subject = str_replace ('{{temporary_path}}', $temporary_path, $subject);
    $subject = str_replace ('{{clientarea_username}}', $user_username, $subject);
    $subject = str_replace ('{{clientarea_password}}', $user_temppass, $subject);
    $subject = str_replace ('{{clientarea_loginlink}}', $client_login, $subject);
    $subject = str_replace ('{{installed_on_server}}', $server_name, $subject);
    $subject = str_replace ('{{server_location}}', $server_location, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{ip}}', $ip, $message);
    $message = str_replace ('{{whm_username}}', $whm_username, $message);
    $message = str_replace ('{{whm_password}}', $whm_password, $message);
    $message = str_replace ('{{domain_name}}', $domain_name, $message);
    $message = str_replace ('{{primary_ns}}', $primary_ns, $message);
    $message = str_replace ('{{primary_ns_ip}}', $primary_ns_ip, $message);
    $message = str_replace ('{{secondary_ns}}', $secondary_ns, $message);
    $message = str_replace ('{{secondary_ns_ip}}', $secondary_ns_ip, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    $message = str_replace ('{{temporary_path}}', $temporary_path, $message);
    $message = str_replace ('{{clientarea_username}}', $user_username, $message);
    $message = str_replace ('{{clientarea_password}}', $user_temppass, $message);
    $message = str_replace ('{{clientarea_loginlink}}', $client_login, $message);
    $message = str_replace ('{{installed_on_server}}', $server_name, $message);
    $message = str_replace ('{{server_location}}', $server_location, $message);
    global $site_name;
    if (strcmp ($default_email, '') == 0)
    {
      $default_email = $email_admin;
    }

    $admin_name = $site_name;
    $client_name = $first_name . ' ' . $last_name;
    exec_email ($email_client, $client_name, $default_email, $admin_name, $subject, $message, 0, 3);
    $subject .= ' - Admin Copy';
    $message .= '

-------------------------------------------------------------';
    $message .= '

This is a copy of the message that was sent to the client.
';
    exec_email ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function dbbackup ($email_admin, $server_backup, $dbhost, $dbuser, $dbpass, $db, $http_admin, $http_images, $which)
  {
    if (!(is_dir ($server_backup)))
    {
      mkdir ($server_backup, 511);
    }

    $date = date ('m-d-Y', time ());
    $filename = $db . '_' . $date . '.sql';
    $fullname = $server_backup . '/' . $filename;
    $dump_cmd = 'mysqldump -h' . $dbhost . ' -u' . $dbuser . ' -p' . $dbpass . ' ' . $db . ' > ' . $fullname;
    passthru ($dump_cmd, $dump_status);
    $dump_status = 'The database ';
    if ($dump_status == 0)
    {
      $lines = file ($fullname);
      foreach ($lines as $line_num => $line)
      {
        if (ereg ('--', $line) == true)
        {
          if (substr_count ($line, '--') == 1)
          {
            $result .= str_replace ('--', '# --', $line);
            continue;
          }
          else
          {
            if (2 <= substr_count ($line, '--'))
            {
              $result .= '# ' . $line;
              continue;
            }
            else
            {
              $result .= $line;
              continue;
            }

            continue;
          }

          continue;
        }
        else
        {
          $result .= $line;
          continue;
        }
      }

      $xread = fopen ($fullname, 'w');
      fwrite ($xread, $result);
      fclose ($xread);
      $comp_cmd = 'gzip -f ' . $fullname;
      passthru ($comp_cmd, $comp_status);
      $dump_status .= 'was backed up successfully!

';
      if ($comp_status == 0)
      {
        chmod ($fullname . '.gz', 493);
        $dump_status .= 'The backup was stored locally in:
<img src=\'' . $http_images . '/error_arrow.gif\'><a href=\'' . $http_admin . '/dbbackup/' . $filename . '.gz\'>' . $fullname . '.gz</a>';
      }
      else
      {
        chmod ($fullname, 493);
        $dump_status .= 'The backup was stored locally in:
<img src=\'' . $http_images . '/error_arrow.gif\'><a href=\'' . $http_admin . '/dbbackup/' . $filename . '\'>' . $fullname . '</a>';
      }
    }
    else
    {
      $dump_status .= 'backup failed!

';
    }

    $subject = 'DB Backup: ' . date ('m/d/Y h:i:s a');
    $message = 'Below are the results of the database backup:
';
    $message .= 'You should save this email in case of disaster!
';
    $message .= '-------------------------------------------------


';
    $message .= $result;
    global $site_name;
    $admin_name = $site_name;
    exec_email ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
    if ($which == 1)
    {
      return nl2br ($dump_status);
    }

  }

  function last_ran_weekly_sales_report ($below_public, $which)
  {
    if ($which == 1)
    {
      if (!(file_exists ($below_public . '/weekly_sales_report.log')))
      {
        $data = time () - 601200;
        $read = fopen ($below_public . '/weekly_sales_report.log', 'w');
        $xdata = fwrite ($read, $data);
        fclose ($read);
        chmod ($below_public . '/weekly_sales_report.log', 511);
        return $data;
      }

      $read = fopen ($below_public . '/weekly_sales_report.log', 'r');
      $result = fread ($read, filesize ($below_public . '/weekly_sales_report.log'));
      fclose ($read);
      return $result;
    }

    if ($which == 0)
    {
      $data = time ();
      $read = fopen ($below_public . '/weekly_sales_report.log', 'w');
      $xdata = fwrite ($read, $data);
      fclose ($read);
    }

  }

  function reports_weekly_sales ($email_admin, $site_name, $which, $currency, $currency_type)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'29\''));
    $default_email = stripslashes (trim ($rs[2]));
    $x = 0;
    $row0 = mysql_query ('select ogcreate, domain_name, pid, total_due_reoccur, payment_term, uid from hosting_order where status=\'1\' order by hosting_order.ogcreate asc');
    while ($rs0 = mysql_fetch_row ($row0))
    {
      if (time () <= $rs0[0] + 604800)
      {
        $rs1 = mysql_fetch_row (mysql_query ('select package_name from plan_specs where pid=\'' . addslashes (trim ($rs0[2])) . '\''));
        $rs2 = mysql_fetch_row (mysql_query ('select first_name, last_name from user where uid=\'' . addslashes (trim ($rs0[5])) . '\''));
        if ($x == 0)
        {
          $data = '1. http://' . $rs0[1] . ', ' . $rs2[0] . ' ' . $rs2[1] . ', ' . $rs1[0] . ', ' . $currency . $rs0[3] . $currency_type . '
';
        }
        else
        {
          $data .= $x . '. http://' . $rs0[1] . ', ' . $rs2[0] . ' ' . $rs2[1] . ', ' . $rs1[0] . ', ' . $currency . $rs0[3] . $currency_type . '
';
        }

        ++$x;
        continue;
      }
    }

    $new_signups = $data;
    $signup_count = $x;
    $generate_date = date ('m/d/Y h:i:s a');
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $subject = str_replace ('{{site_name}}', $site_name, $subject);
    $subject = str_replace ('{{new_signups}}', $new_signups, $subject);
    $subject = str_replace ('{{signup_count}}', $signup_count, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    $message = str_replace ('{{site_name}}', $site_name, $message);
    $message = str_replace ('{{new_signups}}', $new_signups, $message);
    $message = str_replace ('{{signup_count}}', $signup_count, $message);
    if ($which == 99)
    {
      echo nl2br ($message);
      return null;
    }

    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    exec_email ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function last_ran_monthly_revenue_report ($below_public, $which)
  {
    if ($which == 1)
    {
      if (!(file_exists ($below_public . '/monthly_revenue_server_sales_report.log')))
      {
        $data = time () - 2588400;
        $read = fopen ($below_public . '/monthly_revenue_server_sales_report.log', 'w');
        $xdata = fwrite ($read, $data);
        fclose ($read);
        chmod ($below_public . '/monthly_revenue_server_sales_report.log', 511);
        return $data;
      }

      $read = fopen ($below_public . '/monthly_revenue_server_sales_report.log', 'r');
      $result = fread ($read, filesize ($below_public . '/monthly_revenue_server_sales_report.log'));
      fclose ($read);
      return $result;
    }

    if ($which == 0)
    {
      $data = time ();
      $read = fopen ($below_public . '/monthly_revenue_server_sales_report.log', 'w');
      $xdata = fwrite ($read, $data);
      fclose ($read);
    }

  }

  function reports_monthly_revenue_sales ($email_admin, $site_name, $which, $currency, $currency_type)
  {
    global $currency;
    global $currency_type;
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'30\''));
    $subject = stripslashes (trim ($rs[0]));
    $message = stripslashes (trim ($rs[1]));
    $default_email = stripslashes (trim ($rs[2]));
    $generate_date = date ('m/d/Y h:i:s a');
    $return = '';
    $query = 'select ';
    $query .= 'whm_id, ';
    $query .= 'server_name, ';
    $query .= 'server_cost, ';
    $query .= 'server_noclocal ';
    $query .= 'from ';
    $query .= 'server_config';
    $row0 = mysql_query ($query);
    while ($rs0 = mysql_fetch_row ($row0))
    {
      $query1 = 'select ';
      $query1 .= 'SUM(total_due_reoccur) ';
      $query1 .= 'from ';
      $query1 .= 'hosting_order ';
      $query1 .= 'where ';
      $query1 .= 'payment_term=\'monthly\' ';
      $query1 .= 'and ';
      $query1 .= 'whm_id=\'' . addslashes (trim ($rs0[0])) . '\'';
      $query1 .= 'and ';
      $query1 .= 'status=\'1\' ';
      $query1 .= 'or ';
      $query1 .= 'payment_term=\'Monthly\'';
      $query1 .= 'and ';
      $query1 .= 'whm_id=\'' . addslashes (trim ($rs0[0])) . '\' ';
      $query1 .= 'and ';
      $query1 .= 'status=\'1\'';
      $rs1 = mysql_fetch_row (mysql_query ($query1));
      $monthly = $currency . sprintf ('%01.2f', $rs1[0]) . ' ' . $currency_type;
      $monthly_rev = $rs1[0];
      $query1 = 'select ';
      $query1 .= 'SUM(total_due_reoccur) ';
      $query1 .= 'from ';
      $query1 .= 'hosting_order ';
      $query1 .= 'where ';
      $query1 .= 'payment_term=\'quarterly\' ';
      $query1 .= 'and ';
      $query1 .= 'whm_id=\'' . addslashes (trim ($rs0[0])) . '\'';
      $query1 .= 'and ';
      $query1 .= 'status=\'1\' ';
      $query1 .= 'or ';
      $query1 .= 'payment_term=\'Quarterly\' ';
      $query1 .= 'and ';
      $query1 .= 'whm_id=\'' . addslashes (trim ($rs0[0])) . '\' ';
      $query1 .= 'and ';
      $query1 .= 'status=\'1\'';
      $rs1 = mysql_fetch_row (mysql_query ($query1));
      $quarterly = $currency . sprintf ('%01.2f', $rs1[0]) . ' ' . $currency_type;
      $quarterly_rev = $rs1[0];
      $query1 = 'select ';
      $query1 .= 'SUM(total_due_reoccur) ';
      $query1 .= 'from ';
      $query1 .= 'hosting_order ';
      $query1 .= 'where ';
      $query1 .= 'payment_term=\'Semi-Annual\' ';
      $query1 .= 'and ';
      $query1 .= 'whm_id=\'' . addslashes (trim ($rs0[0])) . '\' ';
      $query1 .= 'and ';
      $query1 .= 'status=\'1\' ';
      $query1 .= 'or ';
      $query1 .= 'payment_term=\'semi-annual\' ';
      $query1 .= 'and ';
      $query1 .= 'whm_id=\'' . addslashes (trim ($rs0[0])) . '\' ';
      $query1 .= 'and ';
      $query1 .= 'status=\'1\' ';
      $query1 .= 'or ';
      $query1 .= 'payment_term=\'semi_annual\' ';
      $query1 .= 'and ';
      $query1 .= 'whm_id=\'' . addslashes (trim ($rs0[0])) . '\' ';
      $query1 .= 'and ';
      $query1 .= 'status=\'1\' ';
      $query1 .= 'or ';
      $query1 .= 'payment_term=\'Semi_Annual\' ';
      $query1 .= 'and ';
      $query1 .= 'whm_id=\'' . addslashes (trim ($rs0[0])) . '\' ';
      $query1 .= 'and ';
      $query1 .= 'status=\'1\'';
      $rs1 = mysql_fetch_row (mysql_query ($query1));
      $semi_annual = $currency . sprintf ('%01.2f', $rs1[0]) . ' ' . $currency_type;
      $semi_annual_rev = $rs1[0];
      $query1 = 'select ';
      $query1 .= 'SUM(total_due_reoccur) ';
      $query1 .= 'from ';
      $query1 .= 'hosting_order ';
      $query1 .= 'where ';
      $query1 .= 'payment_term=\'annual\' ';
      $query1 .= 'and ';
      $query1 .= 'whm_id=\'' . addslashes (trim ($rs0[0])) . '\' ';
      $query1 .= 'and ';
      $query1 .= 'status=\'1\' ';
      $query1 .= 'or ';
      $query1 .= 'payment_term=\'Annual\' ';
      $query1 .= 'and ';
      $query1 .= 'whm_id=\'' . addslashes (trim ($rs0[0])) . '\' ';
      $query1 .= 'and ';
      $query1 .= 'status=\'1\'';
      $rs1 = mysql_fetch_row (mysql_query ($query1));
      $annual = $currency . sprintf ('%01.2f', $rs1[0]) . ' ' . $currency_type;
      $annual_rev = $rs1[0];
      $tallcash = $currency . sprintf ('%01.2f', $monthly_rev * 12 + $quarterly_rev * 4 + $semi_annual_rev * 2 + $annual_rev) . ' ' . $currency_type;
      $tallcashclean = $monthly_rev * 12 + $quarterly_rev * 4 + $semi_annual_rev * 2 + $annual_rev;
      $tallcashcleanmonth = $annual_rev / 12 + $quarterly_rev / 3 + $semi_annual_rev / 6 + $monthly_rev;
      $estimated_profit = $currency . sprintf ('%01.2f', $tallcashclean - $rs0[2] * 12) . ' ' . $currency_type;
      $estimated_monthly_profit = $currency . sprintf ('%01.2f', $tallcashcleanmonth - $rs0[2]) . ' ' . $currency_type;
      $server_cost_per_month = $currency . sprintf ('%01.2f', $rs0[2]) . ' ' . $currency_type;
      $return .= 'Server ' . ($g += 1) . ' - ' . stripslashes (trim ($rs0[1])) . ' [WHM ID: ' . $rs0[0] . ']
';
      $return .= 'Server Location: ' . $rs0[3] . '
';
      $return .= '
Estimated Income:
';
      $return .= '--&gt; ' . $monthly . ' Billing Monthly
';
      $return .= '--&gt; ' . $quarterly . ' Billing Quarterly
';
      $return .= '--&gt; ' . $semi_annual . ' Billing Semi-Annually
';
      $return .= '--&gt; ' . $annual . ' Billing Annually
';
      $return .= '
Server Cost Per Month: ' . $server_cost_per_month . '
';
      $return .= 'Estimated Annual Revenue: ' . $tallcash . '
';
      $return .= '
Estimated Annual Profit: ' . $estimated_profit . '';
      $return .= '
Estimated Monthly Profit Earned: ' . $estimated_monthly_profit . '

Figures are mere estimates based on divisional calculations of annual earned revenue less your cost per server

';
      $return .= '=================================================

';
      unset ($monthly);
      unset ($quarterly);
      unset ($semi_annual);
      unset ($annual);
      unset ($query1);
      unset ($rs1);
    }

    $subject = stripslashes (trim ($subject));
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $subject = str_replace ('{{site_name}}', $site_name, $subject);
    $subject = str_replace ('{{server_details}}', $return, $subject);
    $message = stripslashes (trim ($message));
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    $message = str_replace ('{{site_name}}', $site_name, $message);
    $message = str_replace ('{{server_details}}', $return, $message);
    if ($which == 99)
    {
      echo nl2br ($message);
      return null;
    }

    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    exec_email ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function last_ran_monthly_new_account_report ($below_public, $which)
  {
    if ($which == 1)
    {
      if (!(file_exists ($below_public . '/monthly_new_account_sales_report.log')))
      {
        $data = time () - 2588400;
        $read = fopen ($below_public . '/monthly_new_account_sales_report.log', 'w');
        $xdata = fwrite ($read, $data);
        fclose ($read);
        chmod ($below_public . '/monthly_new_account_sales_report.log', 511);
        return $data;
      }

      $read = fopen ($below_public . '/monthly_new_account_sales_report.log', 'r');
      $result = fread ($read, filesize ($below_public . '/monthly_new_account_sales_report.log'));
      fclose ($read);
      return $result;
    }

    if ($which == 0)
    {
      $data = time ();
      $read = fopen ($below_public . '/monthly_new_account_sales_report.log', 'w');
      $xdata = fwrite ($read, $data);
      fclose ($read);
    }

  }

  function reports_monthly_new_account ($email_admin, $site_name, $which, $currency, $currency_type)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'31\''));
    $default_email = stripslashes (trim ($rs[2]));
    $x = 0;
    $row0 = mysql_query ('select ogcreate, domain_name, pid, total_due_reoccur, payment_term, uid from hosting_order where status=\'1\' order by hosting_order.ogcreate asc');
    while ($rs0 = mysql_fetch_row ($row0))
    {
      $record = date ('mY', $rs0[0]);
      $current = date ('mY');
      if (strcmp ($record, $current) == 0)
      {
        $rs1 = mysql_fetch_row (mysql_query ('select package_name from plan_specs where pid=\'' . addslashes (trim ($rs0[2])) . '\''));
        $rs2 = mysql_fetch_row (mysql_query ('select first_name, last_name from user where uid=\'' . addslashes (trim ($rs0[5])) . '\''));
        if ($x == 0)
        {
          $data = '1. http://' . $rs0[1] . ', ' . $rs2[0] . ' ' . $rs2[1] . ', ' . $rs1[0] . ', ' . $currency . $rs0[3] . $currency_type . '
';
        }
        else
        {
          $data .= $x . '. http://' . $rs0[1] . ', ' . $rs2[0] . ' ' . $rs2[1] . ', ' . $rs1[0] . ', ' . $currency . $rs0[3] . $currency_type . '
';
        }

        ++$x;
      }

      unset ($record);
    }

    $generate_date = date ('m/d/Y h:i:s a');
    $month = date ('F');
    $signup_details = $data;
    $signup_count = $x;
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{site_name}}', $site_name, $subject);
    $subject = str_replace ('{{month}}', $month, $subject);
    $subject = str_replace ('{{signup_count}}', $signup_count, $subject);
    $subject = str_replace ('{{signup_details}}', $signup_details, $subject);
    $subject = str_replace ('{{server_details}}', $server_details, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{site_name}}', $site_name, $message);
    $message = str_replace ('{{month}}', $month, $message);
    $message = str_replace ('{{signup_count}}', $signup_count, $message);
    $message = str_replace ('{{signup_details}}', $signup_details, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    if ($which == 99)
    {
      echo nl2br ($message);
      return null;
    }

    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    exec_email ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function send_successful_server_switch ($email_admin, $max_clients, $previous_active_server_name, $new_active_server_name, $server_role)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'6\''));
    $default_email = stripslashes (trim ($rs[2]));
    $generate_date = date ('m/d/Y h:i:s a');
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{max_clients}}', $max_clients, $subject);
    $subject = str_replace ('{{previous_active_server_name}}', $previous_active_server_name, $subject);
    $subject = str_replace ('{{new_active_server_name}}', $new_active_server_name, $subject);
    $subject = str_replace ('{{server_role}}', $server_role, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{max_clients}}', $max_clients, $message);
    $message = str_replace ('{{previous_active_server_name}}', $previous_active_server_name, $message);
    $message = str_replace ('{{new_active_server_name}}', $new_active_server_name, $message);
    $message = str_replace ('{{server_role}}', $server_role, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    exec_email ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function send_max_accounts_reached ($email_admin, $max_accounts, $server_name)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'32\''));
    $default_email = stripslashes (trim ($rs[2]));
    $generate_date = date ('m/d/Y h:i:s a');
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{max_accounts}}', $max_accounts, $subject);
    $subject = str_replace ('{{server_name}}', $server_name, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{max_accounts}}', $max_accounts, $message);
    $message = str_replace ('{{server_name}}', $server_name, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    exec_email ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function convert_month ($month)
  {
    $month = strtolower ($month);
    if ($month == 'jan')
    {
      return '01';
    }

    if ($month == 'feb')
    {
      return '02';
    }

    if ($month == 'mar')
    {
      return '03';
    }

    if ($month == 'apr')
    {
      return '04';
    }

    if ($month == 'may')
    {
      return '05';
    }

    if ($month == 'jun')
    {
      return '06';
    }

    if ($month == 'jul')
    {
      return '07';
    }

    if ($month == 'aug')
    {
      return '08';
    }

    if ($month == 'sep')
    {
      return '09';
    }

    if ($month == 'oct')
    {
      return '10';
    }

    if ($month == 'nov')
    {
      return '11';
    }

    if ($month == 'dec')
    {
      return '12';
    }

  }

  function display_time ($ogcreate, $which)
  {
    $ogcreate = str_replace ('  ', ' ', $ogcreate);
    list ($dayx, $mon, $day, $time, $year) = split (' ', $ogcreate . ' ');
    $mon = convert_month ($mon);
    $time = str_replace (':', '', $time);
    if ($which == 0)
    {
      $ogcreate = mktime (substr ($time, 0, 2), substr ($time, 2, 2), substr ($time, -2), $mon, $day, $year);
      return $ogcreate;
    }

    if ($which == 1)
    {
      $ogcreate = trim ($year) . sprintf ('%02.0f', trim ($mon)) . sprintf ('%02.0f', trim ($day)) . trim ($time);
    }

    return $ogcreate;
  }

  function clean_record ($line)
  {
    $line = substr ($line, 1, strlen (trim ($line)));
    $line = str_replace (',,,,,,,,,', ',', $line);
    $line = str_replace (',,,,,,,', ',', $line);
    $line = str_replace (',,,,', ',', $line);
    $line = str_replace (',,', ',', $line);
    return $line;
  }

  function migrate_user_to_phpbb ($username, $password, $email)
  {
    $rs = mysql_fetch_row (mysql_query ('select uid from user where username=\'' . addslashes (trim ($username)) . '\''));
    mysql_query ('insert into phpbb_users set user_id=\'' . addslashes (trim ($rs[0])) . '\', username=\'' . addslashes (trim ($username)) . '\', user_password=\'' . addslashes (trim ($password)) . '\', user_email=\'' . addslashes (trim ($email)) . '\', user_active=\'1\', user_level=\'0\', user_regdate=\'' . time () . '\'');
  }

  function reset_phpbb_pw ($username, $password)
  {
    mysql_query ('update phpbb_users set user_password=\'' . addslashes (trim ($password)) . '\' where username=\'' . addslashes (trim ($username)) . '\'');
  }

  function reset_phpbb_email ($username, $email)
  {
    mysql_query ('update phpbb_users set user_email=\'' . addslashes (trim ($email)) . '\' where username=\'' . addslashes (trim ($username)) . '\'');
  }

  function suspend_phpbb_user ($username)
  {
    $rs = mysql_fetch_row (mysql_query ('select user_id from phpbb_users where username=\'' . addslashes (trim ($username)) . '\''));
    mysql_query ('insert into phpbb_banlist set ban_userid=\'' . addslashes (trim ($rs[0])) . '\'');
  }

  function unsuspend_phpbb_user ($username)
  {
    $rs = mysql_fetch_row (mysql_query ('select user_id from phpbb_users where username=\'' . addslashes (trim ($username)) . '\''));
    mysql_query ('delete from phpbb_banlist where ban_userid=\'' . addslashes (trim ($rs[0])) . '\'');
  }

  function delete_phpbb_user ($uid)
  {
    @mysql_query ('delete from phpbb_banlist where user_id=\'' . @addslashes (@trim ($uid)) . '\'');
    @mysql_query ('delete from phpbb_users where user_id=\'' . @addslashes (@trim ($uid)) . '\'');
  }

  function get_whois_server ($domain)
  {
    $whoisservers = array (array ('ac', 'whois.nic.ac'), array ('ac.cn', 'whois.cnnic.net.cn'), array ('ac.jp', 'whois.nic.ad.jp'), array ('ac.uk', 'whois.ja.net'), array ('ad.jp', 'whois.nic.ad.jp'), array ('adm.br', 'whois.nic.br'), array ('adv.br', 'whois.nic.br'), array ('aero', 'whois.information.aero'), array ('ag', 'whois.nic.ag'), array ('agr.br', 'whois.nic.br'), array ('ah.cn', 'whois.cnnic.net.cn'), array ('al', 'whois.ripe.net'), array ('am.br', 'whois.nic.br'), array ('arq.br', 'whois.nic.br'), array ('at', 'whois.nic.at'), array ('au', 'whois.aunic.net'), array ('art.br', 'whois.nic.br'), array ('as', 'whois.nic.as'), array ('asn.au', 'whois.aunic.net'), array ('ato.br', 'whois.nic.br'), array ('be', 'whois.geektools.com'), array ('bg', 'whois.digsys.bg'), array ('bio.br', 'whois.nic.br'), array ('biz', 'whois.biz'), array ('bj.cn', 'whois.cnnic.net.cn'), array ('bmd.br', 'whois.nic.br'), array ('br', 'whois.registro.br'), array ('ca', 'whois.cira.ca'), array ('cc', 'whois.nic.cc'), array ('cd', 'whois.cd'), array ('ch', 'whois.nic.ch'), array ('cim.br', 'whois.nic.br'), array ('ck', 'whois.ck-nic.org.ck'), array ('cl', 'whois.nic.cl'), array ('cn', 'whois.cnnic.net.cn'), array ('cng.br', 'whois.nic.br'), array ('cnt.br', 'whois.nic.br'), array ('com', 'rs.internic.net'), array ('com.au', 'whois.aunic.net'), array ('com.br', 'whois.nic.br'), array ('com.cn', 'whois.cnnic.net.cn'), array ('com.eg', 'whois.ripe.net'), array ('com.hk', 'whois.hknic.net.hk'), array ('com.mx', 'whois.nic.mx'), array ('com.ru', 'whois.ripn.ru'), array ('com.tw', 'whois.twnic.net'), array ('conf.au', 'whois.aunic.net'), array ('co.jp', 'whois.nic.ad.jp'), array ('co.uk', 'whois.nic.uk'), array ('cq.cn', 'whois.cnnic.net.cn'), array ('csiro.au', 'whois.aunic.net'), array ('cx', 'whois.nic.cx'), array ('cz', 'whois.nic.cz'), array ('de', 'whois.denic.de'), array ('dk', 'whois.dk-hostmaster.dk'), array ('ecn.br', 'whois.nic.br'), array ('ee', 'whois.eenet.ee'), array ('edu', 'rs.internic.net'), array ('edu.au', 'whois.aunic.net'), array ('edu.br', 'whois.nic.br'), array ('eg', 'whois.ripe.net'), array ('es', 'whois.ripe.net'), array ('esp.br', 'whois.nic.br'), array ('etc.br', 'whois.nic.br'), array ('eti.br', 'whois.nic.br'), array ('eun.eg', 'whois.ripe.net'), array ('emu.id.au', 'whois.aunic.net'), array ('eng.br', 'whois.nic.br'), array ('far.br', 'whois.nic.br'), array ('fi', 'whois.ripe.net'), array ('fj', 'whois.usp.ac.fj'), array ('fj.cn', 'whois.cnnic.net.cn'), array ('fm.br', 'whois.nic.br'), array ('fnd.br', 'whois.nic.br'), array ('fo', 'whois.ripe.net'), array ('fot.br', 'whois.nic.br'), array ('fst.br', 'whois.nic.br'), array ('fr', 'whois.nic.fr'), array ('g12.br', 'whois.nic.br'), array ('gd.cn', 'whois.cnnic.net.cn'), array ('ge', 'whois.ripe.net'), array ('ggf.br', 'whois.nic.br'), array ('gl', 'whois.ripe.net'), array ('gr', 'whois.ripe.net'), array ('gr.jp', 'whois.nic.ad.jp'), array ('gs', 'whois.adamsnames.tc'), array ('gov', 'whois.nic.gov'), array ('gs.cn', 'whois.cnnic.net.cn'), array ('gov.au', 'whois.aunic.net'), array ('gov.br', 'whois.nic.br'), array ('gov.cn', 'whois.cnnic.net.cn'), array ('gov.hk', 'whois.hknic.net.hk'), array ('gob.mx', 'whois.nic.mx'), array ('gs', 'whois.adamsnames.tc'), array ('gz.cn', 'whois.cnnic.net.cn'), array ('gx.cn', 'whois.cnnic.net.cn'), array ('he.cn', 'whois.cnnic.net.cn'), array ('ha.cn', 'whois.cnnic.net.cn'), array ('hb.cn', 'whois.cnnic.net.cn'), array ('hi.cn', 'whois.cnnic.net.cn'), array ('hl.cn', 'whois.cnnic.net.cn'), array ('hn.cn', 'whois.cnnic.net.cn'), array ('hm', 'whois.registry.hm'), array ('hk', 'whois.hknic.net.hk'), array ('hk.cn', 'whois.cnnic.net.cn'), array ('hu', 'whois.ripe.net'), array ('id.au', 'whois.aunic.net'), array ('ie', 'whois.domainregistry.ie'), array ('ind.br', 'whois.nic.br'), array ('imb.br', 'whois.nic.br'), array ('inf.br', 'whois.nic.br'), array ('info', 'whois.afilias.info'), array ('info.au', 'whois.aunic.net'), array ('it', 'whois.nic.it'), array ('idv.tw', 'whois.twnic.net'), array ('int', 'whois.iana.org'), array ('is', 'whois.isnic.is'), array ('il', 'whois.isoc.org.il'), array ('jl.cn', 'whois.cnnic.net.cn'), array ('jor.br', 'whois.nic.br'), array ('jp', 'whois.nic.ad.jp'), array ('js.cn', 'whois.cnnic.net.cn'), array ('jx.cn', 'whois.cnnic.net.cn'), array ('kr', 'whois.krnic.net'), array ('la', 'whois.nic.la'), array ('lel.br', 'whois.nic.br'), array ('li', 'whois.nic.ch'), array ('lk', 'whois.nic.lk'), array ('ln.cn', 'whois.cnnic.net.cn'), array ('lt', 'ns.litnet.lt'), array ('lu', 'whois.dns.lu'), array ('lv', 'whois.ripe.net'), array ('ltd.uk', 'whois.nic.uk'), array ('mat.br', 'whois.nic.br'), array ('mc', 'whois.ripe.net'), array ('med.br', 'whois.nic.br'), array ('mil', 'whois.nic.mil'), array ('mil.br', 'whois.nic.br'), array ('mn', 'whois.nic.mn'), array ('mo.cn', 'whois.cnnic.net.cn'), array ('ms', 'whois.adamsnames.tc'), array ('mus.br', 'whois.nic.br'), array ('mx', 'whois.nic.mx'), array ('name', 'whois.nic.name'), array ('ne.jp', 'whois.nic.ad.jp'), array ('net', 'rs.internic.net'), array ('net.au', 'whois.aunic.net'), array ('net.br', 'whois.nic.br'), array ('net.cn', 'whois.cnnic.net.cn'), array ('net.eg', 'whois.ripe.net'), array ('net.hk', 'whois.hknic.net.hk'), array ('net.lu', 'whois.dns.lu'), array ('net.mx', 'whois.nic.mx'), array ('net.uk', 'whois.nic.uk'), array ('net.ru', 'whois.ripn.ru'), array ('net.tw', 'whois.twnic.net'), array ('nl', 'whois.domain-registry.nl'), array ('nm.cn', 'whois.cnnic.net.cn'), array ('no', 'whois.norid.no'), array ('nom.br', 'whois.nic.br'), array ('not.br', 'whois.nic.br'), array ('ntr.br', 'whois.nic.br'), array ('nx.cn', 'whois.cnnic.net.cn'), array ('nz', 'whois.domainz.net.nz'), array ('plc.uk', 'whois.nic.uk'), array ('odo.br', 'whois.nic.br'), array ('oop.br', 'whois.nic.br'), array ('or.jp', 'whois.nic.ad.jp'), array ('org', 'rs.internic.net'), array ('org.au', 'whois.aunic.net'), array ('org.br', 'whois.nic.br'), array ('org.cn', 'whois.cnnic.net.cn'), array ('org.hk', 'whois.hknic.net.hk'), array ('org.lu', 'whois.dns.lu'), array ('org.ru', 'whois.ripn.ru'), array ('org.tw', 'whois.twnic.net'), array ('org.uk', 'whois.nic.uk'), array ('pl', 'nazgul.nask.waw.pl'), array ('pp.ru', 'whois.ripn.ru'), array ('ppg.br', 'whois.nic.br'), array ('pro.br', 'whois.nic.br'), array ('psi.br', 'whois.nic.br'), array ('psc.br', 'whois.nic.br'), array ('pt', 'whois.ripe.net'), array ('qh.cn', 'whois.cnnic.net.cn'), array ('qsl.br', 'whois.nic.br'), array ('rec.br', 'whois.nic.br'), array ('ro', 'whois.rotld.ro'), array ('ru', 'whois.ripn.ru'), array ('sc.cn', 'whois.cnnic.net.cn'), array ('sd.cn', 'whois.cnnic.net.cn'), array ('se', 'whois.nic-se.se'), array ('sg', 'whois.nic.net.sg'), array ('sh', 'whois.nic.sh'), array ('sh.cn', 'whois.cnnic.net.cn'), array ('si', 'whois.arnes.si'), array ('sk', 'whois.ripe.net'), array ('slg.br', 'whois.nic.br'), array ('sm', 'whois.ripe.net'), array ('sn.cn', 'whois.cnnic.net.cn'), array ('srv.br', 'whois.nic.br'), array ('st', 'whois.nic.st'), array ('sx.cn', 'whois.cnnic.net.cn'), array ('tc', 'whois.adamsnames.tc'), array ('th', 'whois.nic.uk'), array ('tj.cn', 'whois.cnnic.net.cn'), array ('tmp.br', 'whois.nic.br'), array ('to', 'whois.tonic.to'), array ('tr', 'whois.ripe.net'), array ('trd.br', 'whois.nic.br'), array ('tur.br', 'whois.nic.br'), array ('tv', 'whois.tv'), array ('tv.br', 'whois.nic.br'), array ('tw', 'whois.twnic.net'), array ('tw.cn', 'whois.cnnic.net.cn'), array ('uk', 'whois.thnic.net'), array ('va', 'whois.ripe.net'), array ('vet.br', 'whois.nic.br'), array ('vg', 'whois.adamsnames.tc'), array ('wattle.id.au', 'whois.aunic.net'), array ('ws', 'whois.worldsite.ws'), array ('xj.cn', 'whois.cnnic.net.cn'), array ('xz.cn', 'whois.cnnic.net.cn'), array ('yn.cn', 'whois.cnnic.net.cn'), array ('zlg.br', 'whois.nic.br'), array ('zj.cn', 'whois.cnnic.net.cn'), array ('nu', 'whois.nic.nu'));
    $whocnt = count ($whoisservers);
    for ($x = 0; $x < $whocnt; ++$x)
    {
      $artld = $whoisservers[$x][0];
      $tldlen = intval (0 - strlen ($artld));
      if (substr ($domain, $tldlen) == $artld)
      {
        $whosrv = $whoisservers[$x][1];
        continue;
      }
    }

    return $whosrv;
  }

  function parse_a ($xbase, $search)
  {
    $xbase = str_replace ($search, '', strtolower ($xbase));
    $xbase = substr ($xbase, 3, strlen ($xbase));
    $m = substr (trim ($xbase), 0, 3);
    $d = substr (trim ($xbase), 4, 2);
    $y = substr (trim ($xbase), 7, 4);
    $m = convert_month ($m);
    return $m . '|' . $d . '|' . $y . '|';
  }

  function parse_b ($xbase, $search)
  {
    $xbase = str_replace ($search, '', strtolower ($xbase));
    $xbase = substr ($xbase, 0, 8);
    list ($m, $d, $y) = split ('[/]', $xbase);
    return $m . '|' . $d . '|20' . $y . '|';
  }

  function lookup ($dom)
  {
    $lusrv = get_whois_server ($dom);
    if (!($lusrv))
    {
      return '';
    }

    $fp = @fsockopen ($lusrv, 43);
    @fputs ($fp, $dom . '
');
    $string = '';
    while (!(@feof ($fp)))
    {
      $string .= @fgets ($fp, 128);
    }

    @fclose ($fp);
    $reg = '/Whois Server: (.*?)
/i';
    @preg_match_all ($reg, $string, $matches);
    $secondtry = $matches[1][0];
    if ($secondtry)
    {
      $fp = @fsockopen ($secondtry, 43);
      @fputs ($fp, $dom . '
');
      $string = '';
      while (!(@feof ($fp)))
      {
        $string .= @fgets ($fp, 128);
      }

      @fclose ($fp);
    }

    return $string;
  }

  function whois_parse ($base)
  {
    if (ereg ('expiration date:', strtolower ($base)) == true)
    {
      $xbase = stristr (strtolower ($base), 'expiration date:');
      $xbase = substr ($xbase, 0, 35);
      if (ereg ('200', $xbase) == true)
      {
        return parse_a ($xbase, 'expiration date: ');
      }

      return parse_b ($xbase, 'expiration date: ');
    }

    if (ereg ('expires:', strtolower ($base)) == true)
    {
      $xbase = stristr (strtolower ($base), 'expires:');
      $xbase = substr ($xbase, 0, 35);
      if (ereg ('200', $xbase) == true)
      {
        return parse_a ($xbase, 'expires: ');
      }

      return parse_b ($xbase, 'expires: ');
    }

    if (ereg ('registered through-', strtolower ($base)) == true)
    {
      $xbase = stristr (strtolower ($base), 'registered through-');
      $xbase = substr ($xbase, 0, 35);
      if (ereg ('200', $xbase) == true)
      {
        return parse_a ($xbase, 'registered through- ');
      }

      return parse_b ($xbase, 'registered through- ');
    }

  }

  function whois_2_ns ($base, $which)
  {
    $tok = strtok ($base, '
');
    while ($tok)
    {
      if (ereg ('server', strtolower (trim ($tok))) == true)
      {
        $g = 1;
      }
      else
      {
        if ($g == 1)
        {
          if ($which == 0)
          {
            $buffer = trim ($tok) . '|';
          }
          else
          {
            $tok = trim ($tok);
            $buffer .= gethostbyname ($tok) . '@' . $tok . '|';
          }

          $g = 2;
        }
        else
        {
          if ($g == 2)
          {
            if ($which == 0)
            {
              $buffer .= trim ($tok) . '|';
            }
            else
            {
              $tok = trim ($tok);
              $buffer .= gethostbyname ($tok) . '@' . $tok . '|';
            }

            unset ($g);
          }
        }
      }

      $tok = strtok ('
');
    }

    return $buffer;
  }

  function domain_reg_notice ($oid)
  {
    global $currency;
    global $currency_type;
    $query = 'select ';
    $query .= 'subject, ';
    $query .= 'message, ';
    $query .= 'default_email ';
    $query .= 'from ';
    $query .= 'email_templates ';
    $query .= 'where ';
    $query .= 'emid=\'43\' ';
    $query .= 'limit 0, 1';
    $rs = mysql_fetch_row (mysql_query ($query));
    $default_email = stripslashes (trim ($rs[2]));
    $subject = stripslashes (trim ($rs[0]));
    $message = stripslashes (trim ($rs[1]));
    $query = 'select ';
    $query .= 'whm_id ';
    $query .= 'from ';
    $query .= 'hosting_order ';
    $query .= 'where ';
    $query .= 'oid=\'' . addslashes (trim ($oid)) . '\'';
    $rs = mysql_fetch_row (mysql_query ($query));
    $whm_id = stripslashes (trim ($rs[0]));
    $query = 'select ';
    $query .= 'user.first_name, ';
    $query .= 'user.last_name, ';
    $query .= 'user.organization_name, ';
    $query .= 'user.street_address_1, ';
    $query .= 'user.street_address_2, ';
    $query .= 'user.city, ';
    $query .= 'user.state, ';
    $query .= 'user.zip_code, ';
    $query .= 'user.phone, ';
    $query .= 'user.fax, ';
    $query .= 'tld_chart.cost, ';
    $query .= 'hosting_order.domain_name, ';
    $query .= 'server_config.primary_ns, ';
    $query .= 'server_config.primary_ns_ip, ';
    $query .= 'server_config.secondary_ns, ';
    $query .= 'server_config.secondary_ns_ip, ';
    $query .= 'user.email ';
    $query .= 'from ';
    $query .= 'hosting_order, user, tld_chart, server_config ';
    $query .= 'where ';
    $query .= 'hosting_order.oid=\'' . addslashes (trim ($oid)) . '\' ';
    $query .= 'and ';
    $query .= 'hosting_order.uid=user.uid ';
    $query .= 'and ';
    $query .= 'hosting_order.tld_id=tld_chart.tld_id ';
    if ($whm_id == 0)
    {
      $query0 = 'select ';
      $query0 .= 'whm_id, ';
      $query0 .= 'count(*) ';
      $query0 .= 'from ';
      $query0 .= 'server_config ';
      $query0 .= 'where ';
      $query0 .= 'active_server=\'1\' ';
      $query0 .= 'group by whm_id';
      $rs0 = mysql_fetch_row (mysql_query ($query0));
      if (0 < $rs0[1])
      {
        $whm_id = stripslashes (trim ($rs0[0]));
      }
      else
      {
        $query0 = 'select ';
        $query0 .= 'whm_id, ';
        $query0 .= 'count(*) ';
        $query0 .= 'from ';
        $query0 .= 'server_config ';
        $query0 .= 'where ';
        $query0 .= 'manual_install_active=\'1\' ';
        $query0 .= 'group by whm_id';
        $rs0 = mysql_fetch_row (mysql_query ($query0));
        if (0 < $rs0[1])
        {
          $whm_id = stripslashes (trim ($rs0[0]));
        }
        else
        {
          $query0 = 'select ';
          $query0 .= 'whm_id ';
          $query0 .= 'from ';
          $query0 .= 'server_config ';
          $query0 .= 'limit 0, 1 ';
          $rs0 = mysql_fetch_row (mysql_query ($query0));
          $whm_id = stripslashes (trim ($rs0[0]));
        }
      }

      $query .= 'and ';
      $query .= 'server_config.whm_id=\'' . addslashes (trim ($whm_id)) . '\' ';
    }
    else
    {
      $query .= 'and ';
      $query .= 'hosting_order.whm_id=server_config.whm_id ';
    }

    $query .= 'order by hosting_order.oid asc ';
    $query .= 'limit 0, 1';
    $rs = mysql_fetch_row (mysql_query ($query));
    $first_name = stripslashes (trim ($rs[0]));
    $last_name = stripslashes (trim ($rs[1]));
    $organization_name = stripslashes (trim ($rs[2]));
    $street_address_1 = stripslashes (trim ($rs[3]));
    $street_address_2 = stripslashes (trim ($rs[4]));
    $city = stripslashes (trim ($rs[5]));
    $state = stripslashes (trim ($rs[6]));
    $zip_code = stripslashes (trim ($rs[7]));
    $phone = stripslashes (trim ($rs[8]));
    $fax = stripslashes (trim ($rs[9]));
    $cost = stripslashes (trim ($rs[10]));
    $cost = $currency . sprintf ('%01.2f', $cost) . ' ' . $currency_type;
    $domain_name = stripslashes (trim ($rs[11]));
    $primary_ns = stripslashes (trim ($rs[12]));
    $primary_ns_ip = stripslashes (trim ($rs[13]));
    $secondary_ns = stripslashes (trim ($rs[14]));
    $secondary_ns_ip = stripslashes (trim ($rs[15]));
    $email_address = stripslashes (trim ($rs[16]));
    $generate_date = date ('m/d/Y h:i:s a');
    $subject = str_replace ('{{first_name}}', $first_name, $subject);
    $subject = str_replace ('{{last_name}}', $last_name, $subject);
    $subject = str_replace ('{{company_name}}', $organization_name, $subject);
    $subject = str_replace ('{{address_1}}', $street_address_1, $subject);
    $subject = str_replace ('{{address_2}}', $street_address_2, $subject);
    $subject = str_replace ('{{city}}', $city, $subject);
    $subject = str_replace ('{{state}}', $state, $subject);
    $subject = str_replace ('{{zip}}', $zip_code, $subject);
    $subject = str_replace ('{{phone}}', $phone, $subject);
    $subject = str_replace ('{{fax}}', $fax, $subject);
    $subject = str_replace ('{{domain_reg_price}}', $cost, $subject);
    $subject = str_replace ('{{domain_name}}', $domain_name, $subject);
    $subject = str_replace ('{{primary_ns}}', $primary_ns, $subject);
    $subject = str_replace ('{{primary_ns_ip}}', $primary_ns_ip, $subject);
    $subject = str_replace ('{{secondary_ns}}', $secondary_ns, $subject);
    $subject = str_replace ('{{secondary_ns_ip}}', $secondary_ns_ip, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $subject = str_replace ('{{email_address}}', $email_address, $subject);
    $message = str_replace ('{{first_name}}', $first_name, $message);
    $message = str_replace ('{{first_name}}', $first_name, $message);
    $message = str_replace ('{{last_name}}', $last_name, $message);
    $message = str_replace ('{{company_name}}', $organization_name, $message);
    $message = str_replace ('{{address_1}}', $street_address_1, $message);
    $message = str_replace ('{{address_2}}', $street_address_2, $message);
    $message = str_replace ('{{city}}', $city, $message);
    $message = str_replace ('{{state}}', $state, $message);
    $message = str_replace ('{{zip}}', $zip_code, $message);
    $message = str_replace ('{{phone}}', $phone, $message);
    $message = str_replace ('{{fax}}', $fax, $message);
    $message = str_replace ('{{domain_reg_price}}', $cost, $message);
    $message = str_replace ('{{domain_name}}', $domain_name, $message);
    $message = str_replace ('{{primary_ns}}', $primary_ns, $message);
    $message = str_replace ('{{primary_ns_ip}}', $primary_ns_ip, $message);
    $message = str_replace ('{{secondary_ns}}', $secondary_ns, $message);
    $message = str_replace ('{{secondary_ns_ip}}', $secondary_ns_ip, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    $message = str_replace ('{{email_address}}', $email_address, $message);
    global $email_admin;
    global $site_name;
    if (strcmp ($default_email, '') == 0)
    {
      $default_email = $email_admin;
    }

    $admin_name = $site_name;
    exec_email ($email_admin, $admin_name, $default_email, $admin_name, $subject, $message, 0, 3);
  }

?>
