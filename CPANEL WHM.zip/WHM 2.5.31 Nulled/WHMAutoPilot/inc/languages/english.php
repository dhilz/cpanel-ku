<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/
// top navigation labels
$navigate_selectpackage="Select a Package";
$navigate_domainoptions="Domain Options";
$navigate_addonoptions="Account Addons";
$navigate_accountinfo="Account Information";

// the submit button at the bottom of each page style
$orderbutton_style="style=\"font-family:verdana, arial, helvetica; font-size: 8pt; border-style: solid; border-color: 999999; border-width: 1pxl; background-color: e7e7e7; font-weight: 800\"";

$orderinput_style="style=\"BORDER-STYLE: solid; BORDER-COLOR: #999999; BACKGROUND-COLOR: #ffffff; BORDER-WIDTH: 1px; FONT-FAMILY: Verdana; FONT-SIZE: 8pt\"";

// standard tables used on all pages
$standard_table_width="85%"; // main width of internal tables
$standard_table_padding="2";
$standard_table_spacing="0";
$standard_table_border="0";
$standard_table_align="center";
$standard_table_bgcolor="ffffff";

// if you get java errors about the form ID - change this to 1 or 2
$default_formid="0";

// package highlight table information
$package_table_width="85%"; 
$package_table_padding="2";
$package_table_spacing="0";
$package_table_border="0";
$package_table_align="center";
$package_table_bgcolor="ffffff";
$package_highlight_borderwidth="1px";
$package_highlight_borderstyle="solid";
$package_highlight_bordercolor="#3B3B3B";
$package_highlight_selectcolor="#e7e7e7";
$package_highlight_offcolor="#ffffff";

// error message tables
$error_table_width="85%"; 
$error_table_padding="2";
$error_table_spacing="2";
$error_table_border="style='border-style: solid; border-color: 990000; border-width: 1pxl'";
$error_table_align="center";
$error_table_bgcolor="ffcaca";

// standard text used throughout the order system
$text_monthly="Monthly";
$text_month="Month";
$text_quarterly="Quarterly";
$text_semiannual="Semi-Annually";
$text_annual="Annually";
$text_setupfee="Setup Fee";
$text_nosetupfee="No Setup Fee";
$text_available="available";
$text_primarynameserver="Primary Nameserver:";
$text_secondarynameserver="Secondary Nameserver:";
$text_buy="Buy";
$text_addonname="Addon Name";
$text_addoncost="Addon Cost";
$text_goback="<b>Go Back</b>";

//step_four.php text variables
$text_clientinformation="<b>Client Information</b>";
$text_loggedinas="Logged in as:";
$text_existinglogin="<font size='-2'>[<a href='".$http_web."/elogin.php?sid=".trim($sid)."&gid=".trim($gid)."'><b>Existing clients click here to login</b></a>]";
$text_firstname="First Name";
$text_lastname="Last Name";
$text_required="<font size='-2' color='999999'>[REQUIRED]";
$text_companyname="Organization Name";
$text_address1="Mailing Address";
$text_optional="<font size='-2' color='#e8e8e8'>[OPTIONAL]</font>";
$text_city="City";
$text_state="State/Province";
$text_postalcode="Postal Code";
$text_country="Country";
$text_phone="Phone Number";
$call_hint="<font size='1' color='#990000'>International Customers: use 011 + country code + phone number</font>";
$text_fax="Fax Number";
$text_emailaddress="EMail Address";
$text_cc_bin="<b>Bank Indentification Code (BIN)</b><br><img src='".$http_images."/space.gif' width='15' height='9'><font size='-2'>The first 6 digits of your credit card number.</font>";
$text_bin="Enter BIN Number";
$text_clientarealogininfo="<b>Client Area Login</b><BR><img src='".$http_images."/space.gif' width='15' height='9'><font size='-2'>Client Management area login - your cPanel login will differ from this login";
$text_chooseusername="Choose Username";
$text_choosepassword="Choose Password";
$text_verifypassword="Verify Password";
$text_advertisinginfo="<b>Advertising Information</b>";
$text_howfound="How did you find us?";
$text_ifother="If other, please specify";
$text_clientnotes="<b>Order Notes / Special Instructions</b>";
$text_clientnotes2="<img src='".$http_images."/space.gif' width='15' height='9'><font size='-2'>Please enter any notes or special instructions you may have below";
$text_termsofservice="<b>Terms of Service</b>";
$text_termsofservice2="Check to agree to our terms of service agreement.";
$text_viewterms="View the TOS agreement by clicking here.";

//verify_order.php text variables
$text_packageordered="Package Ordered";
$text_clicktoedit="<font color='#990000'>click to edit</font></a>]";

#for dedicated packages
$text_gigdrive="GB Disk Drive";
$text_gigtransfer="GB Transfer";
$text_serveroptions="<b>Server Options</b>";
$text_serverhostname="Server Hostname";
$text_nameservers="Nameservers";
$text_rootpassword="Root Password";

#for standard hosting packages
$text_megwebspace="MB Web Space";
$text_megwebtransfer="MB Transfer";
$text_emailaddresses="EMail Addresses";
$text_unlimited="Unlimited";
$text_none="None";
$text_onetimefee="One Time Fee";
$text_domainoptions="<b>Domain Options</b>";
$text_domainname="Domain Name";
$text_domainregistration="Domain Registration";
$text_domainregcost="Domain Registration Cost";
$text_peryear="per Year";
$text_domainexpireson="Domain Expires on";
$text_wewillregister="We will register this domain for you.";
$text_youwilltransfer="You will register or transfer this domain.";
$text_ournameservers="Our Nameservers";

?>