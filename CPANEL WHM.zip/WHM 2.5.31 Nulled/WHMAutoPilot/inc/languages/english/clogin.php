<?php 
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/
$error_usernotfound = "User not found or login incorrect";
$text_clientarea = "<b>Client Area Login</b>";
$text_ifthisiserror = "If you feel this is an error, please <a href='mailto:".$email_admin."?subject=Login Problems'>click here to contact us.</a>";
$text_enterusername = "Enter Username";
$text_enterpassword = "Enter Password";
$text_loginnow = "Login Now &gt;&gt;";
$text_resendaccount = "<b>Resend your Account Logins</b>";
$text_informationemailed = "Your account information was emailed successfully";
$text_whenyoureceive = "Once you have your logins, simply login using the box above to continue with your order";
$text_norecords = "No records found for: <b>".$email."<b>";
$text_resendnow = "Resend Now &gt;&gt;";
$text_enteremail = "Enter EMail";

?>