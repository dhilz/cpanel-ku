<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/
$text_Home = "Home";
$text_MyAccount = "My Account"; 
$text_Register = "Register"; 
$text_Support = "Support"; 
$text_Demo = "Demo"; 
$text_AboutUs = "About Us";
$text_Agreements = "Agreements"; 
$text_Affiliates = "Affiliates"; 
$text_Links = "Links"; 
?>