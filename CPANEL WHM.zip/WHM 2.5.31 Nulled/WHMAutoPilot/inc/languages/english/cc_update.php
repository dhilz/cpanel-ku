<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/

$error_nofirstname = "<font color='#C60C08'><b>ERROR!</b></font> Please enter the card holders first name to continue.";
$error_nolastname = "<font color='#C60C08'><b>ERROR!</b></font> Please enter the card holders last name to continue.";
$error_noaddress = "<font color='#C60C08'><b>ERROR!</b></font> Please enter the card holders address to continue.";
$error_nocity="<font color='#C60C08'><b>ERROR!</b></font> Please enter the card holders city to continue.";
$error_nozip="<font color='#C60C08'><b>ERROR!</b></font> Please enter the card holders zip code to continue.";
$error_nophone = "<font color='#C60C08'><b>ERROR!</b></font> Please enter the card holders phone number to continue.";
$error_nocard = "<font color='#C60C08'><b>ERROR!</b></font> Please enter the card number to continue.";
$error_noexpiration = "<font color='#C60C08'><b>ERROR!</b></font> Please enter the card expiration dates to continue.";
$text_updateccinfo = "Update Credit Card Information";
$text_ccpersonalinfo = "Credit Card Personal Information";
$text_firstname = "First Name";
$text_lastname = "Last Name";
$text_address1 = "Address";
$text_city = "City";
$text_state = "State";
$text_zip = "Zip Code";
$text_country = "Country";
$text_phone = "Phone";
$text_fax = "Fax";
$text_email = "EMail Address";
$text_ccinfo = "Credit Card Information";
$text_useexisting = "Use Exsiting Card";
$text_enternewcc = "No, Enter New Card Information Below";
$text_newccnumber = "New Card Number";
$text_newccexp = "New Card Expiration";
$text_updatenow = "Update Now";

?>