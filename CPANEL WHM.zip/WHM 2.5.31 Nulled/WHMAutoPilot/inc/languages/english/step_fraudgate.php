<?php

// --- FRAUDGATE FILE for WHMAutopilot module --- //
$continue = "Click to continue";
$finish = "Click after call is completed";
$refresh = "Click to refresh page";
$step1 = "<p align=\"center\"><b><font style=\"font-size: 12pt\">Phone Verification - Step One</font>";
$step2 = "<p align=\"center\"><b><font style=\"font-size: 12pt\">Phone Verification - Step Two</font>";
$step3 = "<p align=\"center\"><b><font style=\"font-size: 12pt\">Phone Verification - Step Three</font>";

$about_to_call_text = "We will be placing an automated phone call to verify your order. Please click on the link below to continue.
                 <p style='color: #990000'>Your order may be declined depending on the results on this call.</p>
                 <p>The phone number we will be calling is <b>";
$calling_text = "<b>Calling ";
$few_minutes_text = "</b><p>Please allow a few minutes for the call to be initiated.
                  <br>After the call is finished, please wait one minute before continuing to allow our system to process the call.";
$random_text = "<p><b>PLEASE HAVE THIS NUMBER READY WHEN THE CALL OCCURS:</b><b style='color: #990000'><p align='center'>";

$pending = "Your call is being processed. Thank you for your patience.";
$success = "Your call was successful. Click below to continue with your order.";
$failed = "Your call was unsucessful. You will not be able to continue with your order. Please contact our support with any questions.
        <p>The reason for your failed call is as follows: <b style='color: #990000'>";
$fg_step_text = "Continue >>";
$order_number_text_begin = "<div align='center'><h2>Your order number is: ";
$order_number_text_end = "</h2></div>";
$invoice_page_notice = "<div align='center'>To verify your order, we will place an automated phone call. Please have your order number on hand when you get the phone call.</div>";
?>
