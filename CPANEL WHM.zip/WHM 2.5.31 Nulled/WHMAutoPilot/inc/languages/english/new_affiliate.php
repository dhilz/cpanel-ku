<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/

#text variables
$text_becomeaffiliate = "Become an Affiliate";
$text_commisionratesasof = "Below are the commission rates as of  ";
$text_packagename ="Package Name";
$text_commissiontype = "Commission Type";
$text_commissionamount = "Commission Amount";
$text_pleasecomplete = "Please complete the following fields to begin the process";
$text_payableto = "Make checks payable to";
$text_SSN = "Tax ID / SSN";
$text_pleasecomplete2="Please complete all fields below";
$text_submitrequest = "Submit Affiliate Request";
?>