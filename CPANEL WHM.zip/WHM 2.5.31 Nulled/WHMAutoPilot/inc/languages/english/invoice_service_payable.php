<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/
$text_payableinvoice = "Payable Invoice for";
$text_remitpayment = "Remit payment to";
$text_invoicedate = "Invoice Date";
$text_invoicenumber = "Invoice Number";
$text_invoicedue = "Invoice Due";
$text_terms = "Terms";
$text_autobilling = "Auto Billing";
$text_payableto = "Payable to";
$text_invoicedate = "Invoice Date";
$text_invoicedto = "Invoiced to";
$text_phone = "Phone";
$text_fax = "Fax";
$text_please = "Please";
$text_printandmail = "print and mail this invoice to the address given above.";
$text_clicktopay = "click the icon below to make payment now:";
$text_clicktopaynow = "Click to pay this invoice now.";
$text_invoicedetails = "Invoice Details";
$text_quantity = "Quantity";
$text_service = "Service";
$text_cost = "Cost";
$text_subtotal = "Subtotal";
$text_additionalinformation = "Additional Information";
$text_total = "Total";
$text_amount = "Amount";
$text_invoiceamount = "Total Invoice Amount";
$text_invoicestatus = "Invoice Status";
$text_none = "None";

?>