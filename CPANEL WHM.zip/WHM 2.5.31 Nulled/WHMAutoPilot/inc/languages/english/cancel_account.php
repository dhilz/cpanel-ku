<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/
$text_cancelhostingfor = "Cancel Hosting for";
$text_requestbeingprocessed = "Your cancel request is being processed.";
$text_required = "Required";
$text_pleaseexplain = "Please explain why you want to cancel";
$text_pleasecomplete = "Please complete all fields below.";
$text_submitcancel = "Submit Cancel Request";


?>