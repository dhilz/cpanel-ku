<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/

//step_one.php variables
$text_iamtransfering = "I have a domain and will update my nameservers";
$text_iwantregistration = "I want $site_name to register my domain, this is a new domain";
$stepone_viewhostingpackages1="View our {{parse1}} Packages"; // do not remove the {{parse}} tags
$stepone_viewhostingpackages2="View our {{parse3}} Packages"; // do not remove the {{parse}} tags

// ERROR MESSAGES IN STEP_ONE.PHP
$stepone_errornopackage="<b>ERROR!</b> You must <b>choose a package</b> to continue.";
$stepone_errorpromoexpired="<b>ERROR!</b> This promotion code, <b>".$promotion_code."</b>, has expired.";
$stepone_errorpromoinvalid="<b>ERROR!</b> This promotion code, <b>".$promotion_code."</b>, is invalid.";

$stepone_choosepaymentterm="Choose Payment Term";
$stepone_choosepayment="<b>Choose Payment Method</b>";
$stepone_promoreferralstitle="<b>Promotions / Referrals</b>";
$stepone_promoinput="Enter Promotion Code:";
$stepone_referralinput="Enter Referrer ID:";
$stepone_optional="<i>Optional</i>";
$stepone_submitbutton="Click to Continue &gt&gt";
?>