<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/

$text_commisionratesasof = "Below are the available commission rates as of ";
$text_noplansfound = "No plans found";
$text_yourcommissionearnings = "Below are your commission earnings as of ";
$text_activeaffiliatemenu = "Active Affiliate Menu";
$text_packagename ="Package Name";
$text_commissiontype = "Commission Type";
$text_commissionamount = "Commission Amount";
$text_referrallink = "Referral Link: ";
$text_volume = "Volume";
$text_commission = "Commission";
$text_yield = "Yield";
$text_norecordsfound = "No records found";
$text_onetimepayout = "One Time Payout";
$text_percbased = "% Based Packages";
$text_onetimebased = "One Time Payout Based Packages";
?>