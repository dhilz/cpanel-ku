<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/
$text_domaininvoicehistory = "<b>Domain Invoice History</b>";
$text_view = "&nbsp;<b>View</b>";
$text_invoice = "&nbsp;<b>Invoice</b>";
$text_domainname = "&nbsp;<b>Domain Name</b>";
$text_created = "&nbsp;<b>Created</b>";
$text_invoicedue = "&nbsp;<b>Invoice Due</b>";
$text_noinvoicesfound = "<font color='#990000'>No hosting invoices found in the database for this domain.</font>";
$text_altviewformatted = "Click to view a printable invoice.";
?>