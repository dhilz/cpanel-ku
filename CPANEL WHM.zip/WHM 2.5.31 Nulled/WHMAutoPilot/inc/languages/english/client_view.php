<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/
$text_hostinginfo = "Hosting Account Information";
$text_accountispending = "Account is pending.";
$text_domainname = "Domain Name:";
$text_domainexpires = "Domain Expires:";
$text_update = "Update &gt;";
$text_servername = "Server Name:";
$text_accountcreatedon = "Account Created on:";
$text_hostingpackage = "Hosting Package:";
$text_installon = "Install on Server:";
$text_installedon = "Installed on:";
$text_currentpayment = "Current Payment Type:";
$text_cpaneluser = "cPanel Username:";
$text_visitcpanel = "visit cPanel:";
$text_cpanelpass = "cPanel Password:";
$text_ipaddress = "IP Address:";
$text_primaryns = "Primary NS";
$text_secondaryns = "Secondary NS:";
$text_serverspecs = "Server Specifications:";
$text_notes = "Notes / Special Instructions:";
$text_nonerecorded = "None Recorded.";
$text_rightcolumnwidth = "65%";
$text_leftcolumnwidth = "35%";
?>