<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/

$text_submitticket = "Submit Ticket";
$text_ticketreceived = "Your ticket was received <b>succesfully!</b>";
$text_willcontact = "A member of our support team will contact you shortly.";
$text_continue = "continue";
$text_youwrote = "You wrote";
$text_youremail = "Your EMail";
$text_enterissue = "Please enter your support issue below. We will reply with a response as soon as possible";
$text_thankspatience = "Thank you for your patience.";
$text_pleasecomplete = "Please complete all fields below.";
$text_email = "Enter EMail";
$text_required = "required";
$text_entersubject = "Enter Subject";
$text_enterissue2 = "Enter your issue below";
$text_openticket = "Open Ticket Now &gt;";
$text_issuesubject = "Issue Subject";
$text_issuedetails = "Issue Details";
$text_ticketid = "Ticked ID";
?>