<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/
$text_activeaffiliatedetails="Active Affiliate Details Per Package";
$text_affiliatesthatyouhaverefered = "Below are the affiliates that you have refered as of";
$text_domain = "Domain";
$text_client = "Client";
$text_monthlypayout = "Monthy Payout";
$text_created = "Created";
$text_norecords = "No records found.";

?>