<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/

//step_four.php variables

//COLUMN WIDTHS
$stepfour_leftcolumn="30%";
$stepfour_rightcolumn="70%";

// ERROR CODES
$stepfour_nofirstname="<b>ERROR!</b> You must enter your <b>first name</b> to continue.";
$stepfour_nolastname="<b>ERROR!</b> You must enter your <b>last name</b> to continue.";
$stepfour_noaddress="<b>ERROR!</b> You must enter your <b>street address</b> to continue.";
$stepfour_nocity="<b>ERROR!</b> You must enter your <b>city</b> to continue.";
$stepfour_nostate="<b>ERROR!</b> You must enter your <b>state or province</b> to continue.";
$stepfour_nozipcode="<b>ERROR!</b> You must enter your <b>postal code</b> to continue.";
$stepfour_nophone="<b>ERROR!</b> You must enter your <b>phone number</b> to continue.";
$stepfour_noemailaddress="<b>ERROR!</b> You must enter your <b>EMail address</b> to continue.";
$stepfour_nousername="<b>ERROR!</b> You must choose a <b>username</b> to continue.";
$stepfour_nopassword="<b>ERROR!</b> Your <b>passwords</b> were left blank or do not match.";
$stepfour_nospecify="<b>ERROR!</b> Please specify the way that <b>you found us</b> in order to continue.";
$stepfour_nochoseother="<b>ERROR!</b> You choose other as how you found us, <b>please specify</b> in order to continue.";
$stepfour_mustacceptterms="<b>ERROR!</b> You must agree to our <b>terms of service</b> to continue.";
$stepfour_usernametaken="<b>ERROR!</b> The username <b>".$username."</b> already in use.";
$stepfour_emailaddressinuse="<b>ERROR!</b> The EMail address <b>".$email."</b> already in use.";
$stepfour_nobin="<b>ERROR!</b> Please enter your BIN number to continue.";

$stepfour_submitbutton="Click to Verify Your Order &gt&gt";
?>