<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/
$error_nofirstname = "<b>ERROR!</b> You must enter your <b>first name</b> to continue.";
$error_nolastname = "<b>ERROR!</b> You must enter your <b>last name</b> to continue.";
$error_nostreet = "<b>ERROR!</b> You must enter your <b>street address</b> to continue.";
$error_nocity = "<b>ERROR!</b> You must enter your <b>city</b> to continue.";
$error_nostate = "<b>ERROR!</b> You must enter your <b>state</b> to continue.";
$error_nopostalcode = "<b>ERROR!</b> You must enter your <b>postal code</b> to continue.";
$error_nophone = "<b>ERROR!</b> You must enter your <b>phone number</b> to continue.";
$error_noemail = "<b>ERROR!</b> You must enter your <b>EMail address</b> to continue.";
$error_nousername = "<b>ERROR!</b> You must choose a <b>username</b> to continue.";
$error_nopassword = "<b>ERROR!</b> Your <b>passwords</b> were left blank or do not match.";
$error_nospecify = "<b>ERROR!</b> Please specify the way that <b>you found us</b> in order to continue.";
$error_nochoseother = "<b>ERROR!</b> You choose other as how you found us, <b>please specify</b> in order to continue.";
$error_mustacceptterms="<b>ERROR!</b> You must agree to our <b>terms of service</b> to continue.";
$error_usernametaken="<b>ERROR!</b> The username <b>".$username."</b> already in use.";
$error_emailaddressinuse="<b>ERROR!</b> The EMail address <b>".$email."</b> already in use.";
$error_nopayablefield = "<b>ERROR!</b> You must complete the <b>Payable to</b> field to continue.";
$error_noSSN = "<b>ERROR!</b> You must complete the <b>Social Security Number</b> field to continue.";

#text variables
$text_becomeaffiliate = "Become an Affiliate";
$text_commisionratesasof = "Below are the available commission rates as of ";
$text_packagename ="Package Name";
$text_commissiontype = "Commission Type";
$text_commissionamount = "Commission Amount";
$text_affiliateinfo = "Affiliate Information";
$text_payableto = "Payable to";
$text_required = "[Required]";
$text_optional = "[<font color='#990000'><i>Optional</i></font>]";
$text_SSN = "Social Security Number";
$text_firstname="First Name";
$text_lastname="Last Name";
$text_companyname="Organization Name";
$text_address1="Street Address";
$text_city="City";
$text_state="State/Province";
$text_postalcode="Postal Code";
$text_country="Country";
$text_phone="Phone Number";
$text_fax="Fax Number";
$text_emailaddress="EMail Address";
$text_clientarealogininfo="<b>Client Area Login</b>";
$text_chooseusername="Choose Username";
$text_choosepassword="Choose Password";
$text_verifypassword="Verify Password";
$text_advertisinginfo="<b>Advertising Information</b>";
$text_howfound="How did you find us?";
$text_ifother="If other, please specify";
$text_termsofservice="<b>Terms of Service</b>";
$text_termsofservice2="Check to agree to our terms of service agreement.";
$text_viewterms="View the TOS agreement by clicking here.";
$text_clicktorequestaffiliatestatus = "Click to Request Affiliate Status &gt&gt";

?>