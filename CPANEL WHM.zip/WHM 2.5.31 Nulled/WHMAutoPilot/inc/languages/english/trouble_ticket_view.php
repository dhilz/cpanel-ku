<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/

$text_troubleticketsystem = "Trouble Ticket System";
$text_pleasecomplete = "Please complete all fields below.";
$text_reply = "Enter Reply";
$text_updateticket = "Update Ticket &gt;&gt;";
$text_ticketstatus = "Ticket Status";
$text_active = "Active";
$text_resolved = "Did this resolve your issue?";
$text_yes = "Yes";
$text_no = "No";
$text_closed = "Closed";
$text_pleaseprint = "Please print this for your records";
$text_adminwrote = "Admin Wrote:";
$text_clientwrote = "Client Wrote";
$text_origticket = "Original Ticket";


?>