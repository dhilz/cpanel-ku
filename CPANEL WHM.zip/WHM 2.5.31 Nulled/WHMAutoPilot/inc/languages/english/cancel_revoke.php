<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/

$text_cancelrevoke = "Revoke Hosting Cancel Request for";
$text_processed = "Your revoke of the cancel request was processed successfully.";
$text_pleasecomplete = "Please complete all fields below.";
$text_pleaseexplain = "Please explain why you want to revoke the cancel request";
$text_required = "REQUIRED";
$text_revoke = "Revoke Cancel Request";

?>
