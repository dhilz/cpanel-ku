<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/

//step_three.php variables
$stepthree_submitbutton="Click to Continue &gt&gt";

// highlight color
$stepthree_highlight="#eeeeee";

// text used
$stepthree_nameserverchoices="Enter your nameserver prefixes choices";

// style
$stepthree_descriptionstyle="style='border-style: solid; border-color: 999999; border-width: 1pxl'><div style='padding:3;color:797979'>";
?>