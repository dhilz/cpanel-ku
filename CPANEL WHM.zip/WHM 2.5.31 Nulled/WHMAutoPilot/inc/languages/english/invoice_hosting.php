<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/
$text_readonlyinvoice = "Read Only Invoice for";
$text_remitpayment = "Remit payment to";
$text_invoicenumber = "Invoice Number";
$text_invoicedue = "Invoice Due";
$text_terms = "Terms";
$text_autobilling = "Auto Billing";
$text_payableto = "Payable to";
$text_invoicedate = "Invoice Date";
$text_invoicedto = "Invoiced to";
$text_phone = "Phone";
$text_fax = "Fax";
$text_thisinvoice = "This invoice";
$text_was = " was";
$text_willbe = " will be";
$text_paidusing = " paid using";
$text_altpaymentmethod = "This is the payment method for this invoice";
$text_invoicedetails = "Hosting Invoice Details";
$text_package = "Package";
$text_domainname = "Domain Name";
$text_onetimefees = "One Time Fees";
$text_recurringfees = "Recurring Fees";
$text_subtotal = "Subtotal";
$text_addonsordered = "Addons / Extras Ordered";
$text_invoiceamount = "Total Invoice Amount";
$text_invoicestatus = "Invoice Status";
$text_none = "None";

?>