<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/

//verify_order.php text variables
$text_packageordered="Package Ordered";
$text_clicktoedit="<font color='#990000'>Click to Edit</font></a>]";
$text_accountaddons="<b>Package Add-ons</b>";
$text_accountinformationtitle="<b>Account Information</b>";
$text_clientfullname="Client Name";
$text_clientusername="Members Area Username";
$text_clientpassword="Members Area Password";
$text_youagreeterms="You have accepted the Terms of Service.";
$text_youdidnotagree="You NOT have accepted the Terms of Service.";
$text_nonerecorded="N/A";
$text_freetrial="Free Trial";
$text_firstchargeamount="Amount billed initially";
$text_totalduetoday="Total Due Today";
$text_totalrecurring="Total Recurring ".$payment_term;
$text_paymentmethod="Payment Method";
$text_packagedetails = "Package Details";
$verifyorder_submitbutton="Click to Proceed to Secure Payment Processing  &gt&gt";
$verifyorder_submitbutton_fraudcall="Click to Verify Your Phone Number  &gt&gt";
$text_cost = "Cost:";
$text_nocost = "No Cost";
$text_setupfee = "Setup Fee:";
$text_onetimefee = " One Time Fee";
$text_permonth = " Per Month";
$text_peryear = " Per Year";
$text_nsprefix = "NS Prefix:";
$text_reflectsdiscount = "Reflects monthly Promotional Discount of";
$text_reflectsonetimediscount  = "Reflects one time Promotional Discount of";
$text_offhostingfees = "off hosting fees";

//COLUMN WIDTHS
$verifyorder_leftcolumn="40%";
$verifyorder_rightcolumn="60%";


$text_firstname="Name";
$text_lastname="Last Name";
$text_companyname="Company";
$text_address1="Address";
$text_city="City";
$text_state="State/Province";
$text_postalcode="Zip Code";
$text_country="Country";
$text_phone="Phone";
$text_fax="Fax";
$text_emailaddress="EMail Address";
$text_howfound="How did you find us?";
$text_ifother="If Other, please specify";
$text_clientnotes="<b>Notes / Special Instructions</b>";
?>