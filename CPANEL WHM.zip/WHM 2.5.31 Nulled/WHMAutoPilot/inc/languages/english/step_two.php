<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/

//step_two.php variables

//ERROR MESSAGES IN STEP_TWO.PHP

$steptwo_serverhostname="<b>ERROR!</b> You must specify a full <b>Server Hostname</b> to continue.";
$steptwo_serverrootpass="<b>ERROR!</b> You must specify a <b>Server Root Password</b> to continue.";
$steptwo_nameserversmissing="<b>ERROR!</b> You must specify a full set of <b>Nameserver Prefixes</b> to continue.";
$steptwo_nodomainerror="<b>ERROR!</b> You must specify a <b>domain name</b> to continue.";
$steptwo_domain_taken_error="<b>ERROR!</b> This domain name is <b>not available</b> for registration.";
$steptwo_domainalreadyinuse="<b>ERROR!</b> This domain name is already in use on our servers.";


//DEDICATED SERVER OPTIONS ON STEP_TWO.PHP

$steptwo_dedicatedoptions="<b>Please enter the server options that you will use below:</b>";
$steptwo_serverhostname="Server Hostname:";
$steptwo_dednameserverprefix="Prefix is added to the Server Hostname domain.";
$steptwo_serverrootpass="Server Root Password:";
$steptwo_nameserverprefix="Nameserver Prefix:";
$steptwo_primaryprefix="Prefix 1:";
$steptwo_secondaryprefix="Prefix 2:";

//STANDARD OPTIONS AND TEXT ON STEP_TWO.PHP

$steptwo_enterdomain="<b>Please enter the domain name that you will use below:</b>";
$steptwo_pleasespecifyoptions="<b>Please Specify Registration Options:</b>";
$steptwo_registerforme[0]="Your total cost to register this domain is <b>";
$steptwo_registerforme[1]="</b>";
$steptwo_iwillregister1="<b>*</b> I will register or transfer this domain name";
$steptwo_iwillregister2="to the following nameservers:";
$steptwo_domainexpirytext="<b>*</b> Enter the date this domain will expire and we will send you a notice<br><img src='".$http_images."/space.gif' width='14' height='1'>30 days before this domain expires.";
$steptwo_expoptional="ex. MM/DD/YYYY [Optional Field]";
$steptwo_submitbutton="Click to Continue &gt&gt";

$steptwo_startwhypen="Domains cannot start with a <b>-</b>";
$steptwo_endwhypen="Domains cannot end with a <b>-</b>";
$steptwo_dash="Domains cannot include the character <b>_</b>";
$steptwo_invalid_char="You have entered <b>one or more</b> invalid characters.";

?>