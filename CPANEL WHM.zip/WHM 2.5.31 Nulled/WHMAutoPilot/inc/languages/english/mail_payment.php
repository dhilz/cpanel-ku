<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/

$text_orderreceived = "Order was received on";
$text_at = "at";
$text_sendpaymentto = "Send Payment to";
$text_clientinfo = "Client Information";
$text_phone = "Phone";
$text_fax = "Fax";
$text_email = "EMail";
$text_orderdetails = "Hosting Order Details";
$text_hostname = "Server Hostname";
$text_nameservers = "Nameservers";
$text_domainname = "Domain Name";
$text_domainregisration = "Domain Registration";
$text_wewillregister = "We will register this domain for you at a cost of ";
$text_peryear = "per Year.";
$text_youwillregister = "You will register this domain name.";
$text_usenameserver = "Use this Nameserver";
$text_domainexpires = "Domain Expire Date";
$text_packageordered = "Package Ordered";
$text_totalduenow = "Total Due Now";
$text_totalrecurring = "Total Reoccurring";
$text_clientareausername = "Client Area Username";
$text_clientareapassword = "Client Area Password";
$text_terms = "Terms of Service";
$text_youhaveagreed = "I have agreed to the terms of service agreement";
$text_notes = "Notes / Special Instructions";
$text_paymentmethod ="Payment Method";
$text_none = "None Recorded.";
$text_personalcheck = "Personal/Business Check";
$text_moneyorder = "Money Order";
$text_cash = "Cash";

?>