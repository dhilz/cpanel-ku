<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/
$text_weexperiencedproblems = "We experienced problems installing your account on our servers";
$text_orderreceived = "Order was received on";
$text_staffcontacted = "Our network team was contacted. We will manually install your account and send you an EMail notification when it's ready";
$text_thankspatience = "Thank you for your patience";
$text_clientinfo = "Client Information";
$text_phone = "Phone";
$text_fax = "Fax";
$text_email = "EMail";
$text_orderdetails = "Hosting Order Details";
$text_serverhostname= "Server Hostname";
$text_nameservers = "Nameservers";
$text_domainname = "Domain Name";
$text_domainregistration ="Domain Registration";
$text_wewillregister = "We will register this domain for you at a cost of ";
$text_peryear = "per Year.";
$text_youwillregister = "You will register this domain name.";
$text_usenameserver = "Use this Nameserver";
$text_domainexpires = "Domain Expire Date";
$text_packageordered = "Package Ordered";
$text_totalduenow = "Total Due Now";
$text_totalrecurring = "Total Reoccurring";
$text_clientareausername = "Client Area Username";
$text_clientareapassword = "Client Area Password";
$text_pathtoclientarea = "Path to Client Area";
$text_whmusername = "cPanel/FTP Username";
$text_whmpassword = "cPanel/FTP Password";
$text_pathtocpanel = "Path to cPanel";
$text_terms = "Terms of Service";
$text_youhaveagreed = "I have agreed to the terms of service agreement";
$text_notes = "Notes / Special Instructions";
$text_paymentmethod ="Payment Method";
$text_none = "None Recorded.";
?>