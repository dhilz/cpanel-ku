<?php
/*-------------------------------------------------------+
| Benchmark Designs, LLC - Copyright 2003                |
| WHM AutoPilot Language Variables File - English        |
+-------------------------------------------------------*/

$text_clientinfo = "Client Information";
$text_name = "Name:";
$text_organization = "Organization:";
$text_address = "Address:";
$text_phone = "Phone:";
$text_update = "Update";
$text_fax = "Fax:";
$text_changeemail = "Change EMail:";
$text_changepass= "Change password:";
$text_SSN = "SSN/ Tax ID:";
$text_affiliatepaysto = "Affiliate Pays to:";
$text_adminnews = "<b>Admin / Site News</b>";
$text_neworder = "<b>Place New Order</b>";
$text_clickhere = "Click to begin &gt;";
$text_opentroubletickets = "<b>Open Trouble Tickets</b>";
$text_newticket = "submit new ticket";
$text_noopentickets = "No open trouble tickets found in our database.";
$text_issuesubject = "Issue Subject";
$text_submitted = "Submitted";
$text_status = "Status";
$text_openticket = "Open Ticket";
$text_close = "close";
$text_delete = "delete";
$text_reopen = "reopen";
$text_closedticket = "Closed Ticket";
$text_currenthosted = "Current Hosted Domains";
$text_showall = "Show All";
$text_pending = "Pending";
$text_active = "Active";
$text_suspended = "Suspended";
$text_view = "View";
$text_domainname = "Domain Name";
$text_cancelacct = "Cancel Acct";
$text_created = "Created on";
$text_altclickhistory = "click to view the invoice history for this domain.";
$text_pendingcancel = "Pending Cancel";
$text_resendsuccesful = "<b>Resent Successfully!</b>";
$text_resendwelcome = "Resend EMail";
$text_cancel = "cancel";
$text_revoke = "revoke request";
$text_cancelled = "Cancelled";
$text_noorders = "No orders found in the database.";
$text_nopending = "No pending orders found in the database.";
$text_noactive = "No active orders found in the database.";
$text_nosuspended = "No suspended orders found in the database.";
$text_billableheader = "Billable Service Invoice History";
$text_invoice = "Invoice";
$text_clientname = "Client Name";
$text_created = "Created";
$text_invoiceterms = "Invoice Terms";
$text_status = "Status";
$text_printableinvoice = "Click to view a printable invoice.";
$text_nobillableservices = "No billable service invoices found in the database.";
?>