<?PHP
$cksid=mysql_fetch_row(mysql_query("select count(*) from session_history where sid='".addslashes(trim($sid))."'"));

if ($cksid[0]<=0) { header("Location: ".$http_web."/step_one.php"); exit; }
else if (!isset($sid)) { header("Location: ".$http_web."/step_one.php"); exit; }
else if (is_locked($sid)==1) { header("Location: ".$http_web."/step_one.php"); exit; }
else if (isset($sid)&&!isset($submit))
	{
	$query="select ";
	$query.="session_history.domain_name, ";			// 0
	$query.="session_history.domain_registration, ";	// 1
	$query.="session_history.domain_expire, ";			// 2
	$query.="session_history.pid, ";					// 3
	$query.="session_history.whm_id, ";					// 4
	$query.="plan_specs.dedicated, ";					// 5
	$query.="session_history.pns1, ";					// 6
	$query.="session_history.pns2, ";					// 7
	$query.="session_history.root_pw, ";				// 8
	$query.="session_history.server_hostname, ";		// 9
	$query.="session_history.tld ";						// 10
	$query.="from ";
	$query.="session_history, ";
	$query.="plan_specs ";
	$query.="where ";
	$query.="session_history.sid='".addslashes(trim($sid))."' ";
	$query.="and ";
	$query.="session_history.pid=plan_specs.pid ";
	$query.="order by session_history.sid asc ";
	$query.="limit 0, 1";

	$rs=mysql_fetch_row(mysql_query($query));

	$pid=stripslashes(trim($rs[3]));
	$domain_name=stripslashes(trim($rs[0]));
	$domain_registration=stripslashes(trim($rs[1]));
	$ds=$domain_registration;
	$dedicated=stripslashes(trim($rs[5]));
	$pns1=stripslashes(trim($rs[6]));
	$pns2=stripslashes(trim($rs[7]));
	$root_pw=stripslashes(trim($rs[8]));
	$server_hostname=stripslashes(trim($rs[9]));
	$tld_id=stripslashes(trim($rs[10]));

	list($domain_expire_m, $domain_expire_d, $domain_expire_y)=split("[/]", $rs[2]);
	}

// start form handler

if (isset($xdedicated)&&isset($submit))
	{
	if (trim($server_hostname)=="") { $e0=true; }
	if (trim($domain_name)=="") { $e1=true; }
	if (trim($root_pw)=="") { $e2=true; }
	if (trim($pns1)=="") { $e3=true; }
	if (trim($pns2)=="") { $e4=true; }

	if (!isset($e0)&&!isset($e1)&&!isset($e2)&&!isset($e3)&&!isset($e4))
		{
		$update="update session_history set ";
		$update.="domain_name='".addslashes(trim($domain_name))."', ";
		$update.="server_hostname='".addslashes(trim($server_hostname))."', ";
		$update.="root_pw='".addslashes(trim($root_pw))."', ";
		$update.="pns1='".addslashes(trim($pns1))."', ";
		$update.="tld='".addslashes(trim(str_replace("|", "", $tld)))."', ";
		$update.="pns2='".addslashes(trim($pns2))."' ";
		$update.="where sid='".addslashes(trim($sid))."'";
		
		mysql_query($update);
		
		$query="select ";
		$query.="plan_specs.addon_gid, ";
		$query.="addon_groups.group_addons ";
		$query.="from ";
		$query.="plan_specs, ";
		$query.="addon_groups ";
		$query.="where ";
		$query.="plan_specs.pid='".addslashes(trim($pid))."' ";
		$query.="and ";
		$query.="plan_specs.addon_gid=addon_groups.addon_gid ";
		$query.="order by plan_specs.pid asc";

		$rs_gpid=mysql_fetch_row(mysql_query($query));

		# added 10/24/2003
		$proceed_ct_base=substr_count($rs_gpid[1], "|");
		$proceed_ct=$proceed_ct_base-1;
		$proceed_arr=explode("|", $rs_gpid[1]);
		for ($i=0; $i<=$proceed_ct; $i++)
			{
			$query0="select ";
			$query0.="coupon ";	
			$query0.="from addon_specs ";
			$query0.="where aid='".addslashes(trim($proceed_arr[$i]))."'";

			$rs0=mysql_fetch_row(mysql_query($query0));

			$coupon=stripslashes(trim($rs0[0]));

			if ($coupon==1) { $proceed_bit+=1; }
			}

		if ($proceed_ct_base<=$proceed_bit) { $skip_step_three=true; }
		# end added 10/24/2003

		if (trim($rs_gpid[0])!="0"&&$pcheck==0&&!isset($skip_step_three))
			{
			header("Location: ".$http_web."/step_three.php?sid=".trim($sid)."&gid=".trim($gid)."&addon_gid=".base64_encode(trim($rs_gpid[0])));
			}
		else { header("Location: ".$http_web."/step_four.php?sid=".trim($sid)."&gid=".trim($gid)); }
		exit;
		}
	}
else if (isset($submit))
	{
	if (strlen(trim($domain_name))==0) 
		{ 
		$err=true;
		if ($domain_registration==1) { $ds=1; }
		}
	list($domain, $junk)=split("[|]", create_clean_domain_name($domain_name));

	$query="select ";
	$query.="tld ";
	$query.="from ";
	$query.="tld_chart ";
	$query.="where ";
	$query.="tld_id='".addslashes(trim($tld_id))."'";

	$rs=mysql_fetch_row(mysql_query($query));

	# added 11/20/2003
	if ($domain_registration==1)
		{
		include "inc/whois.php";
	
		if (strcmp(substr($rs[0], -3),".au")==0) 
			{ 
			if (strcmp(trim(whois_au($domain_name, $rs[0])), "Not Available")==0)
				{
				$err1=true; 
				$ds=1;
				}
			}
		else
			{ 
			$whois_exts=array($rs[0]);

			load_server_info();
			if (!perform_whois($domain, $rs[0])) { $err1=true; $ds=1; } 
			}
		}
	# end added 11/20/2003
	if ($domain==-1||$domain==-2||$domain==-3&&$domain_registration==1) { $ds=1; }

	if (!isset($err)&&!isset($err1)&&$domain!=-1&&$domain!=-2&&$domain!=-3)
		{
		if ($domain_registration==0) 
			{ 
			$domain_expire=$domain_expire_m."/";
			$domain_expire.=$domain_expire_d."/";
			$domain_expire.=$domain_expire_y;
			$domain.=$xtld; 
			}
		else if ($domain_registration==1) { $domain_name=$domain; }

		$str_domain=strlen($domain);
		if ($str_domain<7)
			{
			$needed_chrs=7-$str_domain;
			$needed_chars=substr(md5(date("r")), -$needed_chrs);
			$domain=$domain.$needed_chars;
			}
		
		$whm_username=create_whm_username($domain);
		$whm_password=substr(md5(date("r")), -7);
		$current_server=current_server($sid, 1);
		if ($current_server!=99)
			{
			// read in logins
			$temp=@read_log($current_server, $below_public);
			list($xwhm_username, $xwhm_password)=split("[|]", $temp);
		
			// get the server IP
			$query="select ";
			$query.="server_ip ";
			$query.="from ";
			$query.="server_config ";
			$query.="where ";
			$query.="whm_id='".addslashes(trim($current_server))."'";

			$rsip=mysql_fetch_row(mysql_query($query));

			$check_whm_username=check_whm_username($rsip[0], $xwhm_username, $xwhm_password, $whm_username);
			
			if ($check_whm_username==1) { $err_username=true; }
			else if ($check_whm_username==2) 
				{
				while ($check_whm_username==2)
					{
					$whm_username=substr(md5(microtime()), 0, 7);
					# $whm_username=create_whm_username(substr(md5(microtime()), 0, 7));
					$check_whm_username=check_whm_username($rsip[0], $xwhm_username, $xwhm_password, $whm_username);
					}
				}
			}

		if (!isset($err_username))
			{
			$update="update session_history set ";
			$update.="domain_name='".addslashes(trim($domain_name))."', ";
			$update.="domain_registration='".addslashes(trim($domain_registration))."', ";

			if ($domain_registration==0) 
				{ 
				$update.="domain_expire='".addslashes(trim($domain_expire))."', "; 
				$update.="tld='', ";
				}
			else { $update.="tld='".addslashes(trim($tld_id))."', "; }

			$update.="whm_username='".addslashes(trim($whm_username))."', ";
			$update.="whm_password='".addslashes(trim($whm_password))."', ";
			$update.="ogcreate='".time()."' ";
			$update.="where sid='".addslashes(trim($sid))."'";
			
			mysql_query($update);
			
			# added 10/24/2003
			$query="select ";
			$query.="plan_specs.addon_gid, ";
			$query.="addon_groups.group_addons ";
			$query.="from plan_specs, ";
			$query.="addon_groups ";
			$query.="where ";
			$query.="plan_specs.pid='".addslashes(trim($pid))."' ";
			$query.="and ";
			$query.="plan_specs.addon_gid=addon_groups.addon_gid ";
			$query.="order by plan_specs.pid asc";

			$rs_gpid=mysql_fetch_row(mysql_query($query));
	
			$proceed_ct_base=substr_count($rs_gpid[1], "|");
			$proceed_ct=$proceed_ct_base-1;
			$proceed_arr=explode("|", $rs_gpid[1]);
			for ($i=0; $i<=$proceed_ct; $i++)
				{
				$query0="select ";
				$query0.="coupon ";	
				$query0.="from addon_specs ";
				$query0.="where aid='".addslashes(trim($proceed_arr[$i]))."'";
				
				$rs0=mysql_fetch_row(mysql_query($query0));

				$coupon=stripslashes(trim($rs0[0]));

				if ($coupon==1) { $proceed_bit+=1; }
				}

			if ($proceed_ct_base<=$proceed_bit) { $skip_step_three=true; }
			# end added 10/24/2003

			if (trim($rs_gpid[0])!="0"&&$pcheck==0&&!isset($skip_step_three))
				{
				header("Location: ".$http_web."/step_three.php?sid=".trim($sid)."&gid=".trim($gid)."&addon_gid=".base64_encode(trim($rs_gpid[0])));
				}
			else { header("Location: ".$http_web."/step_four.php?sid=".trim($sid)."&gid=".trim($gid)); }
			exit;
			}
		}
	}

if ($rs[4]!=0&&$rs[4]!=-1)
	{
	$q_="select ";
	$q_.="primary_ns, ";		// 0
	$q_.="primary_ns_ip, ";		// 1
	$q_.="secondary_ns, ";		// 2
	$q_.="secondary_ns_ip ";	// 3
	$q_.="from ";
	$q_.="server_config ";
	$q_.="where ";
	$q_.="whm_id='".addslashes(trim($rs[4]))."' ";
	$q_.="limit 0, 1";

	$rs_=mysql_fetch_row(mysql_query($q_));

	$primary_ns=stripslashes(trim($rs_[0]));
	$primary_ns_ip=stripslashes(trim($rs_[1]));
	$secondary_ns=stripslashes(trim($rs_[2]));
	$secondary_ns_ip=stripslashes(trim($rs_[3]));
	}
else
	{
	$current_ns=current_ns();
	if ($current_ns!=99) { list($primary_ns, $primary_ns_ip, $secondary_ns, $secondary_ns_ip)=split("[|]", $current_ns); }
	else { $skip_ns=true; }
	}

// 2co check
$rspc=mysql_fetch_row(mysql_query("select session_history.payment_method, plan_specs.addon_gid from session_history, plan_specs where session_history.sid='".addslashes(trim($sid))."' and session_history.pid=plan_specs.pid order by session_history.sid asc limit 0, 1"));

if ($rspc[0]==4) { $pcheck=1; $dcheck=0; } 
else if ($rspc[1]==0) { $pcheck=1;  $dcheck=1; } 
else 
	{ 
	$rs_gpid=mysql_fetch_row(mysql_query("select plan_specs.addon_gid, addon_groups.group_addons from plan_specs, addon_groups where plan_specs.pid='".addslashes(trim($pid))."' and plan_specs.addon_gid=addon_groups.addon_gid order by plan_specs.pid asc")); 
	
	# added 10/24/2003
	$proceed_ct_base=substr_count($rs_gpid[1], "|");
	$proceed_ct=$proceed_ct_base-1;
	$proceed_arr=explode("|", $rs_gpid[1]);
	for ($i=0; $i<=$proceed_ct; $i++)
		{
		$query0="select ";
		$query0.="coupon ";	
		$query0.="from addon_specs ";
		$query0.="where aid='".addslashes(trim($proceed_arr[$i]))."'";
		
		$rs0=mysql_fetch_row(mysql_query($query0));

		$coupon=stripslashes(trim($rs0[0]));

		if ($coupon==1) { $proceed_bit+=1; }
		}

	if ($proceed_ct_base<=$proceed_bit) { $pcheck=1; } else { $pcheck=0; }

	$dcheck=1; 
	}
?>