<?PHP
echo("
<SCRIPT LANGUAGE='JavaScript'>
var border_width='".$package_highlight_borderwidth."';
var border_style='".$package_highlight_borderstyle."';
var border_color='".$package_highlight_bordercolor."';

var select_color='".$package_highlight_selectcolor."';
var off_color='".$package_highlight_offcolor."';

var border_on = border_width + \" \" + border_style + \" \" + border_color; 
var border_off = border_width + \" \" + border_style + \" \" + off_color;


function select_row(what, num)
	{
	if (navigator.appName == 'Microsoft Internet Explorer') 
		{
		row = document.all[what + \"_row\" + num.toString()];
		if (!row) return;
		row.style.backgroundColor = select_color;

		lcell = document.all[what + \"_left_cell\" + num.toString()];
		rcell = document.all[what + \"_right_cell\" + num.toString()];

		lcell.style.borderLeft = border_on;
		lcell.style.borderTop = border_on;
		lcell.style.borderBottom = border_on;

		rcell.style.borderRight = border_on;
		rcell.style.borderTop = border_on;
		rcell.style.borderBottom = border_on;

		var i = 0;

		while(i < 10)
			{
			if (!document.all[what + \"_row\" + i.toString()]) break;

			if (i != num)
				{
				row = document.all[what + \"_row\" + i.toString()];
				lcell = document.all[what + \"_left_cell\" + i.toString()];
				rcell = document.all[what + \"_right_cell\" + i.toString()];

				row.style.backgroundColor = off_color;

				lcell.style.borderLeft = border_off;
				lcell.style.borderTop = border_off;
				lcell.style.borderBottom = border_off;

				rcell.style.borderRight = border_off;
				rcell.style.borderTop = border_off;
				rcell.style.borderBottom = border_off;
				}
			i++;
			}
		}
	else if (navigator.appName == 'Netscape') 
		{
		row = document.getElementById(what + \"_row\" + num.toString());
		if(!row) return;
		row.style.backgroundColor = select_color;

		lcell = document.getElementById(what + \"_left_cell\" + num.toString());
		rcell = document.getElementById(what + \"_right_cell\" + num.toString());

		lcell.style.borderLeft = border_on;
		lcell.style.borderTop = border_on;
		lcell.style.borderBottom = border_on;

		rcell.style.borderRight = border_on;
		rcell.style.borderTop = border_on;
		rcell.style.borderBottom = border_on;

		rows = document.getElementsByName(what + \"_row\");
		lcells = document.getElementsByName(what + \"_left_cell\");
		rcells = document.getElementsByName(what + \"_right_cell\");

		for(var i = 0; i < rows.length; i++)
			{
			if(i != num)
				{
				rows[i].style.backgroundColor = off_color;

				lcells[i].style.borderLeft = border_off;
				lcells[i].style.borderTop = border_off;
				lcells[i].style.borderBottom = border_off;

				rcells[i].style.borderRight = border_off;
				rcells[i].style.borderTop = border_off;
				rcells[i].style.borderBottom = border_off;
				}
			}
		}
	else
		{
		}
	}
</SCRIPT>
	");
?>