<?PHP
# generic connection handler
function enom_exec($demo, $qstring)
	{
	# GLOBAL $HTTP_SERVER_VARS;
	$demo=1;
	if ($demo==0) { $which="resellertest"; }
	else { $which="reseller"; }

	
	$link=curl_init();
	curl_setopt($link, CURLOPT_TIMEOUT, 15);
	# curl_setopt($link, CURLOPT_INTERFACE, $HTTP_SERVER_VARS['HTTP_HOST']);

	$query="select enom_ip from config limit 0, 1";
	$rs=mysql_fetch_row(mysql_query($query));

	curl_setopt($link, CURLOPT_INTERFACE, $rs[0]);
	curl_setopt($link, CURLOPT_URL, "https://".$which.".enom.com/interface.asp");
	curl_setopt($link, CURLOPT_HEADER, 0);
	curl_setopt($link, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($link, CURLOPT_POSTFIELDS, $qstring);

	$data=curl_exec($link);
	$data=split("\,", $data);
	curl_close($link);
	
	# print_r($xresult); die;
	return $data;
	}

# core enom functions --------------------------------------------------------------------

# return 0 for success
function enom_setpassword($sld, $tld, $password)
	{
	$temp=enom_get_logins();
	list($enom_user, $enom_pass)=explode("|", $temp);
	
	$qstring="command=SetPassword";
	$qstring.="&uid=".$enom_user;
	$qstring.="&pw=".$enom_pass;
	$qstring.="&sld=".$sld;
	$qstring.="&tld=".$tld;
	$qstring.="&DomainPassword=".$password;

	$results=enom_exec($demo, $qstring);
	
	$res=explode("\r\n", $results[0]);
	
	foreach ($res as $line) 
		{ 
		list($key, $value)=explode("=", $line);
		${$key}=trim($value);
		}

	return $ErrCount;
	}

function enom_purchase($sld, $tld)
	{
	$temp=enom_get_logins();
	list($enom_user, $enom_pass)=explode("|", $temp);
	
	$qstring="command=Purchase";
	$qstring.="&uid=".$enom_user;
	$qstring.="&pw=".$enom_pass;
	$qstring.="&sld=".$sld;
	$qstring.="&tld=".$tld;
	
	$results=enom_exec($demo, $qstring);
	#echo $results[0]; die;
	$res=explode("\r\n", $results[0]);
	
	foreach ($res as $line) 
		{ 
		list($key, $value)=explode("=", $line);
		${$key}=trim($value);
		}
	
	if ($RRPCode==200) 
		{
		list($junk, $order_id)=explode("-", $RRPText);
		$order_id=trim($order_id);
		}
	else { $order_id=0; }

	return $RRPCode."|".$RRPText."|".$order_id;
	}

function enom_modifyns($sld, $tld, $ns1, $ns2)
	{
	$temp=enom_get_logins();
	list($enom_user, $enom_pass)=explode("|", $temp);
	
	$qstring="command=ModifyNS";
	$qstring.="&uid=".$enom_user;
	$qstring.="&pw=".$enom_pass;
	$qstring.="&sld=".$sld;
	$qstring.="&tld=".$tld;
	$qstring.="&NS1=".$ns1;
	$qstring.="&NS2=".$ns2;

	$results=enom_exec($demo, $qstring);
	
	$res=explode("\r\n", $results[0]);
	
	foreach ($res as $line) 
		{ 
		list($key, $value)=explode("=", $line);
		${$key}=trim($value);
		}
	
	return $RRPCode."|".$RRPText;
	}

function enom_contacts($sld, $tld, $uid, $sorp)
	{
	$temp=enom_get_logins();
	list($enom_user, $enom_pass)=explode("|", $temp);
	
	$query="select ";
	$query.="organization_name, ";	// 0
	$query.="first_name, ";			// 1	
	$query.="last_name, ";			// 2
	$query.="street_address_1, ";	// 3
	$query.="street_address_2, ";	// 4
	$query.="city, ";				// 5
	$query.="state, ";				// 6
	$query.="zip_code, ";			// 7
	$query.="country, ";			// 8
	$query.="phone, ";				// 9
	$query.="fax, ";				// 10
	$query.="email ";				// 11
	$query.="from ";
	$query.="user ";
	$query.="where ";
	$query.="uid='".addslashes(trim($uid))."' ";
	$query.="limit 0, 1";
	
	$rs=mysql_fetch_row(mysql_query($query));

	$organization_name=stripslashes(trim($rs[0]));
	$first_name=stripslashes(trim($rs[1]));
	$last_name=stripslashes(trim($rs[2]));
	$street_address_1=stripslashes(trim($rs[3]));
	$street_address_2=stripslashes(trim($rs[4]));
	$city=stripslashes(trim($rs[5]));
	$state=stripslashes(trim($rs[6]));
	$zip_code=stripslashes(trim($rs[7]));
	$country=stripslashes(trim($rs[8]));
	$phone=stripslashes(trim($rs[9]));
	$fax=stripslashes(trim($rs[10]));
	$email=stripslashes(trim($rs[11]));

	$qstring="command=contacts";
	$qstring.="&uid=".$enom_user;
	$qstring.="&pw=".$enom_pass;
	$qstring.="&sld=".$sld;
	$qstring.="&tld=".$tld;

	$qstring.="&Registrantorganizationname=".$organization_name;
	$qstring.="&Registrantfirstname=".$first_name;
	$qstring.="&Registrantlastname=".$last_name;
	$qstring.="&Registrantaddress1=".$street_address_1;
	$qstring.="&Registrantaddress2=".$street_address_2;
	$qstring.="&Registrantcity=".$city;
	$qstring.="&RegistrantStateProvinceChoice=";
	if ($sorp==1) { $qstring.="Province"; }
	else { $qstring.="State"; }
	$qstring.="&Registrantstateprovince=".$state;
	$qstring.="&Registrantpostalcode=".$zip_code;
	$qstring.="&Registrantcountry=".$country;
	$qstring.="&Registrantemailaddress=".$email;
	$qstring.="&Registrantphone=".$phone;
	$qstring.="&Registrantfax=".$fax;
	
	$qstring.="&AUXBILLINGorganizationname=".$organization_name;
	$qstring.="&AUXBILLINGfirstname=".$first_name;
	$qstring.="&AUXBILLINGlastname=".$last_name;
	$qstring.="&AUXBILLINGaddress1=".$street_address_1;
	$qstring.="&AUXBILLINGaddress2=".$street_address_2;
	$qstring.="&AUXBILLINGcity=".$city;
	$qstring.="&AUXBILLINGStateProvinceChoice=";
	if ($sorp==1) { $qstring.="Province"; }
	else { $qstring.="State"; }
	$qstring.="&AUXBILLINGstateprovince=".$state;
	$qstring.="&AUXBILLINGpostalcode=".$zip_code;
	$qstring.="&AUXBILLINGcountry=".$country;
	$qstring.="&AUXBILLINGemailaddress=".$email;
	$qstring.="&AUXBILLINGphone=".$phone;
	$qstring.="&AUXBILLINGfax=".$fax;
	
	$qstring.="&TECHorganizationname=".$organization_name;
	$qstring.="&TECHfirstname=".$first_name;
	$qstring.="&TECHlastname=".$last_name;
	$qstring.="&TECHaddress1=".$street_address_1;
	$qstring.="&TECHaddress2=".$street_address_2;
	$qstring.="&TECHcity=".$city;
	$qstring.="&TECHStateProvinceChoice=";
	if ($sorp==1) { $qstring.="Province"; }
	else { $qstring.="State"; }
	$qstring.="&TECHstateprovince=".$state;
	$qstring.="&TECHpostalcode=".$zip_code;
	$qstring.="&TECHcountry=".$country;
	$qstring.="&TECHemailaddress=".$email;
	$qstring.="&TECHphone=".$phone;
	$qstring.="&TECHfax=".$fax;
	
	$qstring.="&adminorganizationname=".$organization_name;
	$qstring.="&adminfirstname=".$first_name;
	$qstring.="&adminlastname=".$last_name;
	$qstring.="&adminaddress1=".$street_address_1;
	$qstring.="&adminaddress2=".$street_address_2;
	$qstring.="&admincity=".$city;
	$qstring.="&adminStateProvinceChoice=";
	if ($sorp==1) { $qstring.="Province"; }
	else { $qstring.="State"; }
	$qstring.="&adminstateprovince=".$state;
	$qstring.="&adminpostalcode=".$zip_code;
	$qstring.="&admincountry=".$country;
	$qstring.="&adminemailaddress=".$email;
	$qstring.="&adminphone=".$phone;
	$qstring.="&adminfax=".$fax;

	$results=enom_exec($demo, $qstring);
	
	$res=explode("\r\n", $results[0]);
	
	foreach ($res as $line) 
		{ 
		list($key, $value)=explode("=", $line);
		${$key}=trim($value);
		}
	
	return $RRPCode."|".$RRPText;
	}

# local AP functions ---------------------------------------------

function enom_get_logins()
	{
	$query="select ";
	$query.="enom_user, ";
	$query.="enom_pass ";
	$query.="from ";
	$query.="config ";
	$query.="limit 0, 1";
	
	$rs=mysql_fetch_row(mysql_query($query));

	$enom_user=stripslashes(trim($rs[0]));
	$enom_pass=stripslashes(trim($rs[1]));

	$enom_user=d("576cb7f68040520768bf51c75f7f4c84", $enom_user);
	$enom_pass=d("576cb7f68040520768bf51c75f7f4c84", $enom_pass);
	
	return $enom_user."|".$enom_pass;
	}

function enom_record_logins($enom_user, $enom_pass)
	{
	$query="update ";
	$query.="config ";
	$query.="set ";
	$query.="enom_user='".addslashes(trim(e("576cb7f68040520768bf51c75f7f4c84", $enom_user)))."', ";
	$query.="enom_pass='".addslashes(trim(e("576cb7f68040520768bf51c75f7f4c84", $enom_pass)))."', ";
	$query.="use_enom='1'";

	mysql_query($query);

	return 1;
	}

function enom_reg_email($oid, $uid, $email_admin)
	{
	$query0="select ";
	$query0.="subject, ";
	$query0.="message, ";
	$query0.="default_email ";
	$query0.="from ";
	$query0.="email_templates ";
	$query0.="where ";
	$query0.="emid='47' ";
	$query0.="limit 0, 1";

	$rs0=mysql_fetch_row(mysql_query($query0));

	$subject=stripslashes(trim($rs0[0]));
	$message=stripslashes(trim($rs0[1]));
	$default_email=stripslashes(trim($rs0[2]));

	# -------------------------------------------

	$query="select ";
	$query.="domain_name, ";	// 0
	$query.="order_id, ";		// 1
	$query.="purchase_text, ";	// 2
	$query.="expires ";			// 3
	$query.="from ";
	$query.="domains ";
	$query.="where ";
	$query.="oid='".addslashes(trim($oid))."' ";
	$query.="limit 0, 1";

	$rs=mysql_fetch_row(mysql_query($query));

	$domain_name=stripslashes(trim($rs[0]));
	$enom_order_id=stripslashes(trim($rs[1]));
	$enom_response_code=stripslashes(trim($rs[2]));
	$expiration_date=date("m/d/Y", stripslashes(trim($rs[3])));
	$generate_date=date("m/d/Y h:i:s a");

	# {{domain_name}}
	# {{enom_order_id}}
	# {{enom_response_code}}
	# {{expiration_date}}
	# {{generate_date}}

	# -------------------------------------------

	$query="select ";
	$query.="first_name, ";	// 0
	$query.="last_name, ";	// 1
	$query.="street_address_1, ";	// 2
	$query.="street_address_2, ";	// 3
	$query.="city, ";		// 4
	$query.="state, ";		// 5
	$query.="zip_code, ";	// 6
	$query.="phone, ";		// 7
	$query.="fax ";			// 8
	$query.="from ";
	$query.="user ";
	$query.="where ";
	$query.="uid='".addslashes(trim($uid))."' ";
	$query.="limit 0, 1";

	$rs=mysql_fetch_row(mysql_query($query));

	$first_name=stripslashes(trim($rs[0]));
	$last_name=stripslashes(trim($rs[1]));
	$address_1=stripslashes(trim($rs[2]));
	$address_2=stripslashes(trim($rs[3]));
	$city=stripslashes(trim($rs[4]));
	$state=stripslashes(trim($rs[5]));
	$zip=stripslashes(trim($rs[6]));
	$phone=stripslashes(trim($rs[7]));
	$fax=stripslashes(trim($rs[8]));
	
	# {{first_name}}
	# {{last_name}}
	# {{address_1}}
	# {{address_2}}
	# {{city}}
	# {{state}}
	# {{country}}
	# {{zip}}
	# {{phone}}
	# {{fax}}

	# -------------------------------------------

	$subject=str_replace("{{domain_name}}", $domain_name, $subject);
	$subject=str_replace("{{enom_order_id}}", $enom_order_id, $subject);
	$subject=str_replace("{{enom_response_code}}", $enom_response_code, $subject);
	$subject=str_replace("{{expiration_date}}", $expiration_date, $subject);
	$subject=str_replace("{{first_name}}", $first_name, $subject);
	$subject=str_replace("{{last_name}}", $last_name, $subject);
	$subject=str_replace("{{address_1}}", $address_1, $subject);
	$subject=str_replace("{{address_2}}", $address_2, $subject);
	$subject=str_replace("{{city}}", $city, $subject);
	$subject=str_replace("{{state}}", $state, $subject);
	$subject=str_replace("{{country}}", $country, $subject);
	$subject=str_replace("{{zip}}", $zip, $subject);
	$subject=str_replace("{{phone}}", $phone, $subject);
	$subject=str_replace("{{fax}}", $fax, $subject);
	$subject=str_replace("{{generate_date}}", $generate_date, $subject);

	$message=str_replace("{{domain_name}}", $domain_name, $message);
	$message=str_replace("{{enom_order_id}}", $enom_order_id, $message);
	$message=str_replace("{{enom_response_code}}", $enom_response_code, $message);
	$message=str_replace("{{expiration_date}}", $expiration_date, $message);
	$message=str_replace("{{first_name}}", $first_name, $message);
	$message=str_replace("{{last_name}}", $last_name, $message);
	$message=str_replace("{{address_1}}", $address_1, $message);
	$message=str_replace("{{address_2}}", $address_2, $message);
	$message=str_replace("{{city}}", $city, $message);
	$message=str_replace("{{state}}", $state, $message);
	$message=str_replace("{{country}}", $country, $message);
	$message=str_replace("{{zip}}", $zip, $message);
	$message=str_replace("{{phone}}", $phone, $message);
	$message=str_replace("{{fax}}", $fax, $message);
	$message=str_replace("{{generate_date}}", $generate_date, $message);

	$headers="From: ".(($default_email!="")?"".$default_email."":"".$email_admin."")."";
	$headers.="\nReply-To: ".$email_admin;
	$headers.="\nX-Mailer: PHP/".phpversion();

	mail($email_admin, $subject, $message, $headers);
	}
?>