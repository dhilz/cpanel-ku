<?PHP
// very crude way to get this data
include "inc/js_functions.php";
$ts=mysql_fetch_row(mysql_query("select domain_registration from session_history where sid='".addslashes(trim($sid))."'"));
$tick=$ts[0]; 
?>