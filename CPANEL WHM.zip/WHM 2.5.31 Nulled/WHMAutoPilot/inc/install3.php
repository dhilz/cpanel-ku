<?PHP
//
//  NULLED .:. Licensing Functions Stripped
//
include "var.php";
include "install_connect.php";
include "whm_functions.php";

$WHERE[here] = "http://".$_SERVER['HTTP_HOST'];
		if (!strpos($_SERVER['HTTP_REFERER'], $_SERVER['HTTP_HOST'])) 
		{
		header("Location: $WHERE[here]");
		exit();
		}

$xinput_style="style=\"BORDER-STYLE: solid;BORDER-COLOR: #999999; BACKGROUND-COLOR: #ffffff; BORDER-WIDTH: 1px; FONT-FAMILY: Verdana; FONT-SIZE: 8pt\"";

if(phpversion() <= "4.0.6") { $_POST=$HTTP_POST_VARS; }
if ($_POST['submit'])
	{
	$license = '3JLK4B63L4JK5B3L46B3L4KJ6B3LJ4BQL3J4-: _ <<! VST Nulled !>> | [URL] http://vsteam.ws [/URL] _ :-4L5JB2L4J5BV2L3J5B2LJ5B';
			mysql_query("update config set license='".addslashes(trim($license))."'");
			header("Location: install4.php"); 
			exit; 
		}


$b=3;
include "install_header.php";

echo("
	<form action='".$PHP_SELF."' method='POST'>
	<table width='100%' cellpadding='2' cellspacing='0' border='0'>
		<tr>
			<td colspan='2'><img src='install[1].gif'>&nbsp;<font color='#0F82B8'><b>Step 3:</b></font> <b>Register WHM AutoPilot {Ya Right!}</b></td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='middle'>&nbsp;</td>
		</tr>
	");
echo("
		<tr>
			<td width='25%' align='left' valign='top'>Enter License #:</td>
			<td width='75%' align='left' valign='middle'> <b> Just Press Submit to activate!!!! </b></td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='middle'>&nbsp;</td>
		</tr>
		<tr>
			<td width='25%' align='left' valign='middle'></td>
			<td width='75%' align='left' valign='middle'><input type='hidden' name='submit' value='5'><input type='image' src='install[29].gif' onmouseover='this.src=\"install[30].gif\"' onmouseout='this.src=\"install[29].gif\"' alt='Click to Continue'></td>
		</tr>
	</table>
	</form>
	");

include "install_footer.php";
mysql_close($dblink);
?>
