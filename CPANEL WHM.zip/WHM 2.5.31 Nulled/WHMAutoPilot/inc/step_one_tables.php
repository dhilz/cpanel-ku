<?PHP
// prepare for no $gid
//$lg=mysql_fetch_row(mysql_query("select gid from plan_groups order by gid desc limit 0, 1"));

// set gid to the last gid in the db if it's not already set
//if (!isset($gid)) {$gid=$lg[0];} 

// very crude way to get this data
include "inc/js_functions.php";

$ix=0;
$g=mysql_fetch_row(mysql_query("select pid from session_history where sid='".addslashes(trim($sid))."'"));
$rowx=mysql_query("select pid from plan_specs where gid='".addslashes(trim($gid))."' and plan_status='1' order by pid asc");
while ($rsx=mysql_fetch_row($rowx))
	{
	if ($g[0]==$rsx[0])
		{
		$tick=$ix;
		}
	$ix++;
	}
if (!isset($tick)) {$tick=0;}
?>