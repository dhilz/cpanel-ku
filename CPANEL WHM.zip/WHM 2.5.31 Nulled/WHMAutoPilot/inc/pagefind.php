<?PHP
function file_name()
 {
 GLOBAL $PHP_SELF;
 
 $source_ct=substr_count($PHP_SELF, "/");
 $array=explode("/", $PHP_SELF);
 
 for ($i=0; $i<=$source_ct; $i++) 
  { 
  $cleaned=substr($array[$i], 0, (strlen($array[$i])-4)).""; 
  }
 
 return $cleaned;
 }
?>