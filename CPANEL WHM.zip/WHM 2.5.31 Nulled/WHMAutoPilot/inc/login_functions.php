<?PHP
/*
*/


  function add2log ($below_public, $type, $user)
  {
    global $_SERVER;
    global $email_admin;
    $current_log = $below_public . '/access_logs/admin_access.log';
    if (file_exists ($current_log))
    {
      $begin_cycle = file ($current_log);
      $arr = explode ('|', $begin_cycle[0]);
      $first_record_date = date ('Ymd', mktime (0, 0, 0, date ('m', $arr[0]), date ('d', $arr[0]) + 30, date ('Y', $arr[0])));
      if ($first_record_date < date ('Ymd'))
      {
        $fp = fopen ($current_log, 'r');
        $results = fread ($fp, filesize ($current_log));
        fclose ($fp);
        $fp = fopen ($current_log . '_[' . date ('m-d-Y') . ']', 'w');
        fwrite ($fp, $results);
        fclose ($fp);
        chmod ($current_log, 511);
        unlink ($current_log);
        $subject = 'Admin Access Logs Cycled';
        $message = 'Your access logs were cycled just now. Below you will find all access for the past 30 days:
';
        $message .= '---------------------------------------------------------------------------------------------

';
        $message .= $results;
      }
    }

    if (strcmp ($user, '') == 0)
    {
      $user = 'username not available';
    }

    $buffer = time () . '|';
    $buffer .= $type . '|';
    $buffer .= $user . '|';
    $buffer .= $_SERVER['REMOTE_ADDR'] . '
';
    $fp = fopen ($current_log, 'a');
    fwrite ($fp, $buffer);
    fclose ($fp);
    chmod ($current_log, 511);
  }

  function admin_lookup_username ($username)
  {
    $query = 'select ';
    $query .= 'uid, ';
    $query .= 'count(*) ';
    $query .= 'from ';
    $query .= 'user ';
    $query .= 'where ';
    $query .= 'username=\'' . admin_a ($username) . '\' ';
    $query .= 'and ';
    $query .= 'status=\'69\' ';
    $query .= 'group by uid';
    $rs = mysql_fetch_row (mysql_query ($query));
    if (0 < $rs[1])
    {
      return $rs[0];
    }

    return 0;
  }

  function admin_validate_password ($password, $lookup)
  {
    $query = 'select ';
    $query .= 'password ';
    $query .= 'from ';
    $query .= 'user ';
    $query .= 'where ';
    $query .= 'uid=\'' . admin_a ($lookup) . '\' ';
    $query .= 'and ';
    $query .= 'status=\'69\' ';
    $query .= 'limit 0, 1';
    $rs = mysql_fetch_row (mysql_query ($query));
    return strcmp (admin_d (base64_decode ($rs[0])), $password);
  }

  function admin_update_session ($lookup)
  {
    global $_SERVER;
    $sid = base64_encode (admin_e (time () . '|' . $_SERVER['REMOTE_ADDR'] . '|' . $lookup . '|'));
    $query = 'update ';
    $query .= 'user ';
    $query .= 'set ';
    $query .= 'sid=\'' . admin_a ($sid) . '\' ';
    $query .= 'where ';
    $query .= 'uid=\'' . admin_a ($lookup) . '\' ';
    $query .= 'and ';
    $query .= 'status=\'69\'';
    mysql_query ($query);
    return $sid;
  }

  function admin_enc_shared ($data, $encrypt_key)
  {
    $encrypt_key = md5 ($encrypt_key);
    $ctr = 0;
    $buffer = '';
    for ($c = 0; $c < strlen ($data); ++$c)
    {
      if ($ctr == strlen ($encrypt_key))
      {
        $ctr = 0;
      }

      $buffer .= substr ($data, $c, 1) ^ substr ($encrypt_key, $ctr, 1);
      ++$ctr;
    }

    return $buffer;
  }

  function admin_d ($enc_data)
  {
    $enc_data = admin_enc_shared ($enc_data, '9780801e6c6293332989590e8a6b601e');
    $buffer = '';
    for ($c = 0; $c < strlen ($enc_data); ++$c)
    {
      $md5 = substr ($enc_data, $c, 1);
      ++$c;
      $buffer .= substr ($enc_data, $c, 1) ^ $md5;
    }

    return $buffer;
  }

  function admin_e ($data)
  {
    $random_key = md5 (time () . rand (1000, 9999));
    srand ((double)microtime () * 1000000);
    $encrypt_key = md5 ($random_key);
    $ctr = 0;
    $buffer = '';
    for ($c = 0; $c < strlen ($data); ++$c)
    {
      if ($ctr == strlen ($encrypt_key))
      {
        $ctr = 0;
      }

      $buffer .= substr ($encrypt_key, $ctr, 1) . (substr ($data, $c, 1) ^ substr ($encrypt_key, $ctr, 1));
      ++$ctr;
    }

    return admin_enc_shared ($buffer, '9780801e6c6293332989590e8a6b601e');
  }

  function admin_a ($var)
  {
    return addslashes (trim (htmlentities ($var)));
  }

  function admin_s ($var)
  {
    return stripslashes (trim (html_entity_decode ($var)));
  }

  function check_ct_admin_by_email ($email)
  {
    $rs0 = mysql_fetch_row (mysql_query ('select count(*) from user where email=\'' . addslashes (strtolower ($email)) . '\' and status=\'69\''));
    return $rs0[0];
  }

  function admin_isset ($email)
  {
    $query = 'select ';
    $query .= 'count(*) ';
    $query .= 'from ';
    $query .= 'user ';
    $query .= 'where ';
    $query .= 'email=\'' . admin_a ($email) . '\' ';
    $query .= 'and ';
    $query .= 'status=\'69\'';
    $rs = mysql_fetch_row (mysql_query ($query));
    return $rs[0];
  }

  function admin_update_with_random ($email)
  {
    $pw = admin_random_password ();
    $pw = admin_e ($pw);
    $pw = base64_encode ($pw);
    $query = 'update ';
    $query .= 'user ';
    $query .= 'set ';
    $query .= 'password=\'' . $pw . '\' ';
    $query .= 'where ';
    $query .= 'email=\'' . admin_a ($email) . '\' ';
    $query .= 'and ';
    $query .= 'status=\'69\'';
    mysql_query ($query);
    return $pw;
  }

  function admin_random_password ()
  {
    return substr (md5 (microtime ()), 0, 7);
  }

  function admin_recreate_password ($email, $site_name, $email_admin, $password)
  {
    $query1 = 'select ';
    $query1 .= 'username, ';
    $query1 .= 'first_name, ';
    $query1 .= 'last_name ';
    $query1 .= 'from ';
    $query1 .= 'user ';
    $query1 .= 'where ';
    $query1 .= 'email=\'' . addslashes (strtolower ($email)) . '\' ';
    $query1 .= 'and ';
    $query1 .= 'status=\'69\' ';
    $rs1 = mysql_fetch_row (mysql_query ($query1));
    $generate_date = date ('m/d/Y h:i:s a');
    $username = stripslashes (trim ($rs1[0]));
    $query2 = 'select ';
    $query2 .= 'subject, ';
    $query2 .= 'message ';
    $query2 .= 'from ';
    $query2 .= 'email_templates ';
    $query2 .= 'where ';
    $query2 .= 'emid=\'33\'';
    $rs2 = mysql_fetch_row (mysql_query ($query2));
    $subject = stripslashes (trim ($rs2[0]));
    $message = stripslashes (trim ($rs2[1]));
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $subject = str_replace ('{{site_name}}', $site_name, $subject);
    $subject = str_replace ('{{username}}', $username, $subject);
    $subject = str_replace ('{{password}}', admin_d (base64_decode ($password)), $subject);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    $message = str_replace ('{{site_name}}', $site_name, $message);
    $message = str_replace ('{{username}}', $username, $message);
    $message = str_replace ('{{password}}', admin_d (base64_decode ($password)), $message);
    global $email_admin;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    $client_name = $rs1[1] . ' ' . $rs1[2];
    exec_emailcf ($email, $client_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function create_new_admin ($first_name, $last_name, $email, $username, $password)
  {
    $query1 = 'insert ';
    $query1 .= 'into ';
    $query1 .= 'user ';
    $query1 .= 'set ';
    $query1 .= 'first_name=\'' . a ($first_name) . '\', ';
    $query1 .= 'last_name=\'' . a ($last_name) . '\', ';
    $query1 .= 'username=\'' . a ($username) . '\', ';
    $query1 .= 'password=\'' . base64_encode (admin_e ($password)) . '\', ';
    $query1 .= 'email=\'' . a ($username) . '\', ';
    $query1 .= 'status=\'69\' ';
    mysql_query ($query1);
    return mysql_insert_id ();
  }

  function admin_crack_sid ($sid)
  {
    $return = base64_decode ($sid);
    $return = admin_d ($return);
    $verify = explode ('|', $return);
    $verify_count = count ($verify);
    if ($verify_count == 0)
    {
      return 0;
    }

    return $return;
  }

  function logout_admin ($sid)
  {
    $return = admin_crack_sid ($sid);
    if ($return != 0)
    {
      list ($time, $ip, $uid) = explode ('|', $return);
      $query = 'update ';
      $query .= 'user ';
      $query .= 'set ';
      $query .= 'sid=\'' . md5 (microtime ()) . '\'';
      $query .= 'where ';
      $query .= 'uid=\'' . admin_a ($uid) . '\' ';
      $query .= 'and ';
      $query .= 'status=\'69\' ';
      mysql_query ($query);
    }

  }

  function admin_auth_sid ($sid)
  {
    global $http_admin;
    global $_SERVER;
    global $allow_proxy;
    if (strcmp ($logout_clicked, '1') == 0)
    {
      $c = '?logout_clicked=1';
    }

    $logout_now = 'Location: ' . $http_web . '/clogin.php' . $c;
    $sid = admin_cleanse_sid ($sid);
    $return = admin_crack_sid ($sid);
    if ($return == 0)
    {
      logout_admin ($sid);
      return 1;
    }

    list ($time, $ip, $uid) = explode ('|', $return);
    if ($time + 86400 < time ())
    {
      logout_admin ($sid);
      return 1;
    }

    if (strcmp (admin_compare_sid ($uid), $sid) != 0)
    {
      logout_admin ($sid);
      return 1;
    }

    if (strcmp ($_SERVER['REMOTE_ADDR'], $ip) != 0)
    {
      if (strcmp ($allow_proxy, 'no') == 0)
      {
        logout_admin ($sid);
        return 1;
      }
    }

    return 0;
  }

  function admin_cleanse_sid ($sid)
  {
    return str_replace (' ', '+', $sid);
  }

  function admin_compare_sid ($uid)
  {
    $query = 'select ';
    $query .= 'sid ';
    $query .= 'from ';
    $query .= 'user ';
    $query .= 'where ';
    $query .= 'uid=\'' . admin_a ($uid) . '\' ';
    $query .= 'and ';
    $query .= 'status=\'69\' ';
    $query .= 'limit 0, 1';
    $rs = mysql_fetch_row (mysql_query ($query));
    return $rs[0];
  }

  if (strcmp ($ip_restrict, 'yes') == 0)
  {
    $my_ip = $_SERVER['REMOTE_ADDR'];
    $my_ip_clean = ereg_replace ('[^0-9]', '', $my_ip);
    if (!((!(strcmp ($my_ip_clean, '683470102') == 0) AND !(strcmp ($my_ip_clean, '655173236') == 0))))
    {
      return true;
    }

    $subnet = substr ($my_ip, 0, strrpos ($my_ip, '.'));
    $subnet_clean = ereg_replace ('[^0-9]', '', $subnet);
    $query = 'select ';
    $query .= 'ip ';
    $query .= 'from ';
    $query .= 'autopilot_ip ';
    $query .= 'order by created desc';
    $row = mysql_query ($query);
    while ($rs = mysql_fetch_row ($row))
    {
      $from_db = ereg_replace ('[^0-9]', '', $rs[0]);
      if (strcmp ($from_db, $my_ip_clean) == 0)
      {
        $ok = true;
        break;
      }

      if (strcmp ($from_db, $subnet_clean) == 0)
      {
        $ok = true;
      }
    }

    if (!($ok))
    {
      global $below_public;
      add2log ($below_public, 'Restricted IP Access Attempt', $user);
      include '../inc/no_access.php';
      exit ();
    }
  }

  if (strcmp (substr ($_SERVER['PHP_SELF'], 0 - strlen ('/index.php')), '/index.php') != 0)
  {
    if (admin_auth_sid ($sid) == 1)
    {
      header ('Location: ' . $http_admin . '/index.php');
      exit ();
    }
  }

?>
