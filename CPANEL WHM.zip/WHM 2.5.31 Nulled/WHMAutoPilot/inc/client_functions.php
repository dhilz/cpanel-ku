<?PHP
/*
*/


  function lookup_client_username ($username)
  {
    $query = 'select ';
    $query .= 'uid, ';
    $query .= 'count(*) ';
    $query .= 'from ';
    $query .= 'user ';
    $query .= 'where ';
    $query .= 'username=\'' . a ($username) . '\' ';
    $query .= 'and ';
    $query .= 'status=\'0\' ';
    $query .= 'group by uid';
    $rs = mysql_fetch_row (mysql_query ($query));
    if (0 < $rs[1])
    {
      return $rs[0];
    }

    return 0;
  }

  function validate_client_password ($password, $lookup)
  {
    $query = 'select ';
    $query .= 'password ';
    $query .= 'from ';
    $query .= 'user ';
    $query .= 'where ';
    $query .= 'uid=\'' . a ($lookup) . '\' ';
    $query .= 'and ';
    $query .= 'status=\'0\' ';
    $query .= 'limit 0, 1';
    $rs = mysql_fetch_row (mysql_query ($query));
    return strcmp (clogin_d (base64_decode ($rs[0])), $password);
  }

  function update_client_session ($lookup)
  {
    global $_SERVER;
    $sid = base64_encode (clogin_e (time () . '|' . $_SERVER['REMOTE_ADDR'] . '|' . $lookup . '|'));
    $query = 'update ';
    $query .= 'user ';
    $query .= 'set ';
    $query .= 'sid=\'' . a ($sid) . '\' ';
    $query .= 'where ';
    $query .= 'uid=\'' . a ($lookup) . '\' ';
    $query .= 'and ';
    $query .= 'status=\'0\'';
    mysql_query ($query);
    return $sid;
  }

  function clogin_enc_shared ($data, $encrypt_key)
  {
    $encrypt_key = md5 ($encrypt_key);
    $ctr = 0;
    $buffer = '';
    for ($c = 0; $c < strlen ($data); ++$c)
    {
      if ($ctr == strlen ($encrypt_key))
      {
        $ctr = 0;
      }

      $buffer .= substr ($data, $c, 1) ^ substr ($encrypt_key, $ctr, 1);
      ++$ctr;
    }

    return $buffer;
  }

  function clogin_d ($enc_data)
  {
    $enc_data = clogin_enc_shared ($enc_data, '605ac13117bae148bd010f610833baad');
    $buffer = '';
    for ($c = 0; $c < strlen ($enc_data); ++$c)
    {
      $md5 = substr ($enc_data, $c, 1);
      ++$c;
      $buffer .= substr ($enc_data, $c, 1) ^ $md5;
    }

    return $buffer;
  }

  function clogin_e ($data)
  {
    $random_key = md5 (time () . rand (1000, 9999));
    srand ((double)microtime () * 1000000);
    $encrypt_key = md5 ($random_key);
    $ctr = 0;
    $buffer = '';
    for ($c = 0; $c < strlen ($data); ++$c)
    {
      if ($ctr == strlen ($encrypt_key))
      {
        $ctr = 0;
      }

      $buffer .= substr ($encrypt_key, $ctr, 1) . (substr ($data, $c, 1) ^ substr ($encrypt_key, $ctr, 1));
      ++$ctr;
    }

    return clogin_enc_shared ($buffer, '605ac13117bae148bd010f610833baad');
  }

  function a ($var)
  {
    return addslashes (trim (htmlentities ($var)));
  }

  function s ($var)
  {
    return stripslashes (trim (html_entity_decode ($var)));
  }

  function isset_client ($email)
  {
    $query = 'select ';
    $query .= 'count(*) ';
    $query .= 'from ';
    $query .= 'user ';
    $query .= 'where ';
    $query .= 'email=\'' . a ($email) . '\' ';
    $query .= 'and ';
    $query .= 'status=\'0\'';
    $rs = mysql_fetch_row (mysql_query ($query));
    return $rs[0];
  }

  function update_client_with_random ($email)
  {
    $pw = random_password ();
    $pw = clogin_e ($pw);
    $pw = base64_encode ($pw);
    $query = 'update ';
    $query .= 'user ';
    $query .= 'set ';
    $query .= 'password=\'' . $pw . '\' ';
    $query .= 'where ';
    $query .= 'email=\'' . a ($email) . '\' ';
    $query .= 'and ';
    $query .= 'status=\'0\'';
    mysql_query ($query);
    return $pw;
  }

  function random_password ()
  {
    return substr (md5 (microtime ()), 0, 7);
  }

  function recreate_password ($email, $site_name, $email_admin, $password)
  {
    $query1 = 'select ';
    $query1 .= 'username, ';
    $query1 .= 'first_name, ';
    $query1 .= 'last_name ';
    $query1 .= 'from ';
    $query1 .= 'user ';
    $query1 .= 'where ';
    $query1 .= 'email=\'' . addslashes (strtolower ($email)) . '\' ';
    $query1 .= 'and ';
    $query1 .= 'status=\'0\' ';
    $rs1 = mysql_fetch_row (mysql_query ($query1));
    $generate_date = date ('m/d/Y h:i:s a');
    $username = stripslashes (trim ($rs1[0]));
    $query2 = 'select ';
    $query2 .= 'subject, ';
    $query2 .= 'message ';
    $query2 .= 'from ';
    $query2 .= 'email_templates ';
    $query2 .= 'where ';
    $query2 .= 'emid=\'33\'';
    $rs2 = mysql_fetch_row (mysql_query ($query2));
    $subject = stripslashes (trim ($rs2[0]));
    $message = stripslashes (trim ($rs2[1]));
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $subject = str_replace ('{{site_name}}', $site_name, $subject);
    $subject = str_replace ('{{username}}', $username, $subject);
    $subject = str_replace ('{{password}}', clogin_d (base64_decode ($password)), $subject);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    $message = str_replace ('{{site_name}}', $site_name, $message);
    $message = str_replace ('{{username}}', $username, $message);
    $message = str_replace ('{{password}}', clogin_d (base64_decode ($password)), $message);
    global $email_admin;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    $client_name = $rs1[1] . ' ' . $rs1[2];
    exec_emailcf ($email, $client_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function crack_sid ($sid)
  {
    $return = base64_decode ($sid);
    $return = clogin_d ($return);
    $verify = explode ('|', $return);
    $verify_count = count ($verify);
    if ($verify_count == 0)
    {
      return 0;
    }

    return $return;
  }

  function admin_logout ($sid)
  {
    $return = crack_sid ($sid);
    if ($return != 0)
    {
      list ($time, $ip, $uid) = explode ('|', $return);
      $query = 'update ';
      $query .= 'user ';
      $query .= 'set ';
      $query .= 'sid=\'' . md5 (microtime ()) . '\'';
      $query .= 'where ';
      $query .= 'uid=\'' . a ($uid) . '\' ';
      $query .= 'and ';
      $query .= 'status=\'0\' ';
      mysql_query ($query);
    }

  }

  function auth_sid ($sid)
  {
    global $http_admin;
    global $_SERVER;
    if (strcmp ($logout_clicked, '1') == 0)
    {
      $c = '?logout_clicked=1';
    }

    $logout_now = 'Location: ' . $http_web . '/clogin.php' . $c;
    $sid = cleanse_sid ($sid);
    $return = crack_sid ($sid);
    if ($return == 0)
    {
      admin_logout ($sid);
      return 1;
    }

    list ($time, $ip, $uid) = explode ('|', $return);
    if ($time + 86400 < time ())
    {
      admin_logout ($sid);
      return 1;
    }

    if (strcmp (compare_sid ($uid), $sid) != 0)
    {
      admin_logout ($sid);
      return 1;
    }

    if (strcmp ($_SERVER['REMOTE_ADDR'], $ip) != 0)
    {
      admin_logout ($sid);
      return 1;
    }

    return 0;
  }

  function cleanse_sid ($sid)
  {
    return str_replace (' ', '+', $sid);
  }

  function compare_sid ($uid)
  {
    $query = 'select ';
    $query .= 'sid ';
    $query .= 'from ';
    $query .= 'user ';
    $query .= 'where ';
    $query .= 'uid=\'' . a ($uid) . '\' ';
    $query .= 'and ';
    $query .= 'status=\'0\' ';
    $query .= 'limit 0, 1';
    $rs = mysql_fetch_row (mysql_query ($query));
    return $rs[0];
  }

  function exec_emailcf ($to_email, $to_name, $from_email, $from_name, $subject, $message, $email_type, $message_priority)
  {
    global $charset;
    $from_name = str_replace (',', '', $from_name);
    $to_name = str_replace (',', '', $to_name);
    ini_set (sendmail_from, $from_email);
    $generate_date = date ('r');
    $fp = fsockopen (ini_get ('SMTP'), ini_get ('smtp_port'), $errno, $errstr, 30);
    if (!($fp))
    {
      return false;
    }

    $stream = fgets ($fp, 1024);
    fputs ($fp, 'HELO {' . $_SERVER['SERVER_NAME'] . '}
');
    $stream = fgets ($fp, 1024);
    fputs ($fp, 'MAIL FROM:' . $from_email . '
');
    $stream = fgets ($fp, 1024);
    fputs ($fp, 'RCPT TO:' . $to_email . '
');
    $stream = fgets ($fp, 1024);
    fputs ($fp, 'DATA
');
    $stream = fgets ($fp, 1024);
    fputs ($fp, 'Subject: ' . $subject . '
');
    fputs ($fp, 'From: ' . $from_name . ' <' . $from_email . '>
');
    fputs ($fp, 'To: ' . $to_name . '  <' . $to_email . '>
');
    fputs ($fp, 'X-Sender: <' . $from_email . '>
');
    fputs ($fp, 'Return-Path: <' . $from_email . '>
');
    fputs ($fp, 'Errors-To: <' . $from_email . '>
');
    fputs ($fp, 'X-Mailer: PHP/' . phpversion () . '
');
    fputs ($fp, 'X-mimeole: Produced By Microsoft MimeOLE V5.00.2615.200
');
    fputs ($fp, 'X-Priority: ' . $message_priority . '
');
    fputs ($fp, 'Date: ' . $generate_date . '
');
    fputs ($fp, 'X-MSMail-Priority: ' . ($message_priority == 1 ? 'High' : 'Normal') . '
');
    fputs ($fp, 'Content-Type: text/' . ($email_type == 0 ? 'plain' : 'html') . '
');
    fputs ($fp, 'Charset: ' . $charset . '
');
    fputs ($fp, '
');
    fputs ($fp, stripslashes ($message) . '
');
    fputs ($fp, '.
');
    $stream = fgets ($fp, 1024);
    fputs ($fp, 'RSET
');
    $stream = fgets ($fp, 1024);
    fputs ($fp, 'QUIT
');
    $stream = fgets ($fp, 1024);
    fclose ($fp);
    ini_restore (sendmail_from);
    return true;
  }

  function can_i_use_nslookup_via_php ()
  {
    @exec ('nslookup google.com -sil', $result);
    $buffer = '';
    foreach ($result as $result)
    {
      $buffer .= $result;
    }

    if (trim ($buffer) != '')
    {
      return 0;
    }

    return 1;
  }

  function available_languages ($server_inc)
  {
    $buffer = '';
    clearstatcache ();
    if ($dir = opendir ($server_inc . '/languages'))
    {
      while (false !== $file = readdir ($dir))
      {
        if ($file !== '.')
        {
          if ($file !== '..')
          {
            if (is_dir ($server_inc . '/languages/' . $file))
            {
              $buffer .= $file . '|';
              continue;
            }

            continue;
          }

          continue;
        }
      }

      closedir ($dir);
    }

    return $buffer;
  }

  function display_addons_ordered_clientarea ($addon_choices, $http_images)
  {
    echo '
		<table width=\'100%\' cellpadding=\'2\' cellspacing=\'0\' border=\'0\'>
			<tr>
				<td colspan=\'2\' align=\'left\' valign=\'top\'><img src=\'' . $http_images . '/space.gif\' width=\'1\' height=\'4\'></td>
			</tr>
			<tr>
				<td colspan=\'2\' align=\'left\' valign=\'top\'><img src=\'' . $http_images . '/space.gif\' width=\'15\' height=\'9\'>Package Addons:</td>
			</tr>
			<tr>
				<td colspan=\'2\' align=\'left\' valign=\'top\'><img src=\'' . $http_images . '/space.gif\' width=\'1\' height=\'2\'></td>
			</tr>
		';
    $count = substr_count ($addon_choices, '|');
    $explode = explode ('|', $addon_choices);
    for ($i = 0; $i <= $count; ++$i)
    {
      if (trim ($explode[$i]) != '')
      {
        $query2 = 'select ';
        $query2 .= 'addon_name, ';
        $query2 .= 'setup_cost, ';
        $query2 .= 'setup_activate, ';
        $query2 .= 'addon_cost, ';
        $query2 .= 'addon_state, ';
        $query2 .= 'addon_activate ';
        $query2 .= 'from addon_specs ';
        $query2 .= 'where aid=\'' . addslashes (trim ($explode[$i])) . '\'';
        $rs2 = mysql_fetch_row (mysql_query ($query2));
        $addon_name = stripslashes (trim ($rs2[0]));
        $setup_cost = stripslashes (trim ($rs2[1]));
        $setup_activate = stripslashes (trim ($rs2[2]));
        $addon_cost = stripslashes (trim ($rs2[3]));
        $addon_state = stripslashes (trim ($rs2[4]));
        $addon_activate = stripslashes (trim ($rs2[5]));
        echo '
				<tr>
					<td align=\'left\' valign=\'top\'><img src=\'' . $http_images . '/space.gif\' width=\'15\' height=\'9\'>' . $addon_name . '</td>
					<td align=\'left\' valign=\'top\'>
					<table width=\'100%\' cellpadding=\'0\' cellspacing=\'0\' border=\'0\'>
						<tr>
							<td width=\'1%\' align=\'left\' valign=\'top\'>Setup Fee:</td>
							<td width=\'99%\' align=\'left\' valign=\'top\'>
						';
        if ($setup_activate == 1)
        {
          echo $currency . sprintf ('%01.2f', $setup_cost) . ' ' . $currency_type;
        }
        else
        {
          echo 'No Cost';
        }

        echo '
							</td>
						</tr>
						<tr>
							<td width=\'1%\' align=\'left\' valign=\'top\'>Cost:</td>
							<td width=\'99%\' align=\'left\' valign=\'top\'>
						';
        if ($addon_activate == 1)
        {
          echo $currency . sprintf ('%01.2f', $addon_cost) . ' ' . $currency_type;
          if ($addon_state == 1)
          {
            echo ' One Time Fee';
          }
          else
          {
            if ($addon_state == 2)
            {
              echo ' Per Month';
            }
            else
            {
              if ($addon_state == 3)
              {
                echo ' Per Year';
              }
            }
          }
        }
        else
        {
          echo 'No Cost';
        }

        echo '
							</td>
						</tr>
						<tr>
							<td width=\'1%\' align=\'left\' valign=\'top\'><img src=\'' . $http_images . '/space.gif\' width=\'100\' height=\'12\'></td>
							<td width=\'99%\' align=\'left\' valign=\'top\'></td>
						</tr>
					</table>
					</td>
				</tr>
				';
        unset ($addon_name);
        unset ($setup_cost);
        unset ($setup_activate);
        unset ($addon_cost);
        unset ($addon_state);
        unset ($addon_activate);
        unset ($query2);
        unset ($rs2);
        continue;
      }
    }

    echo '</table>';
  }

  function clean_dir ($below_public)
  {
    clearstatcache ();
    if ($dir = opendir ($below_public))
    {
      while (false !== $file = readdir ($dir))
      {
        if (ereg ('_invoice', $file) == true)
        {
          if (fileatime ($below_public . '/' . $file) + 300 <= time ())
          {
            unlink ($below_public . '/' . $file);
            continue;
          }

          continue;
        }
      }

      closedir ($dir);
    }

  }

  function create_sid ()
  {
    return md5 (date ('mdyhisa'));
  }

  function isset_admin ()
  {
    $rs = mysql_fetch_row (mysql_query ('select count(*) from user where status=\'69\''));
    if (1 <= $rs[0])
    {
      return 1;
    }

    return 0;
  }

  function update_sid_w_un_pw ($username, $password, $sid)
  {
    mysql_query ('update user set sid=\'' . addslashes (trim ($sid)) . '\' where username=\'' . addslashes (strtolower ($username)) . '\' and password=\'' . md5 (strtolower ($password)) . '\'');
  }

  function update_sid_w_uid ($uid, $sid)
  {
    mysql_query ('update user set sid=\'' . addslashes (trim ($sid)) . '\' where uid=\'' . addslashes (strtolower ($uid)) . '\'');
  }

  function auth_un_pw ($username, $password)
  {
    $rs0 = mysql_fetch_row (mysql_query ('select count(*) from user where username=\'' . addslashes (strtolower ($username)) . '\' and password=\'' . md5 (strtolower ($password)) . '\''));
    return $rs0[0];
  }

  function auth_un_pw_admin ($username, $password)
  {
    $rs0 = mysql_fetch_row (mysql_query ('select count(*) from user where username=\'' . addslashes (strtolower ($username)) . '\' and password=\'' . md5 (strtolower ($password)) . '\' and status=\'69\''));
    return $rs0[0];
  }

  function renew_sid ($sid)
  {
    $uid = addslashes (trim ($rs0[0]));
    $xsid = $sid;
    $sid = create_sid ();
    mysql_query ('update user set sid=\'' . addslashes (trim ($sid)) . '\' where sid=\'' . addslashes (trim ($xsid)) . '\'');
    return $sid;
  }

  function auth_sid_admin ($sid)
  {
    $rs = mysql_fetch_row (mysql_query ('select count(*) from user where sid=\'' . addslashes (trim ($sid)) . '\' and status=\'69\''));
    if ($rs[0] == 1)
    {
      return 0;
    }

    return 1;
  }

  function check_ct_user_by_email ($email)
  {
    $rs0 = mysql_fetch_row (mysql_query ('select count(*) from user where email=\'' . addslashes (strtolower ($email)) . '\' and status=\'0\''));
    return $rs0[0];
  }

  function grab_news ($below_public)
  {
    $read = fopen ($below_public . '/news.nfo', 'r');
    $news = fread ($read, filesize ($below_public . '/news.nfo'));
    fclose ($read);
    $news = wordwrap ($news, 45);
    return nl2br (trim ($news));
  }

  function grab_aff_para_admin ($below_public)
  {
    if (!(file_exists ($below_public . '/affiliate_paragraph.nfo')))
    {
      $news = '';
      write_affiliate ($below_public, $news);
    }
    else
    {
      $read = fopen ($below_public . '/affiliate_paragraph.nfo', 'r');
      $news = fread ($read, filesize ($below_public . '/affiliate_paragraph.nfo'));
      fclose ($read);
    }

    return trim ($news);
  }

  function grab_aff_para ($below_public)
  {
    $read = @fopen ($below_public . '/affiliate_paragraph.nfo', 'r');
    $news = @fread ($read, @filesize ($below_public . '/affiliate_paragraph.nfo'));
    @fclose ($read);
    return nl2br (trim ($news));
  }

  function grab_news_admin ($below_public)
  {
    if (!(file_exists ($below_public . '/news.nfo')))
    {
      $news = '';
      write_news ($below_public, $news);
    }
    else
    {
      $read = fopen ($below_public . '/news.nfo', 'r');
      $news = fread ($read, filesize ($below_public . '/news.nfo'));
      fclose ($read);
    }

    return trim ($news);
  }

  function write_affiliate ($below_public, $news)
  {
    $read = fopen ($below_public . '/affiliate_paragraph.nfo', 'w');
    $news = fwrite ($read, trim ($news));
    fclose ($read);
    chmod ($below_public . '/affiliate_paragraph.nfo', 511);
    return 1;
  }

  function write_news ($below_public, $news)
  {
    $read = fopen ($below_public . '/news.nfo', 'w');
    $news = fwrite ($read, trim ($news));
    fclose ($read);
    chmod ($below_public . '/news.nfo', 511);
    return 1;
  }

  function update_session_with_uid ($uid, $sid)
  {
    mysql_query ('update session_history set uid=\'' . addslashes (trim ($uid)) . '\', ogcreate=\'' . time . '\' where sid=\'' . addslashes (trim ($sid)) . '\'');
    return 1;
  }

  function is_locked ($sid)
  {
    $rs = mysql_fetch_row (mysql_query ('select locked from session_history where sid=\'' . addslashes (trim ($sid)) . '\''));
    if ($rs[0] == 1)
    {
      return 1;
    }

  }

  function pay_image ($payment_method, $http_images)
  {
    $rs3 = mysql_fetch_row (mysql_query ('select name from payment_process where pid=\'' . addslashes (trim ($payment_method)) . '\''));
    if (ereg ('mail in payment', strtolower ($rs3[0])) == true)
    {
      return '<img src=\'' . $http_images . '/mailin.gif\'>';
    }

    if (ereg ('paypal', strtolower ($rs3[0])) == true)
    {
      return '<img src=\'' . $http_images . '/paypal.gif\'>';
    }

    if (ereg ('tpp-pro', strtolower ($rs3[0])) == true)
    {
      return '<img src=\'' . $http_images . '/paysystems.gif\'>';
    }

    if (ereg ('worldpay', strtolower ($rs3[0])) == true)
    {
      return '<img src=\'' . $http_images . '/worldpay.gif\'>';
    }

    if (ereg ('checkout', strtolower ($rs3[0])) == true)
    {
      return '<img src=\'' . $http_images . '/2checkout.gif\'>';
    }

    if (ereg ('authorize', strtolower ($rs3[0])) == true)
    {
      return '<img src=\'' . $http_images . '/authorize.gif\'>';
    }

    if (ereg ('internetsecure', strtolower ($rs3[0])) == true)
    {
      return '<img src=\'' . $http_images . '/internetsecure.gif\'>';
    }

    if (ereg ('linkpoint', strtolower ($rs3[0])) == true)
    {
      return '<img src=\'' . $http_images . '/linkpoint.gif\'>';
    }

    if (ereg ('credit card', strtolower ($rs3[0])) == true)
    {
      return '<img src=\'' . $http_images . '/offlinecc.gif\'>';
    }

    if (ereg ('cybersourcehop', strtolower ($rs3[0])) == true)
    {
      return '<img src=\'' . $http_images . '/cybersource.gif\'>';
    }

    if (ereg ('psigate', strtolower ($rs3[0])) == true)
    {
      return '<img src=\'' . $http_images . '/psigate.gif\'>';
    }

  }

  function check_user ($username)
  {
    $rs0 = mysql_fetch_row (mysql_query ('select count(*) from user where username=\'' . addslashes (trim (strtolower ($username))) . '\''));
    if ($rs0[0] <= 0)
    {
      return 0;
    }

    return 1;
  }

  function check_email ($email)
  {
    $rs0 = mysql_fetch_row (mysql_query ('select count(*) from user where email=\'' . addslashes (trim (strtolower ($email))) . '\''));
    if ($rs0[0] <= 0)
    {
      return 0;
    }

    return 1;
  }

  function send_unresolved_email ($oid, $email_admin)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'1\''));
    $default_email = stripslashes (trim ($rs[2]));
    $rs0 = mysql_fetch_row (mysql_query ('select user.first_name, hosting_order.domain_name, hosting_order.ns1, hosting_order.ns2, hosting_order.ogcreate, user.email, hosting_order.whm_id from user, hosting_order where user.uid=hosting_order.uid and hosting_order.oid=\'' . addslashes (trim ($oid)) . '\' order by user.uid asc'));
    $first_name = stripslashes (trim ($rs0[0]));
    $client_email = stripslashes (trim ($rs0[5]));
    $domain_name = stripslashes (trim ($rs0[1]));
    $generate_date = date ('m/d/Y h:i:s a');
    $installed_date = date ('m/d/Y', $rs0[4]);
    $rs1 = mysql_fetch_row (mysql_query ('select primary_ns, primary_ns_ip, secondary_ns, secondary_ns_ip from server_config where whm_id=\'' . $rs0[6] . '\''));
    $ns1 = stripslashes (trim ($rs1[0]));
    $ns1_ip = stripslashes (trim ($rs1[1]));
    $ns2 = stripslashes (trim ($rs1[2]));
    $ns2_ip = stripslashes (trim ($rs1[3]));
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{first_name}}', $first_name, $subject);
    $subject = str_replace ('{{domain_name}}', $domain_name, $subject);
    $subject = str_replace ('{{ns1}}', $ns1, $subject);
    $subject = str_replace ('{{ns1_ip}}', $ns1_ip, $subject);
    $subject = str_replace ('{{ns2}}', $ns2, $subject);
    $subject = str_replace ('{{ns2_ip}}', $ns2_ip, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $subject = str_replace ('{{installed_date}}', $installed_date, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{first_name}}', $first_name, $message);
    $message = str_replace ('{{domain_name}}', $domain_name, $message);
    $message = str_replace ('{{ns1}}', $ns1, $message);
    $message = str_replace ('{{ns1_ip}}', $ns1_ip, $message);
    $message = str_replace ('{{ns2}}', $ns2, $message);
    $message = str_replace ('{{ns2_ip}}', $ns2_ip, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    $message = str_replace ('{{installed_date}}', $installed_date, $message);
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    $client_name = $first_name;
    exec_emailcf ($client_email, $client_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function send_successfully_resolved_email ($oid, $email_admin)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'2\''));
    $default_email = stripslashes (trim ($rs[2]));
    $rs0 = mysql_fetch_row (mysql_query ('select user.first_name, hosting_order.domain_name, hosting_order.whm_username, hosting_order.whm_password, user.email from user, hosting_order where user.uid=hosting_order.uid and hosting_order.oid=\'' . addslashes (trim ($oid)) . '\' order by user.uid asc'));
    $first_name = stripslashes (trim ($rs0[0]));
    $domain_name = stripslashes (trim ($rs0[1]));
    $username = stripslashes (trim ($rs0[2]));
    $password = stripslashes (trim ($rs0[3]));
    $generate_date = date ('m/d/Y h:i:s a');
    $client_email = stripslashes (trim ($rs0[4]));
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{first_name}}', $first_name, $subject);
    $subject = str_replace ('{{domain_name}}', $domain_name, $subject);
    $subject = str_replace ('{{username}}', $username, $subject);
    $subject = str_replace ('{{password}}', $password, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{first_name}}', $first_name, $message);
    $message = str_replace ('{{domain_name}}', $domain_name, $message);
    $message = str_replace ('{{username}}', $username, $message);
    $message = str_replace ('{{password}}', $password, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    $client_name = $first_name;
    exec_emailcf ($client_email, $client_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function send_admin_notice_domain_stopped_responding ($oid, $email_admin)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'3\''));
    $default_email = stripslashes (trim ($rs[2]));
    $rs0 = mysql_fetch_row (mysql_query ('select domain_name, whm_id from hosting_order where oid=\'' . addslashes (trim ($oid)) . '\''));
    $rs1 = mysql_fetch_row (mysql_query ('select server_name from server_config where whm_id=\'' . addslashes (trim ($rs0[1])) . '\''));
    $domain_name = stripslashes (trim ($rs0[0]));
    $server = stripslashes (trim ($rs1[0]));
    $generate_date = date ('m/d/Y h:i:s a');
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{domain_name}}', $domain_name, $subject);
    $subject = str_replace ('{{server}}', $server, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{domain_name}}', $domain_name, $message);
    $message = str_replace ('{{server}}', $server, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    exec_emailcf ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function send_resolve_report ($email_admin, $number_resolved, $successful_domain_list, $number_unresolved, $unsuccessful_domain_list, $stopped_responding, $stopped_responding_list, $dom_30a, $dom_30, $dom_5a, $dom_5, $dom_expirea, $dom_expire)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'4\''));
    $default_email = stripslashes (trim ($rs[2]));
    $x30_day_ct = $dom_30a;
    if (strlen (trim ($dom_30)) == 0)
    {
      $x30_day_list = '- No 30 day expires for this run.';
    }
    else
    {
      $x30_day_list = $dom_30;
    }

    $x5_day_ct = $dom_5a;
    if (strlen (trim ($dom_5)) == 0)
    {
      $x5_day_list = '- No 5 day expires for this run.';
    }
    else
    {
      $x5_day_list = $dom_5;
    }

    $expired_ct = $dom_expirea;
    if (strlen (trim ($dom_expire)) == 0)
    {
      $expired_list = '- No expired domains for this run.';
    }
    else
    {
      $expired_list = $dom_expire;
    }

    $generate_date = date ('m/d/Y h:i:s a');
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $subject = str_replace ('{{number_resolved}}', $number_resolved, $subject);
    $subject = str_replace ('{{successful_domain_list}}', $successful_domain_list, $subject);
    $subject = str_replace ('{{number_unresolved}}', $number_unresolved, $subject);
    $subject = str_replace ('{{unsuccessful_domain_list}}', $unsuccessful_domain_list, $subject);
    $subject = str_replace ('{{stopped_responding}}', $stopped_responding, $subject);
    $subject = str_replace ('{{stopped_responding_list}}', $stopped_responding_list, $subject);
    $subject = str_replace ('{{x30_day_ct}}', $x30_day_ct, $subject);
    $subject = str_replace ('{{x30_day_list}}', $x30_day_list, $subject);
    $subject = str_replace ('{{x5_day_ct}}', $x5_day_ct, $subject);
    $subject = str_replace ('{{x5_day_list}}', $x5_day_list, $subject);
    $subject = str_replace ('{{expired_ct}}', $expired_ct, $subject);
    $subject = str_replace ('{{expired_list}}', $expired_list, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    $message = str_replace ('{{number_resolved}}', $number_resolved, $message);
    $message = str_replace ('{{successful_domain_list}}', $successful_domain_list, $message);
    $message = str_replace ('{{number_unresolved}}', $number_unresolved, $message);
    $message = str_replace ('{{unsuccessful_domain_list}}', $unsuccessful_domain_list, $message);
    $message = str_replace ('{{stopped_responding}}', $stopped_responding, $message);
    $message = str_replace ('{{stopped_responding_list}}', $stopped_responding_list, $message);
    $message = str_replace ('{{x30_day_ct}}', $x30_day_ct, $message);
    $message = str_replace ('{{x30_day_list}}', $x30_day_list, $message);
    $message = str_replace ('{{x5_day_ct}}', $x5_day_ct, $message);
    $message = str_replace ('{{x5_day_list}}', $x5_day_list, $message);
    $message = str_replace ('{{expired_ct}}', $expired_ct, $message);
    $message = str_replace ('{{expired_list}}', $expired_list, $message);
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    exec_emailcf ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function display_resolve_report ($email_admin, $individual)
  {
    global $cron;
    $query = 'select ';
    $query .= 'subject, ';
    $query .= 'message, ';
    $query .= 'default_email ';
    $query .= 'from ';
    $query .= 'email_templates ';
    $query .= 'where emid=\'4\'';
    $rs = mysql_fetch_row (mysql_query ($query));
    $default_email = stripslashes (trim ($rs[2]));
    if ($individual == 0)
    {
      $results = resolver ($email_admin);
    }
    else
    {
      $results = resolver_individual ($email_admin, $individual);
    }

    list ($resolved, $unresolved, $monitor, $domain_expire_30, $domain_expire_5, $domain_expired) = explode ('{', $results);
    $resolved_data = '';
    $resolved_count = 0;
    $buffer = explode ('|', $resolved);
    $total_count = count ($buffer) - 1;
    foreach ($buffer as $current_count => $line)
    {
      if (strcmp ($current_count, $total_count) != 0)
      {
        if (strcmp ('None for this run.', $line) != 0)
        {
          $resolved_data .= $current_count + 1 . '. ' . $line;
          continue;
        }
        else
        {
          $resolved_data .= $line;
          continue;
        }

        continue;
      }
      else
      {
        $resolved_count = $line;
        continue;
      }
    }

    unset ($line);
    unset ($total_count);
    unset ($current_count);
    unset ($buffer);
    $unresolved_data = '';
    $unresolved_count = 0;
    $buffer = explode ('|', $unresolved);
    $total_count = count ($buffer) - 1;
    foreach ($buffer as $current_count => $line)
    {
      if (strcmp ($current_count, $total_count) != 0)
      {
        if (strcmp ('None for this run.', $line) != 0)
        {
          $unresolved_data .= $current_count + 1 . '. ' . $line;
          continue;
        }
        else
        {
          $unresolved_data .= $line;
          continue;
        }

        continue;
      }
      else
      {
        $unresolved_count = $line;
        continue;
      }
    }

    unset ($line);
    unset ($total_count);
    unset ($current_count);
    unset ($buffer);
    $monitor_data = '';
    $monitor_count = 0;
    $buffer = explode ('|', $monitor);
    $total_count = count ($buffer) - 1;
    foreach ($buffer as $current_count => $line)
    {
      if (strcmp ($current_count, $total_count) != 0)
      {
        if (strcmp ('None for this run.', $line) != 0)
        {
          $monitor_data .= $current_count + 1 . '. ' . $line;
          continue;
        }
        else
        {
          $monitor_data .= $line;
          continue;
        }

        continue;
      }
      else
      {
        $monitor_count = $line;
        continue;
      }
    }

    unset ($line);
    unset ($total_count);
    unset ($current_count);
    unset ($buffer);
    $domain_expire_30_data = '';
    $domain_expire_30_count = 0;
    $buffer = explode ('|', $domain_expire_30);
    $total_count = count ($buffer) - 1;
    foreach ($buffer as $current_count => $line)
    {
      if (strcmp ($current_count, $total_count) != 0)
      {
        if (strcmp ('None for this run.', $line) != 0)
        {
          $domain_expire_30_data .= $current_count + 1 . '. ' . $line;
          continue;
        }
        else
        {
          $domain_expire_30_data .= $line;
          continue;
        }

        continue;
      }
      else
      {
        $domain_expire_30_count = $line;
        continue;
      }
    }

    unset ($line);
    unset ($total_count);
    unset ($current_count);
    unset ($buffer);
    $domain_expire_5_data = '';
    $domain_expire_5_count = 0;
    $buffer = explode ('|', $domain_expire_5);
    $total_count = count ($buffer) - 1;
    foreach ($buffer as $current_count => $line)
    {
      if (strcmp ($current_count, $total_count) != 0)
      {
        if (strcmp ('None for this run.', $line) != 0)
        {
          $domain_expire_5_data .= $current_count + 1 . '. ' . $line;
          continue;
        }
        else
        {
          $domain_expire_5_data .= $line;
          continue;
        }

        continue;
      }
      else
      {
        $domain_expire_5_count = $line;
        continue;
      }
    }

    unset ($line);
    unset ($total_count);
    unset ($current_count);
    unset ($buffer);
    $domain_expired_data = '';
    $domain_expired_count = 0;
    $buffer = explode ('|', $domain_expired);
    $total_count = count ($buffer) - 1;
    foreach ($buffer as $current_count => $line)
    {
      if (strcmp ($current_count, $total_count) != 0)
      {
        if (strcmp ('None for this run.', $line) != 0)
        {
          $domain_expired_data .= $current_count + 1 . '. ' . $line;
          continue;
        }
        else
        {
          $domain_expired_data .= $line;
          continue;
        }

        continue;
      }
      else
      {
        $domain_expired_count = $line;
        continue;
      }
    }

    unset ($line);
    unset ($total_count);
    unset ($current_count);
    unset ($buffer);
    $generate_date = date ('m/d/Y h:i:s a');
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $subject = str_replace ('{{number_resolved}}', $resolved_count, $subject);
    $subject = str_replace ('{{successful_domain_list}}', $resolved_data, $subject);
    $subject = str_replace ('{{number_unresolved}}', $unresolved_count, $subject);
    $subject = str_replace ('{{unsuccessful_domain_list}}', $unresolved_data, $subject);
    $subject = str_replace ('{{stopped_responding}}', $monitor_count, $subject);
    $subject = str_replace ('{{stopped_responding_list}}', $monitor_data, $subject);
    $subject = str_replace ('{{x30_day_ct}}', $domain_expire_30_count, $subject);
    $subject = str_replace ('{{x30_day_list}}', $domain_expire_30_data, $subject);
    $subject = str_replace ('{{x5_day_ct}}', $domain_expire_5_count, $subject);
    $subject = str_replace ('{{x5_day_list}}', $domain_expire_5_data, $subject);
    $subject = str_replace ('{{expired_ct}}', $domain_expired_count, $subject);
    $subject = str_replace ('{{expired_list}}', $domain_expired_data, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    $message = str_replace ('{{number_resolved}}', $resolved_count, $message);
    $message = str_replace ('{{successful_domain_list}}', $resolved_data, $message);
    $message = str_replace ('{{number_unresolved}}', $unresolved_count, $message);
    $message = str_replace ('{{unsuccessful_domain_list}}', $unresolved_data, $message);
    $message = str_replace ('{{stopped_responding}}', $monitor_count, $message);
    $message = str_replace ('{{stopped_responding_list}}', $monitor_data, $message);
    $message = str_replace ('{{x30_day_ct}}', $domain_expire_30_count, $message);
    $message = str_replace ('{{x30_day_list}}', $domain_expire_30_data, $message);
    $message = str_replace ('{{x5_day_ct}}', $domain_expire_5_count, $message);
    $message = str_replace ('{{x5_day_list}}', $domain_expire_5_data, $message);
    $message = str_replace ('{{expired_ct}}', $domain_expired_count, $message);
    $message = str_replace ('{{expired_list}}', $domain_expired_data, $message);
    if ($cron == 69)
    {
      global $site_name;
      if (strcmp ($default_email, '') != 0)
      {
        $email_admin = $default_email;
      }

      $admin_name = $site_name;
      exec_emailcf ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
      return null;
    }

    return $message;
  }

  function calc_totals ($payment_term, $domain_registration, $domain_fee, $pid, $addon_choices)
  {
    global $tld_id;
    $payment_term = str_replace ('-', '_', strtolower (trim ($payment_term)));
    $query0 = 'select ';
    $query0 .= 'monthly_cost, ';
    $query0 .= 'quarterly_cost, ';
    $query0 .= 'semi_annual_cost, ';
    $query0 .= 'annual_cost, ';
    $query0 .= 'setup_cost ';
    $query0 .= 'from plan_specs ';
    $query0 .= 'where pid=\'' . addslashes (trim ($pid)) . '\'';
    $rs0 = mysql_fetch_row (mysql_query ($query0));
    $monthly_cost = stripslashes (trim ($rs0[0]));
    $quarterly_cost = stripslashes (trim ($rs0[1]));
    $semi_annual_cost = stripslashes (trim ($rs0[2]));
    $annual_cost = stripslashes (trim ($rs0[3]));
    $setup_cost = stripslashes (trim ($rs0[4]));
    if ($domain_registration == 1)
    {
      if ($domain_fee == 0)
      {
        $query_tld = 'select ';
        $query_tld .= 'cost ';
        $query_tld .= 'from ';
        $query_tld .= 'tld_chart ';
        $query_tld .= 'where ';
        $query_tld .= 'tld_id=\'' . addslashes (trim ($tld_id)) . '\'';
        $rs_tld = mysql_fetch_row (mysql_query ($query_tld));
        $domain_cost = $rs_tld[0];
      }
    }

    if (strcmp ('monthly', $payment_term) == 0)
    {
      $payment_term = 'Monthly';
      $hosting_cost = $monthly_cost;
      $term = 1;
    }
    else
    {
      if (strcmp ('quarterly', $payment_term) == 0)
      {
        $payment_term = 'Quarterly';
        $hosting_cost = $quarterly_cost;
        $term = 3;
      }
      else
      {
        if (strcmp ('semi_annual', $payment_term) == 0)
        {
          $payment_term = 'Semi-Annual';
          $hosting_cost = $semi_annual_cost;
          $term = 6;
        }
        else
        {
          if (strcmp ('annual', $payment_term) == 0)
          {
            $payment_term = 'Annual';
            $hosting_cost = $annual_cost;
            $term = 12;
          }
        }
      }
    }

    $array = explode ('|', $addon_choices);
    foreach ($array as $line)
    {
      $query1 = 'select ';
      $query1 .= 'setup_activate, ';
      $query1 .= 'setup_cost, ';
      $query1 .= 'addon_activate, ';
      $query1 .= 'addon_state, ';
      $query1 .= 'addon_cost, ';
      $query1 .= 'unique_ip, ';
      $query1 .= 'extra_webspace ';
      $query1 .= 'from addon_specs ';
      $query1 .= 'where aid=\'' . addslashes (trim ($line)) . '\'';
      $rs1 = mysql_fetch_row (mysql_query ($query1));
      $setup_activate = stripslashes (trim ($rs1[0]));
      $addon_setup_cost = stripslashes (trim ($rs1[1]));
      $addon_activate = stripslashes (trim ($rs1[2]));
      $addon_state = stripslashes (trim ($rs1[3]));
      $addon_cost = stripslashes (trim ($rs1[4]));
      $unique_ip = stripslashes (trim ($rs1[5]));
      $extra_webspace = stripslashes (trim ($rs1[6]));
      if ($setup_activate)
      {
        $addon_one_time_fees += $addon_setup_cost;
      }

      if ($addon_activate)
      {
        if ($addon_state == 1)
        {
          $addon_one_time_fees += $addon_cost;
          continue;
        }
        else
        {
          if ($addon_state == 2)
          {
            $addon_one_time_fees += $addon_cost * $term;
            $addon_recurring_fees += $addon_cost * $term;
            continue;
          }
          else
          {
            if ($addon_state == 3)
            {
              $addon_one_time_fees += $addon_cost;
              if ($term == 12)
              {
                $addon_recurring_fees += $addon_cost;
                continue;
              }

              continue;
            }

            continue;
          }

          continue;
        }

        continue;
      }
    }

    $total_due_today = $setup_cost;
    $total_due_today += $domain_cost;
    $total_due_today += $hosting_cost;
    $total_due_today += $addon_one_time_fees;
    $total_reoccur = $hosting_cost;
    $total_reoccur += $addon_recurring_fees;
    return $total_due_today . '|' . $total_reoccur . '|' . $payment_term . '|';
  }

  function resend_welcome_email_ip ($email_admin, $oid, $unique_ip_ordered)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'10\''));
    $default_email = stripslashes (trim ($rs[2]));
    $query = 'select ';
    $query .= 'hosting_order.domain_name, ';
    $query .= 'hosting_order.ip, ';
    $query .= 'hosting_order.whm_username, ';
    $query .= 'hosting_order.whm_password, ';
    $query .= 'user.email, ';
    $query .= 'hosting_order.whm_id, ';
    $query .= 'user.username, ';
    $query .= 'user.password, ';
    $query .= 'config.http_web, ';
    $query .= 'user.first_name, ';
    $query .= 'user.last_name ';
    $query .= 'from user, hosting_order, config ';
    $query .= 'where user.uid=hosting_order.uid ';
    $query .= 'and hosting_order.oid=\'' . addslashes (trim ($oid)) . '\' ';
    $query .= 'order by user.uid asc';
    $rs1 = mysql_fetch_row (mysql_query ($query));
    $email_client = stripslashes (trim ($rs1[4]));
    $whm_id = stripslashes (trim ($rs1[5]));
    $dns = mysql_fetch_row (mysql_query ('select primary_ns, primary_ns_ip, secondary_ns, secondary_ns_ip, server_name, server_noclocal from server_config where whm_id=\'' . addslashes (trim ($whm_id)) . '\''));
    $primary_ns = $dns[0];
    $primary_ns_ip = $dns[1];
    $secondary_ns = $dns[2];
    $secondary_ns_ip = $dns[3];
    $server_name = $dns[4];
    $server_location = $dns[5];
    $first_name = stripslashes (trim ($rs1[9]));
    $last_name = stripslashes (trim ($rs1[10]));
    $ip = stripslashes (trim ($rs1[1]));
    $whm_username = stripslashes (trim ($rs1[2]));
    $whm_password = stripslashes (trim ($rs1[3]));
    $domain_name = stripslashes (trim ($rs1[0]));
    $user_username = stripslashes (trim ($rs1[6]));
    $user_temppass = clogin_d (base64_decode ($rs1[7]));
    $client_login_temp = stripslashes (trim ($rs1[8]));
    $client_login = $client_login_temp . '/clogin.php';
    $generate_date = date ('m/d/Y h:i:s a');
    if ($unique_ip_ordered == 1)
    {
      $temporary_path = 'http://' . $ip;
    }
    else
    {
      $temporary_path = $ip . '/~' . $whm_username . '/';
    }

    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{ip}}', $ip, $subject);
    $subject = str_replace ('{{whm_username}}', $whm_username, $subject);
    $subject = str_replace ('{{whm_password}}', $whm_password, $subject);
    $subject = str_replace ('{{domain_name}}', $domain_name, $subject);
    $subject = str_replace ('{{primary_ns}}', $primary_ns, $subject);
    $subject = str_replace ('{{primary_ns_ip}}', $primary_ns_ip, $subject);
    $subject = str_replace ('{{secondary_ns}}', $secondary_ns, $subject);
    $subject = str_replace ('{{secondary_ns_ip}}', $secondary_ns_ip, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $subject = str_replace ('{{temporary_path}}', $temporary_path, $subject);
    $subject = str_replace ('{{clientarea_username}}', $user_username, $subject);
    $subject = str_replace ('{{clientarea_password}}', $user_temppass, $subject);
    $subject = str_replace ('{{clientarea_loginlink}}', $client_login, $subject);
    $subject = str_replace ('{{installed_on_server}}', $server_name, $subject);
    $subject = str_replace ('{{server_location}}', $server_location, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{ip}}', $ip, $message);
    $message = str_replace ('{{whm_username}}', $whm_username, $message);
    $message = str_replace ('{{whm_password}}', $whm_password, $message);
    $message = str_replace ('{{domain_name}}', $domain_name, $message);
    $message = str_replace ('{{primary_ns}}', $primary_ns, $message);
    $message = str_replace ('{{primary_ns_ip}}', $primary_ns_ip, $message);
    $message = str_replace ('{{secondary_ns}}', $secondary_ns, $message);
    $message = str_replace ('{{secondary_ns_ip}}', $secondary_ns_ip, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    $message = str_replace ('{{temporary_path}}', $temporary_path, $message);
    $message = str_replace ('{{clientarea_username}}', $user_username, $message);
    $message = str_replace ('{{clientarea_password}}', $user_temppass, $message);
    $message = str_replace ('{{clientarea_loginlink}}', $client_login, $message);
    $message = str_replace ('{{installed_on_server}}', $server_name, $message);
    $message = str_replace ('{{server_location}}', $server_location, $message);
    global $site_name;
    if ($default_email == '')
    {
      $default_email = $email_admin;
    }

    $admin_name = $site_name;
    $client_name = $rs1[9] . ' ' . $rs1[10];
    exec_emailcf ($email_client, $client_name, $default_email, $admin_name, $subject, $message, 0, 3);
    $subject .= ' - Admin Copy';
    $message .= '

-------------------------------------------------------------';
    $message .= '

This is a copy of the message that was sent to the client.
';
    exec_emailcf ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function request_cancel_revoked ($oid, $email_admin, $reason_for_revoke)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'26\''));
    $default_email = stripslashes (trim ($rs[2]));
    $rs1 = mysql_fetch_row (mysql_query ('select domain_name from hosting_order where oid=\'' . addslashes (trim ($oid)) . '\''));
    $domain_name = 'http://' . $rs1[0];
    $generate_date = date ('m/d/Y h:i:s a');
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{domain_name}}', $domain_name, $subject);
    $subject = str_replace ('{{reason_for_revoke}}', $reason_for_revoke, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{domain_name}}', $domain_name, $message);
    $message = str_replace ('{{reason_for_revoke}}', $reason_for_revoke, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    exec_emailcf ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function request_cancel ($oid, $email_admin, $reason_for_cancel)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'24\''));
    $default_email = stripslashes (trim ($rs[2]));
    $rs1 = mysql_fetch_row (mysql_query ('select domain_name from hosting_order where oid=\'' . addslashes (trim ($oid)) . '\''));
    $domain_name = 'http://' . $rs1[0];
    $generate_date = date ('m/d/Y h:i:s a');
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{domain_name}}', $domain_name, $subject);
    $subject = str_replace ('{{reason_for_cancel}}', $reason_for_cancel, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{domain_name}}', $domain_name, $message);
    $message = str_replace ('{{reason_for_cancel}}', $reason_for_cancel, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    exec_emailcf ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function request_cancel_confirm ($oid, $email_admin, $reason_for_cancel)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'25\''));
    $default_email = stripslashes (trim ($rs[2]));
    $rs1 = mysql_fetch_row (mysql_query ('select hosting_order.domain_name, user.email, user.first_name, user.last_name from hosting_order, user where hosting_order.oid=\'' . addslashes (trim ($oid)) . '\' and hosting_order.uid=user.uid order by hosting_order.oid asc limit 0, 1'));
    $domain_name = 'http://' . $rs1[0];
    $generate_date = date ('m/d/Y h:i:s a');
    $client_email = $rs1[1];
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{domain_name}}', $domain_name, $subject);
    $subject = str_replace ('{{reason_for_cancel}}', $reason_for_cancel, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{domain_name}}', $domain_name, $message);
    $message = str_replace ('{{reason_for_cancel}}', $reason_for_cancel, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    $client_name = $rs1[2] . ' ' . $rs1[3];
    exec_emailcf ($client_email, $client_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function cancel_processed ($oid, $email_admin, $reason_for_cancel)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'27\''));
    $default_email = stripslashes (trim ($rs[2]));
    $query = 'select ';
    $query .= 'hosting_order.domain_name, ';
    $query .= 'user.email, ';
    $query .= 'hosting_order.reason_for_cancel, ';
    $query .= 'hosting_order.cancel_date, ';
    $query .= 'user.first_name, ';
    $query .= 'user.last_name ';
    $query .= 'from hosting_order, user ';
    $query .= 'where ';
    $query .= 'hosting_order.oid=\'' . addslashes (trim ($oid)) . '\' ';
    $query .= 'and ';
    $query .= 'hosting_order.uid=user.uid ';
    $query .= 'order by hosting_order.oid asc limit 0, 1';
    $rs1 = mysql_fetch_row (mysql_query ($query));
    $reason_for_cancel = stripslashes (trim ($rs1[2]));
    $cancel_date_time = date ('m/d/Y h:i:s a', $rs1[3]);
    $domain_name = 'http://' . $rs1[0];
    $generate_date = date ('m/d/Y h:i:s a');
    $client_email = $rs1[1];
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{domain_name}}', $domain_name, $subject);
    $subject = str_replace ('{{reason_for_cancel}}', $reason_for_cancel, $subject);
    $subject = str_replace ('{{cancel_date_time}}', $cancel_date_time, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{domain_name}}', $domain_name, $message);
    $message = str_replace ('{{reason_for_cancel}}', $reason_for_cancel, $message);
    $message = str_replace ('{{cancel_date_time}}', $cancel_date_time, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    $client_name = $rs1[4] . ' ' . $rs1[5];
    exec_emailcf ($client_email, $client_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function affiliate_request ($email_admin, $uid)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'12\''));
    $default_email = stripslashes (trim ($rs[2]));
    $rs1 = mysql_fetch_row (mysql_query ('select first_name, last_name, email from user where uid=\'' . addslashes (trim ($uid)) . '\''));
    $generate_date = date ('m/d/Y h:i:s a');
    $client_name = $rs1[0] . ' ' . $rs1[1];
    $client_email = $rs1[2];
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $subject = str_replace ('{{client_name}}', $client_name, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    $message = str_replace ('{{client_name}}', $client_name, $message);
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    exec_emailcf ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function affiliate_approved ($uid, $http_web, $email_admin)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'13\''));
    $default_email = stripslashes (trim ($rs[2]));
    $rs1 = mysql_fetch_row (mysql_query ('select first_name, email, last_name from user where uid=\'' . addslashes (trim ($uid)) . '\''));
    $generate_date = date ('m/d/Y h:i:s a');
    $client_name = $rs1[0];
    $client_email = $rs1[1];
    $login_path = $http_web . '/clogin.php';
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $subject = str_replace ('{{client_name}}', $client_name, $subject);
    $subject = str_replace ('{{login_path}}', $login_path, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    $message = str_replace ('{{client_name}}', $client_name, $message);
    $message = str_replace ('{{login_path}}', $login_path, $message);
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    $client_name = $rs1[0] . ' ' . $rs1[2];
    exec_emailcf ($client_email, $client_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function affiliate_denied ($uid, $http_web, $email_admin)
  {
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'14\''));
    $default_email = stripslashes (trim ($rs[2]));
    $rs1 = mysql_fetch_row (mysql_query ('select first_name, email, last_name from user where uid=\'' . addslashes (trim ($uid)) . '\''));
    $generate_date = date ('m/d/Y h:i:s a');
    $client_name = $rs1[0];
    $client_email = $rs1[1];
    $minimum_period_to_reapply = 30;
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $subject = str_replace ('{{client_name}}', $client_name, $subject);
    $subject = str_replace ('{{minimum_period_to_reapply}}', $minimum_period_to_reapply, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    $message = str_replace ('{{client_name}}', $client_name, $message);
    $message = str_replace ('{{minimum_period_to_reapply}}', $minimum_period_to_reapply, $message);
    global $site_name;
    if (strcmp ($default_email, '') != 0)
    {
      $email_admin = $default_email;
    }

    $admin_name = $site_name;
    $client_name = $rs1[0] . ' ' . $rs1[2];
    exec_emailcf ($client_email, $client_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

  function affiliate_notification_to_client ($uid, $oid, $email_admin)
  {
    global $referrer_id;
    global $site_name;
    $rs = mysql_fetch_row (mysql_query ('select subject, message, default_email from email_templates where emid=\'16\''));
    $default_email = stripslashes (trim ($rs[2]));
    $rs1 = mysql_fetch_row (mysql_query ('select first_name, last_name, email from user where uid=\'' . addslashes (trim ($uid)) . '\''));
    $rs2 = mysql_fetch_row (mysql_query ('select pid from hosting_order where oid=\'' . addslashes (trim ($oid)) . '\''));
    $rs3 = mysql_fetch_row (mysql_query ('select package_name from plan_specs where pid=\'' . addslashes (trim ($rs2[0])) . '\''));
    $rs4 = mysql_fetch_row (mysql_query ('select email from user where uid=\'' . addslashes (trim ($referrer_id)) . '\''));
    $client_email = $rs4[0];
    $generate_date = date ('m/d/Y h:i:s a');
    $first_name = $rs1[0];
    $last_name = $rs1[1];
    $hosting_package = $rs3[0];
    $subject = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $subject = str_replace ('{{first_name}}', $first_name, $subject);
    $subject = str_replace ('{{last_name}}', $last_name, $subject);
    $subject = str_replace ('{{hosting_package}}', $hosting_package, $subject);
    $message = stripslashes (trim ($rs[1]));
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    $message = str_replace ('{{first_name}}', $first_name, $message);
    $message = str_replace ('{{last_name}}', $last_name, $message);
    $message = str_replace ('{{hosting_package}}', $hosting_package, $message);
    if (strcmp ($default_email, '') == 0)
    {
      $default_email = $email_admin;
    }

    $admin_name = $site_name;
    $client_name = $first_name . ' ' . $last_name;
    exec_emailcf ($client_email, $client_name, $default_email, $admin_name, $subject, $message, 0, 3);
  }

  function notify_of_payout ($array)
  {
    global $site_name;
    $query = 'select ';
    $query = 'subject, ';
    $query = 'message, ';
    $query = 'default_email ';
    $query = 'from ';
    $query = 'email_templates ';
    $query = 'where ';
    $query = 'emid=\'28\'';
    $rs = mysql_fetch_row (mysql_query ($query));
    $subject = stripslashes (trim ($rs[0]));
    $message = stripslashes (trim ($rs[1]));
    $default_email = stripslashes (trim ($rs[2]));
    $query = 'select ';
    $query .= 'email, ';
    $query .= 'first_name, ';
    $query .= 'last_name ';
    $query .= 'from ';
    $query .= 'user ';
    $query .= 'where ';
    $query .= 'uid=\'' . addslashes (trim ($array['uid'])) . '\'';
    $rs = mysql_fetch_row (mysql_query ($query));
    $client_email = stripslashes (trim ($rs[0]));
    $first_name = stripslashes (trim ($rs[1]));
    $last_name = stripslashes (trim ($rs[2]));
    $generate_date = date ('m/d/Y h:i:s a');
    $payout_amount = $array['currency'];
    $payout_amount .= $array['payout_amount'];
    $payout_amount .= $array['currency_type'];
    $email_admin = $array['email_admin'];
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $subject = str_replace ('{{payout_amount}}', $payout_amount, $subject);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    $message = str_replace ('{{payout_amount}}', $payout_amount, $message);
    if (strcmp ($default_email, '') == 0)
    {
      $default_email = $email_admin;
    }

    $admin_name = $site_name;
    $client_name = $first_name . ' ' . $last_name;
    exec_emailcf ($client_email, $client_name, $default_email, $admin_name, $subject, $message, 0, 3);
    $subject .= ' - Admin Copy';
    $message .= '

-------------------------------------------------------------';
    $message .= '

This is a copy of the message that was sent to the client.
';
    exec_emailcf ($email_admin, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
    return true;
  }

  function tt_client_new_ticket ($ticket_number)
  {
    global $uid;
    global $email_admin;
    global $email_support;
    global $email;
    $query0 = 'select ';
    $query0 .= 'subject, ';
    $query0 .= 'message, ';
    $query0 .= 'default_email ';
    $query0 .= 'from ';
    $query0 .= 'email_templates ';
    $query0 .= 'where ';
    $query0 .= 'emid=\'44\' ';
    $query0 .= 'limit 0, 1';
    $rs0 = mysql_fetch_row (mysql_query ($query0));
    $subject = stripslashes (trim ($rs0[0]));
    $message = stripslashes (trim ($rs0[1]));
    $default_email = stripslashes (trim ($rs0[2]));
    $query = 'select ';
    $query .= 'first_name, ';
    $query .= 'last_name ';
    $query .= 'from ';
    $query .= 'user ';
    $query .= 'where ';
    $query .= 'uid=\'' . addslashes (trim ($uid)) . '\'';
    $rs = mysql_fetch_row (mysql_query ($query));
    $first_name = stripslashes (trim ($rs[0]));
    $last_name = stripslashes (trim ($rs[1]));
    $query = 'select ';
    $query .= 'message ';
    $query .= 'from ';
    $query .= 'ticket ';
    $query .= 'where ';
    $query .= 'id=\'' . addslashes (trim ($ticket_number)) . '\'';
    $rs = mysql_fetch_row (mysql_query ($query));
    $ticket_details = stripslashes (trim ($rs[0]));
    $generate_date = date ('m/d/Y h:i:s a');
    $subject = str_replace ('{{first_name}}', $first_name, $subject);
    $subject = str_replace ('{{last_name}}', $last_name, $subject);
    $subject = str_replace ('{{ticket_number}}', $ticket_number, $subject);
    $subject = str_replace ('{{ticket_details}}', $ticket_details, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $message = str_replace ('{{first_name}}', $first_name, $message);
    $message = str_replace ('{{last_name}}', $last_name, $message);
    $message = str_replace ('{{ticket_number}}', $ticket_number, $message);
    $message = str_replace ('{{ticket_details}}', $ticket_details, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    global $email_admin;
    global $site_name;
    if (strcmp ($default_email, '') == 0)
    {
      $default_email = $email_admin;
    }

    $admin_name = $site_name;
    exec_emailcf ($email_support, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
    $client_name = $first_name . ' ' . $last_name;
    $subject .= ' - Client Copy';
    $message .= '

This message is an exact copy of your reply to the ticket.';
    exec_emailcf ($email, $client_name, $default_email, $admin_name, $subject, $message, 0, 3);
  }

  function tt_client_reply ($ticket_number)
  {
    global $uid;
    global $email_support;
    global $email;
    $query0 = 'select ';
    $query0 .= 'subject, ';
    $query0 .= 'message, ';
    $query0 .= 'default_email ';
    $query0 .= 'from ';
    $query0 .= 'email_templates ';
    $query0 .= 'where ';
    $query0 .= 'emid=\'45\' ';
    $query0 .= 'limit 0, 1';
    $rs0 = mysql_fetch_row (mysql_query ($query0));
    $subject = stripslashes (trim ($rs0[0]));
    $message = stripslashes (trim ($rs0[1]));
    $default_email = stripslashes (trim ($rs0[2]));
    $query = 'select ';
    $query .= 'first_name, ';
    $query .= 'last_name ';
    $query .= 'from ';
    $query .= 'user ';
    $query .= 'where ';
    $query .= 'uid=\'' . addslashes (trim ($uid)) . '\'';
    $rs = mysql_fetch_row (mysql_query ($query));
    $first_name = stripslashes (trim ($rs[0]));
    $last_name = stripslashes (trim ($rs[1]));
    $query = 'select ';
    $query .= 'message ';
    $query .= 'from ';
    $query .= 'ticket ';
    $query .= 'where ';
    $query .= 'id=\'' . addslashes (trim ($ticket_number)) . '\'';
    $rs = mysql_fetch_row (mysql_query ($query));
    $ticket_details = stripslashes (trim ($rs[0]));
    $generate_date = date ('m/d/Y h:i:s a');
    $subject = str_replace ('{{first_name}}', $first_name, $subject);
    $subject = str_replace ('{{last_name}}', $last_name, $subject);
    $subject = str_replace ('{{ticket_number}}', $ticket_number, $subject);
    $subject = str_replace ('{{ticket_details}}', $ticket_details, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $message = str_replace ('{{first_name}}', $first_name, $message);
    $message = str_replace ('{{last_name}}', $last_name, $message);
    $message = str_replace ('{{ticket_number}}', $ticket_number, $message);
    $message = str_replace ('{{ticket_details}}', $ticket_details, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    global $site_name;
    if (strcmp ($default_email, '') == 0)
    {
      $default_email = $email_admin;
    }

    $admin_name = $site_name;
    exec_emailcf ($email_support, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
    $client_name = $first_name . ' ' . $last_name;
    $subject .= ' - Client Copy';
    $message .= '

This message is an exact copy of your reply to the ticket.';
    exec_emailcf ($email, $client_name, $default_email, $admin_name, $subject, $message, 0, 3);
  }

  function tt_admin_reply ($ticket_number)
  {
    global $uid;
    global $email_support;
    global $email;
    $query0 = 'select ';
    $query0 .= 'subject, ';
    $query0 .= 'message, ';
    $query0 .= 'default_email ';
    $query0 .= 'from ';
    $query0 .= 'email_templates ';
    $query0 .= 'where ';
    $query0 .= 'emid=\'46\' ';
    $query0 .= 'limit 0, 1';
    $rs0 = mysql_fetch_row (mysql_query ($query0));
    $subject = stripslashes (trim ($rs0[0]));
    $message = stripslashes (trim ($rs0[1]));
    $default_email = stripslashes (trim ($rs0[2]));
    $query = 'select ';
    $query .= 'first_name, ';
    $query .= 'last_name ';
    $query .= 'from ';
    $query .= 'user ';
    $query .= 'where ';
    $query .= 'uid=\'' . addslashes (trim ($uid)) . '\'';
    $rs = mysql_fetch_row (mysql_query ($query));
    $first_name = stripslashes (trim ($rs[0]));
    $last_name = stripslashes (trim ($rs[1]));
    $query = 'select ';
    $query .= 'message ';
    $query .= 'from ';
    $query .= 'ticket ';
    $query .= 'where ';
    $query .= 'id=\'' . addslashes (trim ($ticket_number)) . '\'';
    $rs = mysql_fetch_row (mysql_query ($query));
    $ticket_details = stripslashes (trim ($rs[0]));
    $generate_date = date ('m/d/Y h:i:s a');
    $subject = str_replace ('{{first_name}}', $first_name, $subject);
    $subject = str_replace ('{{last_name}}', $last_name, $subject);
    $subject = str_replace ('{{ticket_number}}', $ticket_number, $subject);
    $subject = str_replace ('{{ticket_details}}', $ticket_details, $subject);
    $subject = str_replace ('{{generate_date}}', $generate_date, $subject);
    $message = str_replace ('{{first_name}}', $first_name, $message);
    $message = str_replace ('{{last_name}}', $last_name, $message);
    $message = str_replace ('{{ticket_number}}', $ticket_number, $message);
    $message = str_replace ('{{ticket_details}}', $ticket_details, $message);
    $message = str_replace ('{{generate_date}}', $generate_date, $message);
    $query = 'select ';
    $query .= 'reply ';
    $query .= 'from ';
    $query .= 'ticket_reply ';
    $query .= 'where ';
    $query .= 'id=\'' . addslashes (trim ($ticket_number)) . '\' ';
    $query .= 'and ';
    $query .= 'reply_status=\'1\' ';
    $query .= 'order by rid desc ';
    $query .= 'limit 0, 1';
    $rs = mysql_fetch_row (mysql_query ($query));
    $ticket_details = stripslashes (trim ($rs[0]));
    $subject = str_replace ('{{admin_reply_details}}', $ticket_details, $subject);
    $message = str_replace ('{{admin_reply_details}}', $ticket_details, $message);
    global $email_admin;
    global $site_name;
    if (strcmp ($default_email, '') == 0)
    {
      $default_email = $email_admin;
    }

    $admin_name = $site_name;
    $client_name = $first_name . ' ' . $last_name;
    exec_emailcf ($email, $client_name, $default_email, $admin_name, $subject, $message, 0, 3);
    $subject .= ' - Admin Copy';
    $message .= '

-------------------------------------------------------------';
    $message .= '

This is a copy of the message that was sent to the client.
';
    exec_emailcf ($email_support, $admin_name, $email_admin, $admin_name, $subject, $message, 0, 3);
  }

?>
