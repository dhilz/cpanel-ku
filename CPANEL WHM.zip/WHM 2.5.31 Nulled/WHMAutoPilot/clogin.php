<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/client_functions.php";
if (isset($submit))
	{
	if (trim($username)=="") { $err=true; }
	if (trim($password)=="") { $err=true; }
	$lookup=lookup_client_username($username);
	if ($lookup==0) { $err=true; }

	if (!$err)
		{
		if (validate_client_password($password, $lookup)==0)
			{
			$sid=update_client_session($lookup);

			header("Location: ".$http_web."/client_area.php?sid=".trim($sid));
			exit;
			}
		else { $err=true; }
		}
	}
	
// forgot password...
if (isset($submitx))
	{
	if (check_ct_user_by_email($email)<=0) 
		{ 
		if (strlen(trim($email))==0) { $email="not entered"; }
		$err1=true; 
		} 
	else 
		{ 
		$lookup=isset_client($email);
		if ($lookup>=1) 
			{
			recreate_password($email, $site_name, $email_admin, update_client_with_random($email));

			$done=true;
			}

		# recreate_password($email, $site_name, $email_admin);
		$done=true;
		}
	}

include "inc/header.php";
echo("
		<form action='".$PHP_SELF."' method='POST'>
		<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
		<tr>
			<td colspan='2'><img src='".$http_images."/menu_arrow.gif'>".$text_clientarea."</td>
		<tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/space.gif' width='1' height='4'></td>
		</tr>
		");
if (isset($err))
	{
	echo("
		<tr>
			<td colspan='2'><img src='".$http_images."/space.gif' width='15' height='9'><img src='".$http_images."/error_arrow.gif'>".$error_usernotfound.".</td>
		<tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/space.gif' width='15' height='9'><img src='".$http_images."/drop_arrow.gif'>".$text_ifthisiserror."</td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/space.gif' width='1' height='4'></td>
		</tr>
		");
	}

echo("
		<tr>
			<td align='left' valign='middle' width='25%'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_enterusername.":</td>
			<td align='left' valign='middle' width='75%'><input ".$orderinput_style." size='30' maxlength='50' type='text' name='username' value='".((isset($username))?"".$username."":"")."'></td>
		</tr>
		<tr>
			<td align='left' valign='middle' width='25%'><img src='".$http_images."/space.gif' width='15' height='9'><font color='#000000'>".$text_enterpassword.":</font></td>
			<td align='left' valign='middle' width='75%'><input ".$orderinput_style." size='30' maxlength='50' type='password' name='password' value='".$password."'></td>
		</tr>
		<tr>
			<td align='left' valign='middle' width='25%'></td>
			<td align='left' valign='middle' width='75%'><input ".$orderbutton_style." type='submit' name='submit' value='".$text_loginnow."'></td>
		</tr>
	</table>
	</form>
	
	<form action='".$PHP_SELF."' method='POST'>
	<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
		<tr>
			<td colspan='2'><img src='".$http_images."/space.gif' width='1' height='30'></td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/menu_arrow.gif'>".$text_resendaccount."</td>
		<tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/space.gif' width='1' height='4'></td>
		</tr>
		");
if (isset($done))
	{
	echo("
		<tr>
			<td colspan='2'><img src='".$http_images."/space.gif' width='15' height='9'><img src='".$http_images."/error_arrow.gif'>".$text_informationemailed.".</td>
		<tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/space.gif' width='1' height='4'></td>
		</tr>
		");
	}
if (isset($err1))
	{
	echo("
		<tr>
			<td colspan='2'><img src='".$http_images."/space.gif' width='15' height='9'><img src='".$http_images."/error_arrow.gif'>".$text_norecords."</td>
		<tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/space.gif' width='15' height='9'><img src='".$http_images."/drop_arrow.gif'>".$text_ifthisiserror."</td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/space.gif' width='1' height='4'></td>
		</tr>
		");
	}
echo("
		<tr>
			<td align='left' valign='middle' width='25%'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_enteremail.":</td>
			<td align='left' valign='middle' width='75%'><input ".$orderinput_style." size='30' maxlength='50' type='text' name='email' value='".((isset($email))?"".$email."":"")."'></td>
		</tr>
		<tr>
			<td align='left' valign='middle' width='25%'></td>
			<td align='left' valign='middle' width='75%'><input ".$orderbutton_style." type='submit' name='submitx' value='".$text_resendnow."'></td>
		</tr>
		<tr>
			<td colspan='2'><img src='".$http_images."/space.gif' width='1' height='30'></td>
		</tr>
	</table>
	</form>
	");
include "inc/footer.php";
?>