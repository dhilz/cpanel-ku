<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/varilogix_functions.php";

$cksid=mysql_fetch_row(mysql_query("select count(*) from session_history where sid='".addslashes(trim($sid))."'"));

if ($cksid[0]<=0) {	header("Location: ".$http_web."/step_one.php");	exit; }
else if (!isset($sid)) { header("Location: ".$http_web."/step_one.php"); exit; }

include "inc/header.php";

$query="select ";
$query.="phone ";
$query.="from ";
$query.="session_history ";
$query.="where ";
$query.="sid='".addslashes(trim($sid))."' ";
$query.="limit 0, 1";

$rs=mysql_fetch_row(mysql_query($query));

echo("
	<table width='400' cellpadding='2' cellspacing='0' border='0' align='center'>
		<tr>
			<td>We will now attempt to verify your telephone number [".$rs[0]."].</td>
		</tr>
		<tr>
			<td><img src='".$http_images."/callback[-1].gif' height='4' width='1'></td>
		</tr>
		<tr>
			<td><b>This is a three (3) step process:</b></td>
		</tr>
		<tr>
			<td>&nbsp;1. We are calling you now. Please answer your phone to continue.</td>
		</tr>
		<tr>
			<td>&nbsp;2. Please follow the operators instructions.</td>
		</tr>
		<tr>
			<td>&nbsp;3. We will accept or deny the order based on phone validation.</td>
		</tr>
		<tr>
			<td><img src='".$http_images."/callback[-1].gif' height='4' width='1'></td>
		</tr>
		<tr>
			<td><b>This could take several minutes. Please be patient.</b></td>
		</tr>
		<tr>
			<td><img src='".$http_images."/callback[-1].gif' height='4' width='1'></td>
		</tr>
	</table>
	");

echo "<iframe ";
echo "align='center' ";
echo "frameborder='0' ";
echo "height='300' ";
echo "width='400' ";
echo "scrolling='no' ";
echo "src='".$http_web."/process_phone.php?sid=".$sid."".((isset($gid))?"&gid=".$gid."":"")."'>";
echo "</iframe>";

include "inc/footer.php";
mysql_close($dblink);
?>