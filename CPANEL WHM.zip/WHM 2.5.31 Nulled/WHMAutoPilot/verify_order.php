<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/select.php";
include "inc/client_functions.php";
include "inc/invoice_functions.php";
include "inc/whm_functions.php";
include "inc/affiliate_functions.php";
include $server_tools."/verify_order_code[0].php";
include "inc/header.php";

echo $parse_out0;

echo("
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'><td>
	</tr>
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><b>".$text_packagedetails."</b></td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>[<a href='".$http_web."/verify_order.php?ul=0&sid=".$sid."&gid=".trim($gid)."'>".$text_clicktoedit."</td>
	</tr>
	");
if ($dedicated==1)
	{
	echo("
		<tr>
			<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_packageordered.":</td>
			<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".$plan_group_name.": ".$package_name."<br><img src='".$http_images."/error_arrow.gif'><i>".$web_space." ".$text_gigdrive."</i><br><img src='".$http_images."/error_arrow.gif'><i>".$bandwidth." ".$text_gigtransfer."</i></td>
		</tr>
		");
	}
else
	{
	echo("
		<tr>
			<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_packageordered.":</td>
			<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".$plan_group_name.": ".$package_name."<br><img src='".$http_images."/error_arrow.gif'><i>".$web_space." ".$text_megwebspace."</i><br><img src='".$http_images."/error_arrow.gif'><i>".$bandwidth." ".$text_megwebtransfer."</i><br><img src='".$http_images."/error_arrow.gif'><i>".$text_emailaddresses.":".(($email_wp==-1)?"".$text_unlimited."":"".$email_wp."")." </i></td>
		</tr>
		");
	}
echo("
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='1'></td>
	</tr>
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$payment_term." ".$text_cost.":</td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".$formatted_cost."</td>
	</tr>
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_setupfee.":</td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".(($setup_cost==0)?"".$text_none."":"".$currency.sprintf("%01.2f", $setup_cost)." ".$currency_type." ".$text_onetimefee."")."</td>
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'></td>
	</tr>
	");
if ($dedicated==1)
	{
	echo("
		<tr>
			<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'>".$text_serveroptions." </td>
			<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>[<a href='".$http_web."/verify_order.php?ul=1&sid=".$sid."&gid=".trim($gid)."'>".$text_clicktoedit."</td>
		</tr>
		<tr>
			<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_serverhostname.":</td>
			<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".$server_hostname.".".$domain_name."</td>
		</tr>
		<tr>
			<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_nameservers.":</td>
			<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".$pns1.".".$domain_name."</td>
		</tr>
		<tr>
			<td width='".$verifyorder_leftcolumn."' align='left' valign='top'></td>
			<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".$pns2.".".$domain_name."</td>
		</tr>
		<tr>
			<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_rootpassword."</td>
			<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".$root_pw."</td>
		</tr>
		");
	}
else
	{
	echo("
		<tr>
			<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'>".$text_domainoptions." </td>
			<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>[<a href='".$http_web."/verify_order.php?ul=1&sid=".$sid."&gid=".trim($gid)."'>".$text_clicktoedit."</td>
		</tr>
		<tr>
			<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_domainname.":</td>
			<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>http://www.".$domain_name."</td>
		</tr>
		<tr>
			<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_domainregistration.":</td>
			<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".(($domain_registration==1)?"".$text_wewillregister."":"".$text_youwilltransfer."")."</td>
		</tr>
		");
	if ($domain_registration==1)
		{
		echo("
			<tr>
				<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_domainregcost.":</td>
				<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".$text_peryear." ".(($domain_fee==1)?"<font color='#990000'>* Will be billed separately.</font>":"")."</td>
			</tr>
			");
		}
	if (strlen(trim(str_replace("/", "", $domain_expire)))!=0&&$domain_registration!=1)
		{
		echo("
			<tr>
				<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_domainexpireson.":</td>
				<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".stripslashes($domain_expire)."</td>
			</tr>
			");
		}
	if ($domain_registration!=1)
		{
		// get current NS
		if ($whm_id!=0&&$whm_id!=-1)
			{
			$q_="select ";
			$q_.="primary_ns, ";		// 0
			$q_.="primary_ns_ip, ";		// 1
			$q_.="secondary_ns, ";		// 2
			$q_.="secondary_ns_ip ";	// 3
			$q_.="from ";
			$q_.="server_config ";
			$q_.="where ";
			$q_.="whm_id='".addslashes(trim($whm_id))."' ";
			$q_.="limit 0, 1";

			$rs_=mysql_fetch_row(mysql_query($q_));

			$primary_ns=stripslashes(trim($rs_[0]));
			$primary_ns_ip=stripslashes(trim($rs_[1]));
			$secondary_ns=stripslashes(trim($rs_[2]));
			$secondary_ns_ip=stripslashes(trim($rs_[3]));
			}
		else
			{
			$current_ns=current_ns();
			if ($current_ns!=99) { list($primary_ns, $primary_ns_ip, $secondary_ns, $secondary_ns_ip)=split("[|]", $current_ns); }
			}

		echo("
			<tr>
				<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_ournameservers.":</td>
				<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".stripslashes($primary_ns)." [".$primary_ns_ip."]<br>".$secondary_ns." [".$secondary_ns_ip."]</td>
			</tr>
			");
		}

	// --------------------------------------------------------------------------------------------------------------------
	}

# 8/5/2003
// select all addons for the set
$addon_query="select group_addons from addon_groups where addon_gid='".addslashes(trim($addon_gid))."'";
$rs=mysql_fetch_row(mysql_query($addon_query));
$group_addons=stripslashes(trim($rs[0]));
# 8/5/2003

if (trim($addon_choices)!="") 
	{
	echo("
		<tr>
			<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'></td>
		</tr>
		<tr>
			<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'>".$text_accountaddons." </td>
			<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>[<a href='".$http_web."/verify_order.php?ul=2&sid=".$sid."&gid=".trim($gid)."&addon_gid=".base64_encode($addon_gid)."'>".$text_clicktoedit."</td>
		</tr>
		");

	$temp=$setup_cost;
	include $server_tools."/verify_order_code[1].php";
	$setup_cost=$temp;
	}

echo("
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'></td>
	</tr>
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'>".$text_accountinformationtitle." </td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>[<a href='".$http_web."/verify_order.php?ul=3&sid=".$sid."&gid=".trim($gid)."'>".$text_clicktoedit."</td>
	</tr>
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_clientfullname.":</td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".$first_name." ".$last_name."</td>
	</tr>
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_companyname.":</td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".$organization_name."</td>
	</tr>
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_address1.":</td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".$street_address_1."</td>
	</tr>
	");

if (strlen($street_address_2)!=0)
	{
	echo("
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'></td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".$street_address_2."</td>
	</tr>
		");
	}

echo("
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'></td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".$city.",  ".$state." ".$zip_code." ".$country."</td>
	</tr>
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_phone.":</td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".$phone."</td>
	</tr>
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_fax.":</td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".((strlen(fax)==0)?"N/A":"".$fax."")."</td>
	</tr>
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_emailaddress.":</td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".$email."</td>
	</tr>
	");

if ($uid==0)
	{
	echo("
		<tr>
			<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_clientusername.":</td>
			<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".$username."</td>
		</tr>
		<tr>
			<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_clientpassword.":</td>
			<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".$password."</td>
		</tr>
		");
	}

echo("
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_howfound."</td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".stripslashes($advert)."</td>
	</tr>
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_ifother.":</td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".(($advert_other!=0)?"".$advert_other."":"N/A")."</td>
	</tr>
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_termsofservice."</td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".(($tos==1)?"".$text_youagreeterms."":"".$text_youdidnotagree."")."</td>
	</tr>
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_clientnotes.":</td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>".((trim($client_notes)!="")?"".$client_notes."":"".$text_nonerecorded."")."</td>
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><hr width='100%' color='#e7e7e7'></td>
	</tr>
	");

include $server_tools."/verify_order_code[2].php";

if (trim($free_trial)=="1"&&trim($payment_method)=="1")
	{
	if($cost_per_tld=="") {$cost_per_tld="0.00"; }
	echo("
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'><b>Total due today:</b></td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>
		<table width='100%' cellpadding='0' cellspacing='0' border='0'>
			<tr>
				<td width='15%' align='left' valign='top'><font color='#990000'><b>".$currency."".$cost_per_tld." ".$currency_type."</b></font><br><img src='".$http_image."/space.gif' width='115' height='1'></td>
				<td width='45%' align='left' valign='top'><font color='#990000'>* ".$free_trial_length." ".$text_month."".(($free_trial_length!=1)?"s":"")." ".$text_freetrial."<BR>* Domain Registration Fees will apply, if applicable</font></td>
				<td width='40%' align='left' valign='top'><img src='".$http_image."/space.gif' width='60%' height='1'></td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'></td>
	</tr>
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'><b>".$text_firstchargeamount.":</b></td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>
		<table width='100%' cellpadding='0' cellspacing='0' border='0'>
			<tr>
				<td width='15%' align='left' valign='top'><font color='#990000'><b>".$currency."".sprintf("%01.2f", $total_due_today)."".$currency_type."</b></font><br><img src='".$http_image."/space.gif' width='115' height='1'></td>
				<td width='45%' align='left' valign='top'>".((isset($used_coupon))?"".$used_coupon."":"")."</td>
				<td width='40%' align='left' valign='top'><img src='".$http_image."/space.gif' width='60%' height='1'></td>
			</tr>
		</table>
		</td>
	</tr>
		");
	}
else 
	{ 
	echo("
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'><b>".$text_totalduetoday.":</b></td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>
		<table width='100%' cellpadding='0' cellspacing='0' border='0'>
			<tr>
				<td width='15%' align='left' valign='top'><font color='#990000'><b>".$currency."".sprintf("%01.2f", $total_due_today)."".$currency_type."</b></font><br><img src='".$http_image."/space.gif' width='115' height='1'></td>
				<td width='45%' align='left' valign='top'>".((isset($used_coupon))?"".$used_coupon."":"")."</td>
				<td width='40%' align='left' valign='top'><img src='".$http_image."/space.gif' width='60%' height='1'></td>
			</tr>
		</table>
		</td>
	</tr>
		"); 
	}

echo("
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'></td>
	</tr>
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'><b>".$text_totalrecurring." ".$payment_term.":</b></td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>
		<table width='100%' cellpadding='0' cellspacing='0' border='0'>
			<tr>
				<td width='15%' align='left' valign='top'><font color='#990000'><b>".$currency."".sprintf("%01.2f", $total_reoccur)."".$currency_type."</b></font><br><img src='".$http_image."/space.gif' width='115' height='1'></td>
				<td width='45%' align='left' valign='top'>".((isset($xused_coupon))?"".$xused_coupon."":"")."</td>
				<td width='40%' align='left' valign='top'><img src='".$http_image."/space.gif' width='60%' height='1'></td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'></td>
	</tr>
	<tr>
		<td width='".$verifyorder_leftcolumn."' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'><b>".$text_paymentmethod.":</b></td>
		<td width='".$verifyorder_rightcolumn."' align='left' valign='top'>
	");

echo $parse_out2;

echo("
		</td>
	</tr>
	<tr>
		<td colspan='2'><img src='".$http_images."/space.gif' width='1' height='20'></td>
	</tr>
");
if (strcmp("2checkout", strtolower($payment_type_name))==0)
	{
	echo("
	<tr>
		<TD COLSPAN='2'><center><input ".$orderbutton_style." type='submit' name='submit' value='Purchase from 2Checkout'></center></td>
	</tr>
		");
	}
	else
	{
	echo("
	<tr>
		<TD COLSPAN='2'><center><input ".$orderbutton_style." type='submit' name='submit' value='".$verifyorder_submitbutton."'></center></td>
	</tr>
		");
	}
if (strcmp("2checkout", strtolower($payment_type_name))==0)
	{
	echo("
	<tr>
		<td colspan='2'><center>2Checkout.com, Inc. is an authorized retailer of goods and services provided by  <B>".$site_title."</b></td>
	</tr>
	");
}
echo("
</table>
</form>
	");

include "inc/footer.php";
mysql_close($dblink);
?>