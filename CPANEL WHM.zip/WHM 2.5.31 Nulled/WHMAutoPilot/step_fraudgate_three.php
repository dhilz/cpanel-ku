<?PHP
include "inc/var.php";
include "inc/connect.php";
include $server_inc."/pagefind.php";
include $server_inc."/languages/".$local_lang.".php";
include $server_inc."/languages/".$local_lang."/step_fraudgate.php";

$sid = $_POST['sid'];
$gid = $_POST['gid'];
$cksid=mysql_fetch_row(mysql_query("select count(*) from session_history where sid='".addslashes(trim($sid))."'"));

if ($cksid[0]<=0) {	header("Location: ".$http_web."/step_one.php");	exit; }
else if (!isset($sid)) { header("Location: ".$http_web."/step_one.php"); exit; }

include $server_inc."/header.php";

$query="select fg_call_info from session_history ";
$query.="where sid='".addslashes(trim($sid))."' ";
$query.="limit 0, 1";

$sidrow=@mysql_fetch_array(mysql_query($query));

echo "
	<table width='400' cellpadding='2' cellspacing='0' border='0' align='center' style='border-style: solid; border-color: #999999; border-width: 1px'>
        <tr>
			<td valign='center'>".$step3."</td>
        </tr>
        <tr>
			<td valign='center'>";

if(empty($sidrow['fg_call_info']))
{
    echo $pending . "</td></tr></table>";
    echo '<p align="center"><form action="step_fraudgate_three.php" method=POST>
      <input style="font-family:verdana, arial, helvetica; font-size: 8pt; border-style: solid; border-color: 999999; border-width: 1pxl; background-color: e7e7e7; font-weight: 800" type="submit" name="submit" value="' . $refresh . ' &gt&gt">
      <input type="hidden" name="sid" value="'.trim($sid).'">';
      if (isset($gid)) { echo "<input type='hidden' name='gid' value='".trim($gid)."'>\n"; }
    echo  '</form>';
}
else
{
    $result_info = explode(",", $sidrow['fg_call_info']);
    switch($result_info[0])
    {
        // success
        case 0:
        case 5:
        case 6:
        {
            echo $success . "</td></tr></table>";
            require_once("inc/step_fraudgate_form.php");
            break;
        }
       
        default: // failed
        {
            echo $failed . $result_info[1] . "</b></td></tr></table>";
            break;
        }
    }
           
}
include $server_inc."/footer.php";
mysql_close($dblink);
?>
