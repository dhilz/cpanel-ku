<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/select.php";
include "inc/client_functions.php";
include "inc/whm_functions.php";

// authenicate sid
if (auth_sid($sid)==1) { header("Location: ".$http_web."/clogin.php"); exit; }

$oid=base64_decode($uc);
$oid=d("576cb7f68040520768bf51c75f7f4c84", $oid);

$uid=base64_decode($ud);
$uid=d("576cb7f68040520768bf51c75f7f4c84", $uid);

if(phpversion() <= "4.0.6") { $_POST=$HTTP_POST_VARS; }
if (isset($_POST['x_Submit']))
	{
	if (strlen(trim($_POST['x_First_Name']))==0) { $e0=true; }
	if (strlen(trim($_POST['x_Last_Name']))==0) { $e1=true; }
	if (strlen(trim($_POST['x_Address']))==0) { $e2=true; }
	if (strlen(trim($_POST['x_City']))==0) { $e3=true; }
	if (strlen(trim($_POST['x_Zip']))==0) { $e4=true; }
	if (strlen(trim($_POST['x_Phone']))<10) { $e5=true; }
	if ($_POST['card_select']==0)
		{
		if (strlen(trim($_POST['x_Card_Num']))==0) { $e6=true; }
		if (strlen(trim($_POST['x_Exp_Date_m']))==0||strlen(trim($_POST['x_Exp_Date_y']))==0) { $e7=true; }
		}

	if (!isset($e0)&&!isset($e1)&&!isset($e2)&&!isset($e3)&&!isset($e4)&&!isset($e5)&&!isset($e6)&&!isset($e7))
		{
		$query1="update ";
		$query1.="authnet_master_cc ";
		$query1.="set ";
		$query1.="master_cc='0' ";
		$query1.="where uid='".addslashes(trim($uid))."'";

		mysql_query($query1);

		if ($_POST['card_select']==0)
			{
			$card_info=$_POST['x_Card_Num']."|".$_POST['x_Exp_Date_m'].$_POST['x_Exp_Date_y']."|0|";
			$card_info=e("576cb7f68040520768bf51c75f7f4c84", $card_info);

			$query1="insert into ";
			$query1.="authnet_master_cc ";
			$query1.="set ";
			$query1.="customer_first_name='".addslashes(trim($_POST['x_First_Name']))."', ";
			$query1.="customer_last_name='".addslashes(trim($_POST['x_Last_Name']))."', ";
			$query1.="customer_address='".addslashes(trim($_POST['x_Address']))."', ";
			$query1.="customer_city='".addslashes(trim($_POST['x_City']))."', ";
			$query1.="customer_state='".addslashes(trim($_POST['x_state']))."', ";
			$query1.="customer_zip='".addslashes(trim($_POST['x_Zip']))."', ";
			$query1.="customer_country='".addslashes(trim($_POST['x_Country']))."', ";
			$query1.="customer_phone='".addslashes(trim($_POST['x_Phone']))."', ";
			$query1.="customer_fax='".addslashes(trim($_POST['x_Fax']))."', ";
			$query1.="customer_email='".addslashes(trim($_POST['x_Email']))."', ";
			$query1.="card_info='".addslashes(trim($card_info))."', ";
			$query1.="uid='".addslashes(trim($uid))."', ";
			$query1.="master_cc='1', ";
			$query1.="ogcreate='".time()."'";

			mysql_query($query1);
			}
		else 
			{
			$query1="update ";
			$query1.="authnet_master_cc ";
			$query1.="set ";
			$query1.="customer_first_name='".addslashes(trim($_POST['x_First_Name']))."', ";
			$query1.="customer_last_name='".addslashes(trim($_POST['x_Last_Name']))."', ";
			$query1.="customer_address='".addslashes(trim($_POST['x_Address']))."', ";
			$query1.="customer_city='".addslashes(trim($_POST['x_City']))."', ";
			$query1.="customer_state='".addslashes(trim($_POST['x_state']))."', ";
			$query1.="customer_zip='".addslashes(trim($_POST['x_Zip']))."', ";
			$query1.="customer_country='".addslashes(trim($_POST['x_Country']))."', ";
			$query1.="customer_phone='".addslashes(trim($_POST['x_Phone']))."', ";
			$query1.="customer_fax='".addslashes(trim($_POST['x_Fax']))."', ";
			$query1.="customer_email='".addslashes(trim($_POST['x_Email']))."', ";
			$query1.="master_cc='1' ";
			$query1.="where ";
			$query1.="ccid='".addslashes(trim($_POST['card_select']))."'";
			
			mysql_query($query1);
			}

		$done=true;
		}
	}

$query4="select ";
$query4.="customer_first_name, ";	// 0
$query4.="customer_last_name, ";	// 1
$query4.="customer_address, ";		// 2
$query4.="customer_city, ";			// 3
$query4.="customer_state, ";		// 4
$query4.="customer_zip, ";			// 5
$query4.="customer_country, ";		// 6
$query4.="customer_phone, ";		// 7
$query4.="customer_fax, ";			// 8
$query4.="customer_email, ";		// 9
$query4.="count(*), ";				// 10
$query4.="ccid ";					// 11
$query4.="from ";
$query4.="authnet_master_cc ";
$query4.="where ";
$query4.="uid='".addslashes(trim($uid))."' ";
$query4.="and ";
$query4.="master_cc='1' ";
$query4.="group by customer_last_name";

$rs4=mysql_fetch_row(mysql_query($query4));

$x_First_Name=stripslashes(trim($rs4[0]));
$x_Last_Name=stripslashes(trim($rs4[1]));
$x_Address=stripslashes(trim($rs4[2]));
$x_City=stripslashes(trim($rs4[3]));
$x_state=stripslashes(trim($rs4[4]));
$x_Zip=stripslashes(trim($rs4[5]));
$x_Country=stripslashes(trim($rs4[6]));
$x_Phone=stripslashes(trim($rs4[7]));
$x_Fax=stripslashes(trim($rs4[8]));
$x_Email=stripslashes(trim($rs4[9]));
$count=$rs4[10];
$ccid=$rs4[11];

include "inc/header.php";

if (isset($e0))
	{
	echo("
			<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
				<tr>
					<td><font color='#C60C08'><b>ERROR!</b></font> Please enter the card holders first name to continue.</td>
				</tr>
			</table>
			");
	}

if (isset($e1))
	{
	echo("
			<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
				<tr>
					<td>".$error_nolastname."</td>
				</tr>
			</table>
			");
	}

if (isset($e2))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td>".$error_noaddress."</td>
			</tr>
		</table>
		");
	}

if (isset($e3))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td>".$error_nocity."</td>
			</tr>
		</table>
		");
	}

if (isset($e4))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td>".$error_nozip."</td>
			</tr>
		</table>
		");
	}

if (isset($e5))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td>".$error_nophone."</td>
			</tr>
		</table>
		");
	}

if (isset($e6))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td>".$error_nocard."</td>
			</tr>
		</table>
		");
	}

if (isset($e7))
	{
	echo("
		<table width='".$error_table_width."' cellpadding='".$error_table_padding."' cellspacing='".$error_table_spacing."' ".$error_table_border." align='".$error_table_align."' bgcolor='".$error_table_bgcolor."'>
			<tr>
				<td>".$error_noexpiration."</td>
			</tr>
		</table>
		");
	}

echo("
	<form action='".$PHP_SELF."' method='POST'>
	<input type='hidden' name='uc' value='".$uc."'>
	<input type='hidden' name='ud' value='".$ud."'>
	<input type='hidden' name='sid' value='".$sid."'>
	".((trim($ccid)!="")?"<input type='hidden' name='ccid' value='".$ccid."'>":"")."
	<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
		<tr>
			<td colspan='2'>[<a href='".$http_web."/client_area.php?sid=".$sid."'>".$text_goback."</a>] <b>".$text_updateccinfo."</b></td>
		</tr>
		<tr>
			<td colspan='2'><hr color='#F0EFED'></td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><b>".$text_ccpersonalinfo."</b><td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_firstname.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='40' maxlength='50' type='text' name='x_First_Name' value='".((isset($x_First_Name))?"".$x_First_Name."":"")."'></td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_lastname.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='40' maxlength='50' type='text' name='x_Last_Name' value='".((isset($x_Last_Name))?"".$x_Last_Name."":"")."'></td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_address1.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='40' maxlength='60' type='text' name='x_Address' value='".((isset($x_Address))?"".$x_Address."":"")."'></td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_city.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='40' maxlength='40' type='text' name='x_City' value='".((isset($x_City))?"".$x_City."":"")."'></td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_state.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='40' maxlength='40' type='text' name='x_state' value='".((isset($x_state))?"".$x_state."":"")."'><BR>( 2 Digits State/Province Abbreviation )</td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_zip.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='20' maxlength='20' type='text' name='x_Zip' value='".((isset($x_Zip))?"".$x_Zip."":"")."'></td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_country.":</td>
			<td width='65%' align='left' valign='top'>".display_country($x_Country, $orderinput_style)."</td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_phone.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='15' maxlength='15' type='text' name='x_Phone' value='".((isset($x_Phone))?"".$x_Phone."":"")."'></td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_fax.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='15' maxlength='15' type='text' name='x_Fax' value='".((isset($x_Fax))?"".$x_Fax."":"")."'></td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_email.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='40' maxlength='255' type='text' name='x_Email' value='".((isset($x_Email))?"".$x_Email."":"")."'></td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'><td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><b>".$text_ccinfo."</b><td>
		</tr>
	");

if ($count>=1)
	{
	echo("
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_useexisting.":</td>
			<td width='65%' align='left' valign='top'><select name='card_select' ".$orderinput_style.">
			<option value='0'>".$text_enternewcc."</option>
		");
	$query3="select ";
	$query3.="ccid, ";
	$query3.="card_info, ";
	$query3.="master_cc ";
	$query3.="from ";
	$query3.="authnet_master_cc ";
	$query3.="where ";
	$query3.="uid='".addslashes(trim($uid))."' ";

	$row3=mysql_query($query3);
	while ($rs3=mysql_fetch_row($row3))
		{
		list($card_num, $card_exp, $card_code)=explode("|", d("576cb7f68040520768bf51c75f7f4c84", $rs3[1]));
		$a=substr($card_exp, 0, 2);
		$b=substr($card_exp, -2);

		echo "<option value='".$rs3[0]."'".(($rs3[2]==1)?" selected":"").">".substr($card_num, 0, 2)."**********".substr($card_num, -4)." [expires: ".$a."/".$b."]</option>\n";
		}

	unset($x_Card_Num);
	unset($x_Exp_Date_y);
	unset($x_Exp_Date_m);
	unset($x_Card_Code);
	echo("
				</select></td>
			</tr>
		");
	}
echo("
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_newccnumber.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='40' maxlength='22' type='text' name='x_Card_Num'></td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_newccexp.":</td>
			<td width='65%' align='left' valign='top'><input ".$orderinput_style." size='2' maxlength='2' type='text' name='x_Exp_Date_m'>&nbsp;/&nbsp;<input ".$orderinput_style." size='2' maxlength='2' type='text' name='x_Exp_Date_y'>&nbsp;<font color='#990000'>ex. MM/YY</font></td>
		</tr>
		<tr>
			<td colspan='2' align='left' valign='top'><img src='".$http_images."/space.gif' width='1' height='10'><td>
		</tr>
		<tr>
			<td width='35%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'></td>
			<td width='65%' align='left' valign='top'><input ".$orderbutton_style." type='submit' name='x_Submit' value='".$text_updatenow."'></td>
		</tr>
	</table>
	");
include "inc/footer.php";
mysql_close($dblink);
?>