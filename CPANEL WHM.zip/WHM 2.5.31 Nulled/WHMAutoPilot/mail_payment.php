<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/pagefind.php";
include "inc/languages/".$local_lang.".php";
include "inc/languages/".$local_lang."/".file_name().".php";
include "inc/whm_functions.php";

if (isset($c))
	{
	if (file_exists($below_public."/".$c."_invoice.log"))
		{
		$read=file($below_public."/".$c."_invoice.log");
		list($change_gid, $change_oid)=split("[|]", base64_decode($c));
		}
	else
		{
		header("Location: ".$http_web);
		exit;
		}
	}
else
	{
	header("Location: ".$http_web);
	exit;
	}

if (isset($show))
	{
	echo("
		<html>
		<head>
			<title>".$site_title."</title>
		</head>
		</body>
		");
	}
else
	{
	include "inc/header.php";
	}

// pull in mail to information
$rs0=mysql_fetch_row(mysql_query("select bymail_to, bymail_address1, bymail_address2, bymail_city, bymail_state, bymail_zip from payment_process where name='Mail In Payment'"));

$bymail_to=stripslashes(trim($rs0[0]));
$bymail_address1=stripslashes(trim($rs0[1]));
$bymail_address2=stripslashes(trim($rs0[2]));
$bymail_city=stripslashes(trim($rs0[3]));
$bymail_state=stripslashes(trim($rs0[4]));
$bymail_zip=stripslashes(trim($rs0[5]));

// pull in order to information
$query="select ";
$query.="user.first_name, ";						// 0
$query.="user.last_name, ";							// 1
$query.="user.street_address_1, ";					// 2
$query.="user.street_address_2, ";					// 3
$query.="user.city, ";								// 4
$query.="user.state, ";								// 5
$query.="user.zip_code, ";							// 6
$query.="user.country, ";							// 7
$query.="user.phone, ";								// 8
$query.="user.fax, ";								// 9
$query.="user.email, ";								// 10
$query.="user.username, ";							// 11
$query.="user.password, ";							// 12
$query.="user.advert, ";							// 13
$query.="user.advert_other, ";						// 14
$query.="user.tos, ";								// 15
$query.="hosting_order.pid, ";						// 16
$query.="hosting_order.status, ";					// 17
$query.="hosting_order.domain_name, ";				// 18
$query.="hosting_order.domain_registration, ";		// 19
$query.="hosting_order.domain_expire, ";			// 20
$query.="hosting_order.payment_method, ";			// 21
$query.="hosting_order.payment_term, ";				// 22
$query.="hosting_order.ip, ";						// 23
$query.="hosting_order.ns1, ";						// 24
$query.="hosting_order.ns2, ";						// 25
$query.="hosting_order.total_due_today, ";			// 26
$query.="hosting_order.total_due_reoccur, ";		// 27
$query.="hosting_order.promotion_code, ";			// 28
$query.="hosting_order.referrer_id, ";				// 29
# $query.="UNIX_TIMESTAMP(hosting_order.ogcreate), ";	// 30
$query.="hosting_order.ogcreate, ";					// 30
$query.="user.temp_pw, ";							// 31
$query.="hosting_order.whm_username, ";				// 32
$query.="hosting_order.whm_password, ";				// 33
$query.="user.sid, ";								// 34
$query.="user.uid, ";								// 35
$query.="hosting_order.whm_id, ";					// 36
$query.="hosting_order.client_notes, ";				// 37
$query.="plan_specs.dedicated, ";					// 38
$query.="hosting_order.pns1, ";						// 39
$query.="hosting_order.pns2, ";						// 40
$query.="hosting_order.root_pw, ";					// 41
$query.="hosting_order.server_hostname, ";			// 42
$query.="hosting_order.tld_id ";					// 43
$query.="from user, hosting_order, plan_specs ";
$query.="where hosting_order.oid='".addslashes(trim($change_oid))."' ";
$query.="and hosting_order.uid=user.uid ";
$query.="and hosting_order.pid=plan_specs.pid ";
$query.="order by hosting_order.uid asc limit 0, 1";

$rs1=mysql_fetch_row(mysql_query($query));

$first_name=stripslashes($rs1[0]);
$last_name=stripslashes($rs1[1]);
$street_address_1=stripslashes($rs1[2]);
$street_address_2=stripslashes($rs1[3]);
$city=stripslashes($rs1[4]);
$state=stripslashes($rs1[5]);
$zip_code=stripslashes($rs1[6]);
$country=stripslashes($rs1[7]);
$phone=stripslashes($rs1[8]);
$fax=stripslashes($rs1[9]);
$email=stripslashes($rs1[10]);
$username=stripslashes($rs1[11]);
$password=stripslashes($rs1[12]);
$advert=stripslashes($rs1[13]);
$advert_other=stripslashes($rs1[14]);
$tos=stripslashes($rs1[15]);
$pid=stripslashes($rs1[16]);
$status=stripslashes($rs1[17]);
$domain_name=stripslashes($rs1[18]);
$domain_registration=stripslashes($rs1[19]);
$domain_expire=stripslashes($rs1[20]);
$payment_method=stripslashes($rs1[21]);
$payment_term=stripslashes($rs1[22]);
$ip=stripslashes($rs1[23]);
$ns1=stripslashes($rs1[24]);
$ns2=stripslashes($rs1[25]);
$total_due_today=stripslashes($rs1[26]);
$total_due_reoccur=stripslashes($rs1[27]);
$promotion_code=stripslashes($rs1[28]);
$referrer_id=stripslashes($rs1[29]);
$ogcreate=stripslashes($rs1[30]);
$temp_pw=stripslashes($rs1[31]);
$whm_username=stripslashes($rs1[32]);
$whm_password=stripslashes($rs1[33]);
$sid=stripslashes($rs1[34]);
$uid=stripslashes($rs1[35]);
$whm_id=stripslashes($rs1[36]);
$client_notes=stripslashes($rs1[37]);
$dedicated=stripslashes($rs1[38]);
$pns1=stripslashes($rs1[39]);
$pns2=stripslashes($rs1[40]);
$root_pw=stripslashes($rs1[41]);
$server_hostname=stripslashes($rs1[42]);
$tld_id=stripslashes($rs1[43]);

if ($domain_registration==1)
	{
	$query_tld="select ";
	$query_tld.="cost, ";
	$query_tld.="reg_period ";
	$query_tld.="from ";
	$query_tld.="tld_chart ";
	$query_tld.="where ";
	$query_tld.="tld_id='".addslashes(trim($tld_id))."'";
	
	$rs_tld=mysql_fetch_row(mysql_query($query_tld));

	$tld_fee=stripslashes(trim($rs_tld[0]));
	$reg_period=stripslashes(trim($rs_tld[1]));

	$domain_details=$currency."".sprintf("%01.2f", $tld_fee)." ".$currency_type;
	if ($reg_period==1) { $domain_details.=" per Year."; }
	else if ($reg_period==2) { $domain_details.=" per 2 Years."; }
	else if ($reg_period==3) { $domain_details.=" per 5 Years."; }
	else if ($reg_period==4) { $domain_details.=" per 10 Years."; }
	}

// get plan data
$query1="select ";
$query1.="package_name ";			// 0
$query1.="from plan_specs where pid='".addslashes(trim($pid))."'";

//execute query
$rs1=mysql_fetch_row(mysql_query($query1));

$package_name=stripslashes($rs1[0]);

//execute query
$rs2=mysql_fetch_row(mysql_query("select name from plan_groups where gid='".addslashes(trim($change_gid))."'"));

$group_name=stripslashes($rs2[0]);

$query_invoice="select ";
$query_invoice.="iid ";
$query_invoice.="from ";
$query_invoice.="invoice ";
$query_invoice.="where ";
$query_invoice.="invoice_type='0' ";
$query_invoice.="and ";
$query_invoice.="oid='".$change_oid."' ";
$query_invoice.="and ";
$query_invoice.="master='69'";

$rs_invoice=mysql_fetch_row(mysql_query($query_invoice));

$iid=$rs_invoice[0];

echo("
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td><img src='".$http_images."/menu_arrow.gif'><b>".$text_orderreceived." ".date("m/d/Y", $ogcreate)." ".$text_at." ".date("h:i:s a", $ogcreate).".</b></td>
		<td><a href='".$http_web."/invoice_hosting.php?c=".urlencode(e("576cb7f68040520768bf51c75f7f4c84", $iid))."' target='_blank'><img border='0' src='".$http_images."/printer_friendly.gif'></a></td>
	</tr>
</table>
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td colspan='2'><hr color='#F0EFED'></td>
	</tr>
	<tr>
		<td width='50%' align='left' valign='top'>
		<table width='100%' cellpadding='2' cellspacing='0' border='0'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><i>".$text_sendpaymentto.":</i></td>
			</tr>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$bymail_to."</td>
			</tr>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$bymail_address1."</td>
			</tr>
	");
if (strlen(trim($bymail_address2))!=0)
	{
	echo("
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$bymail_address2."</td>
			</tr>
		");
	}
echo("
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$bymail_city.", ".$bymail_state." ".$bymail_zip."</td>
			</tr>
		</table>
		</td>
		<td width='50%' align='left' valign='top'>
		<table width='100%' cellpadding='2' cellspacing='0' border='0'>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><i>".$text_clientinfo.":</i></td>
			</tr>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$first_name." ".$last_name."</td>
			</tr>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$street_address_1."</td>
			</tr>
	");
if (strlen(trim($street_address_2))!=0)
	{
	echo("
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$street_address_2."</td>
			</tr>
		");
	}
echo("
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$city.", ".$state." ".$zip_code." ".$country."</td>
			</tr>
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_phone.": ".$phone."</td>
			</tr>
	");
if (strlen(trim($fax))!=0)
	{
	echo("
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_fax.": ".$fax."</td>
			</tr>
		");
	}
echo("
			<tr>
				<td align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_email.": ".$email."</td>
			</tr>
		</table>
		</td>
	</tr>
	<tr>
		<td colspan='2'><hr color='#F0EFED'></td>
	</tr>
</table>
<table width='".$standard_table_width."' cellpadding='".$standard_table_padding."' cellspacing='".$standard_table_spacing."' border='".$standard_table_border."' align='".$standard_table_align."' bgcolor='".$standard_table_bgcolor."'>
	<tr>
		<td colspan='2' align='left' valign='top'><img src='".$http_images."/menu_arrow.gif'><i>".$text_orderdetails.":</i></td>
	</tr>
	");
if ($dedicated==1)
	{
	echo("
		<tr>
			<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_hostname.":</td>
			<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$server_hostname.".".$domain_name."</td>
		</tr>
		<tr>
			<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_nameservers.":</td>
			<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$pns1.".".$domain_name."</td>
		</tr>
		<tr>
			<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'></td>
			<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$pns2.".".$domain_name."</td>
		</tr>
		");
	}
else
	{
	echo("
		<tr>
			<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_domainname.":</td>
			<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>http://".$domain_name."</td>
		</tr>
		<tr>
			<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_domainregistration.":</td>
			<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".(($domain_registration=="1")?$text_wewillregister." ".$domain_details:$text_youwillregister)."</td>
		</tr>
		");
	if ($domain_registration!="1")
		{
		// get current NS
		$current_ns=current_ns();
		if ($current_ns!=99)
			{
			list($primary_ns, $primary_ns_ip, $secondary_ns, $secondary_ns_ip)=split("[|]", $current_ns);

			echo("
				<tr>
					<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='18' height='9'><img src='".$http_images."/drop_arrow.gif'>".$text_usenameserver.":</td>
					<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".stripslashes($primary_ns)." [".$primary_ns_ip."]</td>
				</tr>
				<tr>
					<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='18' height='9'><img src='".$http_images."/drop_arrow.gif'>".$text_usenameserver.":</td>
					<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$secondary_ns." [".$secondary_ns_ip."]</td>
				</tr>
				");
			}
		if (strlen(trim(str_replace("/", "", $domain_expire)))!=0)
			{
			echo("
				<tr>
					<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='18' height='9'><img src='".$http_images."/drop_arrow.gif'>".text_domainexpires.":</td>
					<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$domain_expire."</td>
				</tr>
				");
			}
		}
	}
echo("
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_packageordered.":</td>
		<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$group_name.": ".$package_name."</td>
	</tr>
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='18' height='9'><img src='".$http_images."/drop_arrow.gif'>".$text_totalduenow.":</td>
		<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$currency."".$total_due_today."".$currency_type."</td>
	</tr>
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='18' height='9'><img src='".$http_images."/drop_arrow.gif'>".$text_totalrecurring.":</td>
		<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$currency."".$total_due_reoccur."".$currency_type."</td>
	</tr>
	");
$ctu=mysql_fetch_row(mysql_query("select count(*) from hosting_order where uid='".addslashes(trim($uid))."' and status='1'"));
if ($ctu[0]<=1)
	{
	echo("
		<tr>
			<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_clientareausername.":</td>
			<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$username."</td>
		</tr>
		<tr>
			<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_clientareapassword.":</td>
			<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$temp_pw."</td>
		</tr>
		");
	}
echo("
	<!---<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_pathtoclientarea.":</td>
		<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$http_web."/clogin.php [<a href='".$http_web."/client_area.php?sid=".trim($sid)."'>click to access now</a>]</td>
	</tr>--->
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_terms.":</td>
		<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_youhaveagreed.".</td>
	</tr>
	<tr>
		<td width='30%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".$text_notes .":</td>
		<td width='70%' align='left' valign='top'><img src='".$http_images."/space.gif' width='15' height='9'>".((trim($client_notes)!="")?"".$client_notes."":$text_none)."</td>
	</tr>
</table>
</form>
	");
if (isset($show))
	{
	echo("
		</body>
		</html>
		");
	}
else
	{
	include "inc/footer.php";
	}
mysql_close($dblink);
?>