<?PHP
include "inc/var.php";
include "inc/connect.php";
include "inc/whm_functions.php";
include "inc/enom_functions.php";

if (isset($c))
	{
	if (file_exists($below_public."/".$c."_invoice.log"))
		{
		$read=file($below_public."/".$c."_invoice.log");
		list($gid, $oid)=split("[|]", base64_decode($c));
		}
	else { header("Location: ".$http_web); exit; }
	}
else { header("Location: ".$http_web); exit; }

$query="select ";
$query.="hosting_order.uid, ";			// 0
$query.="hosting_order.ns1, ";			// 1
$query.="hosting_order.ns2, ";			// 2
$query.="hosting_order.domain_name, ";	// 3
$query.="hosting_order.sorp, ";			// 4
$query.="hosting_order.whm_password, ";	// 5
$query.="tld_chart.tld, ";				// 6
$query.="tld_chart.cost, ";				// 7
$query.="tld_chart.reg_period ";		// 8
$query.="from ";
$query.="hosting_order, tld_chart ";
$query.="where ";
$query.="hosting_order.oid='".addslashes(trim($oid))."' ";
$query.="and ";
$query.="hosting_order.tld_id=tld_chart.tld_id ";
$query.="order by oid asc ";
$query.="limit 0, 1";

$rs=mysql_fetch_row(mysql_query($query));

$uid=stripslashes(trim($rs[0]));
$ns1=stripslashes(trim($rs[1]));
$ns2=stripslashes(trim($rs[2]));
$sorp=stripslashes(trim($rs[4]));
$password=stripslashes(trim($rs[5]));
$tld=stripslashes(trim($rs[6]));
$cost=stripslashes(trim($rs[7]));
$reg_period=stripslashes(trim($rs[8]));
$domain_name=stripslashes(trim($rs[3]));
$mark=strpos($domain_name, ".");
$sld=substr($domain_name, 0, $mark);
$tld=substr($domain_name, -((strlen($domain_name)-1)-$mark));

$purchase=enom_purchase($sld, $tld);
list($RRPCode, $RRPText, $order_id)=explode("|", $purchase);

if ($RRPCode==200)
	{
	$modifyns=enom_modifyns($sld, $tld, $ns1, $ns2);
	list($modifyns_rc, $modifyns_text)=explode("|", $modifyns);

	$contacts=enom_contacts($sld, $tld, $uid, $sorp);
	list($contacts_rc, $contacts_text)=explode("|", $contacts);

	$setpassword=enom_setpassword($sld, $tld, $password);

	# create record
	$query="insert ";
	$query.="into ";
	$query.="domains ";
	$query.="set ";
	$query.="oid='".addslashes(trim($oid))."', ";
	$query.="uid='".addslashes(trim($uid))."', ";
	$query.="tld_cost='".addslashes(trim($cost))."', ";
	$query.="domain_name='".addslashes(trim($domain_name))."', ";
	$query.="purchase_rc='".addslashes(trim($RRPCode))."', ";
	$query.="purchase_text='".addslashes(trim($RRPText))."', ";
	$query.="modifyns_rc='".addslashes(trim($modifyns_rc))."', ";
	$query.="modifyns_text='".addslashes(trim($modifyns_text))."', ";
	$query.="created='".time()."', ";
	$query.="expires='".mktime(0, 0, 0, date("m"), (date("d")+(365*$reg_period)), date("Y"))."', ";
	$query.="order_id='".addslashes(trim($order_id))."', ";
	$query.="password='".addslashes(trim($password))."', ";
	$query.="status='1'";

	mysql_query($query);

	# added 6/23/2004
	$query="update ";
	$query.="hosting_order ";
	$query.="set ";
	$query.="domain_expire='".date("m/d/Y", mktime(0, 0, 0, date("m"), (date("d")+(365*$reg_period)), date("Y")))."' ";
	$query.="where ";
	$query.="oid='".addslashes(trim($oid))."'";

	mysql_query($query);

	enom_reg_email($oid, $uid, $email_admin);
	}
else 
	{ 
	# create record
	$query="insert ";
	$query.="into ";
	$query.="domains ";
	$query.="set ";
	$query.="oid='".addslashes(trim($oid))."', ";
	$query.="uid='".addslashes(trim($uid))."', ";
	$query.="tld_cost='".addslashes(trim($cost))."', ";
	$query.="domain_name='".addslashes(trim($domain_name))."', ";
	$query.="purchase_rc='".addslashes(trim($RRPCode))."', ";
	$query.="purchase_text='".addslashes(trim($RRPText))."', ";
	$query.="modifyns_rc='N/A - Registration Failed', ";
	$query.="modifyns_text='N/A - Registration Failed', ";
	$query.="order_id='N/A - Registration Failed', ";
	$query.="password='N/A - Registration Failed', ";
	$query.="status='0'";

	mysql_query($query);
	}

mysql_close($dblink);

header("Location: ".$http_web."/invoice_new.php?c=".$c."".((isset($dedicated))?"&dedicated=".$dedicated."":"")."");
exit;
?>