<?PHP
include "inc/var.php";
include "inc/connect.php";
include $server_inc."/pagefind.php";
include $server_inc."/languages/".$local_lang.".php";
include $server_inc."/languages/".$local_lang."/step_fraudgate.php";

$sid = $_POST['sid'];
$gid = $_POST['gid'];
$cksid=mysql_fetch_row(mysql_query("select count(*) from session_history where sid='".addslashes(trim($sid))."'"));

if ($cksid[0]<=0) {	header("Location: ".$http_web."/step_one.php");	exit; }
else if (!isset($sid)) { header("Location: ".$http_web."/step_one.php"); exit; }

include $server_inc."/header.php";

/////////////////      RAMDOMIZING SCRIPRT BY PATRIC VEVERKA       \\\\\\\\\\\\\\\\\\

$t1 = date("mdy");
srand ((float) microtime() * 10000000);
$input = array ("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z");
$rand_keys = array_rand ($input, 2);
$r1 = rand(0,9) . $rand_keys[0] . $rand_keys[1];
$random = $t1.$r1;


$query="select * from session_history ";
$query.="where sid='".addslashes(trim($sid))."' ";
$query.="limit 0, 1";

$sidrow=@mysql_fetch_array(mysql_query($query));

// --- start the fraudgate call --- //
$url = "https://secure.fraudgate.com/gateway/verify.dll";
$postfields = array();

unset($fg_data);
$fg_data = mysql_query("SELECT fg_variable, fg_value FROM autopilot_fraudgate WHERE fg_variable <> 'activate'");
while($fg_row = @mysql_fetch_array($fg_data))
{
    $value = $fg_row['fg_value'];
	if(strpos($fg_row['fg_variable'], "FG_INPUT_") !== FALSE) // it is an input variable
	{
		if(strtolower($value) == "4 digit random number")
			$value = substr($random, 0, 4);
		else if(strtolower($value) == "6 digit random number")
		    $value = substr($random, 0, 6);
		else if(strtolower($value) == "8 digit random number")
			$value = substr($random, 0, 8);
		else if(strtolower($value) == "10 digit random number")
		    $value = substr($random, 0, 10);
		else if(strtolower($value) == "no input required")
		    $value = "";
	}
    $postfields[$fg_row['fg_variable']] = $value;
    
    //print $fg_row['fg_variable']." - ".$value."<br>";
}

$random = $postfields["FG_INPUT_1"];

// now add the customer information
$domain = explode("@", $sidrow['email']);
$postfields['FG_CITY'] = trim($sidrow['city']);
$postfields['FG_STATE'] = trim($sidrow['state']);
$postfields['FG_POSTAL'] = trim($sidrow['zip_code']);
$postfields['FG_COUNTRY'] = trim($sidrow['country']);
$postfields['FG_PHONE'] = trim($sidrow['phone']);
$postfields['FG_DOMAIN'] = trim($domain[1]);
$postfields['FG_IP'] = getenv("REMOTE_ADDR");
$postfields['FG_TRANS_ID'] = "SESSION-" . $sid;

// make the parameters
$params = "";
foreach($postfields as $key => $value)
{
    $params .= "&" . $key . "=" . urlencode($value);
}

// start the call to the gateway
//echo $url . "?" . $params;
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST,1);
curl_setopt($ch, CURLOPT_POSTFIELDS,$params);
curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);  // this line makes it work under https
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);

$chresult=curl_exec($ch);
curl_close ($ch);

// --- end fraudgate call --- //

echo "
	<table width='400' cellpadding='2' cellspacing='0' border='0' align='center' style='border-style: solid; border-color: #999999; border-width: 1px'>
        <tr>
			<td valign='center'>".$step2."</td>
        </tr>
        <tr>
			<td valign='center'>".$calling_text.$sidrow['phone'].'<br><center><img src="images/processing.gif"></center><br>'.$few_minutes_text.$random_text.$random."</b>
        </td>

        </tr>
	</table>
	";

echo '<form action="step_fraudgate_three.php" method="POST">
      <p align="center">
      <input style="font-family:verdana, arial, helvetica; font-size: 8pt; border-style: solid; border-color: 999999; border-width: 1pxl; background-color: e7e7e7; font-weight: 800" type="submit" name="submit" value="' . $finish . ' &gt&gt">
      <input type="hidden" name="sid" value="'.trim($_POST['sid']).'">';
      if (isset($_POST['gid'])) { echo "<input type='hidden' name='gid' value='".trim($_POST['gid'])."'>\n"; }
echo  '</form>';

include $server_inc."/footer.php";
mysql_close($dblink);
?>
