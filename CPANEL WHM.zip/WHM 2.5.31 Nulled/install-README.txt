
================================================================
WHM AutoPilot - Web Host Client Management System

*-*-*-*-*-*-*-*-*-----INSTALL INSTRUCTIONS-----*-*-*-*-*-*-*-*-*

RELEASE DATE: August 17 2005
RELEASE VERSION: v2.5.31

PLEASE READ ALL THE ENCLOSED INSTRUCTIONS TO THE STOP MARK

REMEMBER - IF YOU DO NOT HAVE CURL, CURL SSL and MCRYPT COMPILED
IN YOUR PHP - THIS SCRIPT WILL NOT WORK

         Forum: http://www.whmautopilot.com/forum
Support Center: http://www.whmautopilot.com/support
  Users Manual: http://www.whmautopilot.com/usermanual/  (70%)
Flash Tutorial: http://www.whmautopilot.com/tutorials/nav.swf

================================================================

Tested and built on Linux/Unix servers.

--> PHP v4.1.2 to 4.3.10 (no development releases supported)
------> PHP must be compiled with mcrypt() curl & curl ssl support 
--> SafeMode Off & Register Globals ON or you must have access to php.ini 
--> MySQL 
--> cPanel/WHM Platform (ensim, plesk or hsphere not supported)
--> Ability to configure and run CRON jobs (advanced mode in cPanel)
--> Zend Optimizer v2.5.7 or newer
--> PHPSuexec cannot be enabled or script will fail in areas

In order to install and run this script, you must have the obtained
the following files:

1) current version of script downloaded ( .zip )
2) license key ( license obtained from email or download area)

The script will not run if you did not obtain these files.

=========================================================================
[ Basic Install ]
==========================================================================

1) unzip all files locally and upload to your server in BINARY format

Choose where you are going to install the script.  If you are going to install
it into /public_html - only upload the 'contents' of the folder 'script -- rename' into
your public_html folder.  If you are going to install into a folder location
called /orders - rename 'script -- rename' to 'orders' and upload that folder into your
/public_html folder.

****** DO NOT INSTALL THIS IN A FOLDER CALLED /CPANEL or /WHM ******

UPLOAD THE CONTENTS OF /script -- rename EITHER TO YOUR BASE DIRECTORY OR INTO
AN INTERNAL FOLDER IN BINARY MODE. ASCII MODE WILL CASE 'error reading xx bytes'
ERRORS IN YOUR FILES.

2) make sure /mib_data is UNDER /public_html - not in it and chomd 777
the /mib_data folder and the files and folders 777

3) chmod the folder /inc to 777 (temporarily during install)

Example (here is where the folders should be located):

Say my cPanel username is mysiteap

normal site files /home/mysiteap/public_html/here

mib_date goes here: /home/mysiteap/mib_data

3) create a new database and username w/ password and add user to database

4) go to www.yoursite.com/admin/index.php (or to the folder location
this was installed like www.yoursite.com/autopilot/admin/index.php)

If all goes well, you should see a 'Install Process' area to create your
start the installation of the script.

When complete, please CHMOD /inc back to 755 and delete your phpinfo.php file

================================================================================
If you get an 'INTERNAL ERROR - 500' when going to this process, you are running
under phpSuExec and will need to CHMOD /inc back to 755 and upload the file in
the folder /phpSuExec into the /inc folder.  Then go back to step #4 above.
================================================================================

Once complete, be sure to visit our forums and register as a member.  All
updates, release notes and script information is released to members through
the forum.

[ First Steps After Successful Login and Installation ]

========================================================================
DO NOT USE THE BACK BUTTON OR THE REFRESH KEY IN ADMIN OR YOU WILL BE 
LOGGED OUT OF THE SYSTEM AND WILL NEED TO LOG BACK IN
========================================================================

Flash Tutorials are here: http://www.whmautopilot.com/tutorials/nav.swf

The first items that need to be done are the following

The very first thing to do is click on 'edit client area news' Once you 
have it clicked (you're gonna see errors) - just put something in the 
block and click update.  Do the same for 'Affiliate area paragraph' -
This is the paragraph that explains your affiliate system to your clients.

1) setup your servers

The active server is the server that accounts get automatically installed
onto.  If you don't want autoinstall, then set your current server as the 
manual default server.

Put as many servers in here as you wish.  Just remember, the more servers
you put in, the slower it may take to load the server management page.

Next, if you have more than 1 server installed, make sure you setup the 
automatic rotation - letting the script know which server is next when
the current server is full.

Note: If you see 92 [or 29] accounts and no server stats, it is most like one or
all of the following:

[1] bad key
[2] wrong IP
[3] wrong username

2) Setup what you're selling. 

Create your hosting packages.  It is easier to do this with a server
marked as 'active' since then, if you are a root user, you will be able
to create your packages including the 'cpanel' theme for each package.

If you are a reseller with limited access, your packages must match the
same as those permissioned to you in your WHM.

3) Payment Gateways
Edit and activate (or deactivate) the gateways you will or will not be
using for clients to choose at the time of sale.  You can have all gateways
or just one active at the same time.

4) Setup your affiliate payouts

5) Customize the 'client side' of things to blend into your existing design
or you can leave it as is.

Your order page starts here:

http://yoursite.com/step_one.php

If you have multiple groups (like: http://www.imagelinkusa.net/step_one.php?gid=3)

Then just put that in the link

Example: Value Hosting = Group 3
Link: step_one.php?gid=3

TEST THE SYSTEM - REPORT ALL BUGS IMMEDIATELY

**set one server as 'active' server to test **
1) create a package for $0.20 per month
2) go to step_one.php and order this package using PayPal
3) go through the whole process (to and back from PayPal)

You should get a series of emails
1) once the order is placed and you go to paypal - email sent
2) when you come back from paypal, email sent 
3) when the site is installed on the server - email sent

If there are any problems (domain exists, etc.) the site will
not automatically install onto the server and will revert to
a pending account.  All pending accounts require 'manual' help
to get it all the way in.

All accounts that choose 'unique' IP require Manual installation
and are created as pending accounts.  If you have standard packages
that include a unique IP address - just change the IP in WHM and
update the client information to reflect the new IP address.

If the account is pending, you will need to put in the IP address and
nameservers for this account in the 'pending' view before or after
activation.  Reason: you have the option to 'choose' which server
they get installed on and that information is not automatically put in
to the client record for this purpose.

Once you have an 'active account' either automatically if the script
did the installation or if you activated it manually, they are put
into the 'resolve' queue.  This keeps a steady eye on the domain to
make sure when it resolves, the client is notified.

We also monitor the domains for 'non-resolve' as well. The best part here
is that if a domain resolves, then stops resolving - you are also notified
(not the client).  This was written in for those clients who switch hosts
and forget to tell their current host but, billing continues.  Then, after
3 months you get a call saying 'hey, I cancelled 3 months ago and you've still
been charging me'.  You can contact them as soon as the domain stops to make
sure everything is ok.

This system will also notify clients 30 days prior to expiration of their
domain (if they provided exp date) that their domain is about to expire.

============================
NECESSARY CRON JOBS
============================

Daily:

Ran at 12:15am
15 0 * * * GET http://yourdomain.com/admin/cron_1215.php > /dev/null

Ran at every 8 hours
0 */8 * * * GET http://yourdomain.com/admin/cron_resolver.php > /dev/null

Weekly:

Ran at on Fridays
5 0 * * 6 GET http://yourdomain.com/admin/cron_weekly_sales.php > /dev/null

Monthly:

Ran on the last day of the month
GET http://yourdomain.com/admin/cron_reports_new_monthly_signups.php > /dev/null

GET http://yourdomain.com/admin/cron_reports_monthly_revenue.php > /dev/null

BE SURE TO USE ADVANCED MODE IN CPANEL TO SET THIS UP

[ INSTALLATION INTRUCTIONS STOP ]