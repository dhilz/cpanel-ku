ALTER TABLE `invoice` ADD `txn_id` VARCHAR( 255 ) NOT NULL AFTER `payment_method` ;
ALTER TABLE `authnet_batch` ADD `txn_id` VARCHAR( 255 ) NOT NULL AFTER `bid` ;
ALTER TABLE `hosting_order` ADD `txn_id` VARCHAR( 255 ) NOT NULL AFTER `uid` ;
