ALTER TABLE `plan_specs` ADD `free_trial` INT( 1 ) DEFAULT '0' NOT NULL ,
ADD `free_trial_length` INT( 2 ) DEFAULT '0' NOT NULL ;

ALTER TABLE `addon_specs` ADD `coupon` INT( 1 ) DEFAULT '0' NOT NULL ,
ADD `coupon_code` VARCHAR( 255 ) NOT NULL ,
ADD `coupon_discount_type` INT( 1 ) DEFAULT '0' NOT NULL ,
ADD `coupon_discount_percent` FLOAT NOT NULL ,
ADD `coupon_discount_whole` FLOAT NOT NULL ,
ADD `expires` INT( 40 ) NOT NULL ;

ALTER TABLE `addon_specs` ADD `coupon_terms` INT( 1 ) DEFAULT '0' NOT NULL AFTER `coupon` ;

ALTER TABLE `session_history` ADD `whm_id` BIGINT( 22 ) NOT NULL AFTER `uid` ;

UPDATE `email_templates` SET `message` = 'Hello, On {{order_date}}, a new client {{active_server_name}} Here are the details: Client: {{first_name}} {{last_name}} Email: {{email_address}} How did you find us: {{how_found}} Domain: {{domain_name}} Package Ordered: {{hosting_package}} {{addons}} Payment Type: {{payment_gateway}} {{coupon}} Total Due Today: {{total_due_today}} This order will rebill at a rate of {{total_reoccur}} {{payment_term}} Thank you. Your AutoPilot This message was generated on: {{generate_date}}', `attr_avail` = '{{order_date}}|{{active_server_name}}|{{first_name}}|{{last_name}}|{{domain_name}}|{{hosting_package}}|{{addons}}|{{payment_gateway}}|{{total_due_today}}||{{generate_date}}|{{total_reoccur}}|{{payment_term}}|{{email_address}}|{{how_found}}|{{coupon}}|' WHERE `emid` = '7' LIMIT 1 ;

UPDATE `email_templates` SET `message` = 'Hello, We have received your hosting ORDER and will be processing it shortly. The details of this ORDER are below: First Name: {{first_name}} {{last_name}} Email: {{email_address}} How did you find us: {{how_found}} Domain Name: {{domain_name}} Package Ordered: {{hosting_package}} {{addons}} Payment Gateway: {{payment_gateway}} {{coupon}} Total Due Today: {{total_due_today}} This ORDER will rebill at a rate of {{total_reoccur}} {{payment_term}} You should receive an email FROM us within the next 24 hours with more information. Thank You. Web Host Support This message was generated on: {{generate_date}}', `attr_avail` = '{{first_name}}|{{last_name}}|{{domain_name}}|{{hosting_package}}|{{addons}}|{{payment_gateway}}|{{total_due_today}}|{{total_reoccur}}|{{payment_term}}|{{generate_date}}|{{email_address}}|{{how_found}}|{{coupon}} ' WHERE `emid` = '8' LIMIT 1 ;