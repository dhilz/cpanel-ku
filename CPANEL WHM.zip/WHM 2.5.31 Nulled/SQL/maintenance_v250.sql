ALTER TABLE `payment_process` ADD `offline_email` TEXT NOT NULL AFTER `plugnpay_cardallowed` ;
INSERT INTO `payment_process` VALUES (15, 0, 'Credit Card', '', 'SSC5LA==', 'SSC5LA==', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', '', 1, '');

ALTER TABLE `session_history` ADD `offcid` BIGINT( 22 ) NOT NULL AFTER `lpid` ;

ALTER TABLE `hosting_order` ADD `offcid` VARCHAR( 22 ) NOT NULL AFTER `lpid` ;

CREATE TABLE `offline_holding_queue` (
  `offcid` bigint(22) unsigned NOT NULL auto_increment,
  `sid` varchar(32) NOT NULL default '',
  `oid` bigint(22) NOT NULL default '0',
  `uid` bigint(22) NOT NULL default '0',
  `startdate` text NOT NULL,
  `chargetotal` float NOT NULL default '0',
  `recurringamount` float NOT NULL default '0',
  `periodicity` text NOT NULL,
  `comments` varchar(255) default NULL,
  `cardnumber` varchar(255) NOT NULL default '0',
  `cardexpmonth` varchar(255) NOT NULL default '0',
  `cardexpyear` varchar(255) NOT NULL default '0',
  `ip` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `address1` varchar(255) default NULL,
  `city` varchar(255) default NULL,
  `state` varchar(255) default NULL,
  `country` varchar(255) default NULL,
  `phone` varchar(255) default NULL,
  `fax` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `zip` varchar(255) default NULL,
  `status` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`offcid`)
) TYPE=MyISAM COMMENT='Holding Queue for offline processor' AUTO_INCREMENT=1 ;

INSERT INTO `email_templates` VALUES (112, 'Offline Credit Card Confirmation', '[112] Confirmation Information for {{client_name}} on {{generate_date}}', 'Client Information:\r\n\r\n{{name}}\r\n{{address1}}\r\n{{city}}, {{state}}  {{zip}}\r\n{{country}}\r\n\r\nPhone: {{phone}}\r\nFax: {{fax}}\r\nEmail: {{email}}\r\n\r\n====================\r\nCard Number: {{cardnumber}}  Exp: {{cardexpmonth}} / {{cardexpyear}}\r\nCard Type: {{cardtype}}\r\n====================\r\n\r\nDomains: {{comments}}\r\nBilling Cycle: {{periodicity}}\r\n\r\nCharge Total Today: {{charge_total}}\r\nTotal to Reoccur: {{recurring_amount}}\r\n\r\n===========================', '{{generate_date}}|{{client_name}}|{{comments}}|{{periodicity}}|{{cardnumber}}|{{cardtype}}|{{cardexpmonth}}|{{cardexpyear}}|{{name}}|{{address1}}|{{city}}|{{state}}|{{country}}|{{phone}}|{{fax}}|{{email}}|{{zip}}|{{charge_total}}|{{recurring_amount}}', '');
