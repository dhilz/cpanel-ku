ALTER TABLE `payment_process` ADD `internetsecure_merchant_id` VARCHAR( 25 ) NOT NULL AFTER `paysystems_companyid` ;
ALTER TABLE `payment_process` ADD `internetsecure_language` VARCHAR( 100 ) NOT NULL AFTER `internetsecure_merchant_id` ;
ALTER TABLE `payment_process` ADD `internetsecure_return_cgi` VARCHAR( 255 ) NOT NULL AFTER `internetsecure_language` ;

ALTER TABLE `plan_specs` ADD `internetsecure_period` INT( 20 ) NOT NULL ;

INSERT INTO `payment_process` VALUES (9, 0, 'Internet Secure', '', 'SSC5LA==', 'SSC5LA==', '', '', '', '', '', 0, '', '', 'English', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', 1, '');