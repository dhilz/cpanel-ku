INSERT INTO `email_templates` VALUES ('38', 'Invoice Ready Notification to Client ', 'Your Invoice is Ready', 'Greetings {{first_name}}, Please visit the URL to view and pay this invoice. {{pay_link}} Thanks, Web Support Team This email was generated on: {{generate_date}}', '{{first_name}}|{{pay_link}}|{{generate_date}}|', '');
INSERT INTO `email_templates` VALUES ('37', 'Invoice Paid Successfully', 'Invoice #{{invoice_number}} was paid successfully!', 'Greetings, On {{date_paid}}, {{first_name}} {{last_name}} paid invoice #{{invoice_number}} in the amount of {{total_invoice_amount}}. Please visit your AutoPilot for the invoice details. Thanks Your AutoPilot This email was generated on: {{generate_date}}', '{{invoice_number}}|{{date_paid}}|{{first_name}}|{{last_name}}|{{total_invoice_amount}}|', '');
INSERT INTO `email_templates` VALUES ('39', 'Invoice Due in X Days Notice', 'Your account is due in {{days_until_due}}', 'Greetings {{first_name}}, Your account, {{domain_name}}, is due in {{days_until_due}} and will be billed for {{total_recuur}} via {{payment_processor}}. No action is required on your part, this is just a reminder. Thanks, Web Support Team This email was generated on: {{generate_date}}', '{{days_until_due}}|{{first_name}}|{{domain_name}}|{{total_recuur}}|{{payment_processor}}|{{generate_date}}|', '');
INSERT INTO `email_templates` VALUES ('40', 'Incomplete Order Notification', 'You have incomplete orders', 'Hello, You currently have {{incomplete_orders}} order(s) in the incomplete orders area of your AutoPilot. Please login to your admin area to view/process these orders. Thank you. Your AutoPilot This message was generated on: {{generate_date}}', '{{incomplete_orders}}|{{generate_date}}|', '');
INSERT INTO `email_templates` VALUES ('41', 'Daily Invoice Summary Report', 'Daily Invoice Summary Report', 'Hello,\r\n\r\nBelow is a list of hosting order invoices in the system that are either past due or unpaid past due.\r\n\r\nPlease login to your admin area and go to the invoice management area to update the status of these invoices.\r\n\r\nSome of these may have just rotated into a new billing cycle and have been billed by the proper gateway.  If this has\r\nhappened, verify payment was made at the gateway and update the invoice as paid in your system.  Marking them as paid\r\nwill reset the next due date accordingly for the hosting order.\r\n\r\n*** Past Due Invoices as of {{generate_date}} Seperated by Payment Gateway ***\r\n\r\n{{mail_in_summary}}{{paypal_summary}}{{paysystems_summary}}{{authorize.net_summary}}{{2checkout}}{{worldpay_summary}}', '{{generate_date}}|{{mail_in_summary}}|{{paypal_summary}}|{{paysystems_summary}}|{{authorize.net_summary}}|{{2checkout}}|{{worldpay_summary}}|', 'andy@httpeasy.com');
ALTER TABLE `user` ADD `rsid` VARCHAR( 32 ) NOT NULL AFTER `sid` ;
DROP TABLE `session` 

CREATE TABLE `config` (
  `license` text NOT NULL,
  `site_title` varchar(255) NOT NULL default '',
  `site_name` varchar(255) NOT NULL default '',
  `balance_required_for_payment` int(6) NOT NULL default '0',
  `currency` char(1) NOT NULL default '',
  `currency_type` varchar(4) NOT NULL default '',
  `domain_fee` int(2) NOT NULL default '0',
  `resolve_server` varchar(255) NOT NULL default '',
  `run_domain_expire` char(3) NOT NULL default '',
  `http_web` varchar(255) NOT NULL default '',
  `server_root` varchar(255) NOT NULL default '',
  `below_public` varchar(255) NOT NULL default '',
  `default_reseller_cpanel_theme` varchar(255) NOT NULL default '',
  `theme` varchar(255) NOT NULL default '',
  `strong_security` char(2) NOT NULL default '',
  `phpbb_active` char(2) NOT NULL default '',
  `input_style` varchar(255) NOT NULL default '',
  `button_style` varchar(255) NOT NULL default '',
  `copyright` varchar(255) NOT NULL default '',
  `get_mib_news` varchar(255) NOT NULL default '',
  `email_support` varchar(255) NOT NULL default '',
  `http_web_tools` varchar(255) NOT NULL default '',
  `http_admin` varchar(255) NOT NULL default '',
  `http_admin_tools` varchar(255) NOT NULL default '',
  `http_images` varchar(255) NOT NULL default '',
  `server_backup` varchar(255) NOT NULL default '',
  `resolver_log` varchar(255) NOT NULL default '',
  `server_tools` varchar(255) NOT NULL default '',
  `server_admin_inc` varchar(255) NOT NULL default '',
  `server_inc` varchar(255) NOT NULL default '',
  `server_admin` varchar(255) NOT NULL default '',
  `server_admin_tools` varchar(255) NOT NULL default '',
  `local_lang` varchar(255) NOT NULL default 'english',
  `invoice_notice_period` int(11) NOT NULL default '0',
  `tos_agreement` varchar(255) NOT NULL default '',
  `session_expire` int(3) NOT NULL default '36',
  KEY `site_title` (`site_title`),
  KEY `site_name` (`site_name`),
  KEY `currency` (`currency`),
  KEY `currency_type` (`currency_type`),
  KEY `domain_fee` (`domain_fee`),
  KEY `resolve_server` (`resolve_server`),
  KEY `run_domain_expire` (`run_domain_expire`),
  KEY `http_web` (`http_web`),
  KEY `server_root` (`server_root`),
  KEY `server_deploy` (`below_public`),
  KEY `default_reseller_cpanel_theme` (`default_reseller_cpanel_theme`),
  KEY `theme` (`theme`),
  KEY `strong_security` (`strong_security`),
  KEY `phpbb_active` (`phpbb_active`),
  KEY `input_style` (`input_style`),
  KEY `button_style` (`button_style`),
  KEY `copyright` (`copyright`),
  KEY `get_mib_news` (`get_mib_news`),
  KEY `email_support` (`email_support`),
  KEY `http_web_tools` (`http_web_tools`),
  KEY `http_admin` (`http_admin`),
  KEY `http_admin_tools` (`http_admin_tools`),
  KEY `http_images` (`http_images`),
  KEY `server_backup` (`server_backup`),
  KEY `resolver_log` (`resolver_log`),
  KEY `server_tools` (`server_tools`),
  KEY `server_admin_inc` (`server_admin_inc`),
  KEY `server_inc` (`server_inc`),
  KEY `server_admin` (`server_admin`),
  KEY `server_admin_tools` (`server_admin_tools`),
  KEY `local_lang` (`local_lang`),
  KEY `balance_required_for_payment` (`balance_required_for_payment`)
) TYPE=MyISAM COMMENT='Config Table';

INSERT INTO `config` (`license`, `site_title`, `site_name`, `balance_required_for_payment`, `currency`, `currency_type`, `domain_fee`, `resolve_server`, `run_domain_expire`, `http_web`, `server_root`, `below_public`, `default_reseller_cpanel_theme`, `theme`, `strong_security`, `phpbb_active`, `input_style`, `button_style`, `copyright`, `get_mib_news`, `email_support`, `http_web_tools`, `http_admin`, `http_admin_tools`, `http_images`, `server_backup`, `resolver_log`, `server_tools`, `server_admin_inc`, `server_inc`, `server_admin`, `server_admin_tools`, `local_lang`, `invoice_notice_period`, `tos_agreement`, `session_expire`) VALUES ('', '', '', 50, '$', 'USD', 15, '', 'yes', '', '', '', 'x', 'blue', 'no', 'no', 'style="font-family:verdana, arial, helvetica; font-size: 8pt; border-style: solid; border-color: 000000; border-width: 1pxl; background-color: dbedf9; font-weight: 800"', 'style="font-family:verdana, arial, helvetica; font-size: 8pt; border-style: solid; border-color: 000000; border-width: 1pxl; background-color: dbedf9; font-weight: 800"', '<FONT COLOR="#ffffff" SIZE="-2" FACE="Verdana">� 2002 Benchmark Designs, LLC.</FONT>', 'http://benchmarkdesigns.net/mib_news.nfo', '', '', '', '', '', '', '', '', '', '', '', '', 'english', 86400, '', 36);

CREATE TABLE `invoice` (
  `iid` bigint(22) unsigned NOT NULL auto_increment,
  `uid` bigint(22) NOT NULL default '0',
  `oid` bigint(22) NOT NULL default '0',
  `due_date` int(10) NOT NULL default '0',
  `payment_method` int(3) NOT NULL default '0',
  `additional_information` text NOT NULL,
  `invoice_details` text NOT NULL,
  `invoice_terms` int(2) NOT NULL default '0',
  `status` int(11) NOT NULL default '0',
  `created` int(10) NOT NULL default '0',
  `date_paid` int(10) NOT NULL default '0',
  `invoice_number` bigint(22) NOT NULL default '0',
  `invoice_type` int(1) NOT NULL default '0',
  `total_due_today` float NOT NULL default '0',
  `total_due_reoccur` float NOT NULL default '0',
  `charge_tax` float NOT NULL default '0',
  `extras` text NOT NULL,
  `master` int(11) NOT NULL default '0',
  `checkout_id` varchar(25) NOT NULL default '',
  PRIMARY KEY  (`iid`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

CREATE TABLE `invoice_config` (
  `logo_path` varchar(255) NOT NULL default '',
  `company_contact` mediumtext NOT NULL,
  `payable_to` varchar(255) NOT NULL default '',
  `invoice_number` bigint(22) NOT NULL default '1000'
) TYPE=MyISAM;

INSERT INTO `invoice_config` (`logo_path`, `company_contact`, `payable_to`, `invoice_number`) VALUES ('', 'Your Company\r\n123 Mocking Bird Lane\r\nSomeTown, State Zip USA', 'Your Company', 1000);

CREATE TABLE `invoice_service` (
  `srid` bigint(22) unsigned NOT NULL auto_increment,
  `service_name` varchar(255) NOT NULL default '',
  `service_description` text NOT NULL,
  `service_show_description` int(1) NOT NULL default '0',
  `service_cost` float NOT NULL default '0',
  PRIMARY KEY  (`srid`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

CREATE TABLE `invoice_session` (
  `sid` text NOT NULL,
  `created` int(10) NOT NULL default '0'
) TYPE=MyISAM;
