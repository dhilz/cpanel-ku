CREATE TABLE `domains` (
  `dom_id` bigint(22) unsigned NOT NULL auto_increment,
  `oid` bigint(22) NOT NULL default '0',
  `uid` bigint(22) NOT NULL default '0',
  `tld_cost` float NOT NULL default '0',
  `domain_name` varchar(255) NOT NULL default '',
  `purchase_rc` varchar(25) NOT NULL default '',
  `purchase_text` varchar(255) NOT NULL default '',
  `modifyns_rc` varchar(25) NOT NULL default '',
  `modifyns_text` varchar(255) NOT NULL default '',
  `created` int(15) NOT NULL default '0',
  `expires` int(15) NOT NULL default '0',
  `order_id` varchar(255) NOT NULL default '',
  `password` text NOT NULL,
  `status` int(1) NOT NULL default '0',
  PRIMARY KEY  (`dom_id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

ALTER TABLE `config` ADD `enom_user` VARCHAR( 255 ) NOT NULL , ADD `enom_pass` VARCHAR( 255 ) NOT NULL ;
ALTER TABLE `config` ADD `use_enom` INT( 1 ) DEFAULT '0' NOT NULL AFTER `resolve_works` ;
ALTER TABLE `session_history` ADD `sorp` INT( 1 ) DEFAULT '0' NOT NULL ;
ALTER TABLE `hosting_order` ADD `sorp` INT( 1 ) DEFAULT '0' NOT NULL ;

INSERT INTO `email_templates` ( `emid` , `name` , `subject` , `message` , `attr_avail` , `default_email` ) VALUES (47, 'Admin Domain Registration E-mail', 'eNom Domain Registration - {{domain_name}}', 'Hello, Below are the results of an automated registration through your eNom account. Order ID: {{enom_order_id}} Response: {{enom_response_code}} Domain Name: {{domain_name}} Domain Expiration: {{expiration_date}} * approximate date Registrant Information: {{first_name}} {{last_name}} {{address_1}} {{address_2}} {{city}} {{state}} {{zip}} {{country}} {{phone}} {{fax}} If this registration was successful, there are no actions needed on your part. If there was an error given in the response above, manual registration may need to be completed for this domain. Thank You Your AutoPilot Message Generated on: {{generate_date}}', '{{domain_name}}|{{enom_order_id}}|{{enom_response_code}}|{{expiration_date}}|{{first_name}}|{{last_name}}|{{address_1}}|{{address_2}}|{{city}}|{{state}}|{{country}}|{{zip}}|{{phone}}|{{fax}}|{{generate_date}}|', '');
UPDATE `email_templates` SET `attr_avail` = '{{domain_name}}|{{generate_date}}|{{first_name}}|{{last_name}}|{{domain_reg_price}}|{{company_name}}|{{address_1}}|{{address_2}}|{{city}}|{{state}}|{{zip}}|{{phone}}|{{fax}}|{{primary_ns}}|{{primary_ns_ip}}|{{secondary_ns}}|{{secondary_ns_ip}}|{{email_address}}|' WHERE `emid` = '43' LIMIT 1 ;