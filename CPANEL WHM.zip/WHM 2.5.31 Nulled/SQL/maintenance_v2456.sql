CREATE TABLE `linkpoint_holding_queue` (
  `lpid` bigint(22) unsigned NOT NULL auto_increment,
  `sid` varchar(32) NOT NULL default '',
  `oid` bigint(22) NOT NULL default '0',
  `uid` bigint(22) NOT NULL default '0',
  `startdate` text NOT NULL,
  `chargetotal` float NOT NULL default '0',
  `periodicity` text NOT NULL,
  `thisgoesin` varchar(255) default NULL,
  `comments` varchar(255) default NULL,
  `cardnumber` varchar(255) NOT NULL default '0',
  `cardexpmonth` varchar(255) NOT NULL default '0',
  `cardexpyear` varchar(255) NOT NULL default '0',
  `ip` varchar(255) default NULL,
  `name` varchar(255) default NULL,
  `address1` varchar(255) default NULL,
  `city` varchar(255) default NULL,
  `state` varchar(255) default NULL,
  `country` varchar(255) default NULL,
  `phone` varchar(255) default NULL,
  `fax` varchar(255) default NULL,
  `email` varchar(255) default NULL,
  `zip` varchar(255) default NULL,
  `linkpoint_type` varchar(32) NOT NULL default '',
  `status` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`lpid`)
) TYPE=MyISAM COMMENT='Recurring queue for LinkPoint' AUTO_INCREMENT=1 ;

ALTER TABLE `payment_process` ADD `linkpoint_storeid` VARCHAR( 255 ) NOT NULL AFTER `paysystems_companyid` ;
ALTER TABLE `payment_process` ADD `linkpoint_type` VARCHAR( 255 ) NOT NULL AFTER `linkpoint_storeid` ;

INSERT INTO `payment_process` VALUES (10, 0, 'LinkPoint', '', 'SSC5LA==', 'SSC5LA==', '', '', '', '', '', 0, '', '', 'SALE', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', 0, '');

ALTER TABLE `hosting_order` ADD `linkpoint_recid` VARCHAR( 255 ) DEFAULT '0' NOT NULL ;
ALTER TABlE `hosting_order` ADD `lpid` VARCHAR( 22 ) DEFAULT '' NOT NULL;
ALTER TABLE `session_history` ADD `lpid` VARCHAR( 22 ) DEFAULT '' NOT NULL;