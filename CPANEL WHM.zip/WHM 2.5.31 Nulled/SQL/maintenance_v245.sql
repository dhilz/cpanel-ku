ALTER TABLE `config` ADD `ip_restrict` CHAR( 3 ) DEFAULT 'no' NOT NULL ;
CREATE TABLE `autopilot_ip` (`ipid` BIGINT( 22 ) UNSIGNED NOT NULL AUTO_INCREMENT ,`ip` VARCHAR( 40 ) NOT NULL , `created` INT( 20 ) NOT NULL , PRIMARY KEY ( `ipid` ) );
ALTER TABLE `session_history` ADD `fraudcall_api_response` VARCHAR( 25 ) NOT NULL , ADD `fraudcall_score` VARCHAR( 25 ) NOT NULL ;
ALTER TABLE `session_history` ADD `bin_number` INT( 6 ) NOT NULL ;
ALTER TABLE `hosting_order` ADD `fraudcall_score` VARCHAR( 10 ) NOT NULL ;

CREATE TABLE `autopilot_fraudcall` (
  `fraudcall_key` varchar(255) NOT NULL default '',
  `fraudcall_value` text NOT NULL,
  `fraudcall_message` varchar(255) NOT NULL default '',
  `display_order` int(1) NOT NULL default '0',
  UNIQUE KEY `fraudcall_key` (`fraudcall_key`)
) TYPE=MyISAM;

#
# Dumping data for table `autopilot_fraudcall`
#

INSERT INTO `autopilot_fraudcall` VALUES ('activate_fraud_call', 'no', '', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_121', 'no', 'Dialed unsuccessfully: Toll Free numbers cannot be dialed.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_122', 'no', 'Dialed unsuccessfully: Phone number was in an undialable format.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_123', 'no', 'Dialed unsuccessfully: Undialable country, refer to accepted country list below.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_124', 'no', 'Dialed unsuccessfully: Call cannot be dialed.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_125', 'no', 'Dialed unsuccessfully: Invalid phone number - phone number cannot begin with "1".', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_126', 'no', 'Dialed unsuccessfully: Invalid phone number - area code and Country code combination<br>&nbsp;does not match proper format.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_130', 'no', 'Cannot call Cell Phone as per user\'s preferences.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_131', 'no', 'User does not have sufficient call credits for this call to be placed.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_140', 'no', 'PVS_USERNAME and PVS_PASSWORD is incorrect.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_150', 'no', 'API Post incomplete.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_320', 'stop', 'Caller DECLINED transaction.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_331', 'stop', 'Call failed: The line was busy when we called you.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_332', 'stop', 'Call failed: The call was answered, but nobody responded. Our system detects and waits<br>&nbsp;for a human to say "Hello" before the verification process beings.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_333', 'stop', 'Call failed: The call was answered, but there were more than 3 errors made<br>&nbsp;while entering approve or decline.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_334', 'stop', 'Call failed: An answering machine picked up.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_335', 'stop', 'Call failed: The phone number was unreachable, possibly out of service.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_336', 'stop', 'Call failed: Fax machine or modem answered call.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_337', 'stop', 'Call failed: No answer after 7 rings.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_338', 'no', 'Call failed: System error on VariLogix end.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_339', 'no', 'Call failed: Internal system error on VariLogix end.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('install_3310', 'no', 'Call failed: Cannot call international cell phone.', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('pvs_id', '', '', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('pvs_password', '', '', 0);
INSERT INTO `autopilot_fraudcall` VALUES ('fraud_low', 'yes', 'Call Processed Successfully: [ Very Low Fraud Risk ] 0.00 to 3.50', 3);
INSERT INTO `autopilot_fraudcall` VALUES ('fraud_mid', 'no', 'Call Processed Successfully: [ Medium Fraud Risk ] 3.51 - 7.00', 2);
INSERT INTO `autopilot_fraudcall` VALUES ('fraud_high', 'no', 'Call Processed Successfully: [ High Fraud Risk ] 7.01 - 10.00', 1);
