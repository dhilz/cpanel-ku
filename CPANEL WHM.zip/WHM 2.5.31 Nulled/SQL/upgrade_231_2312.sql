CREATE TABLE `authnet_master_cc` (
  `ccid` bigint(22) unsigned NOT NULL auto_increment,
  `customer_first_name` varchar(255) NOT NULL default '',
  `customer_last_name` varchar(255) NOT NULL default '',
  `customer_address` varchar(255) NOT NULL default '',
  `customer_city` varchar(255) NOT NULL default '',
  `customer_state` varchar(255) NOT NULL default '',
  `customer_zip` varchar(255) NOT NULL default '',
  `customer_country` varchar(255) NOT NULL default '',
  `customer_phone` varchar(25) NOT NULL default '',
  `customer_fax` varchar(25) NOT NULL default '',
  `customer_email` varchar(255) NOT NULL default '',
  `card_info` text NOT NULL,
  `ogcreate` varchar(40) NOT NULL default '',
  `uid` bigint(22) NOT NULL default '0',
  `master_cc` int(1) NOT NULL default '0',
  PRIMARY KEY  (`ccid`)
) TYPE=MyISAM COMMENT='Authorize.net master cc data' AUTO_INCREMENT=1 ;
    
ALTER TABLE `authnet_batch` ADD `ccid` BIGINT( 22 ) NOT NULL AFTER `uid` ;