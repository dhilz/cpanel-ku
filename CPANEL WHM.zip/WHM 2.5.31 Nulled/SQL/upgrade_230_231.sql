CREATE TABLE `tld_chart` (
`tld_id` BIGINT( 22 ) UNSIGNED NOT NULL AUTO_INCREMENT ,
`tld` VARCHAR( 8 ) NOT NULL ,
`cost` FLOAT NOT NULL ,
`reg_period` INT( 1 ) DEFAULT '1' NOT NULL,
PRIMARY KEY ( `tld_id` ) 
);

INSERT INTO `tld_chart` VALUES (10, 'com', '15', 1);
INSERT INTO `tld_chart` VALUES (11, 'net', '15', 1);
INSERT INTO `tld_chart` VALUES (12, 'org', '15', 1);

ALTER TABLE `config` ADD `cont_resolve` int(1) NOT NULL default '0';
ALTER TABLE `config` ADD `resolve_works` int(1) NOT NULL default '0';
ALTER TABLE `session_history` ADD `tld` VARCHAR( 23 ) NOT NULL AFTER `domain_name` ;
ALTER TABLE `hosting_order` CHANGE `domain_lock` `domain_lock` INT( 4 ) DEFAULT '0' NOT NULL;
ALTER TABLE `hosting_order` ADD `tld_id` BIGINT( 22 ) NOT NULL AFTER `domain_registration` ;
INSERT INTO `email_templates` (`emid`, `name`, `subject`, `message`, `attr_avail`, `default_email`) VALUES (43, 'Domain Registration Notice', 'Domain Registration Requested for {{domain_name}}', 'Hello Admin,\r\n\r\nOn, {{generate_date}}, {{first_name}} {{last_name}} ordered hosting that included the registration of a domain name.\r\n\r\nDomain: {{domain_name}}\r\nCost Agreed: {{domain_reg_price}}\r\n\r\nRegistrant Information:\r\n\r\n{{first_name}} {{last_name}}\r\n{{company_name}}\r\n{{address_1}}\r\n{{address_2}}\r\n{{city}} {{state}}, {{zip}}\r\n{{phone}}\r\n{{fax}}\r\n\r\nPlease register this domain for the client immediately and make sure the nameservers placed in at the time of order are:\r\n\r\n{{primary_ns}}\r\n{{primary_ns_ip}}\r\n\r\n{{secondary_ns}}\r\n{{secondary_ns_ip}}\r\n\r\nThank you.\r\n\r\nYour AutoPilot\r\n\r\nMessage Generated on: {{generate_date}}', '{{domain_name}}|{{generate_date}}|{{first_name}}|{{last_name}}|{{domain_reg_price}}|{{company_name}}|{{address_1}}|{{address_2}}|{{city}}|{{state}}|{{zip}}|{{phone}}|{{fax}}|{{primary_ns}}|{{primary_ns_ip}}|{{secondary_ns}}|{{secondary_ns_ip}}|', '');
ALTER TABLE `hosting_order` ADD `client_host` VARCHAR( 255 ) NOT NULL AFTER `client_ip` ;
UPDATE `email_templates` SET `attr_avail` = '{{ip}}|{{whm_username}}|{{whm_password}}|{{domain_name}}|{{primary_ns}}|{{primary_ns_ip}}|{{secondary_ns}}|{{secondary_ns_ip}}|{{generate_date}}|{{clientarea_username}}|{{clientarea_password}}|{{clientarea_loginlink}}' WHERE `emid` = '10' LIMIT 1 ;
UPDATE `email_templates` SET `subject` = 'Recurring Revenue per Server Report', `message` = '================================================= RECURRING REVENUE PER SERVER FOR {{site_name}} ================================================= {{server_details}} This message was generated on: {{generate_date}}' WHERE `emid` = '30' LIMIT 1 ;
ALTER TABLE `config` CHANGE `domain_fee` `domain_fee` INT( 1 ) DEFAULT '0' NOT NULL ;
