DELETE FROM `user` WHERE status='69';
#the above query will delete all admins due to new security

ALTER TABLE `user` CHANGE `password` `password` TEXT NOT NULL;
ALTER TABLE `user` DROP INDEX `sid`;
ALTER TABLE `user` CHANGE `sid` `sid` TEXT NOT NULL;
INSERT INTO `email_templates` ( `emid` , `name` , `subject` , `message` , `attr_avail` , `default_email` ) VALUES ('', 'Payment Processor Returned Transaction Data', 'Gateway Response for {{domain_name}} from {{payment_gateway}}', 'Hello,\n\nBelow are the results for the hosting order for {{domain_name}} paid through {{payment_gateway}}.\n\nThis email should be used for troubleshooting any problems that may have arose during the order process or to be stored as a record of the inital response from the gateway.\n\n{{post_data}}\n\nThank you.\n\nYour AutoPilot\n\nGenerated on: {{generate_date}}', '{{domain_name}}|{{payment_gateway}}|{{post_data}}|{{generate_date}}', '');
INSERT INTO `email_templates` ( `emid` , `name` , `subject` , `message` , `attr_avail` , `default_email` ) VALUES ('', 'Invalid Admin Login Attempt', 'Invalid Admin Login on {{generate_date}}', 'Hello,\n\nOn {{generate_date}}, access to your admin area was attempted but failed.\n\nIP: {{users_ip}}\nUsername: {{username}}\nPassword Attempted: {{password_attempt}}\n\nThank you.\n\nYour AutoPilot.\n\nGenerated on: {{generate_date}}', '{{generate_date}}|{{users_ip}}|{{username}}|{{password_attempt}}', '');
ALTER TABLE `config` ADD `enable_debugging` TINYINT( 1 ) DEFAULT '1' NOT NULL ;