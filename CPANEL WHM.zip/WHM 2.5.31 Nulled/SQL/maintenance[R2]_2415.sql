ALTER TABLE `server_config` ADD `server_cost` FLOAT DEFAULT '0' NOT NULL AFTER `manual_install_active` ;
ALTER TABLE `server_config` ADD `server_noclocal` VARCHAR( 255 ) DEFAULT '0' NOT NULL AFTER `server_cost` ;

UPDATE `email_templates` SET `attr_avail` = '{{ip}}|{{whm_username}}|{{whm_password}}|{{domain_name}}|{{primary_ns}}|{{primary_ns_ip}}|{{secondary_ns}}|{{secondary_ns_ip}}|{{generate_date}}|{{clientarea_username}}|{{clientarea_password}}|{{clientarea_loginlink}}' WHERE `emid` = '10' LIMIT 1 ;