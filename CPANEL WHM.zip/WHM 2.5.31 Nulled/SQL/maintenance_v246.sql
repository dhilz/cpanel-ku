ALTER TABLE `payment_process` ADD `psigate_merchant` VARCHAR( 64 ) NOT NULL AFTER `linkpoint_type` ;
ALTER TABLE `payment_process` ADD `psigate_chargetype` VARCHAR( 2 ) DEFAULT '0' NOT NULL AFTER `psigate_merchant` ;
ALTER TABLE `payment_process` ADD `psigate_emailclient` VARCHAR( 4 ) NOT NULL AFTER `psigate_chargetype` ;

INSERT INTO `payment_process` VALUES (11, 0, 'PSiGate', '', 'SSC5LA==', 'SSC5LA==', '', '', '', '', '', 0, '', '', '', '', '0', '1', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', 0, '');

INSERT INTO `payment_process` VALUES (12, 0, 'PayPal[2]', '', 'SSC5LA==', 'SSC5LA==', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '', 0, '');

INSERT INTO `payment_process` VALUES (13, 0, 'WorldPay[2]', '', 'SSC5LA==', 'SSC5LA==', '', '', '', '', '', 0, '', '', '', '', '0', '', '', '', '', '', 'USD', 0, '', '', '', '', '', '', '', '', '', '', '', 0, '');


CREATE TABLE `psigate_logging` (
  `logid` tinyint(22) unsigned NOT NULL auto_increment,
  `oid` varchar(22) NOT NULL default '',
  `iid` varchar(22) NOT NULL default '',
  `sid` varchar(32) NOT NULL default '',
  `raw_log` text NOT NULL,
  PRIMARY KEY  (`logid`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;