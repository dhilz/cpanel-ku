UPDATE `email_templates` SET `attr_avail` = '{{admin_reply_details}}|{{ticket_number}}|{{ticket_details}}|{{generate_date}}|' WHERE `emid` = '46' LIMIT 1 ;
ALTER TABLE `config` ADD `send_reminders` INT( 1 ) DEFAULT '1' NOT NULL ;
