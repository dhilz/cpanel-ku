ALTER TABLE `config` ADD `maintenance` VARCHAR( 3 ) DEFAULT 'no' NOT NULL AFTER `allow_proxy` ;

ALTER TABLE `affiliate_history` ADD `paid_date` INT( 10 ) NOT NULL AFTER `period_of` ;
ALTER TABLE `affiliate_details` ADD `last_updated` INT( 10 ) NOT NULL AFTER `ogcreate` ;
ALTER TABLE `affiliate_history` CHANGE `owed_to_client` `owed_to_client` DECIMAL( 10, 2 ) DEFAULT '0' NOT NULL ;
ALTER TABLE `affiliate_details` CHANGE `total_amount_package` `total_amount_package` DECIMAL( 10, 2 ) DEFAULT '0' NOT NULL ;
ALTER TABLE `affiliate_details` CHANGE `total_due_to_client` `total_due_to_client` DECIMAL( 10, 2 ) DEFAULT '0' NOT NULL ;

UPDATE `payment_process` SET `name` = 'AlternatePalPay' WHERE `pid` =12 LIMIT 1 ;