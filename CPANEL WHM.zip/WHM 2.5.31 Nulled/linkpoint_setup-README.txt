### LinkPoint API Setup Instructions ###
### Available in v2.4.5.6 or higher  ###

The LinkPoint API system requires that you provide the API with an RSA & CRT that is issued to your at the time your gateway was activated.  If you did not receive this in your activation, please contact LinkPoint before activating in AutoPilot or the gateway will not work.

A) Updating your Key (.pem) File
	1.) download (or edit before upload) /inc/lpnt.pem
	2.) Copy all characters beginning with the line that states, "-----BEGIN RSA PRIVATE KEY-----" through the end it states, "-----END CERTIFICATE-----". 
	3.) paste contents into the lpnt.pem file and save
	4.) upload ( in BINARY ) to your /inc folder

B) Activating the gateway in your "Payment Gateway" configuration area.

	1.) Place your store ID into the ID block
	2.) choose your charge type
		SALE ==> clients card will be authorized & captured upon order completion
		PREAUTH ==> clients card will be authorized for the amount of the sale
		** after validation, you would then need to login to LinkPointCentral.com and perfom a ticket sale **
	3.) click update

No changes need to be made to any packages or any other settings in your AutoPilot.

You will notice after you activate the gateway that a new link will appear in your "General Links" area:

	Manage LinkPoint Periodic Billings


This module was written to handle two of the items required for LinkPoint and periodic billing through linkpoint.

		[a] the initial sale can only be one value, hence, a one time payment but we took it to the next level
		[b] a periodic billing record generated that will create a recurring record at linkpoint


ORDER PROCESS:

Your clients will go through the order system as normal, and end up at a 'credit card' input screen where they would input their billing details and submit.  NOTE: THIS REQUIRES YOU TO SECURE YOUR ORDER PAGES BEHIND SSL

Once the order is completed, AutoPilot will create a 'pending periodic billing record' that you can view from the menu on the main page "Manage LinkPoint Periodic Billings  [ 1 Open ]"

Inside that area you will see all pending & completed periodic billings generated through AutoPilot. ( later, we will add in options to edit & cancel recurrings through here as well ).

To activate a periodic billing record, all you need to do is view the record and click "Send to Linkpoint".  You will get a confirmation via eMail from LinkPoint and the record will revert to the 'completed' area in your main LinkPoint viewing area.