<?
$mysqluser = str_replace("-","","<cpanel print="$user">");
$DBMAX=<cpanel print="$CPDATA{'MAXSQL'}">;
$DBS=$DBMAX - <cpanel Mysql="countdbs()">;


if (is_dir("$fantasticopath/admin/disabled"))
	{
	$FantError.="<p class=Hint><b>Fantastico is currently disabled.<b></p>";
	} else {

if (!is_dir("$adminsettingspath"))
	{
	$FantError.="<p class=Hint><b>Fantastico has not been setup yet. Please come back later and retry.</b></p><p>If you are the administrator, please read the READ_ME file to learn more on how to set up Fantastico.";
	}

if ($DBS == 0 && is_integer($DBMAX))
	{
	$FantError.="<p class=Hint><b>You have reached the maximum of allowed MySQL databases. Fantastico can not proceed with installations until you upgrade your account or reduce the number of used databases (for example by uninstalling a script).</b></p>";
	} 

if (is_file("$fantasticopath/admin/users.inc.php"))
	{
		include("$fantasticopath/admin/users.inc.php");
	} else {
		$restrict_by_users = "disabled";
	}

if (is_file("$fantasticopath/admin/resellers.inc.php"))
	{
		include("$fantasticopath/admin/resellers.inc.php");
	} else {
		$restrict_by_resellers = "disabled";
	}

if (is_file("$fantasticopath/admin/packages.inc.php"))
	{
		include("$fantasticopath/admin/packages.inc.php");
	} else {
		$restrict_by_packages = "disabled";
	}
if ($restrict_by_users == "disabled" && is_dir("$adminsettingspath/disabledusers/$REMOTE_USER")) 
	{
		$FantError.="<p class=Hint>This username is not allowed to use Fantastico. Please contact us to gain access to Fantastico.</p>";
	}

if ($restrict_by_users == "enabled" && !(is_dir("$adminsettingspath/enabledusers/$REMOTE_USER")))
	{
	if (($restrict_by_resellers == "disabled" &&  is_dir("$adminsettingspath/disabledresellers/<cpanel print="$CPDATA{'OWNER'}">")) || ($restrict_by_resellers == "enabled" &&  !(is_dir("$adminsettingspath/enabledresellers/<cpanel print="$CPDATA{'OWNER'}">"))))
		{
			$FantError.="<p class=Hint>You are not allowed to use Fantastico. Please contact us to gain access to Fantastico.</p>";
		}
	
	if (($restrict_by_packages == "disabled" &&  is_dir("$adminsettingspath/disabledpackages/<cpanel print="$CPDATA{'PLAN'}">")) || ($restrict_by_packages == "enabled" &&  !(is_dir("$adminsettingspath/enabledpackages/<cpanel print="$CPDATA{'PLAN'}">"))))
		{
			$FantError.="<p class=Hint>This hosting plan has no access to Fantastico. Upgrade your hosting plan to be able to use Fantastico.</p>";
		}
	}
}
?>
