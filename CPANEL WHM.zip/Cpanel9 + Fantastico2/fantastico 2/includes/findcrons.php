<?php

$findcrons='<cpanel Cron="list_cron()">';
$findcrons=str_replace("input type=text", "input type=hidden", $findcrons);
$findcrons=str_replace("\"", "'", $findcrons);
$findcrons=eregi_replace('<tr>|</tr>|<td>|</td>', '', $findcrons); 
$findcrons=preg_replace('/(\<a href)[^\n\r]+/', '', $findcrons); 


if ($thisapp=="Moodle")
	{
	$findcrons.="
		<input type='hidden' name='0-minute' value='$cronminutes'>
		<input type='hidden' name='0-hour' value='*'>
		<input type='hidden' name='0-day' value='*'>
		<input type='hidden' name='0-month' value='*'>
		<input type='hidden' name='0-weekday' value='*'>
		<input type='hidden' name='0-command' value='wget -q -O /dev/null http://<cpanel print="DOMAIN">/$installdir/admin/cron.php'>";
	} else if ($thisapp=="WebCalendar") {
	$findcrons.="
		<input type='hidden' name='0-minute' value='$cronminutes'>
		<input type='hidden' name='0-hour' value='*'>
		<input type='hidden' name='0-day' value='*'>
		<input type='hidden' name='0-month' value='*'>
		<input type='hidden' name='0-weekday' value='*'>
		<input type='hidden' name='0-command' value='wget -q -O /dev/null http://<cpanel print="DOMAIN">/$installdir/tools/send_reminders.php'>";
	}

?>