<?php

// What did we install until now?
// Show "none" if none, show list if any

$userdata='<cpanel print="$homedir">/.fantasticodata/'.$thisapp;

if (is_dir($userdata))
	{
	if ($thisdir = opendir($userdata)) 
		{
		while (false !== ($file = readdir($thisdir))) 
			{
			if ($file != "." && $file != "..") 
				{ 
				$shortapp=explode(".",$file);
				$myapps[]=$shortapp[0];
				}
			}
		closedir($thisdir); 
		}
	}


$installs = count ($myapps);

if ($installs == 0)
	{
	echo "<br>None";
	} else {
	echo "<br><table>";
	foreach($myapps as $localapp)
		{
		include('<cpanel print="$homedir">/.fantasticodata/'.$thisapp."/"."$localapp");
		echo "<tr><td><b>$localapp</b>";
		
		if (is_file("<cpanel print="$homedir">" . "/public_html/" . $localapp . "/fantversion.php"))
			{
			include("<cpanel print="$homedir">" . "/public_html/" . $localapp . "/fantversion.php");
			echo " (" . $version . ")";
			}

		echo "		</td>
		<td>&nbsp;</td>
		<td><a href=http://<cpanel print="DOMAIN">/$localapp>Visit site</a></td>
		<td>&nbsp;</td>
		<td>
		<form action='autoinstallremoveconfirm.php' method='GET'>
		<input type='submit' name='action' value='Remove'>
		<input type='hidden' name='removedir' value='$localapp'>
		<input type='hidden' name='removedb' value='$thisdb'>
		<input type='hidden' name='removeapp' value='$thisapp'>
		<input type='hidden' name='thispage' value='$thispage'>
		</form>
		</td>
		";
		}
	echo "</tr></table>";
	}

?>

