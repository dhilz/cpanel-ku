<?php
$MYSQLHOST="localhost";
$MYSQLPATH="mysql";
?>

<?
// To change the above values do not modify this file, this will be overwritten when updating 
// Instead, copy the 4 first lines of this file to 'mysqlconfig.local.php' 
// and place it inside the the same includes directory

$localmysqlconfig=$fantasticopath . "/includes/mysqlconfig.local.php";
if (is_file($localmysqlconfig))
	{
	include($localmysqlconfig);
	}
?>

<cpanel Mysql="addhost(192.168.1.%)">

