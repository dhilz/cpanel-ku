<?php
$DBHOST="localhost";
$MYSQLPATH="/usr/local/bin/mysql";
?>

<cpanel Mysql="addhost(192.168.1.%)">

