			  <tr>
				<td width="20" height="18">&nbsp;</td>
				<td width="150" height="18" align="left" valign="top">&nbsp;</td>
				<td width="12" height="18">&nbsp;</td>
				<td height="18" class="MainMenuHead"><?php echo "$humanapp" ?></td>
				<td width="20" height="18">&nbsp;</td>
			  </tr>

			  <tr> 
				<td width="20" height="100%">&nbsp;</td>
				<td width="8" height="100%" align="left" valign="top">
				<table width="100%" border="0" cellspacing="0" cellpadding="0">

<!-- Begin Admin-Link -->

<?php
if ($fantasticoadmin == $REMOTE_USER)
	{
	echo "
		<tr> 
		<td width='10'>&nbsp;</td>
		<td width='4'>&nbsp;</td>
		<td nowrap class='LeftMenuHeaders'>
		Administrate Fantastico
		</td>
	</tr>
	<tr> 
		<td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
		<td width='4'>&nbsp;</td>
		<td nowrap class='LeftMenu'>
		<a href='admin/admin.php' class='LeftMenu'>Admin Area</a>
		</td>
	</tr>
	<tr> 
		<td width='10'>&nbsp;</td>
		<td width='4'>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	";
	}
?>

<!-- Begin Portals -->
<?

$IS_PORTALS=0;
$DEPOT_PORTALS[]=$DEPOT."PHP-Nuke";
$DEPOT_PORTALS[]=$DEPOT."Post-Nuke";
$DEPOT_PORTALS[]=$DEPOT."phpWebSite";
$DEPOT_PORTALS[]=$DEPOT."Xoops";
foreach($DEPOT_PORTALS AS $ROOT_PORTALS)
	{
	if(is_dir($ROOT_PORTALS))
		{
		$IS_PORTALS=1;
		}
	}
if($IS_PORTALS)
	{
	?>
					<tr> 
					  <td width="10">&nbsp;</td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenuHeaders">Portals</td>
					</tr>
	<?
	}
?>
<!-- Begin PHP-Nuke -->
<?
$DEPOT_NUKE=$DEPOT."PHP-Nuke";
if(is_dir($DEPOT_NUKE) && ($thisapp=="PHP-Nuke"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallnukehome.php' class='LeftMenu'>PHP-Nuke</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_NUKE)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallnukehome.php' class='LeftMenu'>PHP-Nuke</a>";
	echo "</td></tr>";
	}
?>
<!-- End PHP-Nuke -->

<!-- Begin Post-Nuke -->
<?
$DEPOT_PNUKE=$DEPOT."Post-Nuke";
if(is_dir($DEPOT_PNUKE) && ($thisapp=="Post-Nuke"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallpostnukehome.php' class='LeftMenu'>Post-Nuke</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_PNUKE)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallpostnukehome.php' class='LeftMenu'>Post-Nuke</a>";
	echo "</td></tr>";
	}
?>
<!-- End Post-Nuke -->

<!-- Begin PHP-Website -->
<?
$DEPOT_WEBSITE=$DEPOT."phpWebSite";
if(is_dir($DEPOT_WEBSITE) && ($thisapp=="phpWebSite"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallwebsitehome.php' class='LeftMenu'>phpWebsite</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_WEBSITE)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallwebsitehome.php' class='LeftMenu'>phpWebsite</a>";
	echo "</td></tr>";
	}
?>
<!-- End PHP-Website -->

<!-- Begin Xoops -->
<?
$DEPOT_XOOPS=$DEPOT."Xoops";
if(is_dir($DEPOT_XOOPS) && ($thisapp=="Xoops"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallxoopshome.php' class='LeftMenu'>Xoops</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_XOOPS)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallxoopshome.php' class='LeftMenu'>Xoops</a>";
	echo "</td></tr>";
	}
?>

<!-- End Xoops -->
<!-- End Portals -->

<!-- Begin Blogs -->
<?
$IS_BLOGS=0;
$DEPOT_BLOGS[]=$DEPOT."b2";
$DEPOT_BLOGS[]=$DEPOT."pMachine_Free";
foreach($DEPOT_BLOGS AS $ROOT_BLOGS)
	{
	if(is_dir($ROOT_BLOGS))
		{
		$IS_BLOGS=1;
		}
	}

if($IS_BLOGS)
	{
	?>
					<tr> 
					  <td width="10">&nbsp;</td>
					  <td width="4">&nbsp;</td>
					  <td>&nbsp;</td>
					</tr>
					<tr> 
					  <td width="10">&nbsp;</td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenuHeaders">Blogs</td>
					</tr>
	<?
	}
?>

<!-- Begin b2 -->
<?
$DEPOT_B2=$DEPOT."b2";
if(is_dir($DEPOT_B2) && ($thisapp=="b2"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallb2home.php' class='LeftMenu'>b2</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_B2)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallb2home.php' class='LeftMenu'>b2</a>";
	echo "</td></tr>";
	}
?>

<!-- End b2 -->

<!-- Begin pMachine Free -->
<?
$DEPOT_PMFREE=$DEPOT."pMachine_Free";
if(is_dir($DEPOT_PMFREE) && ($thisapp=="pMachine_Free"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallpmachinehome.php' class='LeftMenu'>pMachine Free</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_PMFREE)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallpmachinehome.php' class='LeftMenu'>pMachine Free</a>";
	echo "</td></tr>";
	}
?>
<!-- End pMachine Free -->
<!-- End Blogs -->


<!-- Begin Customer Relationship -->
<?
$IS_CRM=0;
$DEPOT_CRM[]=$DEPOT."CS_Live_Help";
$DEPOT_CRM[]=$DEPOT."PHP_Support_Tickets";
$DEPOT_CRM[]=$DEPOT."Support_Services_Manager";
foreach($DEPOT_CRM AS $ROOT_CRM)
	{
	if(is_dir($ROOT_CRM))
		{
		$IS_CRM=1;
		}
	}

if($IS_CRM)
	{
	?>
					<tr> 
					  <td width="10">&nbsp;</td>
					  <td width="4">&nbsp;</td>
					  <td>&nbsp;</td>
					</tr>
					<tr> 
					  <td width="10">&nbsp;</td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenuHeaders">Customer Relationship</td>
					</tr>
	<?
	}
?>

<!-- Begin CS_Live_Help -->
<?
$DEPOT_CSLH=$DEPOT."CS_Live_Help";
if(is_dir($DEPOT_CSLH) && ($thisapp=="CS_Live_Help"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallcslivehelphome.php' class='LeftMenu'>CS Live Help</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_CSLH)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallcslivehelphome.php' class='LeftMenu'>CS Live Help</a>";
	echo "</td></tr>";
	}
?>

<!-- End CS_Live_Help -->

<!-- Begin PHP_Support_Tickets -->
<?
$DEPOT_STICKETS=$DEPOT."PHP_Support_Tickets";
if(is_dir($DEPOT_STICKETS) && ($thisapp=="PHP_Support_Tickets"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallsticketshome.php' class='LeftMenu'>PHP Support Tickets</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_STICKETS)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallsticketshome.php' class='LeftMenu'>PHP Support Tickets</a>";
	echo "</td></tr>";
	}
?>

<!-- End PHP_Support_Tickets -->

<!-- Begin Support_Services_Manager -->
<?
$DEPOT_SSM=$DEPOT."Support_Services_Manager";
if(is_dir($DEPOT_SSM) && ($thisapp=="Support_Services_Manager"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallssmhome.php' class='LeftMenu'>Support Services Manager</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_SSM)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallssmhome.php' class='LeftMenu'>Support Services Manager</a>";
	echo "</td></tr>";
	}
?>

<!-- End Support_Services_Manager -->
<!-- End Customer Relationship -->


<!-- Begin Boards -->
<?
$IS_BOARDS=0;
$DEPOT_BOARDS[]=$DEPOT."phpBB2";
$DEPOT_BOARDS[]=$DEPOT."Invision_Board";
foreach($DEPOT_BOARDS AS $ROOT_BOARDS)
	{
	if(is_dir($ROOT_BOARDS))
		{
		$IS_BOARDS=1;
		}
	}

if($IS_BOARDS)
	{
	?>
					<tr> 
					  <td width="10">&nbsp;</td>
					  <td width="4">&nbsp;</td>
					  <td>&nbsp;</td>
					</tr>
					<tr> 
					  <td width="10">&nbsp;</td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenuHeaders">Discussion Boards</td>
					</tr>
	<?
	}
?>

<!-- Begin phpBB2 -->
<?
$DEPOT_BB2=$DEPOT."phpBB2";
if(is_dir($DEPOT_BB2) && ($thisapp=="phpBB2"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallphpbb2home.php' class='LeftMenu'>phpBB2</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_BB2)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallphpbb2home.php' class='LeftMenu'>phpBB2</a>";
	echo "</td></tr>";
	}
?>
<!-- End phpBB2 -->

<!-- Begin Invision Board -->
<?
$DEPOT_INVBOARD=$DEPOT."Invision_Board";
if(is_dir($DEPOT_INVBOARD) && ($thisapp=="Invision_Board"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstalliboardhome.php' class='LeftMenu'>Invision Board</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_INVBOARD)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstalliboardhome.php' class='LeftMenu'>Invision Board</a>";
	echo "</td></tr>";
	}
?>
<!-- End Invision Board -->
<!-- End Boards -->


<!-- Begin Other -->
<?
$IS_OTHER=0;
$DEPOT_OTHER[]=$DEPOT."OS_Commerce";
$DEPOT_OTHER[]=$DEPOT."4Images_Gallery";
$DEPOT_OTHER[]=$DEPOT."PHPauction";
$DEPOT_OTHER[]=$DEPOT."PHProjekt";
$DEPOT_OTHER[]=$DEPOT."phpLinks";
$DEPOT_OTHER[]=$DEPOT."Moodle";
$DEPOT_OTHER[]=$DEPOT."Noahs_Classifieds";
$DEPOT_OTHER[]=$DEPOT."WebCalendar";
foreach($DEPOT_OTHER AS $ROOT_OTHER)
	{
	if(is_dir($ROOT_OTHER))
		{
		$IS_OTHER=1;
		}
	}
if($IS_OTHER)
	{
	?>
					<tr> 
					  <td width="10">&nbsp;</td>
					  <td width="4">&nbsp;</td>
					  <td>&nbsp;</td>
					</tr>
					<tr> 
					  <td width="10">&nbsp;</td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenuHeaders">Other Scripts</td>
					</tr>
	<?
	}
?>

<!-- Begin OS Commerce -->
<?
$DEPOT_OSC=$DEPOT."OS_Commerce";
if(is_dir($DEPOT_OSC) && ($thisapp=="OS_Commerce"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstalloschome.php' class='LeftMenu'>OS Commerce</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_OSC)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstalloschome.php' class='LeftMenu'>OS Commerce</a>";
	echo "</td></tr>";
	}
?>
<!-- End OS Commerce -->

<!-- Begin 4images -->
<?
$DEPOT_4IMAGES_GALLERY=$DEPOT."4Images_Gallery";
if(is_dir($DEPOT_4IMAGES_GALLERY) && ($thisapp=="4Images_Gallery"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstall4galleryhome.php' class='LeftMenu'>4images Gallery</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_4IMAGES_GALLERY)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstall4galleryhome.php' class='LeftMenu'>4images Gallery</a>";
	echo "</td></tr>";
	}
?>
<!-- End 4images -->

<!-- Begin PHP Auction -->
<?
$DEPOT_AUCTION=$DEPOT."PHPauction";
if(is_dir($DEPOT_AUCTION) && ($thisapp=="PHPauction"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallauctionhome.php' class='LeftMenu'>PHPauction</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_AUCTION)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallauctionhome.php' class='LeftMenu'>PHPauction</a>";
	echo "</td></tr>";
	}
?>
<!-- End PHP Auction -->

<!-- Begin PHProjekt -->
<?
$DEPOT_PHPROJEKT=$DEPOT."PHProjekt";
if(is_dir($DEPOT_PHPROJEKT) && ($thisapp=="PHProjekt"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallprojekthome.php' class='LeftMenu'>PHProjekt</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_PHPROJEKT)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallprojekthome.php' class='LeftMenu'>PHProjekt</a>";
	echo "</td></tr>";
	}
?>
<!-- End PHProjekt -->

<!-- Begin phpLinks -->
<?
$DEPOT_LINKS=$DEPOT."phpLinks";
if(is_dir($DEPOT_LINKS) && ($thisapp=="phpLinks"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstalllinkshome.php' class='LeftMenu'>phpLinks</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_LINKS)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstalllinkshome.php' class='LeftMenu'>phpLinks</a>";
	echo "</td></tr>";
	}
?>
<!-- End phpLinks -->

<!-- Begin Moodle -->
<?
$DEPOT_MOODLE=$DEPOT."Moodle";
if(is_dir($DEPOT_MOODLE) && ($thisapp=="Moodle"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallmoodlehome.php' class='LeftMenu'>Moodle</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_MOODLE)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallmoodlehome.php' class='LeftMenu'>Moodle</a>";
	echo "</td></tr>";
	}
?>

<!-- End Moodle -->

<!-- Begin Noahs_Classifieds -->
<?
$DEPOT_NOAHSCLASS=$DEPOT."Noahs_Classifieds";
if(is_dir($DEPOT_NOAHSCLASS) && ($thisapp=="Noahs_Classifieds"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallnoahsclasshome.php' class='LeftMenu'>Noahs Classifieds</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_NOAHSCLASS)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallnoahsclasshome.php' class='LeftMenu'>Noahs Classifieds</a>";
	echo "</td></tr>";
	}
?>

<!-- End Noahs_Classifieds -->

<!-- Begin PHPlist -->
<?
$DEPOT_PHPlist=$DEPOT."PHPlist";
if(is_dir($DEPOT_PHPlist) && ($thisapp=="PHPlist"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallphplisthome.php' class='LeftMenu'>PHPlist</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_PHPlist)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallphplisthome.php' class='LeftMenu'>PHPlist</a>";
	echo "</td></tr>";
	}
?>

<!-- End PHPlist -->

<!-- Begin WebCalendar -->
<?
$DEPOT_WebCalendar=$DEPOT."WebCalendar";
if(is_dir($DEPOT_WebCalendar) && ($thisapp=="WebCalendar"))
	{
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotblue.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallwebcalendarhome.php' class='LeftMenu'>WebCalendar</a>";
	echo "</td></tr>";
	} else if (is_dir($DEPOT_WebCalendar)) {
	echo "<tr> 
			  <td width='10'><img src='fantasticoimages/xc_dotgrey.gif' width='10' height='12'></td>
			  <td width='4'>&nbsp;</td>
			  <td nowrap class='LeftMenu'>";
	echo "<a href='autoinstallwebcalendarhome.php' class='LeftMenu'>WebCalendar</a>";
	echo "</td></tr>";
	}
?>

<!-- End WebCalendar -->

<!-- End Other -->



				  </table>
				</td>
				<td width="12" height="100%">&nbsp;</td>
				<td height="100%" align="center" valign="top" class="contentcell"> 
				  
