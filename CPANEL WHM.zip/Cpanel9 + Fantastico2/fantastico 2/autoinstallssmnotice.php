<?php
$thisapp="Support_Services_Manager";
$humanapp=str_replace("_", " ", $thisapp);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Fantastico</title>

<?php
if (is_file("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php"))
	{
	include("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php");
	}
	
if ($inxcontroller) {
?>
<cpanel include="../themeheader_subdir1.html">
<cpanel include="includes/mainmenu_icon_subdir.html">
<cpanel include="../themeheader_subdir2.html">
<cpanel include="includes/mainmenu_label.html">
<cpanel include="../themeheader_subdir3.html">

<?php
} else {
?>
<cpanel include="includes/fantasticoheader.html">

<?php
}
?>

<cpanel include="admin/adminuser.inc.php">
<cpanel include="admin/fantasticopath.inc.php">
<cpanel include="includes/adminsettingspath.inc.php">
<cpanel include="includes/restrictions.inc.php">
<cpanel include="includes/masterfilespath.inc.php">
<cpanel include="includes/sidemenu.php">


<script language="JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function YY_checkform() { //v4.66
//copyright (c)1998,2002 Yaromat.com
  var args = YY_checkform.arguments; var myDot=true; var myV=''; var myErr='';var addErr=false;var myReq;
  for (var i=1; i<args.length;i=i+4){
    if (args[i+1].charAt(0)=='#'){myReq=true; args[i+1]=args[i+1].substring(1);}else{myReq=false}
    var myObj = MM_findObj(args[i].replace(/\[\d+\]/ig,""));
    myV=myObj.value;
    if (myObj.type=='text'||myObj.type=='password'||myObj.type=='hidden'){
      if (myReq&&myObj.value.length==0){addErr=true}
      if ((myV.length>0)&&(args[i+2]==1)){ //fromto
        var myMa=args[i+1].split('_');if(isNaN(myV)||myV<myMa[0]/1||myV > myMa[1]/1){addErr=true}
      } else if ((myV.length>0)&&(args[i+2]==2)){
          var rx=new RegExp("^[\\w\.=-]+@[\\w\\.-]+\\.[a-z]{2,4}$");if(!rx.test(myV))addErr=true;
      } else if ((myV.length>0)&&(args[i+2]==3)){ // date
        var myMa=args[i+1].split("#"); var myAt=myV.match(myMa[0]);
        if(myAt){
          var myD=(myAt[myMa[1]])?myAt[myMa[1]]:1; var myM=myAt[myMa[2]]-1; var myY=myAt[myMa[3]];
          var myDate=new Date(myY,myM,myD);
          if(myDate.getFullYear()!=myY||myDate.getDate()!=myD||myDate.getMonth()!=myM){addErr=true};
        }else{addErr=true}
      } else if ((myV.length>0)&&(args[i+2]==4)){ // time
        var myMa=args[i+1].split("#"); var myAt=myV.match(myMa[0]);if(!myAt){addErr=true}
      } else if (myV.length>0&&args[i+2]==5){ // check this 2
            var myObj1 = MM_findObj(args[i+1].replace(/\[\d+\]/ig,""));
            if(myObj1.length)myObj1=myObj1[args[i+1].replace(/(.*\[)|(\].*)/ig,"")];
            if(!myObj1.checked){addErr=true}
      } else if (myV.length>0&&args[i+2]==6){ // the same
            var myObj1 = MM_findObj(args[i+1]);
            if(myV!=myObj1.value){addErr=true}
      }
    } else
    if (!myObj.type&&myObj.length>0&&myObj[0].type=='radio'){
          var myTest = args[i].match(/(.*)\[(\d+)\].*/i);
          var myObj1=(myObj.length>1)?myObj[myTest[2]]:myObj;
      if (args[i+2]==1&&myObj1&&myObj1.checked&&MM_findObj(args[i+1]).value.length/1==0){addErr=true}
      if (args[i+2]==2){
        var myDot=false;
        for(var j=0;j<myObj.length;j++){myDot=myDot||myObj[j].checked}
        if(!myDot){myErr+=args[i+3]+'\n'}
      }
    } else if (myObj.type=='checkbox'){
      if(args[i+2]==1&&myObj.checked==false){addErr=true}
      if(args[i+2]==2&&myObj.checked&&MM_findObj(args[i+1]).value.length/1==0){addErr=true}
    } else if (myObj.type=='select-one'||myObj.type=='select-multiple'){
      if(args[i+2]==1&&myObj.selectedIndex/1==0){addErr=true}
    }else if (myObj.type=='textarea'){
      if(myV.length<args[i+1]){addErr=true}
    }
    if (addErr){myErr+=args[i+3]+'\n'; addErr=false}
  }
  if (myErr!=''){alert(myErr)}
  document.MM_returnValue = (myErr=='');
}
//-->
</script>

<!--
<p align="center"><img src="fantasticoimages/ssm.gif" width="252" height="78">
-->
  <p>
  <table width=100% class='TableMiddle'>
	<tr> 
	  <td>
		<p class="TableMiddleHead">Support Services Manager ("SSM") Software version 1.0 BETA End-User License Agreement</p>
	  </td>
	</tr>
	<tr>
	  <td>&nbsp;</td>
	</tr>
	<tr>
	  <td>
This license is copyright 2001, by Shedd Technologies International<br />SSM is a product of Shedd Technologies International copyright 2001-2002 by Shedd Technologies, All Rights Reserved
<p>
Your use of this product ("SSM") is governed by this End-User License that you agreed to upon downloading this product.  Any usage or modification of this product in anyway that is not specified or allowed under the following terms of this agreement may void your license agreement and result in action by law against you.
<p class=Hint><b>
END-USER LICENSE AGREEMENT</b>
<p>
<p>
Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
<p>
Redistributions in any form other than the original source form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
<p>
Shedd Technologies International may publish revised and/or new versions of this license, each with a distinguishing version number. Once covered code has been published under a particular version of the license, you may always continue to use it under the terms of that version. You may also choose to use such covered code under the terms of any subsequent version of the license published by Shedd Technologies International. No one other than Shedd Technologies International has the right to modify the terms applicable to covered product created under this License.
<p>
Redistributions of any form whatsoever must retain following acknowledgment that exists at the bottom of all generated pages.  Removing this text will void the license agreement and could result in legal action.
<p>
Shedd Technologies International reserves all rights in regard to this product, including the right to distribution.  Shedd Technologies also reserves the right to terminate this license agreement with the End User ("You") at any time for violating this agreement.  You will be notified in writing by Shedd Technologies International before a termination takes effect.
<p>
Redistribution and use in source and binary forms, with or without modification, are restricted by Shedd Technologies International.  Please contact Shedd Technologies International for information of redistributing this product.
<p class=Hint><b>
DISCLAIMER</b>
<p>
THIS SOFTWARE IS PROVIDED "AS IS" AND ANY EXPRESSED OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE SHEDD TECHNOLOGIES INTERNATIONAL DEVELOPMENT TEAM OR ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
<p>
It is not our intent to impede the Open-Source Development of this product at all with this license.  We feel that the most productive was possible to produce a thriving development community is to have one that has a clear center for users and developers.  It is the intent of this license to create this.  If you would like to create a mirror or re-distribute your changes, please inquire using the methods described below.  It is very likely that your request will be approved.
<p>
<b>Contact Shedd Technologies International at the following addresses:</b>
<p>
Legal Information & Claims: <a href=mailto:legal@sheddtech.com>legal@sheddtech.com</a>
<br />Privacy Issues: <a href=mailto:privacy@sheddtech.com>privacy@sheddtech.com</a>
<br />General Information: <a href=mailto:info@sheddtech.com>info@sheddtech.com</a>
<br />Support Issues: <a href=http://net.sheddtech.com/support/>http://net.sheddtech.com/support/</a><p>
</p>
<form action="autoinstallssm.php" method="GET" onSubmit="YY_checkform('form1','agreed','#q','1','You must accept the End-User License Agreement in order to proceed!');return document.MM_returnValue">
		<p align="center">
		<input type="checkbox" name="agreed" value="checkbox">
		I accept the above End-User License Agreement</p>
		<p align="center">
			<input type=hidden name=thisapp value="Support_Services_Manager">
			<input type=hidden name=thispage value="autoinstallssmhome.php">
			<input type="submit" name="submit" value="Continue">
		</p>
</form>
<p>
The developers of <b>Support Services Manager</b> are thankful for any donation which will ensure the further development of this application.
	<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_blank" align=center>
	<input type="hidden" name="cmd" value="_xclick" />
	<input type="hidden" name="business" value="info@sheddtech.com" />
	<input type="image" src="https://www.paypal.com/images/x-click-but04.gif" border="0" name="submit" alt="Help the developers with a donation" title="Help the developers with a donation" />
	</form>
</p>
	  </td>
	</tr>
  </table>


<cpanel include="includes/fantasticofooter.html">
