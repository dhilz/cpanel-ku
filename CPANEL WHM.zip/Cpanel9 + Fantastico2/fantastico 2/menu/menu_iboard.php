			  <tr>
				<td width="20" height="18">&nbsp;</td>
				<td width="150" height="18" align="left" valign="top">&nbsp;</td>
				<td width="12" height="18">&nbsp;</td>
				<td height="18" class="MainMenuHead"><cpanel langprint="FantInvBoard"></td>
				<td width="20" height="18">&nbsp;</td>
			  </tr>

			  <tr> 
				<td width="20" height="100%">&nbsp;</td>
				<td width="8" height="100%" align="left" valign="top">
				<table width="100%" border="0" cellspacing="0" cellpadding="0">

<?
$DEPOT_PATH="/var/autoinstall/english/";
?>

<!-- Begin Portals routine -->

<?

$IS_PORTALS=0;
$DEPOT_PORTALS[]=$DEPOT_PATH."community";
$DEPOT_PORTALS[]=$DEPOT_PATH."postnuke";
$DEPOT_PORTALS[]=$DEPOT_PATH."xoops";
$DEPOT_PORTALS[]=$DEPOT_PATH."website";
foreach($DEPOT_PORTALS AS $ROOT_PORTALS)
	{
	if(is_dir($ROOT_PORTALS))
		{
		$IS_PORTALS=1;
		}
	}
if($IS_PORTALS)
	{
	?>
					<tr> 
					  <td width="10">&nbsp;</td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenuHeaders"><cpanel langprint="FantPortalsHead"></td>
					</tr>
	<?
	}
?>

<!-- Begin PHP-Nuke routine -->
<?

$OLD_NUKE="<cpanel print="$homedir">/public_html/community/config.php";
if(is_file($OLD_NUKE))
	{
	include("$OLD_NUKE");
	}
?>


<?

$DEPOT_NUKE[]=$DEPOT_PATH."community";
foreach($DEPOT_NUKE AS $ROOT_NUKE)
	{
	if(is_dir($ROOT_NUKE))
		{
		$USER_ROOT_NUKE[]="<cpanel print="$homedir">/public_html/community";
		foreach($USER_ROOT_NUKE AS $EXISTROOTNUKE)
			{
			?>
					<tr> 
					  <td width="10"><img src="images/xc_dotgrey.gif" width="10" height="12"></td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenu">
			<?
				if(is_dir($EXISTROOTNUKE))
				{
				echo "<a href='autoinstallnukehome.php' class='LeftMenu'><cpanel langprint="FantPHPNuke"></a>";
					if($Version_Num == "5.6")
					{
						echo " (<a href='autoinstallnukeupgrade.php' class='Hint'><cpanel langprint="FantUpgrade"></a>)";
					}
				}
			else
				{
				echo "<a href='autoinstallnuke.php' class='LeftMenu'><cpanel langprint="FantPHPNuke"></a>";
				}
			echo "</td></tr>";
			}
		}
	}
?>

<!-- End PHP-Nuke routine -->

<!-- Begin Post-Nuke routine -->

<?

$DEPOT_PNUKE[]=$DEPOT_PATH."postnuke";
foreach($DEPOT_PNUKE AS $ROOT_PNUKE)
	{
	if(is_dir($ROOT_PNUKE))
		{
		$USER_ROOT_PNUKE[]="<cpanel print="$homedir">/public_html/postnuke";
		foreach($USER_ROOT_PNUKE AS $EXISTROOTPNUKE)
			{
			?>
					<tr> 
					  <td width="10"><img src="images/xc_dotgrey.gif" width="10" height="12"></td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenu">
			<?
			if(is_dir($EXISTROOTPNUKE))
				{
					echo "<a href='autoinstallpostnukehome.php' class='LeftMenu'><cpanel langprint="FantPostNuke"></a></td></tr>";
				}
			else
				{
					echo "<a href='autoinstallpostnuke.php' class='LeftMenu'><cpanel langprint="FantPostNuke"></a></td></tr>";
				}
			}
		}
	}
?>

<!-- End Post-Nuke routine -->

<!-- Begin PHP-Website routine -->

<?

$DEPOT_WEBSITE[]=$DEPOT_PATH."website";
foreach($DEPOT_WEBSITE AS $ROOT_WEBSITE)
	{
	if(is_dir($ROOT_WEBSITE))
		{
		$USER_ROOT_WEBSITE[]="<cpanel print="$homedir">/public_html/website";
		foreach($USER_ROOT_WEBSITE AS $EXISTROOTWEBSITE)
			{
			?>
					<tr> 
					  <td width="10"><img src="images/xc_dotgrey.gif" width="10" height="12"></td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenu">
			<?
			if(is_dir($EXISTROOTWEBSITE))
				{
					echo "<a href='autoinstallwebsitehome.php' class='LeftMenu'><cpanel langprint="FantWebSite"></a></td></tr>";
				}
			else
				{
					echo "<a href='autoinstallwebsite.php' class='LeftMenu'><cpanel langprint="FantWebSite"></a></td></tr>";
				}
			}
		}
	}
?>

<!-- End PHP-Website routine -->

<!-- Begin Xoops routine -->

<?

$DEPOT_XOOPS[]=$DEPOT_PATH."xoops";
foreach($DEPOT_XOOPS AS $ROOT_XOOPS)
	{
	if(is_dir($ROOT_XOOPS))
		{
		$USER_ROOT_XOOPS[]="<cpanel print="$homedir">/public_html/xoops";
		foreach($USER_ROOT_XOOPS AS $EXISTROOTXOOPS)
			{
			?>
					<tr> 
					  <td width="10"><img src="images/xc_dotgrey.gif" width="10" height="12"></td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenu">
			<?
				if(is_dir($EXISTROOTXOOPS))
				{
					echo "<a href='autoinstallxoopshome.php' class='LeftMenu'><cpanel langprint="FantXoops"></a></td></tr>";
				}
			else
				{
					echo "<a href='autoinstallxoops.php' class='LeftMenu'><cpanel langprint="FantXoops"></a></td></tr>";
				}
			}
		}
	}
?>

<!-- End Xoops routine -->

<!-- End Portals routine -->

<!-- Begin Boards routine -->

<?
$IS_BOARDS=0;
$DEPOT_BOARDS[]=$DEPOT_PATH."forum";
$DEPOT_BOARDS[]=$DEPOT_PATH."iboard";
foreach($DEPOT_BOARDS AS $ROOT_BOARDS)
	{
	if(is_dir($ROOT_BOARDS))
		{
		$IS_BOARDS=1;
		}
	}
if($IS_BOARDS)
	{
	?>
					<tr> 
					  <td width="10">&nbsp;</td>
					  <td width="4">&nbsp;</td>
					  <td>&nbsp;</td>
					</tr>
					<tr> 
					  <td width="10">&nbsp;</td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenuHeaders"><cpanel langprint="FantBoardsHead"></td>
					</tr>
	<?
	}
?>

<!-- Begin phpBB2 routine -->

<?

$DEPOT_FORUM[]=$DEPOT_PATH."forum";
foreach($DEPOT_FORUM AS $ROOT_FORUM)
	{
	if(is_dir($ROOT_FORUM))
		{
		$USER_ROOT_FORUM[]="<cpanel print="$homedir">/public_html/forum";
		foreach($USER_ROOT_FORUM AS $EXISTROOTFORUM)
			{
			?>
					<tr> 
					  <td width="10"><img src="images/xc_dotgrey.gif" width="10" height="12"></td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenu">
			<?
				if(is_dir($EXISTROOTFORUM))
				{
					echo "<a href='autoinstallphpbb2home.php' class='LeftMenu'><cpanel langprint="FantBB2"></a></td></tr>";
				}
			else
				{
					echo "<a href='autoinstallphpbb2.php' class='LeftMenu'><cpanel langprint="FantBB2"></a></td></tr>";
				}
			}
		}
	}
?>

<!-- End phpBB2 routine -->

<!-- Begin Invision Board routine -->

<?

$DEPOT_IBOARD[]=$DEPOT_PATH."iboard";
foreach($DEPOT_IBOARD AS $ROOT_IBOARD)
	{
	if(is_dir($ROOT_IBOARD))
		{
		$USER_ROOT_IBOARD[]="<cpanel print="$homedir">/public_html/iboard";
		foreach($USER_ROOT_IBOARD AS $EXISTROOTIBOARD)
			{
			?>
					<tr> 
					  <td width="10"><img src="images/xc_dotblue.gif" width="10" height="12"></td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenu">
			<?
				if(is_dir($EXISTROOTIBOARD))
				{
					echo "<a href='autoinstalliboardhome.php' class='LeftMenu'><cpanel langprint="FantInvBoard" class='LeftMenu'></a></td></tr>";
				}
			else
				{
					echo "<a href='autoinstalliboardnotice.php' class='LeftMenu'><cpanel langprint="FantInvBoard"></a></td></tr>";
				}
			}
		}
	}
?>

<!-- End Invision Board routine -->

<!-- End Boards routine -->



<!-- Begin Other routine -->

<?
$IS_OTHER=0;
$DEPOT_OTHER[]=$DEPOT_PATH."shop";
$DEPOT_OTHER[]=$DEPOT_PATH."gallery";
$DEPOT_OTHER[]=$DEPOT_PATH."auction";
$DEPOT_OTHER[]=$DEPOT_PATH."office";
$DEPOT_OTHER[]=$DEPOT_PATH."links";
$DEPOT_OTHER[]=$DEPOT_PATH."blog";
foreach($DEPOT_OTHER AS $ROOT_OTHER)
	{
	if(is_dir($ROOT_OTHER))
		{
		$IS_OTHER=1;
		}
	}
if($IS_OTHER)
	{
	?>
					<tr> 
					  <td width="10">&nbsp;</td>
					  <td width="4">&nbsp;</td>
					  <td>&nbsp;</td>
					</tr>
					<tr> 
					  <td width="10">&nbsp;</td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenuHeaders"><cpanel langprint="FantOtherScripts"></td>
					</tr>
	<?
	}

?>

<!-- Begin OS Commerce routine -->

<?

$DEPOT_SHOP[]=$DEPOT_PATH."shop";
foreach($DEPOT_SHOP AS $ROOT_SHOP)
	{
	if(is_dir($ROOT_SHOP))
		{
		$USER_ROOT_SHOP[]="<cpanel print="$homedir">/public_html/shop";
		foreach($USER_ROOT_SHOP AS $EXISTROOTSHOP)
			{
			?>
					<tr> 
					  <td width="10"><img src="images/xc_dotgrey.gif" width="10" height="12"></td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenu">
			<?
				if(is_dir($EXISTROOTSHOP))
				{
					echo "<a href='autoinstallshophome.php' class='LeftMenu'><cpanel langprint="FantOSC"></a></td></tr>";
				}
			else
				{
					echo "<a href='autoinstallshop.php' class='LeftMenu'><cpanel langprint="FantOSC"></a></td></tr>";
				}
			}
		}
	}
?>

<!-- End OS Commerce routine -->

<!-- Begin 4images routine -->

<?

$DEPOT_GALLERY[]=$DEPOT_PATH."gallery";
foreach($DEPOT_GALLERY AS $ROOT_GALLERY)
	{
			?>
					<tr> 
					  <td width="10"><img src="images/xc_dotgrey.gif" width="10" height="12"></td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenu">
			<?
	if(is_dir($ROOT_GALLERY))
		{
		$USER_ROOT_GALLERY[]="<cpanel print="$homedir">/public_html/gallery";
		foreach($USER_ROOT_GALLERY AS $EXISTROOTGALLERY)
			{
				if(is_dir($EXISTROOTGALLERY))
				{
					echo "<a href='autoinstallgalleryhome.php' class='LeftMenu'><cpanel langprint="Fant4iG"></a></td></tr>";
				}
			else
				{
					echo "<a href='autoinstallgallerynotice.php' class='LeftMenu'><cpanel langprint="Fant4iG"></a></td></tr>";
				}
			}
		}
	}
?>

<!-- End 4images routine -->

<!-- Begin PHP Auction routine -->

<?

$DEPOT_AUCTION[]=$DEPOT_PATH."auction";
foreach($DEPOT_AUCTION AS $ROOT_AUCTION)
	{
			?>
					<tr> 
					  <td width="10"><img src="images/xc_dotgrey.gif" width="10" height="12"></td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenu">
			<?
	if(is_dir($ROOT_AUCTION))
		{
		$USER_ROOT_AUCTION[]="<cpanel print="$homedir">/public_html/auction";
		foreach($USER_ROOT_AUCTION AS $EXISTROOTAUCTION)
			{
				if(is_dir($EXISTROOTAUCTION))
				{
					echo "<a href='autoinstallauctionhome.php' class='LeftMenu'><cpanel langprint="FantPHPAuction"></a></td></tr>";
				}
			else
				{
					echo "<a href='autoinstallauction.php' class='LeftMenu'><cpanel langprint="FantPHPAuction"></a></td></tr>";
				}
			}
		}
	}
?>

<!-- End PHP Auction routine -->

<!-- Begin PHProjekt routine -->

<?

$DEPOT_OFFICE[]=$DEPOT_PATH."office";
foreach($DEPOT_OFFICE AS $ROOT_OFFICE)
	{
			?>
					<tr> 
					  <td width="10"><img src="images/xc_dotgrey.gif" width="10" height="12"></td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenu">
			<?
	if(is_dir($ROOT_OFFICE))
		{
		$USER_ROOT_OFFICE[]="<cpanel print="$homedir">/public_html/office";
		foreach($USER_ROOT_OFFICE AS $EXISTROOTOFFICE)
			{
				if(is_dir($EXISTROOTOFFICE))
				{
					echo "<a href='autoinstallprojekthome.php' class='LeftMenu'><cpanel langprint="FantPHProjekt"></a></td></tr>";
				}
			else
				{
					echo "<a href='autoinstallprojekt.php' class='LeftMenu'><cpanel langprint="FantPHProjekt"></a></td></tr>";
				}
			}
		}
	}
?>

<!-- End PHProjekt routine -->

<!-- Begin phpLinks routine -->

<?

$DEPOT_LINKS[]=$DEPOT_PATH."links";
foreach($DEPOT_LINKS AS $ROOT_LINKS)
	{
			?>
					<tr> 
					  <td width="10"><img src="images/xc_dotgrey.gif" width="10" height="12"></td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenu">
			<?
	if(is_dir($ROOT_LINKS))
		{
		$USER_ROOT_LINKS[]="<cpanel print="$homedir">/public_html/links";
		foreach($USER_ROOT_LINKS AS $EXISTROOTLINKS)
			{
				if(is_dir($EXISTROOTLINKS))
				{
					echo "<a href='autoinstalllinkshome.php' class='LeftMenu'><cpanel langprint="FantPHPLinks"></a></td></tr>";
				}
			else
				{
					echo "<a href='autoinstalllinks.php' class='LeftMenu'><cpanel langprint="FantPHPLinks"></a></td></tr>";
				}
			}
		}
	}
?>

<!-- End phpLinks routine -->

<!-- Begin b2 routine -->

<?

$DEPOT_BLOG[]=$DEPOT_PATH."blog";
foreach($DEPOT_BLOG AS $ROOT_BLOG)
	{
			?>
					<tr> 
					  <td width="10"><img src="images/xc_dotgrey.gif" width="10" height="12"></td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenu">
			<?
	if(is_dir($ROOT_BLOG))
		{
		$USER_ROOT_BLOG[]="<cpanel print="$homedir">/public_html/blog";
		foreach($USER_ROOT_BLOG AS $EXISTROOTBLOG)
			{
				if(is_dir($EXISTROOTBLOG))
				{
					echo "<a href='autoinstallbloghome.php' class='LeftMenu'><cpanel langprint="Fantb2"></a></td></tr>";
				}
			else
				{
					echo "<a href='autoinstallblog.php' class='LeftMenu'><cpanel langprint="Fantb2"></a></td></tr>";
				}
			}
		}
	}
?>

<!-- End b2 routine -->

<!-- End Other routine -->



				  </table>
				</td>
				<td width="12" height="100%">&nbsp;</td>
				<td height="100%" align="center" valign="top" class="contentcell"> 
				  
