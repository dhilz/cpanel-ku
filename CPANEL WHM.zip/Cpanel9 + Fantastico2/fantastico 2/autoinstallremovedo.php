<?php
$thisapp=$removeapp;
$humanapp=str_replace("_", " ", $thisapp);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Fantastico</title>

<?php
if (is_file("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php"))
	{
	include("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php");
	}
	
if ($inxcontroller) {
?>
<cpanel include="../themeheader_subdir1.html">
<cpanel include="includes/mainmenu_icon_subdir.html">
<cpanel include="../themeheader_subdir2.html">
<cpanel include="includes/mainmenu_label.html">
<cpanel include="../themeheader_subdir3.html">

<?php
} else {
?>
<cpanel include="includes/fantasticoheader.html">

<?php
}
?>

<cpanel include="admin/adminuser.inc.php">
<cpanel include="admin/fantasticopath.inc.php">
<cpanel include="includes/adminsettingspath.inc.php">
<cpanel include="includes/restrictions.inc.php">
<cpanel include="includes/masterfilespath.inc.php">
<cpanel include="includes/sidemenu.php">


<p class="TableMiddleHead">Removing installation</p>
<p>

<!--
<cpanel Mysql="deldb($FORM{'removedb'})">
-->

The MySQL database <span class="Emphasize"><cpanel print="$FORM{'removedb'}"></span> was removed.<br />

<!--
<cpanel Mysql="deluser($FORM{'removedb'})">
-->

MySQL user <span class="Emphasize"><cpanel print="$FORM{'removedb'}"></span> was removed.<br />

<?
$doremove = $removedir;

if(is_dir($doremove)){
	$shell="rm -rf ". $doremove;
	system($shell);
    echo "<p>The directory <span class='Emphasize'>$removedir</span> was removed.";
}else{
	echo "<p class=Hint>No such directory: </b><span class='Emphasize'>".$removedir."</span>!";
}

$thisdata="<cpanel print="$homedir">/.fantasticodata/".$removeapp."/".$removeprefs;

if(is_file($thisdata)){
	$shell="rm -rf ". $thisdata;
	system($shell);
    echo "<p>The Registration Database was updated.";
}else{
	echo "<p class=Hint>Could not update registration data. Please remove manually the directory $thisdata!";
}

echo "<p>&nbsp;</p><p align=center><a href='$thispage'>Back to $removeapp overview</a>";


?>

<cpanel include="includes/fantasticofooter.html">
