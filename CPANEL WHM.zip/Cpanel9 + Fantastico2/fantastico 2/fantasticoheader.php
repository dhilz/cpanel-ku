<?
foreach($HTTP_GET_VARS AS $key => $val){
 $$key = $val;
}
foreach($HTTP_POST_VARS AS $key => $val){
 $$key = $val;
}
?>
<html>
<head>
<link rel="stylesheet" href="styles.css">
<title><cpanel print="DOMAIN"> | Fantastico Auto-installer</title>
<meta http-equiv="Content-Type" content="text/html">
<meta http-equiv="Content-Type" content="text/html">
</head>

<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
	<table width="100%" border="0" cellpadding="0" cellspacing="0" height="100%">
		<tr valign="top"> 
			<td width="75%"> 
				<p>&nbsp;</p>
				<table width="520" border="0" cellpadding="10" cellspacing="0" align="center" class="TableAll">
					<tr>
						<td align="center" class="TabRawTop"><img src="images/fantasticohead.gif" width="500" height="80">
						</td>
					</tr>
					<tr valign="top"> 
						<td>
							<table width="75%" class="MainMenuItems" align="center">
								<tr>
									<td align='center'>

