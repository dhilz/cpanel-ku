<?php
$thisapp="WebCalendar";
$thispage="autoinstallauctionhome.php";
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Fantastico</title>

<?php
if (is_file("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php"))
	{
	include("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php");
	}
	
if ($inxcontroller) {
?>
<cpanel include="../themeheader_subdir1.html">
<cpanel include="includes/mainmenu_icon_subdir.html">
<cpanel include="../themeheader_subdir2.html">
<cpanel include="includes/mainmenu_label.html">
<cpanel include="../themeheader_subdir3.html">

<?php
} else {
?>
<cpanel include="includes/fantasticoheader.html">

<?php
}
?>

<cpanel include="admin/adminuser.inc.php">
<cpanel include="admin/fantasticopath.inc.php">
<cpanel include="includes/adminsettingspath.inc.php">
<cpanel include="includes/restrictions.inc.php">
<cpanel include="includes/masterfilespath.inc.php">
<cpanel include="includes/sidemenu.php">

<?
if ($FantError)
	{
	echo $FantError;
	} else {
?>

<form action=autoinstallcheck.php method="GET">

<!--
<p align="center"><img src="fantasticoimages/webcalendar.gif" width="86" height="39">
-->
<p>
<table width=100% class='TableMiddle'>
<tr> 
<td colspan="2">
<p class="TableMiddleHead">Install <?=$humanapp ?> (1/3)</p>
</td>
</tr>
<tr>
<td valign=top>
<p><b>Where do you want to install today?</b><br>A top level directory with this name will be created during installation.</p>
</td>
<td valign=top>
<input type="text" name="installdir" size="8">
</td>
</tr>
<tr>
<td colspan="2">&nbsp;</td>
</tr>
<tr>
<td colspan="2" class="Emphasize">
<p>Admin access data</p>
</td>
</tr>
<tr>
<td valign=top>
<p>Enter an Administrator-username (you need this to enter the protected admin area)</p>
</td>
<td valign=top>
<input type="text" name="adminuser" value=admin size="8">
</td>
</tr>
<tr>
<td colspan="2">&nbsp;</td>
</tr>
<tr>
<td valign=top>
<p>Password (you need this to enter the protected admin area)</p>
</td>
<td valign=top>
<input type="password" name="password" size="8" maxlength="8">
</td>
</tr>
<tr>
<td colspan="2">&nbsp;</td>
</tr>
<tr>
<td colspan="2" class="Emphasize">
<p>Base configuration</p>
</td>
</tr>
<tr>
<td>Admin name</td>
<td>
<input type="text" name="adminname" size="22">
</td>
</tr>
<tr>
<td>Admin surname</td>
<td>
<input type="text" name="adminsurname" size="22">
</td>
</tr>
<tr>
<td>Language</td>
<td>
<select name="language">
<option value="Browser-defined">Browser-defined</option>
<option value="Chinese-Big5">Chinese (Traditonal/Big5)</option>
<option value="Chinese-GB2312">Chinese (Simplified/GB2312)</option>
<option value="Czech">Czech</option>
<option value="Danish">Danish</option>
<option value="Dutch">Dutch</option>
<option value="Galician">Galician</option>
<option value="English-US" selected>English</option>
<option value="French">French</option>
<option value="Galician">Galician</option>
<option value="German">German</option>
<option value="Hungarian">Hungarian</option>
<option value="Icelandic">Icelandic</option>
<option value="Italian">Italian</option>
<option value="Japanese">Japanese</option>
<option value="Korean">Korean</option>
<option value="Norwegian">Norwegian</option>
<option value="Polish">Polish</option>
<option value="Portuguese">Portuguese</option>
<option value="Portuguese_BR">Portuguese/Brazil</option>
<option value="Russian">Russian</option>
<option value="Spanish">Spanish</option>
<option value="Swedish">Swedish</option>
<option value="Turkish">Turkish</option>
</select>
</td>
</tr>
<tr>
<td colspan=2><b>Run cron job every 
<select name="cronminutes">
<option value="*/5">5</option>
<option value="*/10">10</option>
<option value="*/15" selected>15</option>
<option value="*/20">20</option>
<option value="*/30">30</option>
</select> minutes.</b>
<p>The cron job will automatically perform some needed tasks for example send out reminders.<br /><span class=Hint><b>Do not set this too low to avoid AUP/TOS violation.</b></span></td>
</tr>
</table>
<p align="center">
<input type="submit" name="action" value="Install <?=$humanapp ?>">
<input type="hidden" name="thisapp" value="<?=$thisapp ?>">
<input type='hidden' name='mysqluser' value='<?=$mysqluser ?>'>
<input type='hidden' name='thisfinddb' value='wcln'>
<input type='hidden' name='continuepage' value='autoinstallwebcalendardo.php'>
</p>
</form>

    <?php
}
?>


<cpanel include="includes/fantasticofooter.html">
