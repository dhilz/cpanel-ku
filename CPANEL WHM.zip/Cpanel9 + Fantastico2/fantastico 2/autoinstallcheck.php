<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Fantastico</title>

<?php
if (is_file("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php"))
	{
	include("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php");
	}
	
if ($inxcontroller) {
?>
<cpanel include="../themeheader_subdir1.html">
<cpanel include="includes/mainmenu_icon_subdir.html">
<cpanel include="../themeheader_subdir2.html">
<cpanel include="includes/mainmenu_label.html">
<cpanel include="../themeheader_subdir3.html">

<?php
} else {
?>
<cpanel include="includes/fantasticoheader.html">

<?php
}
?>

<cpanel include="admin/adminuser.inc.php">
<cpanel include="admin/fantasticopath.inc.php">
<cpanel include="includes/restrictions.inc.php">
<cpanel include="includes/masterfilespath.inc.php">
<cpanel include="includes/sidemenu.php">
<cpanel include="includes/mysqlconfig.php">

<p align="center">
<table class='TableMiddle' align="center">
<tr> 
<td>
<p class="TableMiddleHead">Install <?=$thisapp ?> (2/3)</p>
</td>
</tr>
<tr>
<td>

<?php
$SQLPass=MakeSQLPass();

$thisuser = str_replace("-","","<cpanel print="$user">");
$userdata='<cpanel print="$homedir">/.fantasticodata';
$userroot = "<cpanel print="$homedir">/public_html";
$scriptpath = "<cpanel print="$homedir">/public_html/$installdir";

if (is_dir($scriptpath)) {
		$thiserror = "- This directory already exists or the directory field is empty<br />";
}

if (strlen(str_replace("/","",$installdir))!=strlen($installdir)) {
		$thiserror .="- No valid directory name provided.<br />";
}

if ((strlen($adminuser)==0) && ($thisapp!="Moodle")) {
		$thiserror .="- No valid administrator username provided.<br />";
}

if ((strlen($password)==0) && ($thisapp!="Moodle")) {
		$thiserror .="- No password provided.<br />";
}

if ((strlen($socketuser)==0) && ($thisapp=="PHPlist")) {
		$thiserror .="- No e-mail account username provided.<br />";
}

if ((strlen($socketpass)==0) && ($thisapp=="PHPlist")) {
		$thiserror .="- No e-mail account password provided.<br />";
}

if ((strlen($socketserver)==0) && ($thisapp=="PHPlist")) {
		$thiserror .="- No POP/SMTP server provided.<br />";
}


if ($thiserror) {
echo "<p class=Hint><b>Non valid information detected:</b><br />" . $thiserror ."<p>Please hit 'Back' and correct the error(s).</p>";
} else {

		mysql_connect("$MYSQLHOST", "$REMOTE_USER", "$REMOTE_PASSWORD") or die(mysql_error()); 
		$dbcounter=0;
		$db_check = $thisuser . "_" . $thisfinddb . $dbcounter;
		do
			{
			$dbcounter++;
			$db_check = $thisuser . "_" . $thisfinddb . $dbcounter;
			}
		while (mysql_select_db("$db_check"));
		$thismakedb = $thisfinddb . $dbcounter;

		if ($thisapp=="Moodle" || $thisapp=="WebCalendar")
			{
?>
				<cpanel include="includes/findcrons.php">
<?php
			}

		echo "<p>The MySQL database and MySQL user <b>$db_check</b> will be created and used for this installation. The directory you have selected can be created. <p>Click on 'Finish installation' to continue.";
		echo "<p>&nbsp;</p>";
		echo "
		<form action=$continuepage method='GET'>
		<p align='center'>
		<input type='submit' name='submit' value='Finish installation'>
		<input type='hidden' name='SQLPass' value='$SQLPass'>
		<input type='hidden' name='adminuser' value='$adminuser'>
		<input type='hidden' name='adminemail' value='$adminemail'>
		<input type='hidden' name='adminname' value='$adminname'>
		<input type='hidden' name='adminnickname' value='$adminnickname'>
		<input type='hidden' name='adminsurname' value='$adminsurname'>
		<input type='hidden' name='allowcomments' value='$allowcomments'>
		<input type='hidden' name='articlecount' value='$articlecount'>
		<input type='hidden' name='articlecounthome' value='$articlecounthome'>
		<input type='hidden' name='backendtitle' value='$backendtitle'>
		<input type='hidden' name='begindate' value='$begindate'>
		<input type='hidden' name='company' value='$company'>
		<input type='hidden' name='connect' value='$db_check'>
		<input type='hidden' name='description' value='$description'>
		<input type='hidden' name='dob' value='$dob'>
		<input type='hidden' name='email' value='$email'>
		<input type='hidden' name='emailsignature' value='$emailsignature'>
		<input type='hidden' name='firsthour' value='$firsthour'>
		<input type='hidden' name='footer' value='$footer'>
		<input type='hidden' name='from' value='$from'>
		<input type='hidden' name='installdir' value='$installdir'>
		<input type='hidden' name='keywords' value='$keywords'>
		<input type='hidden' name='language' value='$language'>
		<input type='hidden' name='lasthour' value='$lasthour'>
		<input type='hidden' name='maxuploadsize' value='$maxuploadsize'>
		<input type='hidden' name='multilingual' value='$multilingual'>
		<input type='hidden' name='mysqldb' value='$db_check'>
		<input type='hidden' name='mysqluser' value='$db_check'>
		<input type='hidden' name='newcanblog' value='$newcanblog'>
		<input type='hidden' name='newcanregister' value='$newcanregister'>
		<input type='hidden' name='notify' value='$notify'>
		<input type='hidden' name='oldarticlecount' value='$oldarticlecount'>
		<input type='hidden' name='owner' value='$owner'>
		<input type='hidden' name='password' value='$password'>
		<input type='hidden' name='pause' value='$pause'>
		<input type='hidden' name='reminder' value='$reminder'>
		<input type='hidden' name='rtsallowed' value='$rtsallowed'>
		<input type='hidden' name='rtsemail' value='$rtsemail'>
		<input type='hidden' name='rtssupport' value='$rtssupport'>
		<input type='hidden' name='scriptpath' value='$scriptpath'>
		<input type='hidden' name='sendemail' value='$sendemail'>
		<input type='hidden' name='sex' value='$sex'>
		<input type='hidden' name='shopname' value='$shopname'>
		<input type='hidden' name='sitename' value='$sitename'>
		<input type='hidden' name='slogan' value='$slogan'>
		<input type='hidden' name='smalldescription' value='$smalldescription'>
		<input type='hidden' name='ssl' value='$ssl'>
		<input type='hidden' name='sslserver' value='$sslserver'>
		<input type='hidden' name='state' value='$state'>
		<input type='hidden' name='subtitle' value='$subtitle'>
		<input type='hidden' name='suburb' value='$suburb'>
		<input type='hidden' name='thisapp' value='$thisapp'>
		<input type='hidden' name='thismakedb' value='$thismakedb'>
		<input type='hidden' name='title' value='$title'>
		<input type='hidden' name='ultramode' value='$ultramode'>
		<input type='hidden' name='useflags' value='$useflags'>
		<input type='hidden' name='userdata' value='$userdata'>
		<input type='hidden' name='vat' value='$vat'>
		<input type='hidden' name='socketuser' value='$socketuser'>
		<input type='hidden' name='socketpass' value='$socketpass'>
		<input type='hidden' name='socketserver' value='$socketserver'>

		<input type='hidden' name='bouncetreshold' value='$bouncetreshold'>
		<input type='hidden' name='maxlists' value='$maxlists'>
		<input type='hidden' name='criterias' value='$criterias'>
		<input type='hidden' name='attach' value='$attach'>

		<input type='hidden' name='userrootpath' value='<cpanel print="$homedir">/public_html/'>
		<input type='hidden' name='protectdir' value='$scriptpath/admin'>
		<input type='hidden' name='protected'  value='1'>
		<input type='hidden' name='linksadminfolder' value='admin'>
		<input type='hidden' name='linksresname' value='phpLinks Administration'>
		<input type='hidden' name='oscadminfolder' value='admin'>
		<input type='hidden' name='oscresname' value='OS Commerce Administration'>
		$findcrons
		</p>
		</form>
		";
	}

function MakeSQLPass() {
	$ThisSQLPass = "";
	for ($index = 1; $index <= 12; $index++) 
		{
		$RandomNumber = rand(1, 62);
		if ($RandomNumber < 11) 
			{
			$ThisSQLPass .= chr($RandomNumber + 48 - 1);
			} 
			else if ($RandomNumber < 37) 
			{
				$ThisSQLPass .= chr($RandomNumber + 65 - 10);
			} 
			else 
			{
				$ThisSQLPass .= chr($RandomNumber + 97 - 36);
			}
		}
	return $ThisSQLPass;
	}

?>

	  </td>
	</tr>
</table>
<cpanel include="includes/fantasticofooter.html">
