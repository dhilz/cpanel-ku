FANTASTICO installation guide and copyright notice

!!! Ignore the INSTALLATION GUIDE if you use Fantastico in combination with XController !!!


You need an account with about 100 MB free space in order to get the master files. The first user who will log into the admin area of Fantastico will be the administrator and can manage all aspects of it. This account must use a theme that has access to Fantastico.

You may use an existing account, your master account, an account devoted to manage Fantastico or whatever account you like.

--- INSTALLATION GUIDE ---

If you are a reseller, then steps 1-4 must be done by the server owner (root). A reseller does not have enough rights for these operations. All further configuration and updates will be done by you.



1) Upload fantastico.tgz to a non web-accessible area of your server (eg: place it into /home/ANYUSER/. Upload in BINARY mode.



2) Telnet to your server (log in as root)

		cd /home/some_user/
		tar xzpf fantastico.tgz

(Replace the word "some_user" above with the real username.
Example: cd /home/admin/)



3) Change the owner of the fantastico files to the user that will be the administrator:

		chown -R some_user.some_user fantastico 

(Replace the words "some_user" above with the real username.
Example: chown -R admin.admin fantastico)



4) Move Fantastico into a theme's directory.

To move it into bluelagoon:
		mv /home/some_user/fantastico /usr/local/cpanel/base/frontend/bluelagoon/

To move it into Xskin:
		mv /home/some_user/fantastico /usr/local/cpanel/base/frontend/Xskin/

To move it into coolbreeze:
		mv /home/some_user/fantastico /usr/local/cpanel/base/frontend/coolbreeze/

Coolbreeze (as of version of April 25th 2003) and XController will automatically detect Fantastico and link to it. Other skins will need a symlink to the Fantastico directory and a HTML-link to this symlink (for example create into the theme's directory a symlink named "fantastico" and pointing to the original Fantastico directory. Now add to your skin a HTML-link to ./fantastico/index.php if you didn't modify the name or to ./your_name/index.php if you did modify the name.)

You are done with installation.



--- SETUP ---

DO NOT DO THIS UNLESS THE OWNER OF THE FANTASTICO FILES HAS CHANGED (chown command in step 3)

Log into CPanel of the user who owns fantastico and will manage it (the
"some_user" above). In the URL field of your browser change index.html to
fantastico/admin/admin.php and hit the "Enter" key.

You are now the admin.

Fantastico will inform you that all paths are setup and will ask you to wget the applications' tarballs. Click on the link and Fantastico will get the master tarball, untar it and place the master files where they are expected.

You are done with setup.

You can revisit the admin panel whenever you like by going to Fantastico and clicking on the "Admin Area" link (visible only by you). 



--- OPTIONS ---

You can use the admin panel to:
- wget the latest master tarball
- wget the latest single application tarball
- enable or disable any specific applications
- enable or disable Fantastico (this will just inform the end -user that Fantastico is currently disabled)

- You may restrict usage to specific resellers' accounts or exclude specific resellers' accounts from using Fantastico.

- You may restrict usage to specific hosting plans or exclude specific hosting plans from using Fantastico.

- You may add users to a prohibit list (no matter if other reseller or plan conditions are met) or you may enable specific users no matter if other restrictions apply

(all 3 limitations methods can be used either or. You can't use both enabled and disabled users for example)

- By default every user, every reseller's users and all plans are allowed to use Fantastico.

- You can also change the directory name where fantastico resides. It will rename the directory and will setupp the paths to reflect your changes (Menu "Setup").

- You can enable or disable PHPsuexec (which will chmod all files to 600 or restore original permissions). I don't know however if applications really work with phpsuexec then. Let me know if it does or not or what the correct permissions are (Menu "Setup").

- And last but not least you can update the core fantastico files using fantastico admin panel itself. 




--- Remote MySQL host / mysql ---


- If you use a remote MySQL host, open the file fantastico/includes/mysqlconfig.php and edit the line
$MYSQLHOST="localhost";

Replace localhost with the IP or hostname of your MySQL server.
add

<cpanel Mysql="addhost(192.168.1.%)">
(replace with the IP of your server) AFTER the line containing "?>"

- If you try to install applications and get a "mysql: command or file not found" error, edit the line
$MYSQLPATH="mysql";

and replace mysql with the full path to mysql (for example /usr/local/bin/mysql).



--- COPYRIGHT NOTICE---

Please notice that while some Open Source applications are free, the Fantastico installer is a commercial copyrighted software.

No redistribution allowed even of modified code.

If you install it on more than 1 servers, then you need additional licenses. Please support the development of software by using it legally.  

copyright 2002 & 2003 Ilias Moisidis, support@cpanelthemes.com
http://cpanelthemes.com

I wish you fun with Fantastico AND success with your business!

Ilias Moisidis
CPanelthemes
