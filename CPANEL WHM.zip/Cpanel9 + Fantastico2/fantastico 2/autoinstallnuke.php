<?php
$thisapp="PHP-Nuke";
$humanapp=str_replace("_", " ", $thisapp);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Fantastico</title>

<?php
if (is_file("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php"))
	{
	include("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php");
	}
	
if ($inxcontroller) {
?>
<cpanel include="../themeheader_subdir1.html">
<cpanel include="includes/mainmenu_icon_subdir.html">
<cpanel include="../themeheader_subdir2.html">
<cpanel include="includes/mainmenu_label.html">
<cpanel include="../themeheader_subdir3.html">

<?php
} else {
?>
<cpanel include="includes/fantasticoheader.html">

<?php
}
?>

<cpanel include="admin/adminuser.inc.php">
<cpanel include="admin/fantasticopath.inc.php">
<cpanel include="includes/adminsettingspath.inc.php">
<cpanel include="includes/restrictions.inc.php">
<cpanel include="includes/masterfilespath.inc.php">
<cpanel include="includes/sidemenu.php">

<?
if ($FantError)
	{
	echo $FantError;
	} else {
?>

<form action=autoinstallcheck.php method="GET">

<p align="center"><img src="fantasticoimages/phpnuke.gif" width="335" height="81">
<p>
<table width=100% class='TableMiddle'>
<tr> 
<td colspan="2">
<p class="TableMiddleHead">Install <?=$humanapp ?> (1/3)</p>
</td>
</tr>
<tr>
<td valign=top>
<p><b>Where do you want to install today?</b><br>A top level directory with this name will be created during installation.</p>
</td>
<td valign=top>
<input type="text" name="installdir" size="8">
</td>
</tr>
<tr>
<td colspan="2">&nbsp;</td>
</tr>
<tr>
<td colspan="2" class="Emphasize">
<p>Admin access data</p>
</td>
</tr>
<tr>
<td valign=top>
<p>Administrator-username (you need this to enter the protected admin area)</p>
</td>
<td valign=top>
<input type="text" name="adminuser" size="8" maxlength="8">
</td>
</tr>
<tr>
<td colspan="2">&nbsp;</td>
</tr>
<tr>
<td valign=top>
<p>Password (you need this to enter the protected admin area)</p>
</td>
<td valign=top>
<input type="password" name="password" size="8" maxlength="8">
</td>
</tr>
<tr>
<td colspan="2">&nbsp;</td>
</tr>
<tr>
<td colspan="2" class="Emphasize">
<p>Base configuration</p>
</td>
</tr>
<tr>
<td>Site name</td>
<td>
<input type="text" name="sitename" size="22" value="<cpanel print="DOMAIN">">
</td>
</tr>
<tr>
<td>Your site's slogan</td>
<td>
<input type="text" name="title" size="22">
</td>
</tr>
<tr>
<td>Start date of the site</td>
<td>
<input type="text" name="begindate" size="22">
</td>
</tr>
<tr>
<td>Admin e-mail (your email address)</td>
<td>
<input type="text" name="adminemail" size="22" value="<cpanel print="$user">@<cpanel print="DOMAIN">">
</td>
</tr>
<tr>
<td>How many stories to display in main page</td>
<td>
<input type="text" name="articlecount" size="6" value="10">
</td>
</tr>
<tr>
<td>How many stories to display in Old Articles box</td>
<td>
<input type="text" name="oldarticlecount" size="6" value="10">
</td>
</tr>
<tr>
<td>Footer (HTML allowed). Enter the text you want to display on the bottom of every page.</td>
<td>
<textarea name="footer" cols="22" wrap="VIRTUAL" rows="8">Enter your copyright notice or anything that should display on every page. HTML is allowed.</textarea>
</td>
</tr>
<tr>
<td>Activate Ultramode plain text file backend syndication</td>
<td>
<select name="ultramode">
<option value="1" selected>Yes</option>
<option value="0">No</option>
</select>
</td>
</tr>
<tr>
<td>Title for Ultramode backend</td>
<td>
<input type="text" name="backendtitle" size="22">
</td>
</tr>
<tr>
<td>Send new stories to admin</td>
<td>
<select name="sendemail">
<option value="1" selected>Yes</option>
<option value="0">No</option>
</select>
</td>
</tr>
    <tr>
	  <td>Preferred Language
	  </td>
	  <td>
		<select name="language">
		  <option value="albanian">Albanian</option>
		  <option value="arabic">Arabic</option>
		  <option value="brazilian">Brazilian</option>
		  <option value="catala">Catala</option>
		  <option value="chinese">Chinese</option>
		  <option value="czech">Czech</option>
		  <option value="danish">Danish</option>
		  <option value="dutch">Dutch</option>
		  <option value="english" selected>English</option>
		  <option value="euskara">Euskara</option>
		  <option value="finnish">Finnish</option>
		  <option value="french">French</option>
		  <option value="galego">Galego</option>
		  <option value="german">German</option>
		  <option value="greek">Greek</option>
		  <option value="hungarian">Hungarian</option>
		  <option value="icelandic">Icelandic</option>
		  <option value="indonesian">Indonesian</option>
		  <option value="italian">Italian</option>
		  <option value="macedonian">Macedonian</option>
		  <option value="norwegian">Norwegian</option>
		  <option value="polish">Polish</option>
		  <option value="portuguese">Portuguese</option>
		  <option value="romanian">Romanian</option>
		  <option value="russian">Russian</option>
		  <option value="slovak">Slovak</option>
		  <option value="slovenian">Slovenian</option>
		  <option value="spanish">Spanish</option>
		  <option value="swedish">Swedish</option>
		  <option value="thai">Thai</option>
		  <option value="turkish">Turkish</option>
		  <option value="ukrainian">Ukrainian</option>
		  <option value="vietnamese">Vietnamese</option>
		</select>
	  </td>
	</tr>
<tr>
<td colspan=2><span class='Hint'><b>ATTENTION:</b></span> In the admin panel of PHP-Nuke you will have the option to select additional languages. If you select any language other than the ones listed here, PHP will quit with "Fatal Error" warnings since some modules (Forums, Journal, Webmail) do not include the necessary language files. If you need one of the additional languages, you must add the language files for these 3 modules before switching or your site will not be operational!
</td>
</tr>
<tr>
<td>Activate multilingual features</td>
<td>
<select name="multilingual">
<option value="1" selected>Yes</option>
<option value="0">No</option>
</select>
</td>
</tr>
<tr>
<td>Show Flags for language menu</td>
<td>
<select name="useflags">
<option value="1">Yes</option>
<option value="0" selected>No</option>
</select>
</td>
</tr>

<tr>
<td>Allow unregistered users to post comments</td>
<td>
<select name="allowcomments">
<option value="0">Yes</option>
<option value="1" selected>No</option>
</select>
</td>
</tr>
</table>
<p align="center">
<input type="submit" name="action" value="Install <?=$humanapp ?>">
<input type="hidden" name="thisapp" value="<?=$thisapp ?>">
<input type='hidden' name='mysqluser' value='<?=$mysqluser ?>'>
<input type='hidden' name='thisfinddb' value='nuke'>
<input type='hidden' name='continuepage' value='autoinstallnukedo.php'>
</p>
</form>

    <?php
}
?>

<cpanel include="includes/fantasticofooter.html">
