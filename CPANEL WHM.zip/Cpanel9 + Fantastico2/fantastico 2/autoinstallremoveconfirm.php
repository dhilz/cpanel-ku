<?php
$thisapp=$removeapp;
$humanapp=str_replace("_", " ", $thisapp);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Fantastico</title>

<?php
if (is_file("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php"))
	{
	include("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php");
	}
	
if ($inxcontroller) {
?>
<cpanel include="../themeheader_subdir1.html">
<cpanel include="includes/mainmenu_icon_subdir.html">
<cpanel include="../themeheader_subdir2.html">
<cpanel include="includes/mainmenu_label.html">
<cpanel include="../themeheader_subdir3.html">

<?php
} else {
?>
<cpanel include="includes/fantasticoheader.html">

<?php
}
?>

<cpanel include="admin/adminuser.inc.php">
<cpanel include="admin/fantasticopath.inc.php">
<cpanel include="includes/adminsettingspath.inc.php">
<cpanel include="includes/restrictions.inc.php">
<cpanel include="includes/masterfilespath.inc.php">
<cpanel include="includes/sidemenu.php">

<p class="TableMiddleHead">Last warning!</p>
<p>The directory <span class="BoldText"><cpanel print="$homedir">/public_html/<?php echo "$removedir" ?></span>, and the MySQL database and MySQL user named <span class="BoldText"><?php echo "$removedb" ?></span> will be deleted. 
<p><span class="Hint">You can't undo this! Click on <span class="BoldText">Remove <?=$humanapp ?>
</span> to proceed.</span>
<p align='center'>
<form action="autoinstallremovedo.php" method="GET">
<input type='hidden' name='removedir' value='<cpanel print="$homedir">/public_html/<?php echo "$removedir" ?>'>
<input type='hidden' name='removeprefs' value='<?php echo "$removedir" ?>'>
<input type='hidden' name='removedb' value='<?php echo "$removedb" ?>'>
<input type='hidden' name='thispage' value='<?php echo "$thispage" ?>'>
<input type='hidden' name='removeapp' value='<?php echo "$removeapp" ?>'>
<input type='submit' name='submit' value='Remove <?php echo "$humanapp" ?>'>
</form>

<cpanel include="includes/fantasticofooter.html">
