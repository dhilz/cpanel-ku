<?php
$thisapp="pMachine_Free";
$humanapp=str_replace("_", " ", $thisapp);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Fantastico</title>

<?php
if (is_file("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php"))
	{
	include("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php");
	}
	
if ($inxcontroller) {
?>
<cpanel include="../themeheader_subdir1.html">
<cpanel include="includes/mainmenu_icon_subdir.html">
<cpanel include="../themeheader_subdir2.html">
<cpanel include="includes/mainmenu_label.html">
<cpanel include="../themeheader_subdir3.html">

<?php
} else {
?>
<cpanel include="includes/fantasticoheader.html">

<?php
}
?>

<cpanel include="admin/adminuser.inc.php">
<cpanel include="admin/fantasticopath.inc.php">
<cpanel include="includes/adminsettingspath.inc.php">
<cpanel include="includes/restrictions.inc.php">
<cpanel include="includes/masterfilespath.inc.php">
<cpanel include="includes/sidemenu.php">


<script language="JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function YY_checkform() { //v4.66
//copyright (c)1998,2002 Yaromat.com
  var args = YY_checkform.arguments; var myDot=true; var myV=''; var myErr='';var addErr=false;var myReq;
  for (var i=1; i<args.length;i=i+4){
    if (args[i+1].charAt(0)=='#'){myReq=true; args[i+1]=args[i+1].substring(1);}else{myReq=false}
    var myObj = MM_findObj(args[i].replace(/\[\d+\]/ig,""));
    myV=myObj.value;
    if (myObj.type=='text'||myObj.type=='password'||myObj.type=='hidden'){
      if (myReq&&myObj.value.length==0){addErr=true}
      if ((myV.length>0)&&(args[i+2]==1)){ //fromto
        var myMa=args[i+1].split('_');if(isNaN(myV)||myV<myMa[0]/1||myV > myMa[1]/1){addErr=true}
      } else if ((myV.length>0)&&(args[i+2]==2)){
          var rx=new RegExp("^[\\w\.=-]+@[\\w\\.-]+\\.[a-z]{2,4}$");if(!rx.test(myV))addErr=true;
      } else if ((myV.length>0)&&(args[i+2]==3)){ // date
        var myMa=args[i+1].split("#"); var myAt=myV.match(myMa[0]);
        if(myAt){
          var myD=(myAt[myMa[1]])?myAt[myMa[1]]:1; var myM=myAt[myMa[2]]-1; var myY=myAt[myMa[3]];
          var myDate=new Date(myY,myM,myD);
          if(myDate.getFullYear()!=myY||myDate.getDate()!=myD||myDate.getMonth()!=myM){addErr=true};
        }else{addErr=true}
      } else if ((myV.length>0)&&(args[i+2]==4)){ // time
        var myMa=args[i+1].split("#"); var myAt=myV.match(myMa[0]);if(!myAt){addErr=true}
      } else if (myV.length>0&&args[i+2]==5){ // check this 2
            var myObj1 = MM_findObj(args[i+1].replace(/\[\d+\]/ig,""));
            if(myObj1.length)myObj1=myObj1[args[i+1].replace(/(.*\[)|(\].*)/ig,"")];
            if(!myObj1.checked){addErr=true}
      } else if (myV.length>0&&args[i+2]==6){ // the same
            var myObj1 = MM_findObj(args[i+1]);
            if(myV!=myObj1.value){addErr=true}
      }
    } else
    if (!myObj.type&&myObj.length>0&&myObj[0].type=='radio'){
          var myTest = args[i].match(/(.*)\[(\d+)\].*/i);
          var myObj1=(myObj.length>1)?myObj[myTest[2]]:myObj;
      if (args[i+2]==1&&myObj1&&myObj1.checked&&MM_findObj(args[i+1]).value.length/1==0){addErr=true}
      if (args[i+2]==2){
        var myDot=false;
        for(var j=0;j<myObj.length;j++){myDot=myDot||myObj[j].checked}
        if(!myDot){myErr+=args[i+3]+'\n'}
      }
    } else if (myObj.type=='checkbox'){
      if(args[i+2]==1&&myObj.checked==false){addErr=true}
      if(args[i+2]==2&&myObj.checked&&MM_findObj(args[i+1]).value.length/1==0){addErr=true}
    } else if (myObj.type=='select-one'||myObj.type=='select-multiple'){
      if(args[i+2]==1&&myObj.selectedIndex/1==0){addErr=true}
    }else if (myObj.type=='textarea'){
      if(myV.length<args[i+1]){addErr=true}
    }
    if (addErr){myErr+=args[i+3]+'\n'; addErr=false}
  }
  if (myErr!=''){alert(myErr)}
  document.MM_returnValue = (myErr=='');
}
//-->
</script>

  <p align="center"><img src="fantasticoimages/pmachine.gif" width="128" height="22">
  <p>
  <table width=100% class='TableMiddle'>
	<tr> 
	  <td>
		<p class="TableMiddleHead">Please notice:</p>
	  </td>
	</tr>
	<tr>
	  <td>&nbsp;</td>
	</tr>
	<tr>
	  <td>
		<p>pMachine Free is available for personal, non-commercial use only.
<p>It is NOT permissible to use pMachine Free in or in conjunction with a commercial, or for-profit endeavor. 
<p>Individuals or other agencies being compensated  for professional services related to the installation or use of pMachine  (i.e. web developers acting on behalf of clients) must purchase a commercial license.
<p>Please read the license carefully. 
<p>&nbsp;</p>
<p>THIS LICENSE IS AN AGREEMENT BETWEEN YOU AND PMACHINE.COM FOR THE USE OF PMACHINE SOFTWARE.  BY DOWNLOADING PMACHINE SOFTWARE, YOU AGREE TO BE BOUND BY THE TERMS AND CONDITIONS OF THIS LICENSE.  PMACHINE RESERVES THE RIGHT TO ALTER THIS AGREEMENT AT ANY TIME, FOR ANY REASON, WITHOUT NOTICE.
<p>Revised on: 9 February, 2003
<p>PERMITTED USE: You may install and use ONE copy of pMachine Free for ONE website, residing on ONE server. pMachine Free may be used for personal, non-commercial use only.   Websites engaging in direct, or indirect commercial activities are prohibited from using pMachine Free. pMachine.com will be the sole arbiter as-to what constitutes commercial activities.
<p>RESTRICTIONS:
<p>Unless you have been granted prior, written consent from pMachine, you may NOT:
<p>- reproduce, distribute or transfer pMachine software, or portions thereof, to any third party. 
<p>- sell, rent, lease, assign, or sublet the software or portions thereof, nor grant rights to any other person. 
<p>- sell, or profit from third-party software that interfaces with, extends, or enhances pMachine software. 
<p>- use pMachine software in violation of any U.S. or international law or regulation.
<p>DISPLAY OF COPYRIGHT NOTICES: pMachine Free users MUST display at least one "powered by pMachine" credit giving banner, or text credit on the main page of their publicly viewable site.  This banner may be downloaded from pMachine.com, or created by the license holder.  All copyright and proprietary notices and logos in the control panel and within the scripts must remain intact.
<p>SOFTWARE MODIFICATION:  License holders may alter or modify the software for their own use, but may NOT resell, redistribute or transfer the modified, or derivative version without prior written consent from pMachine. Components from this software may not be extracted and used in other programs without prior written consent from pMachine.
<p>TECHNICAL SUPPORT: Technical support is NOT provided for pMachine Free, however users are allowed to participate in the online support forum.
<p>INDEMNITY: You agree to indemnify and hold harmless pMachine for any third-party claims, actions or suits, as well as any related expenses, liabilities, damages, settlements or fees arising from your use or misuse of the software, or a violation of any terms of this license.
<p>DISCLAIMER OF WARRANTY: THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, WARRANTIES OF QUALITY, PERFORMANCE, NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.  FURTHER, PMACHINE DOES NOT WARRANT THAT THE SOFTWARE OR ANY RELATED SERVICE WILL ALWAYS BE AVAILABLE.
<p>LIMITATIONS OF LIABILITY: YOU ASSUME ALL RISK ASSOCIATED WITH THE INSTALLATION AND USE OF THE SOFTWARE. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS OF PMACHINE SOFTWARE BE LIABLE FOR CLAIMS, DAMAGES OR OTHER LIABILITY ARISING FROM, OUT OF, OR IN CONNECTION WITH THE SOFTWARE.  LICENSE HOLDERS ARE SOLELY RESPONSIBLE FOR DETERMINING THE APPROPRIATENESS OF USE AND ASSUME ALL RISKS ASSOCIATED WITH ITS USE, INCLUDING BUT NOT LIMITED TO THE RISKS OF PROGRAM ERRORS, DAMAGE TO EQUIPMENT, LOSS OF DATA OR SOFTWARE PROGRAMS, OR UNAVAILABILITY OR INTERRUPTION OF OPERATIONS.</p>
<form action="autoinstallpmachine.php" method="GET" onSubmit="YY_checkform('form1','agreed','#q','1','You must accept the License in order to proceed!');return document.MM_returnValue">
		<p align="center">
		<input type="checkbox" name="agreed" value="checkbox">
		I accept the above Terms of Use</p>
		<p align="center">
			<input type=hidden name=thisapp value="pMachine_Free">
			<input type=hidden name=thispage value="autoinstallpmachinehome.php">
			<input type="submit" name="submit" value="Continue with the installation">
		</p>
</form>
		<p align="center"><a href="https://secure.pmachine.com/" target="_blank">Purchase a pMachine Pro license or a license for commercial/profit use</a></p>
	  </td>
	</tr>
  </table>


<cpanel include="includes/fantasticofooter.html">
