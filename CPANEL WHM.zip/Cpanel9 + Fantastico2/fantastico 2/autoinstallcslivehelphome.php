<?php
$thisapp="CS_Live_Help";
$thispage="autoinstallcslivehelphome.php";
$humanapp=str_replace("_", " ", $thisapp);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Fantastico</title>

<?php
if (is_file("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php"))
	{
	include("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php");
	}
	
if ($inxcontroller) {
?>
<cpanel include="../themeheader_subdir1.html">
<cpanel include="includes/mainmenu_icon_subdir.html">
<cpanel include="../themeheader_subdir2.html">
<cpanel include="includes/mainmenu_label.html">
<cpanel include="../themeheader_subdir3.html">

<?php
} else {
?>
<cpanel include="includes/fantasticoheader.html">

<?php
}
?>

<cpanel include="admin/adminuser.inc.php">
<cpanel include="admin/fantasticopath.inc.php">
<cpanel include="includes/adminsettingspath.inc.php">
<cpanel include="includes/restrictions.inc.php">
<cpanel include="includes/masterfilespath.inc.php">
<cpanel include="includes/sidemenu.php">

<p align="center"><img src="fantasticoimages/cslivehelp.gif" width="134" height="51">
<p align=center>
<table class="MainMenuItems" align="center">
<tr> 
<td>
<p>
<a href='autoinstallcslivehelp.php'>New installation</a>
<?
if (is_file($DEPOT . $thisapp . "/fantversion.php"))
	{
	include($DEPOT . $thisapp . "/fantversion.php");
	echo " (" . $version . ")";
	}
?>	
<p>
<a href='http://www.craftysyntax.com/livehelp/' target='_blank'><?=$humanapp ?> homepage</a>
<p><br><span class='Hint'><b>Current installations:</b></span>
<cpanel include="includes/findinstalls.php">
</td>
</tr>
</table>

<cpanel include="includes/fantasticofooter.html">
