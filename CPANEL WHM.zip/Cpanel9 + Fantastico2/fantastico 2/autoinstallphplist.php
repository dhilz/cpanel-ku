<?php
$thisapp="PHPlist";
$humanapp=str_replace("_", " ", $thisapp);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Fantastico</title>

<?php
if (is_file("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php"))
	{
	include("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php");
	}
	
if ($inxcontroller) {
?>
<cpanel include="../themeheader_subdir1.html">
<cpanel include="includes/mainmenu_icon_subdir.html">
<cpanel include="../themeheader_subdir2.html">
<cpanel include="includes/mainmenu_label.html">
<cpanel include="../themeheader_subdir3.html">

<?php
} else {
?>
<cpanel include="includes/fantasticoheader.html">

<?php
}
?>

<cpanel include="admin/adminuser.inc.php">
<cpanel include="admin/fantasticopath.inc.php">
<cpanel include="includes/adminsettingspath.inc.php">
<cpanel include="includes/restrictions.inc.php">
<cpanel include="includes/masterfilespath.inc.php">
<cpanel include="includes/sidemenu.php">

<?
if ($FantError)
	{
	echo $FantError;
	} else {
?>

<form action=autoinstallcheck.php method="GET">

<p align="center"><img src="fantasticoimages/phplist.gif" width="88" height="31">
<p>
<table width=100% class='TableMiddle'>
<tr> 
<td colspan="2">
<p class="TableMiddleHead">Install <?=$humanapp ?> (1/3)</p>
</td>
</tr>
<tr>
<td valign=top>
<p><b>Where do you want to install today?</b><br>A top level directory with this name will be created during installation.</p>
</td>
<td valign=top>
<input type="text" name="installdir" size="8">
</td>
</tr>
<tr>
<td colspan="2">&nbsp;</td>
</tr>
<tr>
<td colspan="2" class="Emphasize">
<p>Admin access data</p>
</td>
</tr>
<tr>
<td valign=top>
<p>Administrator-username (you need this to enter the protected admin area)</p>
</td>
<td valign=top>
<input type="text" name="adminuser" size="8" maxlength="8">
</td>
</tr>
<tr>
<td colspan="2">&nbsp;</td>
</tr>
<tr>
<td valign=top>
<p>Password (you need this to enter the protected admin area)</p>
</td>
<td valign=top>
<input type="password" name="password" size="8" maxlength="8">
</td>
</tr>
<tr>
<td colspan="2">&nbsp;</td>
</tr>
<tr>
<td colspan="2" class="Emphasize">
<p>Base configuration</p>
</td>
</tr>

<td>How many bounces in a row need to have occurred for a user to be marked unconfirmed</td>
<td>
<input type="text" name="bouncetreshold" size="6" value="5">
</td>
</tr>

<td>How many lists can be created per administrator</td>
<td>
<input type="text" name="maxlists" size="6" value="5">
</td>
</tr>

<td>Number of criterias you want to be able to select when sending a message</td>
<td>
<input type="text" name="criterias" size="6" value="2">
</td>
</tr>

<td>Number of attachments you want to add per message (max)</td>
<td>
<input type="text" name="attach" size="6" value="2">
</td>
</tr>

<tr>
<td>Preferred Language</td>
<td>
<select name="language">
<option value="danish">Danish</option>
<option value="dutch">Dutch</option>
<option value="english" selected>English</option>
<option value="french">French</option>
<option value="german">German (Du)</option>
<option value="italian">Italian</option>
<option value="portuguese">Portuguese</option>
<option value="portuguese_pt">Portuguese (PT)</option>
<option value="spanish">Spanish</option>
<option value="swedish">Swedish</option>
<option value="turkish">Turkish</option>
</select>
</td>
</tr>

<tr>
<td colspan="2" class="Emphasize">
<p>E-mail account configuration. If you didn't create a pop account to use exclusively with PHPlist, do it now before proceeding (will be used to send emails and receive bounced messages)</p>
</td>
</tr>
<tr>
<td>E-mail account username</td>
<td>
<input type="text" name="socketuser" size="22" value="<cpanel print="$user">">
</td>
</tr>
<tr>
<td>E-mail account password</td>
<td>
<input type="text" name="socketpass" size="22" value="">
</td>
</tr>
<tr>
<td>POP/SMTP server</td>
<td>
<input type="text" name="socketserver" size="22" value="<cpanel print="DOMAIN">">
</td>
</tr>

</table>
<p align="center">
<input type="submit" name="action" value="Install <?=$humanapp ?>">
<input type="hidden" name="thisapp" value="<?=$thisapp ?>">
<input type='hidden' name='mysqluser' value='<?=$mysqluser ?>'>
<input type='hidden' name='thisfinddb' value='plst'>
<input type='hidden' name='continuepage' value='autoinstallphplistdo.php'>
</p>
</form>

    <?php
}
?>

<cpanel include="includes/fantasticofooter.html">
