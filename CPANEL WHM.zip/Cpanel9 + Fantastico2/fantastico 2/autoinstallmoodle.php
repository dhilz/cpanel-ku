<?php
$thisapp="Moodle";
$humanapp=str_replace("_", " ", $thisapp);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Fantastico</title>

<?php
if (is_file("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php"))
	{
	include("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php");
	}
	
if ($inxcontroller) {
?>
<cpanel include="../themeheader_subdir1.html">
<cpanel include="includes/mainmenu_icon_subdir.html">
<cpanel include="../themeheader_subdir2.html">
<cpanel include="includes/mainmenu_label.html">
<cpanel include="../themeheader_subdir3.html">

<?php
} else {
?>
<cpanel include="includes/fantasticoheader.html">

<?php
}
?>

<cpanel include="admin/adminuser.inc.php">
<cpanel include="admin/fantasticopath.inc.php">
<cpanel include="includes/adminsettingspath.inc.php">
<cpanel include="includes/restrictions.inc.php">
<cpanel include="includes/masterfilespath.inc.php">
<cpanel include="includes/sidemenu.php">

<?
if ($FantError)
	{
	echo $FantError;
	} else {
?>

<form action=autoinstallcheck.php method="GET">

<p align="center"><img src="fantasticoimages/moodle.gif" width="130" height="19">
<p>
<table width=100% class='TableMiddle'>
<tr> 
<td colspan="2">
<p class="TableMiddleHead">Install <?=$humanapp ?> (1/3)</p>
</td>
</tr>
<tr>
<td valign=top>
<p><b>Where do you want to install today?</b><br>A top level directory with this name will be created during installation.</p>
</td>
<td valign=top>
<input type="text" name="installdir" size="8">
</td>
</tr>
<tr> 
<td colspan="2">
&nbsp;
</td>
</tr>
<tr>
<td colspan=2><b>Run cron job every 
<select name="cronminutes">
<option value="*/5">5</option>
<option value="*/10">10</option>
<option value="*/15" selected>15</option>
<option value="*/20">20</option>
<option value="*/30">30</option>
</select> minutes.</b>
<p>The cron job will perform some needed tasks, for example, Moodle needs to check the discussion forums so it can mail out copies of posts to people who have subscribed.<br /><span class=Hint><b>Do not set this too low to avoid AUP/TOS violation.</b></span></td>
</tr>
</table>
<p align="center">
<input type="submit" name="action" value="Install <?=$humanapp ?>">
<input type="hidden" name="thisapp" value="<?=$thisapp ?>">
<input type='hidden' name='mysqluser' value='<?=$mysqluser ?>'>
<input type='hidden' name='thisfinddb' value='mdle'>
<input type='hidden' name='continuepage' value='autoinstallmoodledo.php'>
</p>
</form>

    <?php
}
?>

<cpanel include="includes/fantasticofooter.html">
