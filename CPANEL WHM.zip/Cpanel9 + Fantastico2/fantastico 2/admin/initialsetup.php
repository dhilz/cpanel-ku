<?php

if ($action=="firststep")
	{

	$myfile=@fopen($fantasticoadminpath."/fantasticopath.inc.php", "w");
	if (!($myfile))
		{
		$chownpath=realpath($fantasticopath);
		echo "<p>The permissions on the fantastico directory were not set. You must chown the Fantastico directory to be owned by user '$REMOTE_USER' using following SSH command:<p class=Hint><b>chown -R $REMOTE_USER.$REMOTE_USER $chownpath</b></p>";

		} else {

		$fp = fwrite($myfile,"<?");
		$fp = fwrite($myfile,chr(10));
		$fp = fwrite($myfile,"\$fantasticopath = \"$chownpath\";");
		$fp = fwrite($myfile,chr(10));
		$fp = fwrite($myfile,"?>");	
		fclose($myfile);
	
		$myfile = fopen($fantasticopath."/includes/masterfilespath.inc.php", "w");
		$fp = fwrite($myfile,"<?");
		$fp = fwrite($myfile,chr(10));
		$fp = fwrite($myfile,"\$DEPOT = \"<cpanel print="$homedir">/fantastico_files/\";");
		$fp = fwrite($myfile,chr(10));
		$fp = fwrite($myfile,"?>");	
		fclose($myfile);
	
		$myfile = fopen($fantasticopath."/includes/adminsettingspath.inc.php", "w");
		$fp = fwrite($myfile,"<?");
		$fp = fwrite($myfile,chr(10));
		$fp = fwrite($myfile,"\$adminsettingspath = \"<cpanel print="$homedir">/fantastico_admin_settings\";");
		$fp = fwrite($myfile,chr(10));
		$fp = fwrite($myfile,"?>");	
		fclose($myfile);
	
		$myfile = fopen("$fantasticoadminpath/fantasticodirname.inc.php", "w");
		$fp = fwrite($myfile,"<?");
		$fp = fwrite($myfile,chr(10));
		$fp = fwrite($myfile,"\$fantasticodirname = \"$fantasticodirname\";");
		$fp = fwrite($myfile,chr(10));
		$fp = fwrite($myfile,"?>");	
		fclose($myfile);
	
		if ($fantasticoadmin == "")
		{
			$myfile = fopen("$fantasticoadminpath/adminuser.inc.php", "w");
			$fp = fwrite($myfile,"<?");
			$fp = fwrite($myfile,chr(10));
			$fp = fwrite($myfile,"\$fantasticoadmin = \"$REMOTE_USER\";");
			$fp = fwrite($myfile,chr(10));
			$fp = fwrite($myfile,"?>");	
			fclose($myfile);
		}

		echo "<p class=Hint><b>All paths are setup and saved.</b><p>User <span class=Hint><b>$REMOTE_USER</b></span> is now the administrator of Fantastico. Whenever you load Fantastico, you will see an administration link. This link is not visible by regular users.<p>&nbsp;</p><p class=Hint><b>We need the applications' master files</b><p>You don't have the applications' tarballs yet. We need to get them before proceeding. A directory called <b>'<cpanel print="$homedir">/fantastico_files/'</b> will be created and inside there will reside all master application files. <span class=Hint><b>Do not remove nor rename this directory or your users will not be able to install any application!</b></span><p align=center><a href='admin.php?action=wgetall&hlmenu=setup'>Wget the master files now!</a><p>(Please wait after clicking, getting the files and unpacking the archive needs some time)";
	}
}

if ($action == "setup") {
	if ($phpsuexec == 1) {
		$is1 = "selected";
	} else {
		$is0 = "selected";
	}

?>
	<form action="admin.php">
	<input type="hidden" name="action" value="setupdo">
	<input type="hidden" name="hlmenu" value="setup">
	<p>What is the name of the Fantastico directory:<br />(plain name, not the full path, don't use any slash)<br /><b>Do not change this unless you know what you are doing and can handle modifying your skins to reflect the changed path. You may change this if you want to hide Fantastico for your clients and give away the path manually. If something goes wrong, edit the file 'admin/fantasticodirname.inc.php' to restore functionality.</b>
		<p><input type="text" name="fantasticodirnamenew" size="24" value="<?=$fantasticodirname?>">
<!--
		<tr>
		<td>MySQL host (hostname or IP):</td>
		<td><input type="text" name="mysqlhostnew" size="24" value="<?=$mysqlhost?>"></td>
		</tr>	
-->
	<p>&nbsp;</p>
	<p>PHPsuexec is:
	<p><select name="phpsuexecnew"><option value="0" <?=$is0?>>Not installed</option><option value="1" <?=$is1?>>Installed</option></select>
	<p>&nbsp;</p>
	<p align=center><input type="submit" value="Save">
	</form>
<?php
}


if ($action == "setupdo") {

	$fantasticopathold="/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/". $fantasticodirname;
	$fantasticopathnew="/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/". $fantasticodirnamenew;
	$fantasticoadminpathold=$fantasticopathold . "/admin";
	$fantasticoadminpathnew=$fantasticopathnew . "/admin";

	$myfile = fopen($fantasticoadminpathold."/fantasticopath.inc.php", "w");
	$fp = fwrite($myfile,"<?");
	$fp = fwrite($myfile,chr(10));
	$fp = fwrite($myfile,"\$fantasticopath = \"$fantasticopathnew\";");
	$fp = fwrite($myfile,chr(10));
	$fp = fwrite($myfile,"?>");	
	fclose($myfile);

	$myfile = fopen($fantasticopathold."/includes/adminsettingspath.inc.php", "w");
	$fp = fwrite($myfile,"<?");
	$fp = fwrite($myfile,chr(10));
	$fp = fwrite($myfile,"\$adminsettingspath = \"<cpanel print="$homedir">/fantastico_admin_settings\";");
	$fp = fwrite($myfile,chr(10));
	$fp = fwrite($myfile,"?>");	
	fclose($myfile);

	$myfile = fopen("$fantasticoadminpathold/fantasticodirname.inc.php", "w");
	$fp = fwrite($myfile,"<?");
	$fp = fwrite($myfile,chr(10));
	$fp = fwrite($myfile,"\$fantasticodirname = \"$fantasticodirnamenew\";");
	$fp = fwrite($myfile,chr(10));
	$fp = fwrite($myfile,"?>");	
	fclose($myfile);

	if ($fantasticodirname != $fantasticodirnamenew)
		{
		$shell_result=`mv $fantasticopathold $fantasticopathnew`;
		echo $shell_result;
		echo "<p class=Hint><b>The Fantastico directory has been renamed to <span class=Hint>$fantasticodirnamenew</span>.</b><p>Don't forget to modify links or symlinks to Fantastico to point to <span class=Hint>$fantasticodirnamenew</span>.<p>&nbsp;</p><p><a href='/frontend/<cpanel print="$CPDATA{'RS'}">/$fantasticodirnamenew/admin/admin.php'>Back to main</a>";
	}
	
	if ($phpsuexec == 0 AND $phpsuexecnew == 1)
		{
		echo "<p>Really chmod -R 755 <cpanel print=\"$homedir\">/fantastico_files/ ?<p>If this doesn't work come back here and change PHPsuexec to 'Not installed'.";
		?>
		<p>
		<form action="admin.php">
		<input type="hidden" name="action" value="phpsuexecdo">
		<input type="hidden" name="hlmenu" value="setup">
		<input type="submit" value="Yes">
		</form>
		<?
		
	} elseif ($phpsuexec == 1 AND $phpsuexecnew == 0) {
		Echo "<p>You have disabled PHPsuexec. Click on 'Proceed' to restore original permissions";
		?>
		<p>
		<form action="admin.php">
		<input type="hidden" name="action" value="restorepermissions">
		<input type="hidden" name="hlmenu" value="setup">
		<input type="submit" value="Proceed">
		</form>
		<?
	}

}

if ($action == "phpsuexecdo") {
	$myfile = fopen("$fantasticoadminpath/phpsuexec.inc.php", "w");
	$fp = fwrite($myfile,"<?");
	$fp = fwrite($myfile,chr(10));
	$fp = fwrite($myfile,"\$phpsuexec = 1;");
	$fp = fwrite($myfile,chr(10));
	$fp = fwrite($myfile,"?>");	
	fclose($myfile);
	$shell_result=`chmod -R 755 <cpanel print="$homedir">/fantastico_files/`;
	if (!$shell_result) {
		echo "<p>All master files were chmoded 755. This doesn't affect already installed applications.<p><a href='admin.php'>Back to main</a>";
		} else {
		echo "<p>$shell_result";
		}
	}

if ($action == "restorepermissions") {
	$myfile = fopen("$fantasticoadminpath/phpsuexec.inc.php", "w");
	$fp = fwrite($myfile,"<?");
	$fp = fwrite($myfile,chr(10));
	$fp = fwrite($myfile,"\$phpsuexec = 0;");
	$fp = fwrite($myfile,chr(10));
	$fp = fwrite($myfile,"?>");	
	fclose($myfile);

	foreach ($application as $item) {
		$shell_result=`wget --http-user=<cpanel hostname=""> --http-passwd=<cpanel hostname=""> -N http://cpanelthemes.com/tarballs/$item.tgz 2>&1`;
		if (stristr($shell_result,$FANTsaved)) 
		{ 
			$shell_result=`rm -rf <cpanel print="$homedir">/fantastico_files/$item`;
			echo "<p>$shell_result";
			$shell_result=`tar xzpf $item.tgz`;
			echo "<p>$shell_result";
			$shell_result=`mv /tmp/$item <cpanel print="$homedir">/fantastico_files/`;
			echo "<p>$shell_result";
			$this_result="The newest <p><span class=Hint><b>$item</b></span> tarball has been copied and extracted.<br />"; 
		} else if (stristr($shell_result,$FANTnonewer)) { 
			$shell_result=`tar xzpf $item.tgz`;
			echo "<p>$shell_result";
			$shell_result=`mv /tmp/$item <cpanel print="$homedir">/fantastico_files/`;
			echo "<p>$shell_result";
			$this_result="The existing <p><span class=Hint><b>$item</b></span>$item tarball has been copied and extracted.<br />"; 
		} else if (stristr($shell_result,$FANTpermissiondenied)) { 
			$no_license=$no_license_text; 
		}
	}

	if ($no_license)
	{
			echo $no_license;
	}

	echo "<p><a href='admin.php'>Back to main</a>";

}

?>