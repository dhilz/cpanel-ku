<cpanel include="adminuser.inc.php">
<cpanel include="../../fantasticoinc.php">
<cpanel include="../includes/masterfilespath.inc.php">
<cpanel include="fantasticopath.inc.php">
<cpanel include="functions.inc.php">
<cpanel include="fantasticodirname.inc.php">
<cpanel include="phpsuexec.inc.php">
<cpanel include="fantasticoversion.inc.php">

<?php

$no_license_text="This server has no license or:<br>- you didn't send us yet the <b>hostname (<cpanel hostname="">)</b> of this server<br>- You did but we didn't enable it yet<br>- The hostname you emailed was misspelled (Linux is case sensitive)<p>- If you have purchased Fantastico but didn't fill out the 'hostname' field when ordering, please send an email to <a href='mailto:support@cpanelthemes.com'>support@cpanelthemes.com</a> with Order Number and the hostname of your server: <b><cpanel hostname=""></b>. <p>- If you are a RackShack customer, please send an email to <a href='mailto:support@cpanelthemes.com'>support@cpanelthemes.com</a> with main IP (probably <b><cpanel print="$ip"></b>) and the hostname of this server: <b><cpanel hostname=""></b>. <p>- If you are using a demo version of Fantastico, <a href='http://cpanelthemes.com/shop/product_info.php?products_id=29' target=_blank>click here</a> to purchase a license."; 

if (($fantasticoadmin != "") && ($fantasticoadmin != $REMOTE_USER))
{
echo "<p align=center><b>$REMOTE_USER,</b><br /> where do you want to go today?</p>";
} else if ($fantasticoadmin == "") {
$action = "firststep";
$hlmenu = "setup";
} 

if (($fantasticoadmin == "$REMOTE_USER") || ($fantasticoadmin == "")) {
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Fantastico</title>

<meta http-equiv="Content-Type" content="text/html; charset=<cpanel langprint="CHARSET">">
<link href="../styles.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="100%" height="100%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr>
	<td height="100%" align="center" valign="middle">
	<table width="600" height="400" border="0" cellpadding="0" cellspacing="0">
		<tr> 
		  <td height="22"> 
			<table width="100%" height="22" border="0" cellpadding="0" cellspacing="0">
			  <tr> 
				<td width="24" align="left" valign="top"><a href="../../logout.html"><img src="../fantasticoimages/xc_left.gif" width="24" height="22" border="0"></a></td>
				<td align="left" width="100%" valign="top"><img src="../fantasticoimages/xc_center.gif" width="100%" height="22" border="0"></td>
				<td width="24" align="right" valign="top"><img src="../fantasticoimages/xc_right.gif" width="24" height="22" border="0"></td>
			  </tr>
			</table>
		  </td>
		</tr>
		<tr>
		  <td height="100%" valign="top"  background="../fantasticoimages/xc_stripes.gif" class="BottomTable">
			<table width="100%" height="60" border="0" cellpadding="0" cellspacing="0" class="IconsTable">
			  <tr> 
				<td width="8" height="48">&nbsp;</td>

				<td width='48' height='48' align='center' valign='top'><a href='/'><img src='../fantasticoimages/tools.gif' width='48' height='48' border='0'></a></td>
				<td width="8" height="48">&nbsp;</td>
				<td width='48' height='48' align='center' valign='top'><a href='../index.php'><img src='../fantasticoimages/fantastico.gif' width='48' height='48' border='0'></a></td>

				<td height="48">&nbsp;</td>
			  </tr>
			  <tr> 
				<td width="8">&nbsp;</td>
				<td width='48' align='center' valign='top' class='TopMenu' nowrap>Control Panel</td>
				<td width="8">&nbsp;</td>
				<td width='48' align='center' valign='top' class='TopMenu' nowrap>Fantastico</td>
				<td>&nbsp;</td>
			  </tr>
			</table>
			<table width="100%" height="318" border="0" cellpadding="0" cellspacing="0">

			  <tr>
				<td width="20" height="18">&nbsp;</td>
				<td width="150" height="18" align="left" valign="top">
				</td>
				<td width="12" height="18">&nbsp;</td>
				<td height="18" class="MainMenuHead">Fantastico Admin Panel</td>
				<td width="20" height="18">&nbsp;</td>
			  </tr>

			  <tr> 
				<td width="20" height="100%">&nbsp;</td>
				<td width="8" height="100%" align="left" valign="top">

				<cpanel include="admin_menu.inc.php">
				
				</td>
				<td width="12" height="100%">&nbsp;</td>
				<td height="100%" align="center" valign="top" class="contentcell"> 
				  
<table width=100%>
<tr>
<td>
<p>

<!-- beginn main php code -->

<?php
if ($fantasticodirname == "")
	{
		$fantasticodirname = "fantastico";
	}

$fantasticopath="/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/". $fantasticodirname;
$fantasticoadminpath=$fantasticopath . "/admin";


$adminsettings="<cpanel print="$homedir">/fantastico_admin_settings/";
if (!(is_dir($adminsettings))) 
	{
		mkdir($adminsettings,0755) or die("<p><span class=Hint><b>ERROR!</b></span> You must have write permissions on your base directory in order to proceed. Please correct this and retry.");
	}
	
$DEPOT="<cpanel print="$homedir">/fantastico_files/";
if (!(is_dir($DEPOT))) 
	{
	mkdir($DEPOT,0755) or die("<p><span class=Hint><b>ERROR!</b></span> You must have write permissions on your base directory in order to proceed. Please correct this and retry.");
	}

$enableduserssettings="<cpanel print="$homedir">/fantastico_admin_settings/enabledusers/";
if (!(is_dir($enableduserssettings))) 
	{
	mkdir($enableduserssettings,0755) or die("<p><span class=Hint><b>ERROR!</b></span> You must have write permissions on your base directory in order to proceed. Please correct this and retry.");
	}

$disableduserssettings="<cpanel print="$homedir">/fantastico_admin_settings/disabledusers/";
if (!(is_dir($disableduserssettings))) 
	{
	mkdir($disableduserssettings,0755) or die("<p><span class=Hint><b>ERROR!</b></span> You must have write permissions on your base directory in order to proceed. Please correct this and retry.");
	}

$enabledpackagessettings="<cpanel print="$homedir">/fantastico_admin_settings/enabledpackages/";
if (!(is_dir($enabledpackagessettings))) 
	{
	mkdir($enabledpackagessettings,0755) or die("<p><span class=Hint><b>ERROR!</b></span> You must have write permissions on your base directory in order to proceed. Please correct this and retry.");
	}

$disabledpackagessettings="<cpanel print="$homedir">/fantastico_admin_settings/disabledpackages/";
if (!(is_dir($disabledpackagessettings))) 
	{
	mkdir($disabledpackagessettings,0755) or die("<p><span class=Hint><b>ERROR!</b></span> You must have write permissions on your base directory in order to proceed. Please correct this and retry.");
	}

$enabledresellerssettings="<cpanel print="$homedir">/fantastico_admin_settings/enabledresellers/";
if (!(is_dir($enabledresellerssettings))) 
	{
	mkdir($enabledresellerssettings,0755) or die("<p><span class=Hint><b>ERROR!</b></span> You must have write permissions on your base directory in order to proceed. Please correct this and retry.");
	}

$disabledresellerssettings="<cpanel print="$homedir">/fantastico_admin_settings/disabledresellers/";
if (!(is_dir($disabledresellerssettings))) 
	{
	mkdir($disabledresellerssettings,0755) or die("<p><span class=Hint><b>ERROR!</b></span> You must have write permissions on your base directory in order to proceed. Please correct this and retry.");
	}




$FANTsaved="saved";
$FANTnonewer="no newer";
$FANTpermissiondenied="Authorization failed";

$application[]="4Images_Gallery";
$application[]="b2";
$application[]="CS_Live_Help";
$application[]="Invision_Board";
$application[]="Moodle";
$application[]="Noahs_Classifieds";
$application[]="OS_Commerce";
$application[]="PHP-Nuke";
$application[]="PHPauction";
$application[]="phpBB2";
$application[]="phpLinks";
$application[]="PHPlist";
$application[]="PHProjekt";
$application[]="phpWebSite";
$application[]="PHP_Support_Tickets";
$application[]="pMachine_Free";
$application[]="Post-Nuke";
$application[]="Support_Services_Manager";
$application[]="WebCalendar";
$application[]="Xoops";

?>

<cpanel include="initialsetup.php">

<?php
if ($action == "" || $action == "applications") 
	{
	echo "<table cellspacing=0 cellpadding=3 border=0 width=100%>
<tr>
	<td><a href='admin.php?action=wgetall'><b>Get complete master files</b></a></td>
	<td>&nbsp;</td>
	<td>&nbsp;</td>
	<td>&nbsp;</td>
	<td>&nbsp;</td>
	<td>&nbsp;</td>
	<td>&nbsp;</td>
</tr>
<tr>
	<td><a href='admin.php?action=forceuntar'><b>Force untar master files</b></a></td>
	<td>&nbsp;</td>
	<td>&nbsp;</td>
	<td>&nbsp;</td>
	<td>&nbsp;</td>
	<td>&nbsp;</td>
	<td>&nbsp;</td>
</tr>
<tr>
	<td colspan=7>&nbsp;</td>
</tr>";


	foreach ($application as $applisting) {
		$appdirenabled = "<cpanel print="$homedir">/fantastico_files/".$applisting;
		$appdirdisabled = "<cpanel print="$homedir">/fantastico_files/_".$applisting;
		$humanapplisting=str_replace("_", " ", $applisting);
		echo "
<tr>
	<td><b>$humanapplisting</b></td>";
		if (is_dir("$appdirenabled"))
			{
			echo "
	<td>&nbsp;</td>
	<td width=10><img src='../fantasticoimages/xc_dotgreen.gif' width=10 height=12></td>
	<td>&nbsp;</td><td align=center><a href='admin.php?action=disable&item=$applisting'>[Disable]</a></td>";
			} elseif (is_dir($appdirdisabled)) {
			echo "
	<td>&nbsp;</td>
	<td width=10><img src='../fantasticoimages/xc_dotred.gif' width=10 height=12></td>
	<td>&nbsp;</td><td align=center><a href='admin.php?action=enable&item=$applisting'>[Enable]</a></td>";
			} else {
			echo "
	<td>&nbsp;</td>
	<td width=10>&nbsp;</td>
	<td>&nbsp;</td><td align=center>[Not found]</td>";

			}
		echo "
	<td>&nbsp;</td><td><a href='admin.php?action=update&item=$applisting'>[Get latest]</a></td>
</tr>";
		}
	
	if ($fantasticoversion)
		{
			echo "
			<tr>
				<td colspan=7>&nbsp;</td>
			</tr>
			<tr>
				<td colspan=7 align=center>Version: $fantasticoversion / Date: $fantasticodate </td>
			</tr>
			";
		}	
	echo "

</table>";
	}


if ($action == "remove")
	{
	$shell_result=`rm -rf <cpanel print="$homedir">/fantastico_files`;
	echo "<p>$shell_result";

	echo "The Fantastico tarballs have been removed. No installations can be performed. Go to 'Applications' and get the complete master files to reactivate Fantastico.<p><a href='admin.php'>Back to main</a>";
	}


if ($action == "wgetall")
	{
	foreach ($application as $item) 
		{

		$shell_result=`wget --http-user=<cpanel hostname=""> --http-passwd=<cpanel hostname=""> -N http://cpanelthemes.com/tarballs/$item.tgz 2>&1`;
		if (stristr($shell_result,$FANTsaved)) 
			{ 
				$shell_temp=`rm -rf <cpanel print="$homedir">/fantastico_files/$item`;
				echo "<p>$shell_temp";
				$shell_temp=`tar xzpf $item.tgz`;
				echo "<p>$shell_temp";
				$shell_temp=`mv /tmp/$item <cpanel print="$homedir">/fantastico_files/`;
				echo "<p>$shell_temp";
				if ($phpsuexec == 1) {
					$shell_temp=`chmod -R 755 <cpanel print="$homedir">/fantastico_files/$item`;
					echo "<p>$shell_temp";
				}
				$this_result="The newest <span class=Hint><b>$item</b></span> tarball has been copied and extracted.<br />"; 
				echo $this_result;
			} 
		else if (stristr($shell_result,$FANTnonewer)) 
			{ 
				$this_result="No newer master files for <span class=Hint><b>$item</b></span>!<br />"; 
				echo $this_result;
			} 
		else if (stristr($shell_result,$FANTpermissiondenied)) 
			{ 
				$no_license=$no_license_text; 
			}
		}

	if ($no_license)
		{
			echo $no_license;
		}

	echo "<p><a href='admin.php'>Back to main</a>";

	}


if ($action == "forceuntar")
	{
	foreach ($application as $item) 
		{

		$shell_result=`wget --http-user=<cpanel hostname=""> --http-passwd=<cpanel hostname=""> -N http://cpanelthemes.com/tarballs/$item.tgz 2>&1`;
		if (stristr($shell_result,$FANTsaved)) 
			{ 
				$shell_temp=`rm -rf <cpanel print="$homedir">/fantastico_files/$item`;
				echo "<p>$shell_temp";
				$shell_temp=`tar xzpf $item.tgz`;
				echo "<p>$shell_temp";
				$shell_temp=`mv /tmp/$item <cpanel print="$homedir">/fantastico_files/`;
				echo "<p>$shell_temp";
				if ($phpsuexec == 1) {
					$shell_temp=`chmod -R 755 <cpanel print="$homedir">/fantastico_files/$item`;
					echo "<p>$shell_temp";
				}
				$this_result="The newest <span class=Hint><b>$item</b></span> tarball has been copied and extracted.<br />"; 
				echo $this_result;
			} 
		else if (stristr($shell_result,$FANTnonewer)) 
			{ 
				$shell_temp=`rm -rf <cpanel print="$homedir">/fantastico_files/$item`;
				echo "<p>$shell_temp";
				$shell_temp=`tar xzpf $item.tgz`;
				echo "<p>$shell_temp";
				$shell_temp=`mv /tmp/$item <cpanel print="$homedir">/fantastico_files/`;
				echo "<p>$shell_temp";
				if ($phpsuexec == 1) {
					$shell_temp=`chmod -R 755 <cpanel print="$homedir">/fantastico_files/$item`;
					echo "<p>$shell_temp";
				}
				$this_result="The existing <span class=Hint><b>$item</b></span> tarball has been extracted.<br />"; 
				echo $this_result;
			} 
		else if (stristr($shell_result,$FANTpermissiondenied)) 
			{ 
				$no_license=$no_license_text; 
			}
		}

	if ($no_license)
		{
			echo $no_license;
		}
	echo "<p><a href='admin.php'>Back to main</a>";

	}

	
if ($action == "update")
	{
	$shell_result=`wget --http-user=<cpanel hostname=""> --http-passwd=<cpanel hostname=""> -N http://cpanelthemes.com/tarballs/$item.tgz 2>&1`;
	if (stristr($shell_result,$FANTsaved)) 
		{ 
			$wgetsuccess=1;
			$this_result="The newest <p><span class=Hint><b>$item</b></span> tarball has been copied.<br />"; 
			echo $this_result;
		} 
	else if (stristr($shell_result,$FANTnonewer)) 
		{ 
			$this_result="No newer tarball for <p><span class=Hint><b>$item</b></span>!<br />"; 
			echo $this_result;
		} 
	else if (stristr($shell_result,$FANTpermissiondenied)) 
		{ 
			$no_license=$no_license_text; 
			echo $no_license;
		}
		

	$appdirdisabled = "<cpanel print="$homedir">/fantastico_files/_".$item;
		if (is_dir("$appdirdisabled"))
			{
			$restoredisable=1;
			$shell_result=`rm -rf <cpanel print="$homedir">/fantastico_files/$item`;
			echo "<p>$shell_result";
			}
	$shell_result=`tar xzpf $item.tgz`;
	echo "<p>$shell_result";
	
	if ($wgetsuccess)
		{
			$shell_result=`rm -rf <cpanel print="$homedir">/fantastico_files/$item`;
			echo "<p>$shell_result";
		
			$shell_result=`mv /tmp/$item <cpanel print="$homedir">/fantastico_files/`;
			echo "<p>$shell_result";
			if ($phpsuexec == 1) {
				$shell_temp=`chmod -R 755 <cpanel print="$homedir">/fantastico_files/$item`;
				echo "<p>$shell_temp";
			}
		}

	if ("$restoredisable")
		{
		$shell_result=`mv <cpanel print="$homedir">/fantastico_files/$item <cpanel print="$homedir">/fantastico_files/_$item`;
		echo "<p>$shell_result";
		}
	
	echo "<p><span class=Hint><b>$item</b></span> has been updated.<p><a href='admin.php'>Back to main</a>";
	}

if ($action == "enable")
	{
	$shell_result=`mv <cpanel print="$homedir">/fantastico_files/_$item <cpanel print="$homedir">/fantastico_files/$item`;
	echo "<p>$shell_result";
	echo "<p><p><span class=Hint><b>$item</b></span> has been <b>enabled</b>.<p><a href='admin.php'>Back to main</a>";
	}

if ($action == "disable")
	{
	$shell_result=`mv <cpanel print="$homedir">/fantastico_files/$item <cpanel print="$homedir">/fantastico_files/_$item`;
	echo "<p>$shell_result";
	echo "<p><p><span class=Hint><b>$item</b></span> has been <b>disabled</b>.<p><a href='admin.php'>Back to main</a>";
	}

if ($action == "coreupdate")
	{
		$updatepath=realpath($fantasticopath);
		echo "
		<p class='Hint'><b>Update core Fantastico files</b></p><p>By proceeding, you will replace the current Fantastico files with the updated ones. Do this only in case you did get an email notifying you that you need to perform a <span class=Hint><b>Core Files Update</b></span>.</p><p class=Hint>If you have modified your headers/footers or have altered the core files in any way, enter a directory name below. The core files will be copied in this directory inside your home directory (<cpanel print="$homedir">/)  and you may re-apply your changes and copy over to the Fantastico directory (<b>$updatepath</b>).
		<p><form action='admin.php?action=coreupdatedo&hlmenu=coreupdate' method='POST'>
		Name of alternate directory (leave empty if you haven't modified Fantastico)
		<p class=ButtonPosition><input type='text' name='copydir'>
		<p class=ButtonPosition><input type='submit' value='Update'>
		</form>

	";
	}

	
if ($action == "coreupdatedo")
	{
	$shell_result=`wget --http-user=<cpanel hostname=""> --http-passwd=<cpanel hostname=""> -N http://cpanelthemes.com/tarballs/fantastico.tgz 2>&1`;
	if (stristr($shell_result,$FANTsaved)) 
		{ 
			$wgetsuccess=1;
			$this_result="The <b>Fantastico core files</b> have been copied."; 
		} 
	else if (stristr($shell_result,$FANTnonewer)) 
		{ 
			$this_result="There is currently <b>no newer</b> Fantastico version than the one already installed."; 
		} 
	else if (stristr($shell_result,$FANTpermissiondenied)) 
		{ 
			$no_license=$no_license_text; 
		}

	if ($no_license)
		{
			echo $no_license;
		} else if ($this_result) {
			echo $this_result;
		} else {
			echo $shell_result;
		}
		
	if ($wgetsuccess) {
		$shell_result=`tar xzf fantastico.tgz`;
		echo "<p>$shell_result";
		if ($copydir != "") {
			$copypath="<cpanel print="$homedir">/$copydir";
			mkdir($copypath,0755);
			} else {
			$copypath=realpath($fantasticopath);
		}
		$itdrivesmecrazy="*";
		$shell_result=`cp -rfpd /tmp/fantastico/$itdrivesmecrazy $copypath/`;
		echo "<p>$shell_result";
	
		$shell_result=`rm -rf /tmp/fantastico`;
		echo "<p>$shell_result";
		
		echo "Fantastico core files have been updated. The newest files are located at <span class=Hint><b>$copypath</b></span><p><a href='admin.php'>Back to main</a>";
		}
	}
if ($action == "disablefantastico")
	{
	$hlmenu="togglefantastico";
	mkdir("$fantasticopath/admin/disabled",0755) or die("<p><span class=Hint><b>ERROR!</b></span> The directory <b>$fantasticopath/admin/disabled</b> could not be created. Please create it manually.");
	echo "<p>Fantastico has been <b>disabled</b>.<p><a href='admin.php'>Back to main</a>";
	}
	
if ($action == "enablefantastico")
	{
	$hlmenu="togglefantastico";
	rmdir("$fantasticopath/admin/disabled") or die("<p><span class=Hint><b>ERROR!</b></span> The directory <b>$fantasticopath/admin/disabled</b> could not be removed. Please remove it manually");
	echo "<p>Fantastico has been <b>enabled</b>.<p><a href='admin.php'>Back to main</a>";
	}
	

if ($changerestrictmodus == 1)
	{
	$myfile = fopen("$fantasticopath/admin/$module.inc.php", "w");
	$fp = fwrite($myfile,"<?");
	$fp = fwrite($myfile,chr(10));
	$fp = fwrite($myfile,"\$restrict_by_$module = \"$mode\";");
	$fp = fwrite($myfile,chr(10));
	$fp = fwrite($myfile,"?".">");	
	fclose($myfile);
	}

if ($action == "restrictuser" || $action == "restrictreseller" || $action == "restrictpackage") 
{
	if ($action == "restrictuser") 
	{
		$labelwhat="user";
		if (is_file("$fantasticopath/admin/users.inc.php"))
			{
			include("$fantasticopath/admin/users.inc.php");
			} else {
				$restrict_by_users = "disabled";
				$mode = "disabled";
			}
	
		if($restrict_by_users == "enabled")
		{
			$form_header = "Add a user to the allowed list:";
			$checkdir = $enableduserssettings;
			$mode_header = "Users displayed here are allowed to use Fantastico no matter what reseller or hosting plan limitations might apply:";
			$change_mode_link = "<a href=admin.php?action=restrictuser&mode=disabled&hlmenu=restrictuser&changerestrictmodus=1&module=users>Change mode to 'Enable all'</a>";	
		} else if ($restrict_by_users == "disabled") {
			$form_header = "Add a user to the restricted list:";
			$checkdir=$disableduserssettings;
			$mode_header = "All users are allowed to use Fantastico (unless a reseller or hosting plan limitation apply) except for the following:";	
			$change_mode_link = "<a href=admin.php?action=restrictuser&mode=enabled&hlmenu=restrictuser&changerestrictmodus=1&module=users>Change mode to 'Allow specific'</a>";
		}	

	} else if ($action == "restrictreseller") 
	{
		$labelwhat="reseller";
		if (is_file("$fantasticopath/admin/resellers.inc.php"))
			{
			include("$fantasticopath/admin/resellers.inc.php");
			} else {
				$restrict_by_resellers = "disabled";
				$mode = "disabled";
			}

		if($restrict_by_resellers == "enabled")
		{
			$form_header = "Add a reseller to the allowed list:";
			$checkdir = $enabledresellerssettings;
			$mode_header = "Only clients of resellers displayed here are allowed to use Fantastico   (unless a user or hosting plan limitation apply). Add reseller <b>'root'</b> to enable non resold accounts to use Fantastico:";
			$change_mode_link = "<a href=admin.php?action=restrictreseller&mode=disabled&hlmenu=restrictreseller&changerestrictmodus=1&module=resellers>Change mode to 'Enable all'</a>";	
		} else if ($restrict_by_resellers == "disabled") {
			$form_header = "Add a reseller to the restricted list:";
			$checkdir=$disabledresellerssettings;
			$mode_header = "All resellers' clients are allowed to use Fantastico (unless a user or hosting plan limitation apply) except for the following:";	
			$change_mode_link = "<a href=admin.php?action=restrictreseller&mode=enabled&hlmenu=restrictreseller&changerestrictmodus=1&module=resellers>Change mode to 'Allow specific'</a>";
		}	
	
	} else if ($action == "restrictpackage") 
	{
		$labelwhat="package";
		if (is_file("$fantasticopath/admin/packages.inc.php"))
			{
			include("$fantasticopath/admin/packages.inc.php");
			} else {
				$restrict_by_packages = "disabled";
				$mode = "disabled";
			}
	
		if($restrict_by_packages == "enabled")
		{
			$form_header = "Add a hosting plan to the allowed list:";
			$checkdir = $enabledpackagessettings;
			$mode_header = "Hosting plans displayed here are allowed to use Fantastico (unless a user or reseller limitation apply):";
			$change_mode_link = "<a href=admin.php?action=restrictpackage&mode=disabled&hlmenu=restrictpackage&changerestrictmodus=1&module=packages>Change mode to 'enable all'</a>";	
		} else if ($restrict_by_packages == "disabled") {
			$form_header = "Add a hosting plan to the restricted list:";
			$checkdir=$disabledpackagessettings;
			$mode_header = "All hosting plans are allowed to use Fantastico (unless a user or reseller limitation apply) except for the following:";	
			$change_mode_link = "<a href=admin.php?action=restrictpackage&mode=enabled&hlmenu=restrictpackage&changerestrictmodus=1&module=packages>Change mode to 'Allow specific'</a>";
		}	
	}

	if (is_dir($checkdir))
		{
		if ($thisdir = opendir($checkdir)) 
			{
			while (false !== ($file = readdir($thisdir))) 
				{
				if ($file != "." && $file != "..") 
					{ 
					$restricteditems=explode(".",$file);
					$myitems[]=$restricteditems[0];
					}
				}
			closedir($thisdir); 
			}
		}
	
	$restricteditems = count ($myitems);
	echo "<p class='Hint'><b>$mode_header</b></p>";	
	if ($restricteditems == 0)
		{
		echo "None";
		} else {
		echo "<table>
		";
		foreach($myitems as $localitem)
			{
			echo "<tr><td><b>$localitem</b>
			</td>
			<td>&nbsp;</td>
			<td><a href=admin.php?action=removerestricteditem&removerestricteditem=" . str_replace(" ", "%20" , $localitem) . "&checkdir=$checkdir&hlmenu=restrict" . $labelwhat . "&labelwhat=$labelwhat>Remove from list</a></td>
			<td>&nbsp;</td>
			";
			}
		echo "</tr></table>";
		}
		echo "
		<p>&nbsp;</p>
		<p class='Hint'><b>$form_header</b></p><p>You may enter multiple items separated by a comma</p>
		<form action='admin.php?action=restrictitemadd&hlmenu=restrict" . $labelwhat . "&labelwhat=$labelwhat&checkdir=$checkdir' method='POST'>
		<input type='text' name='additem'>
		<input type='submit' value='Add'>
		</form>

	";
		echo "<p>&nbsp;</p><p><b>$change_mode_link</b>";
	}

if ($action == "restrictitemadd"){ 
$items_to_add = explode(",",$additem);
$i = 0;
	while($items_to_add[$i]){
	$items_to_add[$i] = trim($items_to_add[$i]); 
	$dodir="'" . $checkdir . $items_to_add[$i] . "'" ;
		if (is_dir("$dodir"))
		{
		echo "<p class='Hint'><b>This $labelwhat is already listed!</b></p>";
		} else {
		$shell_result=`mkdir $dodir --mode=0755`;
		echo "<p>$shell_result";

//		mkdir($dodir,0755) or die("<p><span class=Hint><b>ERROR!</b></span> The necessary data could not be saved into $checkdir. Check the permissions and quota and retry.");
		echo "";
		echo "$labelwhat <span class=Hint><b>".$items_to_add[$i]."</b></span> was added to the list.<br />";
		
		}
		$i++;
	}
echo "<p><a href='admin.php?action=restrict$labelwhat&hlmenu=restrictuser'>Back to $labelwhat usage rules</a>";
	}

if ($action == "removerestricteditem") 
	{
	$removedir="$checkdir" . "$removerestricteditem";
		echo "
		<p class='Hint'><b>Remove from the list of restricted $labelwhat</b></p>Are you sure you want to remove <span class='Hint'><b>" . str_replace('%20', ' ' , $removerestricteditem) . "</b></span> from the list of restricted " . $labelwhat . "s?</p>
		<form action='admin.php?action=removerestricteditemdo&hlmenu=restrict" . $labelwhat ."&removerestricteditem=" . str_replace("%20", " " , $removerestricteditem) . "&removedir=$removedir&labelwhat=" . $labelwhat . "' method='POST'>
		<input type='submit' value='Remove'>
		</form>

	";
	}

if ($action == "removerestricteditemdo") 
	{
	$removedir = "'" . str_replace("%20", " " , $removedir) . "'";
	$shell_result=`rm -rf $removedir`;
	echo "<p>$shell_result";

	echo "<p class='Hint'><b>$removerestricteditem</b></span> was removed from the list of restricted " . $labelwhat . "s.
<p><a href='admin.php?action=restrict" . $labelwhat . "&hlmenu=restrict" . $labelwhat . "'>Back to $labelwhat usage rules</a>";
	}

}
?>
<!-- end main php code -->

<p>


</td>
</tr>
</table>

<cpanel include="../includes/fantasticofooter.html">

