<?php
if ($fantasticoadmin == "") {
	$hlmenu = "setup";
	} else if ($hlmenu=="") {
	$hlmenu="applications";
	}
?>



<!-- start menu -->

				  <table width="100%" border="0" cellspacing="0" cellpadding="0">

<?php


if ($hlmenu=="applications") {
?>
					<tr> 
					  <td width="10"><img src="../fantasticoimages/xc_dotblue.gif" width="10" height="12"></td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenu"><a href="admin.php?action=applications&hlmenu=applications" class="LeftMenu">Applications</a></td>
					</tr>
<?php
} else {
?>
					<tr> 
					  <td width="10"><img src="../fantasticoimages/xc_dotgrey.gif" width="10" height="12"></td>
					  <td width="4">&nbsp;</td>
					  <td nowrap class="LeftMenu"><a href="admin.php?action=applications&hlmenu=applications" class="LeftMenu">Applications</a></td>
					</tr>
<?php
}

if ($hlmenu=="restrictreseller") {
?>
					<tr> 
					  <td width="10"><img src="../fantasticoimages/xc_dotblue.gif" width="10" height="12"></td>
					  <td>&nbsp;</td>
					  <td nowrap class="LeftMenu"><a href="admin.php?action=restrictreseller&hlmenu=restrictreseller" class="LeftMenu">Resellers usage rules</a></td>
					</tr>
<?php
} else {
?>
					<tr> 
					  <td width="10"><img src="../fantasticoimages/xc_dotgrey.gif" width="10" height="12"></td>
					  <td>&nbsp;</td>
					  <td nowrap class="LeftMenu"><a href="admin.php?action=restrictreseller&hlmenu=restrictreseller" class="LeftMenu">Resellers usage rules</a></td>
					</tr>
<?php
}

if ($hlmenu=="restrictuser") {
?>
					<tr> 
					  <td width="10"><img src="../fantasticoimages/xc_dotblue.gif" width="10" height="12"></td>
					  <td>&nbsp;</td>
					  <td nowrap class="LeftMenu"><a href="admin.php?action=restrictuser&hlmenu=restrictuser" class="LeftMenu">Users usage rules</a></td>
					</tr>
<?php
} else {
?>
					<tr> 
					  <td width="10"><img src="../fantasticoimages/xc_dotgrey.gif" width="10" height="12"></td>
					  <td>&nbsp;</td>
					  <td nowrap class="LeftMenu"><a href="admin.php?action=restrictuser&hlmenu=restrictuser" class="LeftMenu">Users usage rules</a></td>
					</tr>
<?php
}

if ($hlmenu=="restrictpackage") {
?>
					<tr> 
					  <td width="10"><img src="../fantasticoimages/xc_dotblue.gif" width="10" height="12"></td>
					  <td>&nbsp;</td>
					  <td nowrap class="LeftMenu"><a href="admin.php?action=restrictpackage&hlmenu=restrictpackage" class="LeftMenu">Hosting plans usage rules</a></td>
					</tr>
<?php
} else {
?>
					<tr> 
					  <td width="10"><img src="../fantasticoimages/xc_dotgrey.gif" width="10" height="12"></td>
					  <td>&nbsp;</td>
					  <td nowrap class="LeftMenu"><a href="admin.php?action=restrictpackage&hlmenu=restrictpackage" class="LeftMenu">Hosting plans usage rules</a></td>
					</tr>
<?php
}

if ($hlmenu=="setup") {
?>
					<tr> 
					  <td width="10" valign=top><img src="../fantasticoimages/xc_dotblue.gif" width="10" height="12"></td>
					  <td>&nbsp;</td>
					  <td nowrap class="LeftMenu"><a href="admin.php?action=setup&hlmenu=setup" class="LeftMenu">Setup</a><br /></td>
					</tr>

<?php
} else {
?>
					<tr> 
					  <td width="10" valign=top><img src="../fantasticoimages/xc_dotgrey.gif" width="10" height="12"></td>
					  <td>&nbsp;</td>
					  <td nowrap class="LeftMenu"><a href="admin.php?action=setup&hlmenu=setup" class="LeftMenu">Setup</a><br /></td>
					</tr>

<?php
}

if ($hlmenu=="coreupdate") {
?>
					<tr>
					  <td width="10"><img src="../fantasticoimages/xc_dotblue.gif" width="10" height="12"></td>
					  <td>&nbsp;</td>
					  <td nowrap class="LeftMenu"><a href="admin.php?action=coreupdate&hlmenu=coreupdate" class="LeftMenu">Core files update</a></td>
					</tr>
<?php
} else {
?>
					<tr>
					  <td width="10"><img src="../fantasticoimages/xc_dotgrey.gif" width="10" height="12"></td>
					  <td>&nbsp;</td>
					  <td nowrap class="LeftMenu"><a href="admin.php?action=coreupdate&hlmenu=coreupdate" class="LeftMenu">Core files update</a></td>
					</tr>
<?php
}

if (!(is_dir("$fantasticopath/admin/disabled")) && $hlmenu!="togglefantastico")
	{
	?>
		<tr> 
		  <td width="10"><img src="../fantasticoimages/xc_dotgrey.gif" width="10" height="12"></td>
		  <td>&nbsp;</td>
		  <td nowrap class="LeftMenu"><a href="admin.php?action=disablefantastico&hlmenu=togglefantastico" class="LeftMenu">Disable Fantastico</a></td>
		</tr>
	<?php
	} else if (!(is_dir("$fantasticopath/admin/disabled")) && $hlmenu=="togglefantastico") {
	?>
		<tr> 
		  <td width="10"><img src="../fantasticoimages/xc_dotblue.gif" width="10" height="12"></td>
		  <td>&nbsp;</td>
		  <td nowrap class="LeftMenu"><a href="admin.php?action=enablefantastico&hlmenu=togglefantastico" class="LeftMenu">Enable Fantastico</a></td>
		</tr>
	<?php
		} else if (is_dir("$fantasticopath/admin/disabled") && $hlmenu!="togglefantastico") { 
	?>
		<tr> 
		  <td width="10"><img src="../fantasticoimages/xc_dotgrey.gif" width="10" height="12"></td>
		  <td>&nbsp;</td>
		  <td nowrap class="LeftMenu"><a href="admin.php?action=enablefantastico&hlmenu=togglefantastico" class="LeftMenu">Enable Fantastico</a></td>
		</tr>
	<?php
	} else if (is_dir("$fantasticopath/admin/disabled") && $hlmenu=="togglefantastico"){
	?>
		<tr> 
			  <td width="10"><img src="../fantasticoimages/xc_dotblue.gif" width="10" height="12"></td>
			  <td>&nbsp;</td>
			  <td nowrap class="LeftMenu"><a href="admin.php?action=disablefantastico&hlmenu=togglefantastico" class="LeftMenu">Disable Fantastico</a></td>
		</tr>
<?php
	}
?>

				  </table>


<!-- end menu -->
