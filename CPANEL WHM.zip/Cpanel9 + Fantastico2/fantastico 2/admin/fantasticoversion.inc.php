<?php
$fantasticoversion = "2.01.08";
$fantasticodate = "2003 06 09 - 15.15 UTC<br />Nice greetings to all spanish friends, especially the Spanish National Soccer Team :)";
?>
