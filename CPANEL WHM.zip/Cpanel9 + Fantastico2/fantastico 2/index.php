<?php
$thisapp="Fantastico";
?>
<cpanel include="admin/adminuser.inc.php">
<cpanel include="admin/fantasticopath.inc.php">
<cpanel include="includes/adminsettingspath.inc.php">
<cpanel include="includes/restrictions.inc.php">
<cpanel include="includes/masterfilespath.inc.php">



<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Fantastico</title>

<?php
if (is_file("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php"))
	{
	include("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php");
	}
	
if ($inxcontroller) 
	{
		?>
		<cpanel include="../themeheader_subdir1.html">
		<cpanel include="includes/mainmenu_icon_subdir.html">
		<cpanel include="../themeheader_subdir2.html">
		<cpanel include="includes/mainmenu_label.html">
		<cpanel include="../themeheader_subdir3.html">
		
		<?php
	} else {
		?>
		<cpanel include="includes/fantasticoheader.html">
		
		<?php
	}
?>

<cpanel include="includes/sidemenu.php">

<table width=100%>
<tr>
<td>
<p>
Use Fantastico to automatically install any of the scripts listed on the left.<p>Click on any of the items on the left to get more details.

<?
if ($FantError)
	{
	echo $FantError;
	} 
?>

<p>


</td>
</tr>
</table>
				  
<cpanel include="includes/fantasticofooter.html">
