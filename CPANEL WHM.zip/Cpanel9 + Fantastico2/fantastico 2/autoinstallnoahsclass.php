<?php
$thisapp="Noahs_Classifieds";
$humanapp=str_replace("_", " ", $thisapp);
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Fantastico</title>

<?php
if (is_file("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php"))
	{
	include("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php");
	}
	
if ($inxcontroller) {
?>
<cpanel include="../themeheader_subdir1.html">
<cpanel include="includes/mainmenu_icon_subdir.html">
<cpanel include="../themeheader_subdir2.html">
<cpanel include="includes/mainmenu_label.html">
<cpanel include="../themeheader_subdir3.html">

<?php
} else {
?>
<cpanel include="includes/fantasticoheader.html">

<?php
}
?>

<cpanel include="admin/adminuser.inc.php">
<cpanel include="admin/fantasticopath.inc.php">
<cpanel include="includes/adminsettingspath.inc.php">
<cpanel include="includes/restrictions.inc.php">
<cpanel include="includes/masterfilespath.inc.php">
<cpanel include="includes/sidemenu.php">

<?
if ($FantError)
	{
	echo $FantError;
	} else {
?>

<form action=autoinstallcheck.php method="GET">

<p align="center"><img src="fantasticoimages/noahsclassifieds.gif" width="307" height="29">
<p>
<table width=100% class='TableMiddle'>
<tr> 
<td colspan="2">
<p class="TableMiddleHead">Install <?=$humanapp ?> (1/3)</p>
</td>
</tr>
<tr>
<td valign=top>
<p><b>Where do you want to install today?</b><br>A top level directory with this name will be created during installation.</p>
</td>
<td valign=top>
<input type="text" name="installdir" size="8">
</td>
</tr>
<tr>
<td colspan="2">&nbsp;</td>
</tr>
<tr>
<td colspan="2" class="Emphasize">
<p>Admin access data</p>
</td>
</tr>
<tr>
<td valign=top>
<p>Administrator-username (you need this to enter the protected admin area)</p>
</td>
<td valign=top>
<input type="text" name="adminuser" size="8" maxlength="8">
</td>
</tr>
<tr>
<td colspan="2">&nbsp;</td>
</tr>
<tr>
<td valign=top>
<p>Password (you need this to enter the protected admin area)</p>
</td>
<td valign=top>
<input type="password" name="password" size="8" maxlength="8">
</td>
</tr>
<tr>
<td>Admin e-mail (add your e-mail here)</td>
<td>
<input type="text" name="adminemail" size="22" value="<cpanel print="$user">@<cpanel print="DOMAIN">">
</td>
</tr>

</table>
<p align="center">
<input type="submit" name="action" value="Install <?=$humanapp ?>">
<input type="hidden" name="thisapp" value="<?=$thisapp ?>">
<input type='hidden' name='mysqluser' value='<?=$mysqluser ?>'>
<input type='hidden' name='thisfinddb' value='clss'>
<input type='hidden' name='continuepage' value='autoinstallnoahsclassdo.php'>
</p>
</form>

    <?php
}
?>

<cpanel include="includes/fantasticofooter.html">
