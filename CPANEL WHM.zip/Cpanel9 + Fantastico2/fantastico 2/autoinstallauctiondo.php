<?php
$thisapp="PHPauction";
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Fantastico</title>

<?php
if (is_file("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php"))
	{
	include("/usr/local/cpanel/base/frontend/<cpanel print="$CPDATA{'RS'}">/fantasticoinc.php");
	}
	
if ($inxcontroller) {
?>
<cpanel include="../themeheader_subdir1.html">
<cpanel include="includes/mainmenu_icon_subdir.html">
<cpanel include="../themeheader_subdir2.html">
<cpanel include="includes/mainmenu_label.html">
<cpanel include="../themeheader_subdir3.html">

<?php
} else {
?>
<cpanel include="includes/fantasticoheader.html">

<?php
}
?>

<cpanel include="admin/adminuser.inc.php">
<cpanel include="admin/fantasticopath.inc.php">
<cpanel include="includes/adminsettingspath.inc.php">
<cpanel include="includes/restrictions.inc.php">
<cpanel include="includes/masterfilespath.inc.php">
<cpanel include="includes/sidemenu.php">
<cpanel include="includes/mysqlconfig.php">


<p class="TableMiddleHead">Install <?=$humanapp ?> (3/3)</p>

<cpanel Mysql="adddb($FORM{'thismakedb'})"> 
<cpanel Mysql="adduser($FORM{'thismakedb'},$FORM{'SQLPass'})">
<cpanel Mysql="adduserdb($FORM{'connect'},$FORM{'connect'})">

<?
$INSTALLDIR=$installdir;
$MYSQLUSER = $connect;
$MYSQLDB = $connect;
$MYSQLPASS = $SQLPass;
$USER = $REMOTE_USER;
$DOMAIN = "<cpanel print="DOMAIN">";
$USER_ROOT = "<cpanel print="$homedir">/public_html";
$SCRIPTPATH = $scriptpath;
$THISDEPOT = $DEPOT.$thisapp;
$SQLDATA = $SCRIPTPATH."/data.sql";
$ADMIN = $adminuser;
$SITENAME = $sitename;
$SITEURL = "http://<cpanel print="DOMAIN">/$INSTALLDIR";
$ADMINEMAIL = $adminemail;
$MAXUPLOADSIZE = $maxuploadsize;
$MD5_PREFIX = $MYSQLPASS;
$ADMINPASS = md5($MD5_PREFIX.$password);
$TODAY = date("Ymd");
$TODAYHOUR = date("YmdHis");
$LANGUAGE = $language;
$ADMINPASS_NOMD5 = $password;

//-----------------------------------------


if (!(is_dir($userdata)))
	{
	mkdir($userdata) or die("<p><span class=Hint><b>ERROR!</b></span> Your base directory must have write permissions for user to proceed");
	}
if (!(is_dir($userdata."/".$thisapp))) 
	{
	mkdir($userdata."/".$thisapp) or die("<p><span class=Hint><b>ERROR!</b></span> Your base directory must have write permissions for user to proceed");
	}

$myprefs = fopen($userdata."/".$thisapp."/"."$INSTALLDIR","w");
$fp = fputs($myprefs,"<?");
$fp = fwrite($myprefs,"\n");
$fp = fwrite($myprefs,"\$thisdb = \"".$mysqldb."\"; ");
$fp = fwrite($myprefs,"\n");
$fp = fputs($myprefs,"?>");
fclose($myprefs);

mkdir($SCRIPTPATH);
	$shell="cp -rfp ". $THISDEPOT ."/* ". $SCRIPTPATH."/";
	system($shell);

	$shell="cp -rfpd ".$SCRIPTPATH."/languages/".$LANGUAGE."/messages.inc.php ". $SCRIPTPATH."/includes/";
	system($shell);

// Copy O.K. Start Config...

$CONFIG_FILE[]=$SCRIPTPATH."/includes/config.inc.php";
$CONFIG_FILE[]=$SCRIPTPATH."/includes/passwd.inc.php";
$CONFIG_FILE[]=$SCRIPTPATH."/phpAdsNew/config.inc.php";
$CONFIG_FILE[]=$SQLDATA;

echo "<p align='left'>";
foreach($CONFIG_FILE AS $FILE){
	if(is_file($FILE)){
		echo "<b>".$FILE."</b> configured<br>";
		$fd = fopen ($FILE, "r");
		$contents = fread ($fd, filesize ($FILE));
		$contents = str_replace("<MYSQLHOST>", $MYSQLHOST, $contents);
		$contents = str_replace("<MYSQLUSER>", $MYSQLUSER, $contents);
		$contents = str_replace("<MYSQLDB>", $MYSQLDB, $contents);
		$contents = str_replace("<MYSQLPASS>", $MYSQLPASS, $contents);		
		$contents = str_replace("<SCRIPTPATH>", $SCRIPTPATH, $contents);
		$contents = str_replace("<USER>", $USER, $contents);
		$contents = str_replace("<DOMAIN>", $DOMAIN, $contents);
		$contents = str_replace("<ADMIN>", $ADMIN, $contents);
		$contents = str_replace("<ADMINPASS>", $ADMINPASS, $contents);
		$contents = str_replace("<ADMINEMAIL>", $ADMINEMAIL, $contents);
		$contents = str_replace("<ADMINPASS_NOMD5>", $ADMINPASS_NOMD5, $contents);
		$contents = str_replace("<SITENAME>", $SITENAME, $contents);
		$contents = str_replace("<SITEURL>", $SITEURL, $contents);
		$contents = str_replace("<MAXUPLOADSIZE>", $MAXUPLOADSIZE, $contents);
		$contents = str_replace("<TODAY>", $TODAY, $contents);
		$contents = str_replace("<TODAYHOUR>", $TODAYHOUR, $contents);
		$contents = str_replace("<LANGUAGE>", $LANGUAGE, $contents);
		$contents = str_replace("<INSTALLDIR>", $INSTALLDIR, $contents);

		fclose ($fd);
		$fd = fopen ($FILE, "w");
		fputs($fd, $contents);
		fclose($fd);
	}else{
echo ++$i.") File:<b> ".$FILE."</b> [<span class='Hint'><i>Error </i></span>]<br>";
	}
}
	$shellsqlimport=$MYSQLPATH. " -h" .$MYSQLHOST. " -u ". $MYSQLUSER ." -p". $MYSQLPASS." ".$MYSQLDB." < $SQLDATA";
	system($shellsqlimport);
?>


<p align="center"><b>Please notice:</b></p>
<p align="left">We only offer auto-installation and auto-configuration of <span class="Emphasize"><?=$humanapp ?></span> but do not offer any kind of support.</p>
<p align="left">You need a username and a password to enter the admin area. Your username is <span class="Hint"><b><?=$ADMIN ?></b></span>. Your password is <span class="Hint"><b><?=$password ?></b></span>. The full URL to the admin area <span class="Hint"><b>(Bookmark this!)</b></span>:
<a href="http://<?=$DOMAIN ?>/<?=$installdir ?>/admin/admin.php" target="blank">http://<?=$DOMAIN ?>/<?=$installdir ?>/admin/admin.php</a></p>
<p align="left">The full URL to this installation of <span class="Emphasize"><?=$humanapp ?></span>: <a href="http://<?=$DOMAIN ?>/<?=$installdir ?>/" target="blank">http://<?=$DOMAIN ?>/<?=$installdir ?>/</a></p>

<cpanel include="includes/fantasticofooter.html">
